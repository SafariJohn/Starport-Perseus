package data.scripts.world.systems;

import campaign.ids.SPP_Conditions;
import campaign.ids.SPP_MemKeys;
import campaign.ids.SPP_Tags;
import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import campaign.procgen.SPP_StarSystemGenerator;
import java.util.ArrayList;
import java.util.List;
import util.SPP_PortFunctions;

public class Westernesse {

	public void generate(SectorAPI sector) {

		StarSystemAPI system = sector.createStarSystem("Westernesse");
		LocationAPI hyper = Global.getSector().getHyperspace();

		system.setBackgroundTextureFilename("graphics/backgrounds/background6.jpg");

		// create the star and generate the hyperspace anchor for this system
		PlanetAPI westernesse_star = system.initStar("westernesse",
				"star_yellow",
				750f,
				500, // extent of corona outside star
				10f, // solar wind burn level
				1f, // flare probability
				3f); // CR loss multiplier, good values are in the range of 1-5

		system.setLightColor(new Color(255, 245, 185)); // light color in entire system, affects all entities

		float radiusAfter1 = SPP_StarSystemGenerator.addOrbitingEntities(system, westernesse_star, StarAge.OLD,
				1, 2, // min/max entities to add
				1800, // radius to start adding at
				0, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
				true,
				true); // whether to use custom or system-name based names

		PlanetAPI horn = system.addPlanet("horn", westernesse_star, "Horn", "rocky_unstable", 90, 225, radiusAfter1 + 1500, 90);
		horn.setCustomDescriptionId("planet_horn");

            MarketAPI market = Global.getFactory().createMarket("horn_market", horn.getName(), 0);
            market.setPlanetConditionMarketOnly(true);
            market.setFactionId(Factions.NEUTRAL);

            market.setSurveyLevel(MarketAPI.SurveyLevel.FULL);
            market.setPrimaryEntity(horn);

//            market.addCondition(SPP_Conditions.MOON_PORT);
//            SPP_PortFunctions.getOrbitalConditions(market).add(SPP_Conditions.MOON_PORT);
//            market.addCondition(Conditions.POPULATION_3);
//            SPP_PortFunctions.getOrbitalConditions(market).add(Conditions.POPULATION_2);
            market.addCondition(Conditions.VERY_HOT);
            market.addCondition(Conditions.NO_ATMOSPHERE);
            market.addCondition(Conditions.TECTONIC_ACTIVITY);
            market.addCondition(SPP_Conditions.CRUSHING_GRAVITY);
            market.addCondition(Conditions.ORE_RICH);
            market.addCondition(Conditions.RARE_ORE_RICH);
//            market.addCondition(SPP_Conditions.CLOSE_MOON); // Moon connected below
//            market.addCondition(SPP_Conditions.TIGHT_MOON);

            horn.setMarket(market);

			PlanetAPI athulf = system.addPlanet("athulf", horn, "Athulf", "rocky_metallic", 30, 65, 575, 24);
			athulf.setCustomDescriptionId("planet_athulf");

//            athulf.getMemoryWithoutUpdate().set(SPP_Tags.MEMKEY_ORBITAL_PLANET_ID, horn.getId());
//            horn.getMemoryWithoutUpdate().set(SPP_Tags.MEMKEY_CLOSE_MOON_ID, athulf.getId());

			PlanetAPI fikenhild = system.addPlanet("fikenhild", horn, "Fikenhild", "water", 270, 85, 850, 34);
			fikenhild.getSpec().setPlanetColor(new Color(240,225,255,255));
			fikenhild.applySpecChanges();
			fikenhild.setCustomDescriptionId("planet_fikenhild");

		//	SectorEntityToken fikenhildStation = system.addCustomEntity("fikenhild_station", "Horn Starport", "station_midline1",  Factions.PERSEAN);
		//	fikenhildStation.setCircularOrbitPointingDown( fikenhild, 0, 150, 30);
		//	fikenhildStation.setInteractionImage("illustrations", "orbital");

		JumpPointAPI jumpPoint1 = Global.getFactory().createJumpPoint("westernesse_jump", "Westernesse Jump-point");
		jumpPoint1.setCircularOrbit( system.getEntityById("westernesse"), 90 + 60, radiusAfter1 + 1500 , 90);
		jumpPoint1.setRelatedPlanet(horn);
		jumpPoint1.setStandardWormholeToHyperspaceVisual();
		system.addEntity(jumpPoint1);

		// Westernesse Relay - L5 (behind)
		SectorEntityToken westernesse_relay = system.addCustomEntity("westernesse_relay", "Westernesse Relay", "comm_relay", "persean");
		westernesse_relay.setCircularOrbitPointingDown( system.getEntityById("westernesse"), 90 - 60, radiusAfter1 + 1500 , 90);

		PlanetAPI suddene = system.addPlanet("suddene", westernesse_star, "Suddene", "barren-desert", 180, 145, radiusAfter1+2600, 210);
		suddene.setCustomDescriptionId("planet_suddene");

		PlanetAPI ailmar = system.addPlanet("ailmar", westernesse_star, "Ailmar", "tundra", 0, 165, radiusAfter1+3300, 390);
		ailmar.setCustomDescriptionId("planet_ailmar");
			PlanetAPI rymenhild = system.addPlanet("rymenhild", ailmar, "Rymenhild", "barren-bombarded", 180, 65, 450, 40);

            // Store Rymenhild's conditions
            List<String> rymenhildConditions = new ArrayList<String>();
            rymenhildConditions.add(Conditions.NO_ATMOSPHERE);
            rymenhildConditions.add(Conditions.VERY_COLD);
            rymenhildConditions.add(Conditions.LOW_GRAVITY);
            rymenhildConditions.add(Conditions.ORE_SPARSE);
            rymenhildConditions.add(Conditions.FARMLAND_POOR);
            rymenhildConditions.add(Conditions.VOLATILES_DIFFUSE);
            SPP_PortFunctions.getOrbitalConditions(rymenhild).add(Conditions.FARMLAND_POOR);
            SPP_PortFunctions.getOrbitalConditions(rymenhild).add(Conditions.VOLATILES_DIFFUSE);
            rymenhildConditions.add(SPP_Conditions.TIGHT_ORBIT);
            rymenhildConditions.add(SPP_Conditions.MOON);
            // And link it with Ailmar
            rymenhild.getMemoryWithoutUpdate().set(SPP_MemKeys.LUNAR_CONDITIONS, rymenhildConditions);
//            rymenhild.getMemoryWithoutUpdate().set(SPP_Tags.MEMKEY_ORBITAL_PLANET_ID, ailmar.getId());
//            ailmar.getMemoryWithoutUpdate().set(SPP_Tags.MEMKEY_CLOSE_MOON_ID, rymenhild.getId());

		SectorEntityToken westernesse_stable2 = system.addCustomEntity(null, null, "nav_buoy_makeshift", Factions.INDEPENDENT);
		westernesse_stable2.setCircularOrbitPointingDown(westernesse_star, -60, radiusAfter1+3300, 390);


		float radiusAfter2 = SPP_StarSystemGenerator.addOrbitingEntities(system, westernesse_star, StarAge.AVERAGE,
					2, 3, // min/max entities to add
					radiusAfter1 + 7600, // radius to start adding at
					4, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
					true,
					true); // whether to use custom or system-name based names

		SPP_StarSystemGenerator.addSystemwideNebula(system, StarAge.OLD);
		system.autogenerateHyperspaceJumpPoints(true, true);
	}
}