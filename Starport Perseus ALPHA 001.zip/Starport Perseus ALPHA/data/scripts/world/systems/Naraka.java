package data.scripts.world.systems;

import campaign.ids.SPP_Conditions;
import campaign.ids.SPP_MemKeys;
import campaign.ids.SPP_Tags;
import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import campaign.procgen.SPP_StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.submarkets.StoragePlugin;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.BaseRingTerrain.RingParams;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import java.util.ArrayList;
import java.util.List;
import util.SPP_PortFunctions;

public class Naraka {

	public void generate(SectorAPI sector) {

		StarSystemAPI system = sector.createStarSystem("Naraka");
		LocationAPI hyper = Global.getSector().getHyperspace();

		system.setBackgroundTextureFilename("graphics/backgrounds/background2.jpg");

		// create the star and generate the hyperspace anchor for this system
		PlanetAPI naraka_star = system.initStar("naraka", // unique id for this star
											    "star_orange",  // id in planets.json
											    650f, 		  // radius (in pixels at default zoom)
											    200, // corona
											    5f, // solar wind burn level
												0.65f, // flare probability
												2.2f); // CR loss multiplier, good values are in the range of 1-5

		system.setLightColor(new Color(255, 220, 200)); // light color in entire system, affects all entities

		SectorEntityToken naraka_stable1 = system.addCustomEntity(null, null, "stable_location", "neutral");
		naraka_stable1.setCircularOrbitPointingDown(naraka_star, 0, 2750, 160);

		system.addRingBand(naraka_star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 3300, 220f, Terrain.RING, "The Yamuna");

		PlanetAPI naraka_b = system.addPlanet("yama", naraka_star, "Yama", "arid", 60, 165, 4600, 140);
		naraka_b.setCustomDescriptionId("planet_yama");
			PlanetAPI naraka_b1 = system.addPlanet("yami", naraka_b, "Yami", "barren-bombarded", 0, 60, 450, 40);

            // Store Yami's conditions
            List<String> yamiConditions = new ArrayList<String>();
            yamiConditions.add(Conditions.NO_ATMOSPHERE);
            yamiConditions.add(Conditions.HOT);
            yamiConditions.add(Conditions.LOW_GRAVITY);
            yamiConditions.add(Conditions.ORE_SPARSE);
            yamiConditions.add(Conditions.FARMLAND_POOR);
            SPP_PortFunctions.getOrbitalConditions(naraka_b1).add(Conditions.FARMLAND_POOR);
            yamiConditions.add(SPP_Conditions.TIGHT_ORBIT);
            yamiConditions.add(SPP_Conditions.MOON);
            // And link it with Gilead
            naraka_b1.getMemoryWithoutUpdate().set(SPP_MemKeys.LUNAR_CONDITIONS, yamiConditions);
            naraka_b1.getMemoryWithoutUpdate().set(SPP_Tags.MEMKEY_ORBITAL_PLANET_ID, naraka_b.getId());
            naraka_b.getMemoryWithoutUpdate().set(SPP_Tags.MEMKEY_CLOSE_MOON_ID, naraka_b1.getId());

		// Yamidutas : asteroids
		system.addAsteroidBelt(naraka_b, 60, 900, 170, 200, 250, Terrain.ASTEROID_BELT, "The Servants");
		system.addRingBand(naraka_b, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 900, 220f);

		PlanetAPI naraka_b2 = system.addPlanet("nachiketa", naraka_star, "Nachiketa", "barren", 60 - 60, 65, 4600, 140);
		naraka_b2.setCustomDescriptionId("planet_nachiketa");
		naraka_b2.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "aurorae"));
		naraka_b2.getSpec().setGlowColor(new Color(255,60,240,200));
		naraka_b2.getSpec().setUseReverseLightForGlow(true);
		naraka_b2.getSpec().setTexture(Global.getSettings().getSpriteName("planets", "barren02"));
		naraka_b2.applySpecChanges();

		// naraka jump-point


		PlanetAPI naraka_c = system.addPlanet("chitagupta", naraka_star, "Chitagupta", "barren", 90, 100, 5750, 380);

		JumpPointAPI jumpPoint1 = Global.getFactory().createJumpPoint("naraka_jump", "Naraka Jump-point");
		jumpPoint1.setCircularOrbit( system.getEntityById("naraka"), 60 + 60, 4600, 140);
		jumpPoint1.setRelatedPlanet(naraka_c);
		system.addEntity(jumpPoint1);

		// Naraka Relay
		SectorEntityToken relay = system.addCustomEntity("naraka_relay", "Naraka Relay", "comm_relay", "hegemony");
		relay.setCircularOrbitPointingDown(system.getEntityById("naraka"), 60 + 180, 4600, 140);

		float radiusAfter = SPP_StarSystemGenerator.addOrbitingEntities(system, naraka_star, StarAge.AVERAGE,
				4, 5, // min/max entities to add
				6500, // radius to start adding at
				3, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
				true,
				true);
				//true); // whether to use custom or system-name based names

		//SPP_StarSystemGenerator.addSystemwideNebula(system, StarAge.OLD);
		system.autogenerateHyperspaceJumpPoints(true, true);
	}
}