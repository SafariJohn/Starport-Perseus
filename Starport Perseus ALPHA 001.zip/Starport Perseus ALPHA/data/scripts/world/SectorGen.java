package data.scripts.world;

import campaign.SPP_CoreCampaignPluginImpl;
import campaign.SPP_CoreScript;
import campaign.fleets.SPP_DisposableLuddicPathFleetManager;
import campaign.fleets.SPP_DisposablePirateFleetManager;
import campaign.fleets.SPP_EconomyFleetRouteManager;
import campaign.fleets.SPP_MercFleetManager;
import campaign.ids.SPP_Factions;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SectorGeneratorPlugin;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.events.CoreEventProbabilityManager;
//import com.fs.starfarer.api.impl.campaign.fleets.MercFleetManagerV2;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;
import com.fs.starfarer.api.util.Misc;

import data.hullmods.HeavyArmor;
import data.scripts.world.corvus.Corvus;
import data.scripts.world.systems.AlGebbar;
import data.scripts.world.systems.Arcadia;
import data.scripts.world.systems.Askonia;
import data.scripts.world.systems.Aztlan;
import data.scripts.world.systems.Canaan;
import data.scripts.world.systems.Duzahk;
import data.scripts.world.systems.Eos;
import data.scripts.world.systems.Galatia;
import data.scripts.world.systems.Hybrasil;
import data.scripts.world.systems.Isirah;
import data.scripts.world.systems.KumariKandam;
import data.scripts.world.systems.Magec;
import data.scripts.world.systems.Mayasura;
import data.scripts.world.systems.Naraka;
import data.scripts.world.systems.Penelope;
import data.scripts.world.systems.Samarra;
import data.scripts.world.systems.Thule;
import data.scripts.world.systems.TiaTaxet;
import data.scripts.world.systems.Tyle;
import data.scripts.world.systems.Valhalla;
import data.scripts.world.systems.Westernesse;
import data.scripts.world.systems.Yma;
import data.scripts.world.systems.Zagan;

public class SectorGen implements SectorGeneratorPlugin {

	public void generate(SectorAPI sector) {
		//ClassLoader cl = Global.getSettings().getScriptClassLoader();

		StarSystemAPI system = sector.createStarSystem("Corvus");
		//system.getLocation().set(16000 - 8000, 9000 - 10000);
		system.setBackgroundTextureFilename("graphics/backgrounds/background4.jpg");

		//sector.setCurrentLocation(system);
		sector.setRespawnLocation(system);
		sector.getRespawnCoordinates().set(-2500, -3500);

		initFactionRelationships(sector);

		new Galatia().generate(sector);
		new Askonia().generate(sector);
		new Eos().generate(sector);
		new Valhalla().generate(sector);
		new Arcadia().generate(sector);
		new Magec().generate(sector);
		new Corvus().generate(sector);
		new Aztlan().generate(sector);
		new Samarra().generate(sector);
		new Penelope().generate(sector);
		new Yma().generate(sector);
		new Hybrasil().generate(sector);
		new Duzahk().generate(sector);
		new TiaTaxet().generate(sector);
		new Canaan().generate(sector);
		new AlGebbar().generate(sector);
		new Isirah().generate(sector);
		new KumariKandam().generate(sector);
		new Naraka().generate(sector);
		new Thule().generate(sector);
		new Mayasura().generate(sector);
		new Zagan().generate(sector);
		new Westernesse().generate(sector);
		new Tyle().generate(sector);

		LocationAPI hyper = Global.getSector().getHyperspace();

		SectorEntityToken abyssLabel = hyper.addCustomEntity("opabyss_label_id", null, "opabyss_label", null);
		SectorEntityToken zinLabel = hyper.addCustomEntity("zin_label_id", null, "zin_label", null);
		abyssLabel.setFixedLocation(-65000, -47000);
		zinLabel.setFixedLocation(-11800, -9400);

		/*SectorEntityToken deep_hyperspace_test = Global.getSector().getHyperspace().addTerrain(Terrain.NEBULA, new BaseTiledTerrain.TileParams(
				"   xx     " +
				"   xxx    " +
				"  xxx x   " +
				"  xx   x  " +
				" xxxx xxx " +
				"  xxxxxxx " +
				" xxxxxxxxx" +
				" xxxxxxxxx" +
				"  xxxxxxx " +
				" xxxxxxx  " +
				" x xxxxx  " +
				"  xxxxxx  " +
				" xxxx xxx " +
				"xxxx  xxx " +
				" xxxx     " +
				"xxxxxxxxx " +
				"  xxxxxxxx" +
				" xxxxxxxxx" +
				"  xxxxxxx " +
				"   xxx    ",
				10, 20, // size of the nebula grid, should match above string
				"terrain", "deep_hyperspace", 4, 4));

		deep_hyperspace_test.getLocation().set(5000,5000);*/


		SectorEntityToken deep_hyperspace = Misc.addNebulaFromPNG("data/campaign/terrain/hyperspace_map.png",
		//SectorEntityToken deep_hyperspace = Misc.addNebulaFromPNG("data/campaign/terrain/hyperspace_map_filled.png",
				  0, 0, // center of nebula
				  Global.getSector().getHyperspace(), // location to add to
				  "terrain", "deep_hyperspace", // "nebula_blue", // texture to use, uses xxx_map for map
				  4, 4, Terrain.HYPERSPACE, null); // number of cells in texture



		// ensure area round stars is clear
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;
		for (StarSystemAPI curr : sector.getStarSystems()) {
			float radius = curr.getMaxRadiusInHyperspace() * 0.5f;
			editor.clearArc(curr.getLocation().x, curr.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
			editor.clearArc(curr.getLocation().x, curr.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
		}



//		PirateSpawnPoint pirateSpawn = new PirateSpawnPoint(sector, sector.getHyperspace(), 1, 15, system.getHyperspaceAnchor());
//		system.addSpawnPoint(pirateSpawn);
//		for (int i = 0; i < 2; i++) {
//			pirateSpawn.spawnFleet();
//		}

		// need to do this after hyperspace terrain exists
		//SectorProcGen.generate();
		// this is done through settings.json, "plugins"->"newGameSectorProcGen"

		sector.registerPlugin(new SPP_CoreCampaignPluginImpl());
		sector.addScript(new SPP_CoreScript());
		sector.addScript(new CoreEventProbabilityManager());

		sector.addScript(new SPP_EconomyFleetRouteManager());
		//sector.addScript(new MercFleetManager());
		sector.addScript(new SPP_MercFleetManager());


		sector.addScript(new SPP_DisposablePirateFleetManager());
		sector.addScript(new SPP_DisposableLuddicPathFleetManager());

//		sector.addScript(new LuddicPathFleetManager());
//		sector.addScript(new PirateFleetManager());
//		sector.addScript(new BountyPirateFleetManager());

	}

	public static void initFactionRelationships(SectorAPI sector) {


		// forget why this is necessary - workaround for some JANINO issue, I think
		Class c = HeavyArmor.class; // Doesn't seem needed anymore, but whatever -SJ

		FactionAPI hegemony = sector.getFaction(Factions.HEGEMONY);
		FactionAPI tritachyon = sector.getFaction(Factions.TRITACHYON);
		FactionAPI pirates = sector.getFaction(Factions.PIRATES);
		FactionAPI independent = sector.getFaction(Factions.INDEPENDENT);
		FactionAPI knights = sector.getFaction(Factions.KOL);
		FactionAPI church = sector.getFaction(Factions.LUDDIC_CHURCH);
		FactionAPI path = sector.getFaction(Factions.LUDDIC_PATH);
		FactionAPI player = sector.getFaction(Factions.PLAYER);
		FactionAPI diktat = sector.getFaction(Factions.DIKTAT);
		FactionAPI persean = sector.getFaction(Factions.PERSEAN);
		FactionAPI remnant = sector.getFaction(Factions.REMNANTS);
		FactionAPI derelict = sector.getFaction(Factions.DERELICT);
		FactionAPI koCombine = sector.getFaction(SPP_Factions.KO_COMBINE);
		FactionAPI blackCompany = sector.getFaction(SPP_Factions.BLACK_COMPANY);
		FactionAPI daredevils = sector.getFaction(SPP_Factions.DAREDEVILS);
		FactionAPI dynasty = sector.getFaction(SPP_Factions.DYNASTY);

		player.setRelationship(hegemony.getId(), 0);
		player.setRelationship(tritachyon.getId(), 0);
		player.setRelationship(persean.getId(), 0);
		//player.setRelationship(pirates.getId(), RepLevel.HOSTILE);
		player.setRelationship(pirates.getId(), -0.65f);

		player.setRelationship(independent.getId(), 0);
		player.setRelationship(knights.getId(), 0);
		player.setRelationship(church.getId(), 0);
		//player.setRelationship(path.getId(), RepLevel.HOSTILE);
		player.setRelationship(path.getId(), -0.65f);

		player.setRelationship(koCombine.getId(), 0);
		player.setRelationship(blackCompany.getId(), 0);
		player.setRelationship(daredevils.getId(), 0);
		player.setRelationship(dynasty.getId(), 0);


		// replaced by hostilities set in CoreLifecyclePluginImpl
		//hegemony.setRelationship(tritachyon.getId(), RepLevel.HOSTILE);
		//hegemony.setRelationship(persean.getId(), RepLevel.HOSTILE);

		hegemony.setRelationship(pirates.getId(), RepLevel.HOSTILE);

		tritachyon.setRelationship(pirates.getId(), RepLevel.HOSTILE);
		//tritachyon.setRelationship(independent.getId(), -1);
		tritachyon.setRelationship(knights.getId(), RepLevel.HOSTILE);
		//tritachyon.setRelationship(church.getId(), RepLevel.HOSTILE);
		tritachyon.setRelationship(path.getId(), RepLevel.HOSTILE);
		tritachyon.setRelationship(persean.getId(), RepLevel.SUSPICIOUS);

		pirates.setRelationship(knights.getId(), RepLevel.HOSTILE);
		pirates.setRelationship(church.getId(), RepLevel.HOSTILE);
		pirates.setRelationship(path.getId(), 0);
		pirates.setRelationship(independent.getId(), RepLevel.HOSTILE);
		pirates.setRelationship(diktat.getId(), RepLevel.HOSTILE);
		pirates.setRelationship(persean.getId(), RepLevel.HOSTILE);
		pirates.setRelationship(koCombine.getId(), RepLevel.HOSTILE);
		pirates.setRelationship(blackCompany.getId(), RepLevel.HOSTILE);

		church.setRelationship(knights.getId(), RepLevel.COOPERATIVE);
		path.setRelationship(knights.getId(), RepLevel.FAVORABLE);

		path.setRelationship(independent.getId(), RepLevel.HOSTILE);
		path.setRelationship(hegemony.getId(), RepLevel.HOSTILE);
		path.setRelationship(diktat.getId(), RepLevel.HOSTILE);
		path.setRelationship(persean.getId(), RepLevel.HOSTILE);
		path.setRelationship(church.getId(), RepLevel.COOPERATIVE);
		path.setRelationship(pirates.getId(), 0);
		path.setRelationship(koCombine.getId(), RepLevel.HOSTILE);
		path.setRelationship(daredevils.getId(), RepLevel.HOSTILE);

		persean.setRelationship(tritachyon.getId(), RepLevel.SUSPICIOUS);
		persean.setRelationship(pirates.getId(), RepLevel.HOSTILE);
		persean.setRelationship(path.getId(), RepLevel.HOSTILE);
		persean.setRelationship(diktat.getId(), RepLevel.COOPERATIVE);

        koCombine.setRelationship(independent.getId(), RepLevel.FRIENDLY);
        koCombine.setRelationship(tritachyon.getId(), RepLevel.HOSTILE);
        koCombine.setRelationship(hegemony.getId(), RepLevel.SUSPICIOUS);
        koCombine.setRelationship(pirates.getId(), RepLevel.INHOSPITABLE);

        blackCompany.setRelationship(hegemony.getId(), RepLevel.FRIENDLY);
        blackCompany.setRelationship(daredevils.getId(), RepLevel.HOSTILE);
        blackCompany.setRelationship(dynasty.getId(), RepLevel.HOSTILE);
        blackCompany.setRelationship(path.getId(), RepLevel.INHOSPITABLE);

        daredevils.setRelationship(tritachyon.getId(), RepLevel.FAVORABLE);
        daredevils.setRelationship(persean.getId(), RepLevel.FAVORABLE);
        daredevils.setRelationship(pirates.getId(), 0);
        daredevils.setRelationship(path.getId(), RepLevel.INHOSPITABLE);
        daredevils.setRelationship(hegemony.getId(), RepLevel.HOSTILE);

        dynasty.setRelationship(pirates.getId(), 0);
        dynasty.setRelationship(path.getId(), RepLevel.INHOSPITABLE);
        dynasty.setRelationship(hegemony.getId(), RepLevel.HOSTILE);

		player.setRelationship(remnant.getId(), RepLevel.HOSTILE);
		independent.setRelationship(remnant.getId(), RepLevel.HOSTILE);
		pirates.setRelationship(remnant.getId(), RepLevel.HOSTILE);
		hegemony.setRelationship(remnant.getId(), RepLevel.HOSTILE);
		knights.setRelationship(remnant.getId(), RepLevel.HOSTILE);
		church.setRelationship(remnant.getId(), RepLevel.HOSTILE);
		path.setRelationship(remnant.getId(), RepLevel.HOSTILE);
		diktat.setRelationship(remnant.getId(), RepLevel.HOSTILE);
		persean.setRelationship(remnant.getId(), RepLevel.HOSTILE);


	}
}