package data.hullmods;

import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import hullmods.SPP_BaseLogisticsHullMod;

@SuppressWarnings("unchecked")
public class HighResSensors extends SPP_BaseLogisticsHullMod {

	public static float BONUS = 60;
	public static float CAPITAL_BONUS = 100;

//	private static Map mag = new HashMap();
//	static {
//		mag.put(HullSize.FRIGATE, 300f);
//		mag.put(HullSize.DESTROYER, 200f);
//		mag.put(HullSize.CRUISER, 100f);
//		mag.put(HullSize.CAPITAL_SHIP, 100f);
//	}

	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		//stats.getSensorStrength().modifyPercent(id, ((Float) mag.get(hullSize)).intValue());
		float bonus = BONUS;
		if (hullSize == HullSize.CAPITAL_SHIP) bonus = CAPITAL_BONUS;
		stats.getSensorStrength().modifyFlat(id, bonus);
	}

	public String getDescriptionParam(int index, HullSize hullSize) {
		if (index == 0) return "" + (int) BONUS;
		if (index == 1) return "" + (int) CAPITAL_BONUS;
//		if (index == 0) return "" + ((Float) mag.get(HullSize.FRIGATE)).intValue();
//		if (index == 1) return "" + ((Float) mag.get(HullSize.DESTROYER)).intValue();
//		if (index == 2) return "" + ((Float) mag.get(HullSize.CRUISER)).intValue();
		//if (index == 3) return "" + ((Float) mag.get(HullSize.CAPITAL_SHIP)).intValue();
		return null;
	}


}
