package scripts.world;

import campaign.procgen.SPP_StarSystemGenerator;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.procgen.AgeGenDataSpec;
import com.fs.starfarer.api.impl.campaign.procgen.Constellation;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator.CustomConstellationParams;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator.GenResult;
import static com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator.MAX_ORBIT_RADIUS;
import static com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator.NEBULA_BLUE;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator.StarSystemType;
import com.fs.starfarer.api.impl.campaign.terrain.StarCoronaTerrainPlugin;
import com.fs.starfarer.api.util.Misc;
import java.util.LinkedHashMap;
import java.util.List;
import org.apache.log4j.Logger;

/**
 * Author: SafariJohn
 */
public class SPP_AtlantianCloudGenerator extends SPP_StarSystemGenerator {
    public static final String CORAL_NEBULA = "Coral";
    public static final String CORAL_NEBULA_CENTER = "SPP_coralNebulaCenter";

    public static final String SERPENTIS = "Serpentis";
    public static final String SERPENTIS_STAR = "SPP_serpentis";

    public static final String ITOS = "Itos";
    public static final String ITOS_STAR = "SPP_itos";

    public SPP_AtlantianCloudGenerator(CustomConstellationParams params) {
        super(params);
        sector = Global.getSector();

        // Override super's stuff
        this.params  = new CustomConstellationParams(StarAge.YOUNG);
        constellationAge = StarAge.YOUNG;
		constellationAgeData = (AgeGenDataSpec) Global.getSettings().getSpec(AgeGenDataSpec.class, constellationAge.name(), true);
        nebulaType = NEBULA_BLUE;

		lagrangeParentMap = new LinkedHashMap<SectorEntityToken, PlanetAPI>();
		allNameableEntitiesAdded = new LinkedHashMap<SectorEntityToken, List<SectorEntityToken>>();
    }

    @Override
    @Deprecated
    /**
     * returns null
     */
    public Constellation generate() {
        return null;
    }

    public StarSystemAPI generateCoralNebula() {
        system = sector.createStarSystem(CORAL_NEBULA);
        system.setType(StarSystemType.NEBULA);
        systemType = StarSystemType.NEBULA;
        system.setBaseName(system.getBaseName());

        createSystem(CORAL_NEBULA_CENTER, true);

        return system;
    }

    public StarSystemAPI generateSerpentis() {
        system = sector.createStarSystem(SERPENTIS);
        system.setType(StarSystemType.SINGLE);
        systemType = StarSystemType.SINGLE;

        createSystem(SERPENTIS_STAR, false);

        return system;
    }

    public StarSystemAPI generateItos() {
        system = sector.createStarSystem(ITOS);
        system.setType(StarSystemType.SINGLE);
        systemType = StarSystemType.SINGLE;

        createSystem(ITOS_STAR, false);

        return system;
    }

    private void createSystem(String starName, boolean isNebula) {
        poisoned = true;
		sector = Global.getSector();
		hyper = Global.getSector().getHyperspace();

		system.setBackgroundTextureFilename("graphics/backgrounds/background5.jpg");

		star = null;
		secondary = null;
		tertiary = null;
		systemCenter = null;

        system.setAge(StarAge.YOUNG);

		if (!addStars(starName)) {
            Logger.getLogger(SPP_AtlantianCloudGenerator.class).fatal("Failed to generate " + starName + "!");
            cleanup();
            return;
        }

		starAge = StarAge.YOUNG;
		starAgeData = (AgeGenDataSpec) Global.getSettings().getSpec(AgeGenDataSpec.class, starAge.name(), true);

		GenResult result = addPlanetsAndTerrain(MAX_ORBIT_RADIUS);


        if (isNebula) star.setSkipForJumpPointAutoGen(true);

		addJumpPoints(result, false);

        if (isNebula) {
            system.removeEntity(star);
            StarCoronaTerrainPlugin coronaPlugin = Misc.getCoronaFor(star);
            if (coronaPlugin != null) {
                system.removeEntity(coronaPlugin.getEntity());
            }
            system.setStar(null);
            systemCenter = system.initNonStarCenter();
            for (SectorEntityToken entity : system.getAllEntities()) {
                if (entity.getOrbitFocus() == star ||
                    entity.getOrbitFocus() == system.getCenter()) {
                    entity.setOrbit(null);
                }
            }
            system.getCenter().addTag(Tags.AMBIENT_LS);
        }

		system.autogenerateHyperspaceJumpPoints(true, false);

        if (isNebula) system.setStar(star);

		addStableLocations();

		addSystemwideNebula();

        poisoned = false;
    }

}
