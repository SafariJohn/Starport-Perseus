package scripts;

import campaign.SPP_MinorMoonNoInteraction;
import campaign.SPP_ImmigrationScript;
import campaign.econ.industries.SPP_Spaceport;
import campaign.ids.SPP_Conditions;
import campaign.ids.SPP_Factions;
import campaign.ids.SPP_Industries;
import campaign.ids.SPP_Tags;
import campaign.intel.SPP_TestingIntel;
import campaign.intel.SPP_SystemControlIntel;
import campaign.procgen.*;
import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.ModSpecAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.characters.ImportantPeopleAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Ranks;
import com.fs.starfarer.api.impl.campaign.procgen.*;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator.CustomConstellationParams;
import com.thoughtworks.xstream.XStream;
import scripts.world.SPP_AtlantianCloudGenerator;
import static scripts.world.SPP_AtlantianCloudGenerator.CORAL_NEBULA;
import static scripts.world.SPP_AtlantianCloudGenerator.ITOS;
import static scripts.world.SPP_AtlantianCloudGenerator.SERPENTIS;
import util.SPP_Misc;
import util.SPP_PortFunctions;

/**
 * Author: SafariJohn
 */
public class SPP_ModPlugin extends BaseModPlugin {
    public static final String CORE_WORLDS_CONSTELLATION = "Core Worlds";
    public static final String LEAGUE_WORLDS_CONSTELLATION = "League Worlds";
    public static final String TELMUN_CLOUD = "Telmun"; // Telmun Molecular Cloud
//    public static final String ZIN_WASTES = "Wastes of Zin";
    public static final String CATHEDRAL_NEBULA = "Cathedral";
    public static final String ATLANTIAN_CLOUD = "Atlantian"; // Atlantian Cloud
    public static final String PILGRIMS_PATH_CONSTELLATION = "Pilgrim's Path";

    @Override
    public void onNewGame() {
//        SPP_MeetingManager meetMan = new SPP_MeetingManager();
//        Global.getSector().getMemoryWithoutUpdate().set(SPP_MemKeys.MEETING_MANAGER, meetMan);

        ProcgenUsedNames.notifyUsed(CORAL_NEBULA);
        ProcgenUsedNames.notifyUsed(SERPENTIS);
        ProcgenUsedNames.notifyUsed(ITOS);

        Global.getSector().registerPlugin(new SPP_MinorMoonNoInteraction());
    }

    @Override
    public void onNewGameAfterEconomyLoad() {
        SectorAPI sector = Global.getSector();
        assignLocationsAndConstellations(sector);
        removeLabels(sector);

        addImmigrationScripts(sector);

//        sector.getEntityById("makal").getMarket().addTag("luddicShrine");

        SPP_CrushingGravityScript.run(sector);
        SPP_MagneticFieldScript.run(sector);
        SPP_MoonScript.run(sector);
        SPP_NativePopsScript.run(sector);
        setAbandonedStationsAndBeacons(sector);

        SPP_Cleanup.run(sector);

        // Init war fleet managers
        for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
            SPP_Misc.getWarFleetRouteManager(market.getStarSystem());
        }

        sector.getFaction(Factions.HEGEMONY).addKnownIndustry(SPP_Industries.DOMAIN_FUEL);
        sector.getFaction(Factions.DIKTAT).addKnownIndustry(SPP_Industries.DOMAIN_FUEL);
//        sector.getFaction(Factions.INDEPENDENT).addKnownIndustry(SPP_Industries.DOMAIN_FUEL);
//        sector.getFaction(Factions.PERSEAN).addKnownIndustry(SPP_Industries.DOMAIN_FUEL);

        // Switch Kanta to Dynasty faction
        ImportantPeopleAPI ip = sector.getImportantPeople();
        for (PersonAPI person : ip.getPeopleWithPost(Ranks.POST_ADMINISTRATOR)) {
            if (person.getName().getFirst().equals("Kanta")) {
                person.setFaction(SPP_Factions.DYNASTY);
                break;
            }
        }
    }

    @Override
    public void onApplicationLoad() throws Exception {
        for (ModSpecAPI spec : Global.getSettings().getModManager().getEnabledModsCopy()) {
            if (spec.getId().equals("starportPerseus")) continue;
            if (spec.getId().equals("starportPerseus_alpha")) continue;

            if (!spec.isUtility()) {
                System.exit(0);
            }
        }

        // Replace static
		PlanetConditionGenerator.generators.put("gravity", new SPP_GravityConditionGenerator());
    }

    /**
     * Fix vanilla system positions and assign to constellations
     */
    private void assignLocationsAndConstellations(SectorAPI sector) {
        Constellation core = new Constellation(Constellation.ConstellationType.NORMAL, StarAge.AVERAGE);
        Constellation league = new Constellation(Constellation.ConstellationType.NORMAL, StarAge.AVERAGE);
        Constellation telmun = new Constellation(Constellation.ConstellationType.NEBULA, StarAge.AVERAGE);
//        Constellation zin = new Constellation(Constellation.ConstellationType.NORMAL, StarAge.OLD);
        Constellation cathedral = new Constellation(Constellation.ConstellationType.NEBULA, StarAge.OLD);
        Constellation atlantian = new Constellation(Constellation.ConstellationType.NEBULA, StarAge.YOUNG);
        Constellation pilgrim = new Constellation(Constellation.ConstellationType.NORMAL, StarAge.AVERAGE);

        core.setNamePick(new ProcgenUsedNames.NamePick(new NameGenData("null", "null"), CORE_WORLDS_CONSTELLATION, null));
        league.setNamePick(new ProcgenUsedNames.NamePick(new NameGenData("null", "null"), LEAGUE_WORLDS_CONSTELLATION, null));
        telmun.setNamePick(new ProcgenUsedNames.NamePick(new NameGenData("null", "null"), TELMUN_CLOUD, null));
//        zin.setNamePick(new ProcgenUsedNames.NamePick(new NameGenData("null", "null"), ZIN_WASTES, null));
        cathedral.setNamePick(new ProcgenUsedNames.NamePick(new NameGenData("null", "null"), CATHEDRAL_NEBULA, null));
        atlantian.setNamePick(new ProcgenUsedNames.NamePick(new NameGenData("null", "null"), ATLANTIAN_CLOUD, null));
        pilgrim.setNamePick(new ProcgenUsedNames.NamePick(new NameGenData("null", "null"), PILGRIMS_PATH_CONSTELLATION, null));

        //<editor-fold defaultstate="collapsed" desc="Core Worlds">
//		"askonia":[-7800,-13500],
        StarSystemAPI system = sector.getStarSystem("Askonia");
        system.getLocation().set(-15450,-13000);
        system.setConstellation(core);
        core.getSystems().add(system);

//		"aztlan":[-7000,-16000],
        system = sector.getStarSystem("Aztlan");
        system.getLocation().set(-20300,-18400);
        system.setConstellation(core);
        core.getSystems().add(system);

//		"duzahk":[-3600,-5300],
        system = sector.getStarSystem("Duzahk");
        system.getLocation().set(-17700,-16500);
        system.setConstellation(core);
        core.getSystems().add(system);

//		"magec":[-6850,-7900],
        system = sector.getStarSystem("Magec");
        system.getLocation().set(-12850,-14700);
        system.setConstellation(core);
        core.getSystems().add(system);

//		"naraka":[-3750,-21000],
        system = sector.getStarSystem("Naraka");
        system.getLocation().set(-23200, -22500);
        system.setConstellation(core);
        core.getSystems().add(system);

//		"samarra":[-10100,-19100],
        system = sector.getStarSystem("Samarra");
        system.getLocation().set(-16100, -19400);
        system.setConstellation(core);
        core.getSystems().add(system);
        //</editor-fold>


        //<editor-fold defaultstate="collapsed" desc="Pilgrim's Path">
//		"algebbar":[-28000,-11500],
        system = sector.getStarSystem("Al Gebbar");
        system.getLocation().set(1100, -16300);
        system.setConstellation(pilgrim);
        pilgrim.getSystems().add(system);

//		"canaan":[-25000,-11300],
        system = sector.getStarSystem("Canaan");
        system.getLocation().set(-850, -18700);
        system.setConstellation(pilgrim);
        pilgrim.getSystems().add(system);

//		"penelope":[-24500,-15000
        system = sector.getStarSystem("Penelope's Star");
        system.getLocation().set(-3800, -21000);
        system.setConstellation(pilgrim);
        pilgrim.getSystems().add(system);
        //</editor-fold>


        //<editor-fold defaultstate="collapsed" desc="Telmun Molecular Cloud">
//		"arcadia":[1600,-9000],
        system = sector.getStarSystem("Arcadia");
        system.getLocation().set(-21800, -8000);
        system.setConstellation(telmun);
        telmun.getSystems().add(system);

//		"thule":[6800,-7800],
        system = sector.getStarSystem("Thule");
        system.getLocation().set(-18500, -6600);
        system.setConstellation(telmun);
        telmun.getSystems().add(system);

//		"valhalla":[-850,-13000],
        system = sector.getStarSystem("Valhalla");
        system.getLocation().set(-21900, -12300);
        system.setConstellation(telmun);
        telmun.getSystems().add(system);

//		"zagan":[4000,-12100],
        system = sector.getStarSystem("Zagan");
        system.getLocation().set(-19300, -10600);
        system.setConstellation(telmun);
        telmun.getSystems().add(system);
        //</editor-fold>


        //<editor-fold defaultstate="collapsed" desc="Cathedral Nebula">
//		"corvus":[-14000,-10000],
        system = sector.getStarSystem("Corvus");
        system.getLocation().set(-8300, -14400);
        system.setConstellation(cathedral);
        cathedral.getSystems().add(system);

//		"eos":[-18500,-8500],
        system = sector.getStarSystem("Eos Exodus");
        system.getLocation().set(-4300, -12600);
        system.setConstellation(cathedral);
        cathedral.getSystems().add(system);

//		"galatia":[-15000,-14500],
        system = sector.getStarSystem("Galatia");
        system.getLocation().set(-8800, -18250);
        system.setConstellation(cathedral);
        cathedral.getSystems().add(system);

//		"isirah":[-22000,-3000],
        system = sector.getStarSystem("Isirah");
        system.getLocation().set(-7350, -10950);
        system.setConstellation(cathedral);
        cathedral.getSystems().add(system);

//		"westernesse":[-18000,-600],
        system = sector.getStarSystem("Westernesse");
        system.getLocation().set(-2300, -10000);
        system.setConstellation(cathedral);
        cathedral.getSystems().add(system);
        //</editor-fold>


        //<editor-fold defaultstate="collapsed" desc="Atlantian Cloud">
        CustomConstellationParams params = new CustomConstellationParams(StarAge.YOUNG);
        SPP_AtlantianCloudGenerator gen = new SPP_AtlantianCloudGenerator(params);
//		"coralNebula":[-4900,13400],
        system = gen.generateCoralNebula();
        system.getLocation().set(-4500, 1000);
        system.setConstellation(atlantian);
        atlantian.getSystems().add(system);

//		"hybrasil":[7400,13300],
        system = sector.getStarSystem("Hybrasil");
        system.getLocation().set(0, 0);
        system.setConstellation(atlantian);
        atlantian.getSystems().add(system);

//		"itos":[2200,14300],
        system = gen.generateItos();
        system.getLocation().set(2700, 2000);
        system.setConstellation(atlantian);
        atlantian.getSystems().add(system);

//		"serpentis":[2700,10300],
        system = gen.generateSerpentis();
        system.getLocation().set(3200, -2000);
        system.setConstellation(atlantian);
        atlantian.getSystems().add(system);

        atlantian.setLagrangeParentMap(gen.getLagrangeParentMap());
		atlantian.setAllEntitiesAdded(gen.getAllEntitiesAdded());
		atlantian.setLeavePickedNameUnused(true);
		NameAssigner namer = new NameAssigner(atlantian);
        namer.setSpecialNamesProbability(1f);
		namer.setRenameSystem(false);
		namer.assignNames(ATLANTIAN_CLOUD, null);

		for (SectorEntityToken entity : atlantian.getAllEntitiesAdded().keySet()) {
			if (entity instanceof PlanetAPI && entity.getMarket() != null) {
				entity.getMarket().setName(entity.getName());
			}
		}
        //</editor-fold>


        //<editor-fold defaultstate="collapsed" desc="League Worlds">
//		"kumarikandam":[-16000,-4500],
        system = sector.getStarSystem("Kumari Kandam");
        system.getLocation().set(-8800, -6000);
        system.setConstellation(league);
        league.getSystems().add(system);

//		"mayasura":[-3100,2700],
        system = sector.getStarSystem("Mayasura");
        system.getLocation().set(-5750, -5300);
        system.setConstellation(league);
        league.getSystems().add(system);

//		"tia":[2000,5000],
        system = sector.getStarSystem("Tia");
        system.getLocation().set(-12400, -1600);
        system.setConstellation(league);
        league.getSystems().add(system);

//		"tyle":[-8700,3600],
        system = sector.getStarSystem("Tyle");
        system.getLocation().set(-15000, -3200);
        system.setConstellation(league);
        league.getSystems().add(system);

//		"yma":[2400,750],
        system = sector.getStarSystem("Yma");
        system.getLocation().set(-12200, -4350);
        system.setConstellation(league);
        league.getSystems().add(system);
        //</editor-fold>

        Global.getSector().getHyperspace().updateAllOrbits();
    }

    @Override
    public void onNewGameAfterTimePass() {
        for (StarSystemAPI system : Global.getSector().getStarSystems()) {
            Global.getSector().getIntelManager().addIntel(new SPP_SystemControlIntel(system));
        }

        Global.getSector().getIntelManager().addIntel(new SPP_TestingIntel());
    }

    //<editor-fold defaultstate="collapsed" desc="Other New Game methods">
    private void removeLabels(SectorAPI sector) {
		LocationAPI hyper = sector.getHyperspace();
		hyper.removeEntity(hyper.getEntityById("atlantic_label_id"));
		hyper.removeEntity(hyper.getEntityById("luddic_label_id"));
//		hyper.removeEntity(hyper.getEntityById("zin_label_id"));
		hyper.removeEntity(hyper.getEntityById("persean_label_id"));
		hyper.removeEntity(hyper.getEntityById("telmun_label_id"));
		hyper.removeEntity(hyper.getEntityById("cathedral_label_id"));
		hyper.removeEntity(hyper.getEntityById("core_label_id"));
    }

    private void addImmigrationScripts(SectorAPI sector) {
        for (MarketAPI market : sector.getEconomy().getMarketsCopy()) {
            if (!market.getMemory().contains(SPP_ImmigrationScript.MEM_KEY)) {
                SPP_ImmigrationScript script = new SPP_ImmigrationScript(market);
                market.getMemoryWithoutUpdate().set(SPP_ImmigrationScript.MEM_KEY, script);
                market.getContainingLocation().addScript(script);
            }
        }
    }

    private void setAbandonedStationsAndBeacons(SectorAPI sector) {
        // Skyhook in Al Gebbar
        StarSystemAPI system = sector.getStarSystem("Al Gebbar");

        SectorEntityToken planet = system.getEntityById("gebbar5");
        addToConditionMarket(planet, SPP_Conditions.ABANDONED_STATION);

        SectorEntityToken orbital = system.getEntityById("abandoned_station");
        orbital.getMemoryWithoutUpdate().set(SPP_Tags.MEMKEY_ORBITAL_PLANET_ID, planet.getId());
//        planet.getMemoryWithoutUpdate().set(SPP_Tags.MEMKEY_ORBITAL_ENTITY_ID, orbital.getId());

        // Terraforming platform in Corvus
        system = sector.getStarSystem("Corvus");

        planet = system.getEntityById("asharu");
        addToConditionMarket(planet, SPP_Conditions.ABANDONED_STATION);

        orbital = system.getEntityById("corvus_abandoned_station");
        orbital.getMemoryWithoutUpdate().set(SPP_Tags.MEMKEY_ORBITAL_PLANET_ID, planet.getId());
//        planet.getMemoryWithoutUpdate().set(SPP_Tags.MEMKEY_ORBITAL_ENTITY_ID, orbital.getId());

        // Sporeship in Penelope's Star
        system = sector.getStarSystem("Penelope's Star");

        planet = system.getEntityById("penelope5");
        addToConditionMarket(planet, SPP_Conditions.ABANDONED_STATION);

        orbital = system.getEntityById("telepylus_station");
        orbital.getMemoryWithoutUpdate().set(SPP_Tags.MEMKEY_ORBITAL_PLANET_ID, planet.getId());
//        planet.getMemoryWithoutUpdate().set(SPP_Tags.MEMKEY_ORBITAL_ENTITY_ID, orbital.getId());

        // Astropolis over Mairaath
        system = sector.getStarSystem("Mayasura");

        planet = system.getEntityById("mairaath");
        addToConditionMarket(planet, SPP_Conditions.ABANDONED_STATION);

        orbital = system.getEntityById("mairaath_abandoned_station1");
        orbital.getMemoryWithoutUpdate().set(SPP_Tags.MEMKEY_ORBITAL_PLANET_ID, planet.getId());
//        planet.getMemoryWithoutUpdate().set(SPP_Tags.MEMKEY_ORBITAL_ENTITY_ID, orbital.getId());

        // Siphon platform in Yma
        system = sector.getStarSystem("Yma");

        planet = system.getEntityById("chupi_orco");
        addToConditionMarket(planet, SPP_Conditions.ABANDONED_STATION);
        if (SPP_PortFunctions.getVolatiles(planet.getMarket()) < 0) {
            planet.getMarket().addCondition(Conditions.VOLATILES_DIFFUSE);
        }

        orbital = system.getEntityById("yma_abandoned_station");
        orbital.getMemoryWithoutUpdate().set(SPP_Tags.MEMKEY_ORBITAL_PLANET_ID, planet.getId());
//        planet.getMemoryWithoutUpdate().set(SPP_Tags.MEMKEY_ORBITAL_ENTITY_ID, orbital.getId());


        // Warning beacon in Eos
        system = sector.getStarSystem("Eos Exodus");

        planet = system.getEntityById("daedaleon");
        addToConditionMarket(planet, SPP_Conditions.WARNING_BEACON);

        orbital = system.getEntityById("eos_warning_beacon");
        orbital.getMemoryWithoutUpdate().set(SPP_Tags.MEMKEY_ORBITAL_PLANET_ID, planet.getId());
//        planet.getMemoryWithoutUpdate().set(SPP_Tags.MEMKEY_ORBITAL_ENTITY_ID, orbital.getId());
    }

    private void addToConditionMarket(SectorEntityToken entity, String condition) {
        if (entity instanceof PlanetAPI) {
            addToConditionMarket((PlanetAPI) entity, condition);
            return;
        }

        MarketAPI market = entity.getMarket();
        if (market == null) {
            market = Global.getFactory().createMarket("SPP_market_" + entity.getId(), entity.getName(), 1);
            market.setPrimaryEntity(entity);
            market.setFactionId(Factions.NEUTRAL);
            market.setPlanetConditionMarketOnly(true);
            entity.setMarket(market);
        }

        market.addCondition(condition);
    }

    private void addToConditionMarket(PlanetAPI planet, String condition) {
        MarketAPI market = planet.getMarket();
        if (market == null) market = SPP_Misc.createPlanetConditionMarket(planet);

        market.addCondition(condition);
    }
    //</editor-fold>

    @Override
    public void configureXStream(XStream x) {
		x.alias("Spaceport", SPP_Spaceport.class);
    }

}
