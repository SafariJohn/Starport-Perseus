package util;

import campaign.SPP_ImmigrationScript;
import campaign.SPP_ImmigrationScript.PopLimitModifier;
import campaign.SPP_PortDevelopmentPluginImpl;
import campaign.fleets.SPP_SystemWarFleetRouteManager;
import campaign.fleets.SPP_WarFleetRouteSource;
import campaign.ids.SPP_MemKeys;
import campaign.ids.SPP_Tags;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.ImmigrationPlugin;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.procgen.PlanetConditionGenerator;
import com.fs.starfarer.api.util.Misc;
import java.util.*;
import org.json.JSONObject;

/**
 * Author: SafariJohn
 */
public class SPP_Misc extends Misc {
    public static MarketAPI createPlanetConditionMarket(PlanetAPI planet) {
        MarketAPI market = Global.getFactory().createMarket("SPP_market_" + planet.getId(), planet.getName(), 1);
        market.setPlanetConditionMarketOnly(true);
        market.setPrimaryEntity(planet);
        market.setFactionId(Factions.NEUTRAL);
        planet.setMarket(market);
//        if (true) return null;

        PlanetConditionGenerator.generateConditionsForPlanet(planet, planet.getStarSystem().getAge());

        return planet.getMarket();
    }

    public static float getPortSizeProgress(MarketAPI market) {
        return getMarketSizeProgress(market);
    }

	public static float getMarketSizeProgress(MarketAPI market) {
		ImmigrationPlugin plugin = getImmigrationPlugin(market);
		float min = plugin.getWeightForMarketSize(market.getSize());
		float max = plugin.getWeightForMarketSize(market.getSize() + 1);

		float curr = market.getPopulation().getWeightValue();

		if (max <= min) return 0f;

		float f = (curr - min) / (max - min);
		if (f < 0) f = 0;
		if (f > 1) f = 1;
		return f;
	}

	public static ImmigrationPlugin getImmigrationPlugin(MarketAPI market) {
		ImmigrationPlugin plugin = Global.getSector().getPluginPicker().pickImmigrationPlugin(market);
		if (plugin == null) {
			plugin = new SPP_PortDevelopmentPluginImpl(market);
		}
		return plugin;
	}

	public static SPP_ImmigrationScript getPopImmigrationPlugin(MarketAPI market) {
		SPP_ImmigrationScript script = (SPP_ImmigrationScript) market.getMemoryWithoutUpdate().get(SPP_ImmigrationScript.MEM_KEY);
        if (script == null) {
            if (market.getContainingLocation() == null) return null;
            script = new SPP_ImmigrationScript(market);
            market.getMemoryWithoutUpdate().set(SPP_ImmigrationScript.MEM_KEY, script);
            market.getContainingLocation().addScript(script);
        }
		return script;
	}

    public static Map<String, PopLimitModifier> getPopulationLimitModifiers(MarketAPI market) {
        MemoryAPI mem = market.getMemoryWithoutUpdate();
        Map<String, PopLimitModifier> mods = (Map<String, PopLimitModifier>) mem.get(SPP_ImmigrationScript.POP_LIMIT_MODS);

        if (mods == null) {
            mods = new LinkedHashMap<String, PopLimitModifier>();
            mem.set(SPP_ImmigrationScript.POP_LIMIT_MODS, mods);
        }

        return mods;
    }

    public static int getPopulationLimit(MarketAPI market) {
        Map<String, PopLimitModifier> mods;
        mods = (Map<String, PopLimitModifier>) market.getMemoryWithoutUpdate().get(SPP_ImmigrationScript.POP_LIMIT_MODS);

        if (mods == null) return 0;

        int limit = 0;
        int pop = SPP_PortFunctions.getPopulationSize(market);
        for (String key : mods.keySet()) {
            PopLimitModifier mod = mods.get(key);
            if (pop > mod.scale) continue;

            limit += mod.mod;
        }

        return limit;
    }

    public static int getPopulationGrowth(MarketAPI market) {
        Map<String, PopLimitModifier> mods;
        mods = (Map<String, PopLimitModifier>) market.getMemoryWithoutUpdate().get(SPP_ImmigrationScript.POP_LIMIT_MODS);

        if (mods == null) return 0;

        int growth = 0;
        int limit = 0;
        int pop = SPP_PortFunctions.getPopulationSize(market);
        for (String key : mods.keySet()) {
            PopLimitModifier mod = mods.get(key);
            if (pop > mod.scale) continue;

            growth += mod.growth;
            limit += mod.mod;
        }

        if (pop >= limit) return 0;

        return growth;
    }

    public static float getPopulationSizeProgress(MarketAPI market) {
//        if (!market.getMemoryWithoutUpdate().getBoolean(SPP_Tags.MEMKEY_POP_GROWTH)) return 0;

		SPP_ImmigrationScript script = getPopImmigrationPlugin(market);

		float min = script.getWeightForPopulationSize(SPP_PortFunctions.getPopulationSize(market));
		float max = script.getWeightForPopulationSize(1 + SPP_PortFunctions.getPopulationSize(market));

		float curr = script.getPop().getWeightValue();

		if (max <= min) return 0f;

		float f = (curr - min) / (max - min);
		if (f < 0) f = 0;
		if (f > 1) f = 1;
		return f;
    }

	public static void setAbandonedStationMarket(String marketId, SectorEntityToken station) {
//		station.getMemoryWithoutUpdate().set("$abandonedStation", true);
//		MarketAPI market = Global.getFactory().createMarket(marketId, station.getName(), 0);
//		market.setSurveyLevel(MarketAPI.SurveyLevel.FULL);
//		market.setPrimaryEntity(station);
//		market.setFactionId(station.getFaction().getId());
////		market.addCondition(Conditions.ABANDONED_STATION);
////		market.addSubmarket(Submarkets.SUBMARKET_STORAGE);
//		market.setPlanetConditionMarketOnly(false);
//		((StoragePlugin)market.getSubmarket(Submarkets.SUBMARKET_STORAGE).getPlugin()).setPlayerPaidToUnlock(true);
		station.setMarket(null);
		station.getMemoryWithoutUpdate().unset("$tradeMode");
	}

    public static SPP_SystemWarFleetRouteManager getWarFleetRouteManager(StarSystemAPI system) {
        SPP_SystemWarFleetRouteManager manager = (SPP_SystemWarFleetRouteManager) system
                    .getMemoryWithoutUpdate().get(SPP_MemKeys.SYSTEM_WAR_FLEET_MANAGER);
        if (manager == null) {
            manager = new SPP_SystemWarFleetRouteManager(system);
            system.addScript(manager);
            system.getMemoryWithoutUpdate().set(SPP_MemKeys.SYSTEM_WAR_FLEET_MANAGER, manager);
        }

        return manager;
    }

    public static List<SPP_WarFleetRouteSource> getFactionWarFleetSources(FactionAPI faction) {
        MemoryAPI memory = faction.getMemoryWithoutUpdate();
        List<SPP_WarFleetRouteSource> sources = (List) memory.get(SPP_MemKeys.FACTION_WAR_FLEET_SOURCES);

        if (sources == null) {
            sources = new ArrayList<>();
            memory.set(SPP_MemKeys.FACTION_WAR_FLEET_SOURCES, sources);
        }

        return sources;
    }

    public static Map<String, String> getFactionWarFleetBonusFleets(FactionAPI faction) {
        MemoryAPI memory = faction.getMemoryWithoutUpdate();
        Map<String, String> bonusFleets = (Map) memory.get(SPP_MemKeys.FACTION_WAR_FLEET_BONUS_FLEETS);

        if (bonusFleets == null) {
            bonusFleets = new HashMap<>();
            memory.set(SPP_MemKeys.FACTION_WAR_FLEET_BONUS_FLEETS, bonusFleets);
        }

        return bonusFleets;
    }

    public static PlanetAPI getParent(SectorEntityToken entity) {
        String parentId = (String) entity.getMemoryWithoutUpdate().getString(SPP_Tags.MEMKEY_ORBITAL_PLANET_ID);
        if (parentId == null) parentId = "";
        PlanetAPI parent = (PlanetAPI) entity.getContainingLocation().getEntityById(parentId);

        return parent;
    }

    public static PlanetAPI getMoon(SectorEntityToken entity) {
        String moonId = (String) entity.getMemoryWithoutUpdate().getString(SPP_Tags.MEMKEY_CLOSE_MOON_ID);
        if (moonId == null) moonId = "";
        PlanetAPI moon = (PlanetAPI) entity.getContainingLocation().getEntityById(moonId);

        return moon;
    }

    public static PlanetAPI getMoonOrParent(SectorEntityToken entity) {
        String otherId = (String) entity.getMemoryWithoutUpdate().getString(SPP_Tags.MEMKEY_CLOSE_MOON_ID);
        if (otherId == null) otherId = (String) entity.getMemoryWithoutUpdate().getString(SPP_Tags.MEMKEY_ORBITAL_PLANET_ID);
        if (otherId == null) otherId = "";
        PlanetAPI other = (PlanetAPI) entity.getContainingLocation().getEntityById(otherId);

        return other;
    }

    public static SectorEntityToken getOther(SectorEntityToken entity) {
        String otherId = (String) entity.getMemoryWithoutUpdate().getString(SPP_Tags.MEMKEY_CLOSE_MOON_ID);
        if (otherId == null) otherId = (String) entity.getMemoryWithoutUpdate().getString(SPP_Tags.MEMKEY_ORBITAL_PLANET_ID);
        if (otherId == null) otherId = (String) entity.getMemoryWithoutUpdate().getString(SPP_Tags.MEMKEY_ORBITAL_STATION_ID);
        if (otherId == null) otherId = "";
        SectorEntityToken other = entity.getContainingLocation().getEntityById(otherId);

        return other;
    }

    public static SectorEntityToken getStation(SectorEntityToken entity) {
        String stationId = (String) entity.getMemoryWithoutUpdate().getString(SPP_Tags.MEMKEY_ORBITAL_STATION_ID);
        if (stationId == null) stationId = "";
        SectorEntityToken station = entity.getContainingLocation().getEntityById(stationId);

        return station;
    }

    public static List<FactionAPI> getSystemClaimants(StarSystemAPI system) {
        List<FactionAPI> claimants = new ArrayList<>();

        FactionAPI claimant = getClaimingFaction(system.getCenter());

        if (claimant != null) claimants.add(claimant);

        if (claimant == null) {
            for (MarketAPI port : Global.getSector().getEconomy().getMarkets(system)) {
                if (port.getFactionId().equals(Factions.PLAYER)) {
                    claimants.add(Global.getSector().getPlayerFaction());
                }
            }
        }

        return claimants;
    }
}
