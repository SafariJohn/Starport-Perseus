package util;

import campaign.SPP_ImmigrationScript;
import campaign.SPP_ImmigrationScript.PopLimitModifier;
import campaign.econ.SPP_OrbitalBlockCondition;
import campaign.econ.SPP_OrbitalTempBlockCondition;
import campaign.econ.SPP_PlanetBlockCondition;
import campaign.econ.SPP_PlanetTempBlockCondition;
import campaign.econ.industries.SPP_CommandBase;
import campaign.ids.SPP_Conditions;
import campaign.ids.SPP_MemKeys;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.ImmigrationPlugin;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import java.util.*;

/**
 * Author: SafariJohn
 */
public class SPP_PortFunctions {

    public static int getPopulationSize(MarketAPI market) {
        if (market.hasCondition(SPP_Conditions.POPULATION_0)) return 0;
        if (market.hasCondition(Conditions.POPULATION_1)) return 1;
        if (market.hasCondition(Conditions.POPULATION_2)) return 2;
        if (market.hasCondition(Conditions.POPULATION_3)) return 3;
        if (market.hasCondition(Conditions.POPULATION_4)) return 4;
        if (market.hasCondition(Conditions.POPULATION_5)) return 5;
        if (market.hasCondition(Conditions.POPULATION_6)) return 6;
        if (market.hasCondition(Conditions.POPULATION_7)) return 7;
        if (market.hasCondition(Conditions.POPULATION_8)) return 8;
        if (market.hasCondition(Conditions.POPULATION_9)) return 9;
        if (market.hasCondition(Conditions.POPULATION_10)) return 10;

        return -1;
    }

    public static String getPopulationConditionId(MarketAPI market) {
        return getPopulationConditionId(getPopulationSize(market));
    }

    public static String getPopulationConditionId(int size) {
        if (size <= 0) return SPP_Conditions.POPULATION_0;
        if (size > 10) size = 10;

        return "population_" + size;
    }

    /**
     * Used for raw resource production. Based on population, but capped by port size
     * to prevent a new port from having a huge impact.
     * @param market
     * @return Population size, capped by port commodity size + 3
     */
    public static int getPopulationCommoditySize(MarketAPI market) {
//        return getPopulationSize(market);
        return Math.min(getPopulationSize(market), getPortCommoditySize(market.getSize()) + 3);
    }

    public static int getPortCommoditySize(int marketSize) {
//        switch (marketSize) {
//            case 1: return 1;
//            case 2: return 2;
//            case 3: return 4;
//            case 4: return 5;
//            case 5:
//            case 6: return 6;
//            case 7:
//            case 8: return 7;
//            case 9:
//            case 10: return 8;
//            default: return marketSize;
//        }
        switch (marketSize) {
            case 1: return 1;
            case 2: return 2;
            case 3: return 3;
            case 4:
            case 5: return 4;
            case 6: return 5;
            case 7:
            case 8: return 6;
            case 9:
            case 10: return 7;
            default: return marketSize;
        }
    }

	public static Map<String, Integer> getPlanetBuildCost(PlanetAPI planet) {
		Map<String, Integer> result = new LinkedHashMap<String, Integer>();

        SectorEntityToken orbital = SPP_Misc.getStation(planet);

        if (orbital == null || orbital.getMarket() == null
                    || orbital.getMarket().getFaction().isNeutralFaction()) {
            result.put(Commodities.CREW, 500);
            result.put(Commodities.HEAVY_MACHINERY, 100);
            result.put(Commodities.SUPPLIES, 200);
            result.put(Commodities.HAND_WEAPONS, 100);
        } else {
            int size = orbital.getMarket().getSize();
            size--;
            result.put(Commodities.CREW, 500 * size);
            result.put(Commodities.HEAVY_MACHINERY, 100 * size);
            result.put(Commodities.SUPPLIES, 200 * size);
            size++;
            result.put(Commodities.HAND_WEAPONS, 100 * size);
        }

		return result;

	}

	public static Map<String, Integer> getStationBuildCost(MarketAPI market) {
		Map<String, Integer> result = new LinkedHashMap<String, Integer>();

		result.put(Commodities.CREW, 500);
		result.put(Commodities.HEAVY_MACHINERY, 100);
		result.put(Commodities.SUPPLIES, 200);
		result.put(Commodities.METALS, 1000);

		return result;
	}

    public static Set<String> getOrbitalConditions(MarketAPI market) {
        if (market.getPrimaryEntity() == null) return new HashSet<>();

        return getOrbitalConditions(market.getPrimaryEntity());
    }

    public static Set<String> getOrbitalConditions(SectorEntityToken entity) {
        Set<String> conditions = (Set) entity.getMemoryWithoutUpdate().get(SPP_MemKeys.ORBITAL_CONDITIONS);
        if (conditions == null) {
            conditions = new HashSet<>();
            entity.getMemoryWithoutUpdate().set(SPP_MemKeys.ORBITAL_CONDITIONS, conditions);
        }

        return conditions;
    }

    public static boolean factionHasCommandBase(FactionAPI faction) {
        for (MarketAPI m : Global.getSector().getEconomy().getMarketsCopy()) {
            if (m.getFaction() != faction) {
                continue;
            }
            for (Industry mc : m.getIndustries()) {
                if (mc instanceof SPP_CommandBase) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Currently does nothing because the faction name screen is not
     * accessible from the API
     */
    @Deprecated
    public static void establishPlayerFaction(boolean override) {
        if (!override) return;

        Global.getSoundPlayer().playUISound("ui_establish_faction", 1f, 1f);
    }

    public static void playColonyEstablishedSound() {
        Global.getSoundPlayer().playUISound("ui_establish_colony_or_waystation", 1f, 1f);
    }

    public static boolean hasPlanetPortBlock(MarketAPI market) {
        return hasOrbitalPortBlock(market, true);
    }

    public static boolean hasPlanetPortBlock(MarketAPI market, boolean checkTemp) {
        for (MarketConditionAPI cond : market.getConditions()) {
            if (cond.getPlugin() instanceof SPP_PlanetBlockCondition) return true;
        }

        if (!checkTemp) {
            for (MarketConditionAPI cond : market.getConditions()) {
                if (cond.getPlugin() instanceof SPP_PlanetTempBlockCondition) return true;
            }
        }

        return false;
    }

    public static boolean hasOrbitalPortBlock(MarketAPI market) {
        return hasOrbitalPortBlock(market, true);
    }

    public static boolean hasOrbitalPortBlock(MarketAPI market, boolean checkTemp) {
        for (MarketConditionAPI cond : market.getConditions()) {
            if (cond.getPlugin() instanceof SPP_OrbitalBlockCondition) return true;
        }

        if (!checkTemp) {
            for (MarketConditionAPI cond : market.getConditions()) {
                if (cond.getPlugin() instanceof SPP_OrbitalTempBlockCondition) return true;
            }
        }

        return false;
    }

    //<editor-fold defaultstate="collapsed" desc="Resource Conditions as Integers">
    public static int getFood(MarketAPI market) {
//        if (hasAquaculture(market)) return getAquaculture(market);

        int maxFarm = -2;
        if (market.hasCondition(Conditions.FARMLAND_POOR)) maxFarm = -1;
        if (market.hasCondition(Conditions.FARMLAND_ADEQUATE)) maxFarm = 0;
        if (market.hasCondition(Conditions.FARMLAND_RICH)) maxFarm = 1;
        if (market.hasCondition(Conditions.FARMLAND_BOUNTIFUL)) maxFarm = 2;

        return maxFarm;
    }

    public static boolean hasAquaculture(MarketAPI market) {
        return getPopulationSize(market) > 0 && market.hasCondition(Conditions.WATER_SURFACE);
    }

    /**
     * @param market
     * @return -2 for none, 0 for normal, 2 for lobsters
     */
    public static int getAquaculture(MarketAPI market) {
        if (!hasAquaculture(market)) return -2;

        if (market.hasCondition(Conditions.VOLTURNIAN_LOBSTER_PENS)) return 2;
        else return 0;
    }

    public static int getOre(MarketAPI market) {
        int maxOre = -2;
        if (market.hasCondition(Conditions.ORE_SPARSE)) maxOre = -1;
        if (market.hasCondition(Conditions.ORE_MODERATE)) maxOre = 0;
        if (market.hasCondition(Conditions.ORE_ABUNDANT)) maxOre = 1;
        if (market.hasCondition(Conditions.ORE_RICH)) maxOre = 2;
        if (market.hasCondition(Conditions.ORE_ULTRARICH)) maxOre = 3;

        return maxOre;
    }

    public static int getRareOre(MarketAPI market) {
        int maxRare = -2;
        if (market.hasCondition(Conditions.RARE_ORE_SPARSE)) maxRare = -1;
        if (market.hasCondition(Conditions.RARE_ORE_MODERATE)) maxRare = 0;
        if (market.hasCondition(Conditions.RARE_ORE_ABUNDANT)) maxRare = 1;
        if (market.hasCondition(Conditions.RARE_ORE_RICH)) maxRare = 2;
        if (market.hasCondition(Conditions.RARE_ORE_ULTRARICH)) maxRare = 3;

        return maxRare;
    }

    public static int getOrganics(MarketAPI market) {
        int maxDrill = -2;
        if (market.hasCondition(Conditions.ORGANICS_TRACE)) maxDrill = -1;
        if (market.hasCondition(Conditions.ORGANICS_COMMON)) maxDrill = 0;
        if (market.hasCondition(Conditions.ORGANICS_ABUNDANT)) maxDrill = 1;
        if (market.hasCondition(Conditions.ORGANICS_PLENTIFUL)) maxDrill = 2;

        return maxDrill;
    }

    public static int getVolatiles(MarketAPI market) {
        int maxSiphon = -2;
        if (market.hasCondition(Conditions.VOLATILES_TRACE)) maxSiphon = -1;
        if (market.hasCondition(Conditions.VOLATILES_DIFFUSE)) maxSiphon = 0;
        if (market.hasCondition(Conditions.VOLATILES_ABUNDANT)) maxSiphon = 1;
        if (market.hasCondition(Conditions.VOLATILES_PLENTIFUL)) maxSiphon = 2;

        return maxSiphon;
    }

    public static int getRuins(MarketAPI market) {
        int maxRuins = 0;
        if (market.hasCondition(Conditions.RUINS_SCATTERED)) maxRuins = 1;
        if (market.hasCondition(Conditions.RUINS_WIDESPREAD)) maxRuins = 2;
        if (market.hasCondition(Conditions.RUINS_EXTENSIVE)) maxRuins = 3;
        if (market.hasCondition(Conditions.RUINS_VAST)) maxRuins = 4;

        return maxRuins;
    }
    //</editor-fold>

    public static String getResourceCondId(String commodityId, int value) {
        switch (commodityId) {
            case Commodities.FOOD:
                if (value >= 2) return Conditions.FARMLAND_BOUNTIFUL;
                if (value == 1) return Conditions.FARMLAND_RICH;
                if (value == 0) return Conditions.FARMLAND_ADEQUATE;
                if (value == -1) return Conditions.FARMLAND_POOR;
            case Commodities.ORE:
                if (value >= 3) return Conditions.ORE_ULTRARICH;
                if (value == 2) return Conditions.ORE_RICH;
                if (value == 1) return Conditions.ORE_ABUNDANT;
                if (value == 0) return Conditions.ORE_MODERATE;
                if (value == -1) return Conditions.ORE_SPARSE;
            case Commodities.RARE_ORE:
                if (value >= 3) return Conditions.RARE_ORE_ULTRARICH;
                if (value == 2) return Conditions.RARE_ORE_RICH;
                if (value == 1) return Conditions.RARE_ORE_ABUNDANT;
                if (value == 0) return Conditions.RARE_ORE_MODERATE;
                if (value == -1) return Conditions.RARE_ORE_SPARSE;
            case Commodities.ORGANICS:
                if (value >= 2) return Conditions.ORGANICS_PLENTIFUL;
                if (value == 1) return Conditions.ORGANICS_ABUNDANT;
                if (value == 0) return Conditions.ORGANICS_COMMON;
                if (value == -1) return Conditions.ORGANICS_TRACE;
            case Commodities.VOLATILES:
                if (value >= 2) return Conditions.VOLATILES_PLENTIFUL;
                if (value == 1) return Conditions.VOLATILES_ABUNDANT;
                if (value == 0) return Conditions.VOLATILES_DIFFUSE;
                if (value == -1) return Conditions.VOLATILES_TRACE;
        }

        return "";
    }

    //<editor-fold defaultstate="collapsed" desc="Aliases of SPP_Misc methods">
    public static float getPortSizeProgress(MarketAPI market) {
        return SPP_Misc.getPortSizeProgress(market);
    }

    public static float getPopulationSizeProgress(MarketAPI market) {
        return SPP_Misc.getPopulationSizeProgress(market);
    }

    public static int getPopulationLimit(MarketAPI market) {
        return SPP_Misc.getPopulationLimit(market);
    }

    public static Map<String, PopLimitModifier> getPopulationLimitModifiers(MarketAPI market) {
        return SPP_Misc.getPopulationLimitModifiers(market);
    }

    public static ImmigrationPlugin getImmigrationPlugin(MarketAPI market) {
        return SPP_Misc.getImmigrationPlugin(market);
    }

    public static SPP_ImmigrationScript getPopImmigrationPlugin(MarketAPI market) {
        return SPP_Misc.getPopImmigrationPlugin(market);
    }
    //</editor-fold>

}
