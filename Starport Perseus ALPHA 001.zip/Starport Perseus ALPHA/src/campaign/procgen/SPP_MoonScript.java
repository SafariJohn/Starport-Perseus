package campaign.procgen;

import campaign.econ.SPP_Population;
import campaign.econ.SPP_ResourceDepositsCondition;
import campaign.econ.SPP_PlanetBlockCondition;
import campaign.ids.SPP_Conditions;
import campaign.ids.SPP_Planets;
import campaign.ids.SPP_Tags;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;
import com.fs.starfarer.api.impl.campaign.ids.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import util.SPP_PortFunctions;
import util.SPP_Misc;

/**
 * Author: SafariJohn
 */
public class SPP_MoonScript {
    public static final String MOON_COUNT = "$SPP_moonCount";

    public static final float TIGHT_MOON_MAX_DIST = 200f; // When station would be too close
    public static final float CLOSE_MOON_MAX_DIST = 400f; // 400?

    // Resource boosts per world type/category
    // Semi-hardcoded cause lazy
    public static final Map<String, Map> MOON_RESOURCES = new HashMap<>();
    static {
        //<editor-fold defaultstate="collapsed">
        Map<String, Integer> bonuses;

        // cat_giant
        // in the odd case a gas giant could be a moon
        // probably not possible
        bonuses = new HashMap<>();
        MOON_RESOURCES.put(SPP_Planets.CAT_GIANT, bonuses);
        bonuses.put(Commodities.VOLATILES, 2);

        // cat_lava
        bonuses = new HashMap<>();
        MOON_RESOURCES.put(SPP_Planets.CAT_LAVA, bonuses);
        bonuses.put(Commodities.ORE, 2);
        bonuses.put(Commodities.RARE_ORE, 1);

        // Lava minor
        bonuses = new HashMap<>();
        MOON_RESOURCES.put(StarTypes.PLANET_LAVA_MINOR, bonuses);
        bonuses.put(Commodities.ORE, 2);

        // cat_hab5
        bonuses = new HashMap<>();
        MOON_RESOURCES.put(SPP_Planets.CAT_HAB5, bonuses);
        bonuses.put(Commodities.FOOD, 3);
        bonuses.put(Commodities.ORGANICS, 2);

        // cat_hab4
        bonuses = new HashMap<>();
        MOON_RESOURCES.put(SPP_Planets.CAT_HAB4, bonuses);
        bonuses.put(Commodities.FOOD, 2);
        bonuses.put(Commodities.ORGANICS, 1);

        // cat_hab3
        bonuses = new HashMap<>();
        MOON_RESOURCES.put(SPP_Planets.CAT_HAB3, bonuses);
        bonuses.put(Commodities.FOOD, 1);
        bonuses.put(Commodities.ORGANICS, 1);

        // cat_hab2
        bonuses = new HashMap<>();
        MOON_RESOURCES.put(SPP_Planets.CAT_HAB2, bonuses);
        bonuses.put(Commodities.ORGANICS, 2);

        // cat_hab1
        bonuses = new HashMap<>();
        MOON_RESOURCES.put(SPP_Planets.CAT_HAB1, bonuses);
        bonuses.put(Commodities.ORGANICS, 1);

        // cat_frozen
        bonuses = new HashMap<>();
        MOON_RESOURCES.put(SPP_Planets.CAT_FROZEN, bonuses);
        bonuses.put(Commodities.ORE, 1);
        bonuses.put(Commodities.VOLATILES, 1);

        // cat_cryovolcanic
        bonuses = new HashMap<>();
        MOON_RESOURCES.put(SPP_Planets.CAT_CRYO, bonuses);
        bonuses.put(Commodities.ORE, 1);
        bonuses.put(Commodities.VOLATILES, 2);

        // cat_barren
        bonuses = new HashMap<>();
        MOON_RESOURCES.put(SPP_Planets.CAT_BARREN, bonuses);
        bonuses.put(Commodities.ORE, 1);

        // cat_irradiated
        bonuses = new HashMap<>();
        MOON_RESOURCES.put(SPP_Planets.CAT_RAD, bonuses);
        bonuses.put(Commodities.ORE, 1);
        bonuses.put(Commodities.RARE_ORE, 2);

        // cat_toxic
        bonuses = new HashMap<>();
        MOON_RESOURCES.put(SPP_Planets.CAT_TOXIC, bonuses);
        bonuses.put(Commodities.VOLATILES, 1);
//</editor-fold>
    }



    public static void run(SectorAPI sector) {
        List<StarSystemAPI> systems = sector.getStarSystems();
        List<PlanetAPI> planets = new ArrayList<>();
        for (StarSystemAPI system : systems) {
            planets.addAll(system.getPlanets());
        }

        // Loop to mark moons and apply minor moon effects
        for (PlanetAPI planet : planets) {
            SectorEntityToken focus = planet.getOrbitFocus();
            if (focus == null || focus.isStar() || focus.isSystemCenter()) continue;

            MarketAPI market = planet.getMarket();
            if (market == null) market = SPP_Misc.createPlanetConditionMarket(planet);

            if (!market.getFaction().isNeutralFaction()) continue;

            MarketAPI fMarket = focus.getMarket();
            boolean fMNull = false;
            if (fMarket == null) {
                fMNull = true;
                fMarket = Global.getFactory().createMarket("SPP_market_" + focus.getId(), focus.getName(), 1);
                fMarket.setPrimaryEntity(focus);
                fMarket.setFactionId(Factions.NEUTRAL);
                fMarket.setPlanetConditionMarketOnly(true);
                focus.setMarket(fMarket);
            }

            if (!fMarket.getFaction().isNeutralFaction()) continue;

            if (focus instanceof PlanetAPI) {
                if (fMNull) fMarket = SPP_Misc.createPlanetConditionMarket((PlanetAPI) focus);

                float dist = SPP_Misc.getDistance(planet, focus);
                if (dist - (focus.getRadius() + planet.getRadius()) <= TIGHT_MOON_MAX_DIST * (1 - planet.getRadius() / focus.getRadius())) {
                    // If the planet can't have a port at all,
                    // then the tight moon can have a port
                    if (SPP_PortFunctions.hasPlanetPortBlock(fMarket)
                                && SPP_PortFunctions.hasOrbitalPortBlock(fMarket)) {
                        String token = market.addCondition(SPP_Conditions.MOON);
                        market.getSpecificCondition(token).setSurveyed(true);
                    } else {
                        attachMinorMoon(planet, fMarket);
                    }

                    //<editor-fold defaultstate="collapsed" desc="old">
//                    // Add conditions
//                    String token = fMarket.addCondition(SPP_Conditions.CLOSE_MOON);
//                    fMarket.getSpecificCondition(token).setSurveyed(true);
//                    token = fMarket.addCondition(SPP_Conditions.TIGHT_MOON);
//                    fMarket.getSpecificCondition(token).setSurveyed(true);
//
//                    token = market.addCondition(SPP_Conditions.TIGHT_ORBIT);
//                    market.getSpecificCondition(token).setSurveyed(true);
//                    token = market.addCondition(SPP_Conditions.MOON);
//                    market.getSpecificCondition(token).setSurveyed(true);
//
//                    // Set memory
//                    focus.getMemoryWithoutUpdate().set(SPP_Tags.MEMKEY_CLOSE_MOON_ID, planet.getId());
//                    planet.getMemoryWithoutUpdate().set(SPP_Tags.MEMKEY_ORBITAL_PLANET_ID, focus.getId());
//
//                    // Share resources and ruins
//                    shareResourcesAndRuins(fMarket, market);
                    //</editor-fold>
                } else if (dist - (focus.getRadius() + planet.getRadius()) <= CLOSE_MOON_MAX_DIST * (1 - planet.getRadius() / focus.getRadius())) {
                    // If there can't be a planet port on the parent,
                    // or the parent can't have a port at all
                    // or the parent already has 1 or more minor moons
                    // then the close moon can have a port
                    if (SPP_PortFunctions.hasPlanetPortBlock(fMarket)
                                || (SPP_PortFunctions.hasPlanetPortBlock(fMarket)
                                && SPP_PortFunctions.hasOrbitalPortBlock(fMarket))
                                || fMarket.hasCondition(SPP_Conditions.TIGHT_MOON)) {
                        String token = market.addCondition(SPP_Conditions.MOON);
                        market.getSpecificCondition(token).setSurveyed(true);
                    } else {
                        attachMinorMoon(planet, fMarket);
                    }

                } else {
                    String token = market.addCondition(SPP_Conditions.MOON);
                    market.getSpecificCondition(token).setSurveyed(true);
                }


                // Count moons
                int moonCount = 0;
                boolean isNull = focus.getMemoryWithoutUpdate().get(MOON_COUNT) == null;
                if (!isNull) moonCount = (int) focus.getMemoryWithoutUpdate().get(MOON_COUNT);
                // Exception for Balar in Hybrasil since it has an inhabited moon
                if (focus.getId().equals("balar") && moonCount == 0) {
                    moonCount = 1;
                }

                moonCount++;

                focus.getMemoryWithoutUpdate().set(MOON_COUNT, moonCount);

                // Add stationBlock condition
                if (moonCount == 4) {
                    fMarket.addCondition(SPP_Conditions.FULL_ORBIT);
//                    Logger.getLogger(SPP_MoonScript.class).info("Added four moons condition to " + focus.getName() + " in the " + focus.getStarSystem().getName() + " system.");
                }
            }

            market.reapplyConditions();
        }

        // Second loop to detect volatile taps
        // Must come after minor moon effects, since they could add volatiles to the parent
        for (PlanetAPI planet : planets) {
            if (planet.hasTag(SPP_Tags.NO_INTERACTION)) continue;

            SectorEntityToken focus = planet.getOrbitFocus();
            if (focus == null || focus.isStar() || focus.isSystemCenter()) continue;

            MarketAPI market = planet.getMarket();
            if (market == null) market = SPP_Misc.createPlanetConditionMarket(planet);

            if (!market.getFaction().isNeutralFaction()) continue;

            MarketAPI fMarket = focus.getMarket();
            boolean fMNull = false;
            if (fMarket == null) {
                fMNull = true;
                fMarket = Global.getFactory().createMarket("SPP_market_" + focus.getId(), focus.getName(), 1);
                fMarket.setPrimaryEntity(focus);
                fMarket.setFactionId(Factions.NEUTRAL);
                fMarket.setPlanetConditionMarketOnly(true);
                focus.setMarket(fMarket);
            }

            if (!fMarket.getFaction().isNeutralFaction()) continue;

            // Skip minor moons
            if (market == fMarket) continue;

            if (focus instanceof PlanetAPI) {
                if (fMNull) fMarket = SPP_Misc.createPlanetConditionMarket((PlanetAPI) focus);

                float dist = SPP_Misc.getDistance(planet, focus);
                if (dist - (focus.getRadius() + planet.getRadius()) <= CLOSE_MOON_MAX_DIST) {
                    // Check to see if moon should have volatiles tap condition
                    int mVol = SPP_PortFunctions.getVolatiles(market);
                    int pVol = SPP_PortFunctions.getVolatiles(fMarket);

                    if (!SPP_PortFunctions.hasOrbitalPortBlock(fMarket)
                                && !SPP_PortFunctions.hasOrbitalPortBlock(market)
                                && pVol >= 0 && pVol > mVol) {
                        market.addCondition(SPP_Conditions.MOON_SIPHON);

                        // Set memory
                        focus.getMemoryWithoutUpdate().set(SPP_Tags.MEMKEY_SIPHON_MOON, planet);
                        planet.getMemoryWithoutUpdate().set(SPP_Tags.MEMKEY_TAP_TARGET, focus);
                    }

                    //<editor-fold defaultstate="collapsed" desc="old">
    // Add conditions
    //                    String token = fMarket.addCondition(SPP_Conditions.CLOSE_MOON);
    //                    fMarket.getSpecificCondition(token).setSurveyed(true);
    //
    //                    token = market.addCondition(SPP_Conditions.LUNAR_ORBIT);
    //                    market.getSpecificCondition(token).setSurveyed(true);
    //                    token = market.addCondition(SPP_Conditions.MOON);
    //                    market.getSpecificCondition(token).setSurveyed(true);
    //
    //                    // Set memory
    //                    focus.getMemoryWithoutUpdate().set(SPP_Tags.MEMKEY_CLOSE_MOON_ID, planet.getId());
    //                    planet.getMemoryWithoutUpdate().set(SPP_Tags.MEMKEY_ORBITAL_PLANET_ID, focus.getId());
    //
    //                    // Share resources and ruins
    //                    shareResourcesAndRuins(fMarket, market);
    //</editor-fold>
                }
            }
        }
    }

    public static void attachMinorMoon(PlanetAPI moon, MarketAPI focusMarket) {
        // Link minor moon to planet
//        moon.setMarket(focusMarket);
        moon.addTag(SPP_Tags.NO_INTERACTION);

        moon.setDiscoverable(false);

        // Add minor moon(s) condition
        if (!focusMarket.hasCondition(SPP_Conditions.TIGHT_MOON)) {
            String token = focusMarket.addCondition(SPP_Conditions.TIGHT_MOON);
            focusMarket.getSpecificCondition(token).setSurveyed(true);
        }

        // Adjust resource deposits by moon's planet type or category
        Map<String, Integer> bonuses = MOON_RESOURCES.get(moon.getTypeId());
        if (bonuses == null) bonuses = MOON_RESOURCES.get(SPP_Planets.CATEGORIES.get(moon.getTypeId()));
        if (bonuses != null) {
            for (String com : bonuses.keySet()) {
                int bonus = bonuses.get(com);
                int curr = 0;

                switch (com) {
                    case Commodities.FOOD: curr = SPP_PortFunctions.getFood(focusMarket); break;
                    case Commodities.ORE: curr = SPP_PortFunctions.getOre(focusMarket); break;
                    case Commodities.RARE_ORE: curr = SPP_PortFunctions.getRareOre(focusMarket); break;
                    case Commodities.ORGANICS: curr = SPP_PortFunctions.getOrganics(focusMarket); break;
                    case Commodities.VOLATILES: curr = SPP_PortFunctions.getVolatiles(focusMarket); break;
                }

                // Remove old condition
                String condId = SPP_PortFunctions.getResourceCondId(com, curr);
                focusMarket.removeCondition(condId);
                // Add new condition
                condId = SPP_PortFunctions.getResourceCondId(com, curr + bonus);
                if (!condId.isEmpty()) {
                    String token = focusMarket.addCondition(condId);
                    focusMarket.getSpecificCondition(token).setSurveyed(true);
                }
            }
        }

        focusMarket.reapplyConditions();
    }

    //<editor-fold defaultstate="collapsed" desc="unused">
    private static void shareResourcesAndRuins(MarketAPI parent, MarketAPI moon) {
        // Get parent's resource values
        int food = SPP_PortFunctions.getFood(parent);
        boolean aquaculture = SPP_PortFunctions.hasAquaculture(parent);
        if (aquaculture) food = SPP_PortFunctions.getAquaculture(parent);
        int ore = SPP_PortFunctions.getOre(parent);
        int rare = SPP_PortFunctions.getRareOre(parent);
        int organics = SPP_PortFunctions.getOrganics(parent);
        int volatiles = SPP_PortFunctions.getVolatiles(parent);
        int ruins = SPP_PortFunctions.getRuins(parent);
        int pop = SPP_PortFunctions.getPopulationSize(parent);

        // Get moon's resource values
        int mFood = SPP_PortFunctions.getFood(moon);
        boolean mAquaculture = SPP_PortFunctions.hasAquaculture(moon);
        if (mAquaculture) mFood = SPP_PortFunctions.getAquaculture(moon);
        int mOre = SPP_PortFunctions.getOre(moon);
        int mRare = SPP_PortFunctions.getRareOre(moon);
        int mOrganics = SPP_PortFunctions.getOrganics(moon);
        int mVolatiles = SPP_PortFunctions.getVolatiles(moon);
        int mRuins = SPP_PortFunctions.getRuins(moon);
        int mPop = SPP_PortFunctions.getPopulationSize(moon);

        // Find old conditions, then remove
        List<MarketConditionAPI> toRemove = new ArrayList<>();
        // And check for habitable & uninhabitable
//        boolean parentHabitable = false;
//        boolean moonHabitable = false;
        boolean parentUninhabitable = false;
        boolean moonUninhabitable = false;
        for (MarketConditionAPI mc : parent.getConditions()) {
            if (mc.getPlugin() instanceof SPP_PlanetBlockCondition) {
                parentUninhabitable = true;
            }

            if (mc.getPlugin() instanceof SPP_ResourceDepositsCondition) {
                toRemove.add(mc);
            }

            if (mc.getPlugin() instanceof SPP_Population) {
                toRemove.add(mc);
            }

//            if (mc.getId().equals(Conditions.HABITABLE)) {
//                parentHabitable = true;
//            }
        }
        for (MarketConditionAPI mc : moon.getConditions()) {
            if (mc.getPlugin() instanceof SPP_PlanetBlockCondition) {
                moonUninhabitable = true;
            }

            if (mc.getPlugin() instanceof SPP_ResourceDepositsCondition) {
                toRemove.add(mc);
            }

            if (mc.getPlugin() instanceof SPP_Population) {
                toRemove.add(mc);
            }

//            if (mc.getId().equals(Conditions.HABITABLE)) {
//                moonHabitable = true;
//            }
        }
        // Remove
        for (MarketConditionAPI mc : toRemove) {
            parent.removeCondition(mc.getId());
            moon.removeCondition(mc.getId());
        }

        // Configure ruins and population per uninhabitable booleans
        if (parentUninhabitable && moonUninhabitable) {
            ruins = 0; mRuins = 0;
            pop = 0; mPop = 0;
        } else if (parentUninhabitable) {
            mRuins = Math.max(ruins, mRuins);
            mPop = Math.max(pop, mPop);
            ruins = 0;
            pop = 0;
        } else if (moonUninhabitable) {
            ruins = Math.max(ruins, mRuins);
            pop = Math.max(pop, mPop);
            mRuins = 0;
            mPop = 0;
        }

        if (ruins > mRuins && mRuins != 0) {
            mRuins = ruins;
        } else if (mRuins > ruins && ruins != 0) {
            ruins = mRuins;
        } else if (mRuins > ruins && ruins == 0) {
            parentUninhabitable = true; // hijacking
        }

        if (pop > mPop && mPop != 0) {
            mPop = pop;
        } else if (mPop > pop && pop != 0) {
            pop = mPop;
        } else if (mPop > pop && pop == 0) {
            parentUninhabitable = true; // hijacking
        }

        // Remove orbital junk
        for (SectorEntityToken junk : parent.getContainingLocation().getEntitiesWithTag(Tags.ORBITAL_JUNK)) {
            if (junk.getOrbitFocus() == parent || junk.getOrbitFocus() == moon) {
                parent.getContainingLocation().removeEntity(junk);
            }
        }

        // Remove ruins
//        parent.removeCondition(Conditions.DECIVILIZED);
        parent.removeCondition(Conditions.RUINS_SCATTERED);
        parent.removeCondition(Conditions.RUINS_WIDESPREAD);
        parent.removeCondition(Conditions.RUINS_EXTENSIVE);
        parent.removeCondition(Conditions.RUINS_VAST);

//        moon.removeCondition(Conditions.DECIVILIZED);
        moon.removeCondition(Conditions.RUINS_SCATTERED);
        moon.removeCondition(Conditions.RUINS_WIDESPREAD);
        moon.removeCondition(Conditions.RUINS_EXTENSIVE);
        moon.removeCondition(Conditions.RUINS_VAST);


        //<editor-fold defaultstate="collapsed" desc="Set new conditions">
        // Check if farmland greater than or equal to aquaculture
        boolean skip = false;
        if (aquaculture || mAquaculture && !(aquaculture && mAquaculture)) {
            if (aquaculture && !mAquaculture && mFood >= 0) {
                skip = true;

                if (food == 2) {
                    parent.addCondition(Conditions.VOLTURNIAN_LOBSTER_PENS);
                    moon.addCondition(Conditions.VOLTURNIAN_LOBSTER_PENS);
                }

                food = -2;
            }

            if (!aquaculture && mAquaculture && food >= 0) {
                skip = true;

                if (mFood == 2) {
                    parent.addCondition(Conditions.VOLTURNIAN_LOBSTER_PENS);
                    moon.addCondition(Conditions.VOLTURNIAN_LOBSTER_PENS);
                }

                mFood = -2;
            }
        }

        String condId = Conditions.WATER_SURFACE;
        int temp = Math.max(food, mFood);
        if (aquaculture && !skip) {
            parent.addCondition(condId);
            moon.addCondition(condId);

            if (aquaculture && !mAquaculture) {
                SPP_PortFunctions.getOrbitalConditions(moon).add(condId);
            } else if (!aquaculture && mAquaculture) {
                SPP_PortFunctions.getOrbitalConditions(parent).add(condId);
            }

            if (food == 2 || mFood == 2) {
                parent.addCondition(Conditions.VOLTURNIAN_LOBSTER_PENS);
                moon.addCondition(Conditions.VOLTURNIAN_LOBSTER_PENS);
            }
        } else {
            switch (temp) {
                case  2:
                    condId = Conditions.FARMLAND_BOUNTIFUL;
                    break;
                case  1:
                    condId = Conditions.FARMLAND_RICH;
                    break;
                case  0:
                    condId = Conditions.FARMLAND_ADEQUATE;
                    break;
                case -1:
                    condId = Conditions.FARMLAND_POOR;
            }

            if (temp > -2) {
                parent.addCondition(condId);
                moon.addCondition(condId);
            }

            if (food > mFood) {
                SPP_PortFunctions.getOrbitalConditions(moon).add(condId);
            } else if (food < mFood) {
                SPP_PortFunctions.getOrbitalConditions(parent).add(condId);
            }
        }

        // Ore
        temp = Math.max(ore, mOre);
        switch (temp) {
            case 3:
                condId = Conditions.ORE_ULTRARICH;
                break;
            case  2:
                condId = Conditions.ORE_RICH;
                break;
            case  1:
                condId = Conditions.ORE_ABUNDANT;
                break;
            case  0:
                condId = Conditions.ORE_MODERATE;
                break;
            case -1:
                condId = Conditions.ORE_SPARSE;
        }

        if (temp > -2) {
            parent.addCondition(condId);
            moon.addCondition(condId);
        }

        if (ore > mOre) {
            SPP_PortFunctions.getOrbitalConditions(moon).add(condId);
        } else if (ore < mOre) {
            SPP_PortFunctions.getOrbitalConditions(parent).add(condId);
        }

        // Rare ore
        temp = Math.max(rare, mRare);
        switch (temp) {
            case 3:
                condId = Conditions.RARE_ORE_ULTRARICH;
                break;
            case  2:
                condId = Conditions.RARE_ORE_RICH;
                break;
            case  1:
                condId = Conditions.RARE_ORE_ABUNDANT;
                break;
            case  0:
                condId = Conditions.RARE_ORE_MODERATE;
                break;
            case -1:
                condId = Conditions.RARE_ORE_SPARSE;
        }

        if (temp > -2) {
            parent.addCondition(condId);
            moon.addCondition(condId);
        }

        if (rare > mRare) {
            SPP_PortFunctions.getOrbitalConditions(moon).add(condId);
        } else if (rare < mRare) {
            SPP_PortFunctions.getOrbitalConditions(parent).add(condId);
        }

        // Organics
        temp = Math.max(organics, mOrganics);
        switch (temp) {
            case  2:
                condId = Conditions.ORGANICS_PLENTIFUL;
                break;
            case  1:
                condId = Conditions.ORGANICS_ABUNDANT;
                break;
            case  0:
                condId = Conditions.ORGANICS_COMMON;
                break;
            case -1:
                condId = Conditions.ORGANICS_TRACE;
        }

        if (temp > -2) {
            parent.addCondition(condId);
            moon.addCondition(condId);
        }

        if (organics > mOrganics) {
            SPP_PortFunctions.getOrbitalConditions(moon).add(condId);
        } else if (organics < mOrganics) {
            SPP_PortFunctions.getOrbitalConditions(parent).add(condId);
        }

        // Volatiles
        temp = Math.max(volatiles, mVolatiles);
        switch (temp) {
            case  2:
                condId = Conditions.VOLATILES_PLENTIFUL;
                break;
            case  1:
                condId = Conditions.VOLATILES_ABUNDANT;
                break;
            case  0:
                condId = Conditions.VOLATILES_DIFFUSE;
                break;
            case -1:
                condId = Conditions.VOLATILES_TRACE;
        }

        if (temp > -2) {
            parent.addCondition(condId);
            moon.addCondition(condId);
        }

        if (volatiles > mVolatiles) {
            SPP_PortFunctions.getOrbitalConditions(moon).add(condId);
        } else if (volatiles < mVolatiles) {
            SPP_PortFunctions.getOrbitalConditions(parent).add(condId);
        }

        // Population
        temp = Math.max(pop, mPop);
        condId = getPopulationConditionId(temp);

        if (temp > -1) {
            parent.addCondition(condId);
            moon.addCondition(condId);

            if (moonUninhabitable) {
                SPP_PortFunctions.getOrbitalConditions(moon).add(condId);
            } else if (parentUninhabitable) {
                SPP_PortFunctions.getOrbitalConditions(parent).add(condId);
            }
        }

        // Ruins
        // Preprocessing FTW
        temp = Math.max(ruins, mRuins);
        switch (temp) {
            case  2:
                condId = Conditions.RUINS_VAST;
                break;
            case  1:
                condId = Conditions.RUINS_EXTENSIVE;
                break;
            case  0:
                condId = Conditions.RUINS_WIDESPREAD;
                break;
            case -1:
                condId = Conditions.RUINS_SCATTERED;
        }

        if (temp > -2) {
            parent.addCondition(condId);
            moon.addCondition(condId);

            if (moonUninhabitable) {
//                parent.addCondition(Conditions.DECIVILIZED);
                addJunk(parent, ruins);

                SPP_PortFunctions.getOrbitalConditions(moon).add(condId);
            } else if (parentUninhabitable) {
//                moon.addCondition(Conditions.DECIVILIZED);
                addJunk(moon, mRuins);

                SPP_PortFunctions.getOrbitalConditions(parent).add(condId);
//            }
            } else {
//                parent.addCondition(Conditions.DECIVILIZED);
//                moon.addCondition(Conditions.DECIVILIZED);
//
                addJunk(parent, ruins);
                addJunk(moon, ruins);
            }
        }
        //</editor-fold>

        if (parent.getSurveyLevel().equals(MarketAPI.SurveyLevel.FULL)) {
            for (MarketConditionAPI mc : parent.getConditions()) {
                mc.setSurveyed(true);
            }
            for (MarketConditionAPI mc : moon.getConditions()) {
                mc.setSurveyed(true);
            }
        }
    }
//</editor-fold>

    private static String getPopulationConditionId(int size) {
        if (size <= 0) return SPP_Conditions.POPULATION_0;
        if (size > 10) size = 10;

        return "population_" + size;
    }

    private static void addJunk(MarketAPI market, int ruinSize) {
			int numJunk = 5;
            switch (ruinSize) {
                case 4: numJunk += 25;
                case 3: numJunk += 10;
                case 2: numJunk += 5;
            }

			//System.out.println("With ruins: " + planet.getName() + ", " + location.getNameWithLowercaseType());

			float radius = market.getPrimaryEntity().getRadius() + 100f;
			float minOrbitDays = radius / 20;
			float maxOrbitDays = minOrbitDays + 10f;

			market.getContainingLocation().addOrbitalJunk(market.getPrimaryEntity(),
					 "orbital_junk", // from custom_entities.json
					 numJunk, // num of junk
					 12, 20, // min/max sprite size (assumes square)
					 radius, // orbit radius
					 //70, // orbit width
					 110, // orbit width
					 minOrbitDays, // min orbit days
					 maxOrbitDays, // max orbit days
					 60f, // min spin (degress/day)
					 360f); // max spin (degrees/day)
    }
}
