package campaign.procgen;

import campaign.econ.SPP_NativePopCondition;
import campaign.econ.SPP_OrbitalBlockCondition;
import campaign.econ.SPP_PlanetBlockCondition;
import campaign.ids.SPP_Conditions;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI.SurveyLevel;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import util.SPP_Misc;
import util.SPP_PortFunctions;

/**
 * Author: SafariJohn
 */
public class SPP_NativePopsScript {

    public static void run(SectorAPI sector) {

        List<StarSystemAPI> systems = sector.getStarSystems();
        List<PlanetAPI> planets = new ArrayList<>();
        for (StarSystemAPI system : systems) {
            planets.addAll(system.getPlanets());
        }

        PLANETS:
        for (PlanetAPI planet : planets) {
            if (planet.isStar()) continue;
            if (planet.isSystemCenter()) continue;

            MarketAPI market = planet.getMarket();
            if (market == null) market = SPP_Misc.createPlanetConditionMarket(planet);

//            if (market.hasCondition(Conditions.DECIVILIZED)) {
//                market.removeCondition(Conditions.DECIVILIZED);
//                String token = market.addCondition(SPP_Conditions.DECIVILIZED);
//                market.getSpecificCondition(token).setSurveyed(true);
//            }

            if (!market.getFaction().isNeutralFaction()) continue;

            SectorEntityToken other = SPP_Misc.getMoonOrParent(planet);

            if (other != null && !other.getFaction().isNeutralFaction()) continue;

            boolean deciv = false;
            boolean habitable = false;
            boolean uninhabitable = false;
            boolean stationBlocked = false;
            for (MarketConditionAPI mc : market.getConditions()) {
                if (mc.getPlugin() instanceof SPP_PlanetBlockCondition) {
                    uninhabitable = true;
                }

                // Could already be set. If so, skip
                if (mc.getPlugin() instanceof SPP_NativePopCondition) {
                    continue PLANETS;
                }

                if (mc.getPlugin() instanceof SPP_OrbitalBlockCondition) {
                    stationBlocked = true;
                }

                if (mc.getId().equals(Conditions.HABITABLE)) {
                    habitable = true;
                }

                if (mc.getId().equals(Conditions.DECIVILIZED)) {
                    deciv = true;
                }
            }

            market.removeCondition(Conditions.DECIVILIZED);

            // Get pop
            int population = SPP_PortFunctions.getPopulationSize(market);

            // No pop at all on uninhabitable planets
            String popId = SPP_PortFunctions.getPopulationConditionId(population);
            if (uninhabitable && other == null) {
                market.removeCondition(popId);

                if (!stationBlocked) {
                    String token = market.addCondition(SPP_Conditions.POPULATION_0);
                    if (market.getSurveyLevel() == SurveyLevel.FULL) market.getSpecificCondition(token).setSurveyed(true);
                }

                continue;
            }

            if (population <= 0) continue;

            int ruins = SPP_PortFunctions.getRuins(market);

            switch (population) {
                case 10:
                case 9:
                case 8: market.removeCondition(Conditions.RUINS_VAST);
                case 7: market.removeCondition(Conditions.RUINS_EXTENSIVE);
                case 6: market.removeCondition(Conditions.RUINS_WIDESPREAD);
                case 5:
                case 4: market.removeCondition(Conditions.RUINS_SCATTERED);
            }

            // Add valid possibilities to picker
            float hazard = market.getHazardValue();
            WeightedRandomPicker<String> picker = new WeightedRandomPicker<>();
            if (habitable && population > 3 && hazard < 1.6) picker.add(SPP_Conditions.PRIMITIVES, 10);
            if (population > 3 && hazard < 2.1) picker.add(SPP_Conditions.NATION_STATES, 5);
            if (population < 5 && hazard < 2.1 && deciv) picker.add(SPP_Conditions.DECIVILIZED, 100);
            else if (population < 5 && hazard < 2.1) picker.add(SPP_Conditions.DECIVILIZED, 10);
            picker.add(SPP_Conditions.WORLD_ORDER, 2);
            picker.add(SPP_Conditions.XENOPHOBES, 1);

            // Pick and apply
            String condId = picker.pick();
            String token = market.addCondition(condId);
            if (market.getSurveyLevel().equals(SurveyLevel.FULL)) market.getSpecificCondition(token).setSurveyed(true);

            if (!condId.equals(SPP_Conditions.PRIMITIVES) && population / 3 > ruins) {
                for (SectorEntityToken junk : market.getContainingLocation().getEntitiesWithTag(Tags.ORBITAL_JUNK)) {
                    if (junk.getOrbitFocus() == market.getPrimaryEntity()) {
                        market.getContainingLocation().removeEntity(junk);
                    }
                }

                addJunk(market, population / 3);
            }

            Set orbitals = SPP_PortFunctions.getOrbitalConditions(planet);
            if (uninhabitable || orbitals.contains(popId)) {
                orbitals.add(condId);
            }

            // And apply to moon/parent, if exists
            if (other != null) {
                MarketAPI oMarket = other.getMarket();
                if (oMarket == null) {
                    oMarket = Global.getFactory().createMarket("SPP_market_" + other.getId(), other.getName(), 1);
                    oMarket.setPrimaryEntity(other);
                    oMarket.setFactionId(Factions.NEUTRAL);
                    oMarket.setPlanetConditionMarketOnly(true);
                    other.setMarket(oMarket);
                }

                List<MarketConditionAPI> toRemove = new ArrayList<>();
                for (MarketConditionAPI mc : oMarket.getConditions()) {
                    // Could already be set. If so, remove
                    if (mc.getPlugin() instanceof SPP_NativePopCondition) {
                        toRemove.add(mc);
                    }
                }
                // Remove
                for (MarketConditionAPI mc : toRemove) {
                    oMarket.removeCondition(mc.getId());
                }

                token = oMarket.addCondition(condId);
                if (oMarket.getSurveyLevel().equals(SurveyLevel.FULL)) oMarket.getSpecificCondition(token).setSurveyed(true);

                Set oOrbitals = SPP_PortFunctions.getOrbitalConditions(other);
                if (oOrbitals.contains(popId)) oOrbitals.add(condId);
                else if (!condId.equals(SPP_Conditions.PRIMITIVES) && population / 3 > ruins) {
                    for (SectorEntityToken junk : oMarket.getContainingLocation().getEntitiesWithTag(Tags.ORBITAL_JUNK)) {
                        if (junk.getOrbitFocus() == oMarket.getPrimaryEntity()) {
                            oMarket.getContainingLocation().removeEntity(junk);
                        }
                    }

                    addJunk(oMarket, population / 3);
                }

            }


            market.reapplyConditions();
        }
    }

    private static void addJunk(MarketAPI market, int ruinSize) {
			int numJunk = 5;
            switch (ruinSize) {
                case 4: numJunk += 25;
                case 3: numJunk += 10;
                case 2: numJunk += 5;
            }

			//System.out.println("With ruins: " + planet.getName() + ", " + location.getNameWithLowercaseType());

			float radius = market.getPrimaryEntity().getRadius() + 100f;
			float minOrbitDays = radius / 20;
			float maxOrbitDays = minOrbitDays + 10f;

			market.getContainingLocation().addOrbitalJunk(market.getPrimaryEntity(),
					 "orbital_junk", // from custom_entities.json
					 numJunk, // num of junk
					 12, 20, // min/max sprite size (assumes square)
					 radius, // orbit radius
					 //70, // orbit width
					 110, // orbit width
					 minOrbitDays, // min orbit days
					 maxOrbitDays, // max orbit days
					 60f, // min spin (degress/day)
					 360f); // max spin (degrees/day)
    }
}
