package campaign.procgen;

import campaign.econ.SPP_ResourceDepositsCondition;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import java.util.ArrayList;
import java.util.List;
import util.SPP_Misc;
import util.SPP_PortFunctions;

/**
 * Author: SafariJohn
 */
public class SPP_Cleanup {
    public static void run(SectorAPI sector) {
        List<StarSystemAPI> systems = sector.getStarSystems();
        List<PlanetAPI> planets = new ArrayList<>();
        for (StarSystemAPI system : systems) {
            planets.addAll(system.getPlanets());
        }

        for (PlanetAPI planet : planets) {
            if (planet.isStar()) continue;
            if (planet.isSystemCenter()) continue;

            MarketAPI market = planet.getMarket();
            if (market == null) market = SPP_Misc.createPlanetConditionMarket(planet);

            if (!market.getFaction().isNeutralFaction()) continue;

            SectorEntityToken other = SPP_Misc.getOther(planet);

            if (other != null && !other.getFaction().isNeutralFaction()) continue;

            List<MarketConditionAPI> toRemove = new ArrayList<>();
            boolean stationBlock = SPP_PortFunctions.hasOrbitalPortBlock(market, false);
            boolean uninhabitable = SPP_PortFunctions.hasPlanetPortBlock(market, false);

            for (MarketConditionAPI mc : market.getConditions()) {
                if (mc.getPlugin() instanceof SPP_ResourceDepositsCondition) {
                    toRemove.add(mc);
                }
            }

            if (stationBlock && uninhabitable) {
                if (other == null) {
                    for (MarketConditionAPI mc : toRemove) {
                        market.removeCondition(mc.getId());
                    }
                } else {
                    MarketAPI oMarket = other.getMarket();
                    if (oMarket == null) {
                        oMarket = Global.getFactory().createMarket("SPP_market_" + other.getId(), other.getName(), 1);
                        oMarket.setPrimaryEntity(other);
                        oMarket.setFactionId(Factions.NEUTRAL);
                        oMarket.setPlanetConditionMarketOnly(true);
                        other.setMarket(oMarket);
                    }

                    stationBlock = SPP_PortFunctions.hasOrbitalPortBlock(oMarket, false);
                    uninhabitable = SPP_PortFunctions.hasPlanetPortBlock(oMarket, false);
                    for (MarketConditionAPI mc : oMarket.getConditions()) {
                        if (mc.getPlugin() instanceof SPP_ResourceDepositsCondition) {
                            toRemove.add(mc);
                        }
                    }

                    if (stationBlock && uninhabitable) {
                        for (MarketConditionAPI mc : toRemove) {
                            market.removeCondition(mc.getId());
                            oMarket.removeCondition(mc.getId());
                        }
                    }

                    oMarket.reapplyConditions();
                }
            }

            market.reapplyConditions();
        }
    }
}
