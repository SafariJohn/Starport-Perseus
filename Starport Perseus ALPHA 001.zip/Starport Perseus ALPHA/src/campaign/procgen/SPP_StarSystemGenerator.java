package campaign.procgen;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.*;
import static com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator.*;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import java.awt.Color;
import java.util.Collection;

/**
 * Author: SafariJohn
 */
public class SPP_StarSystemGenerator extends StarSystemGenerator {

    public static final float NEW_STARTING_RADIUS_MOON = STARTING_RADIUS_MOON_BASE;
    public static final float NEW_MOON_RADIUS_MAX_FRACTION_OF_PARENT = 0.5f;
    public static final float NEW_MIN_MOON_RADIUS = 20f;

    protected static boolean poisoned = false;

    public SPP_StarSystemGenerator(CustomConstellationParams params) {
        super(params);
    }

    public static float addOrbitingEntities(StarSystemAPI system, SectorEntityToken parentStar, StarAge age,
										   int min, int max, float startingRadius,
										   int nameOffset, boolean withSpecialNames, boolean poison) {
        poisoned = poison;
        float result = addOrbitingEntities(system, parentStar, age, min, max, startingRadius, nameOffset, withSpecialNames);
        poisoned = false;

        return result;
    }

	public static float addOrbitingEntities(StarSystemAPI system, SectorEntityToken parentStar, StarAge age,
										   int min, int max, float startingRadius,
										   int nameOffset, boolean withSpecialNames) {
		CustomConstellationParams p = new CustomConstellationParams(age);
		p.forceNebula = true; // not sure why this is here; should avoid small nebula at lagrange points though (but is that desired?)

		SPP_StarSystemGenerator gen = new SPP_StarSystemGenerator(p);
		gen.system = system;
		gen.starData = (StarGenDataSpec) Global.getSettings().getSpec(StarGenDataSpec.class, system.getStar().getSpec().getPlanetType(), false);
		gen.starAge = age;
		gen.constellationAge = age;
		gen.starAgeData = (AgeGenDataSpec) Global.getSettings().getSpec(AgeGenDataSpec.class, age.name(), true);
		gen.star = system.getStar();
		gen.pickNebulaAndBackground();

		gen.systemCenter = system.getCenter();

		StarGenDataSpec starData = gen.starData;
		PlanetGenDataSpec planetData = null;
		PlanetAPI parentPlanet = null;
		if (parentStar instanceof PlanetAPI) {
			PlanetAPI planet = (PlanetAPI) parentStar;
			if (planet.isStar()) {
				starData = (StarGenDataSpec) Global.getSettings().getSpec(StarGenDataSpec.class, planet.getSpec().getPlanetType(), false);
			} else {
				planetData = (PlanetGenDataSpec) Global.getSettings().getSpec(PlanetGenDataSpec.class, planet.getSpec().getPlanetType(), false);
				parentPlanet = planet;
			}
		}

		int parentOrbitIndex = -1;
		int startingOrbitIndex = 0;

		boolean addingAroundStar = parentPlanet == null;
		float r = 0;
		if (parentStar != null) {
			r = parentStar.getRadius();
		}

		float approximateExtraRadiusPerOrbit = 400f;
		if (addingAroundStar) {
			parentOrbitIndex = -1;
			startingOrbitIndex = (int) ((startingRadius  - r - STARTING_RADIUS_STAR_BASE - STARTING_RADIUS_STAR_RANGE * 0.5f) /
							     (BASE_INCR * 1.25f + approximateExtraRadiusPerOrbit));

			if (startingOrbitIndex < 0) startingOrbitIndex = 0;
		} else {
			float dist = 0f;
			if (parentPlanet.getOrbitFocus() != null) {
				dist = Misc.getDistance(parentPlanet.getLocation(), parentPlanet.getOrbitFocus().getLocation());
			}
			parentOrbitIndex = (int) ((dist - r - STARTING_RADIUS_STAR_BASE - STARTING_RADIUS_STAR_RANGE * 0.5f) /
					 		   (BASE_INCR * 1.25f + approximateExtraRadiusPerOrbit));
			startingOrbitIndex = (int) ((startingRadius - STARTING_RADIUS_MOON_BASE - STARTING_RADIUS_MOON_RANGE * 0.5f) /
					 		   (BASE_INCR_MOON * 1.25f));

			if (parentOrbitIndex < 0) parentOrbitIndex = 0;
			if (startingOrbitIndex < 0) startingOrbitIndex = 0;
		}

		int num = (int) Math.round(getNormalRandom(min, max));

		GenContext context = new GenContext(gen, system, gen.systemCenter, starData,
							parentPlanet, startingOrbitIndex, age.name(), startingRadius, MAX_ORBIT_RADIUS,
							planetData != null ? planetData.getCategory() : null, parentOrbitIndex);


		GenResult result = gen.addOrbitingEntities(context, num, false, addingAroundStar, false, false);


		Constellation c = new Constellation(Constellation.ConstellationType.NORMAL, age);
		c.getSystems().add(system);
		c.setLagrangeParentMap(gen.lagrangeParentMap);
		c.setAllEntitiesAdded(gen.allNameableEntitiesAdded);
		c.setLeavePickedNameUnused(true);
		NameAssigner namer = new NameAssigner(c);
		if (withSpecialNames) {
			namer.setSpecialNamesProbability(1f);
		} else {
			namer.setSpecialNamesProbability(0f);
		}
		namer.setRenameSystem(false);
		namer.setStructuralNameOffset(nameOffset);
		namer.assignNames(null, null);

		for (SectorEntityToken entity : gen.allNameableEntitiesAdded.keySet()) {
			if (entity instanceof PlanetAPI && entity.getMarket() != null) {
				entity.getMarket().setName(entity.getName());
			}
		}

		return result.orbitalWidth * 0.5f;

	}

    @Override
    public CategoryGenDataSpec pickCategory(GenContext context, String extraMult, boolean nothingOk) {
//		int orbitIndex = context.orbitIndex;
//		if (context.parentOrbitIndex >= 0) {
//			orbitIndex = context.parentOrbitIndex;
//		}
//		int fromParentOrbitIndex = context.orbitIndex;
		String age = context.age;
		//String starType = context.star.getTypeId();
		String starType = star.getTypeId();
		if (context.center instanceof PlanetAPI) {
			PlanetAPI star = (PlanetAPI) context.center;
			if (star.isStar()) starType = star.getTypeId();
		}

		String parentCategory = context.parentCategory;

		WeightedRandomPicker<CategoryGenDataSpec> picker = new WeightedRandomPicker<CategoryGenDataSpec>(random);
		Collection<Object> categoryDataSpecs = Global.getSettings().getAllSpecs(CategoryGenDataSpec.class);
		for (Object obj : categoryDataSpecs) {
			CategoryGenDataSpec categoryData = (CategoryGenDataSpec) obj;
			boolean catNothing = categoryData.getCategory().equals(CAT_NOTHING);
			if (!nothingOk && catNothing) continue;
            if (poisoned && categoryData.getCategory().contains("_hab")) continue;
//			if (categoryData.getCategory().equals("cat_terrain_rings")) {
//				System.out.println("sdfkwefewfe");
//			}
			float weight = categoryData.getFrequency();
			if (age != null) weight *= categoryData.getMultiplier(age);
			if (starType != null) weight *= categoryData.getMultiplier(starType);
			if (parentCategory != null) weight *= categoryData.getMultiplier(parentCategory);
			for (String col : context.multipliers) {
				weight *= categoryData.getMultiplier(col);
			}
			if (extraMult != null) weight *= categoryData.getMultiplier(extraMult);


			//if (weight > 0 && (catNothing || !isCategoryEmpty(categoryData, orbitIndex, fromParentOrbitIndex, age, starType, parentCategory, extraMult))) {
			if (weight > 0 && (catNothing || !isCategoryEmpty(categoryData, context, extraMult, nothingOk))) {
				picker.add(categoryData, weight);
			}
		}

		if (DEBUG) {
			boolean withParent = context.parent != null;
			int orbitIndex = context.orbitIndex;
			String parentType = "";
			if (withParent) {
				parentType = context.parent.getSpec().getPlanetType();
				orbitIndex = context.parentOrbitIndex;
			}

//			float offset = orbitIndex;
//			float minIndex = context.starData.getHabZoneStart() + planetData.getHabOffsetMin() + offset;
//			float maxIndex = context.starData.getHabZoneStart() + planetData.getHabOffsetMax() + offset;
			//boolean inRightRange = orbitIndex >= minIndex && orbitIndex <= maxIndex;
			int habDiff = orbitIndex - (int) context.starData.getHabZoneStart();
			if (withParent) {
				picker.print("  Picking category for moon of " + parentType +
							 ", orbit from star: " + orbitIndex + " (" + habDiff + ")" +  ", extra: " + extraMult);
			} else {
				picker.print("  Picking category for entity orbiting star " + starType +
							", orbit from star: " + orbitIndex + " (" + habDiff + ")" +  ", extra: " + extraMult);
			}
		}

		CategoryGenDataSpec pick = picker.pick();
		if (DEBUG) {
			System.out.println("  Picked: " + pick.getCategory());
			System.out.println();
		}

		return pick;
    }

    @Override
    public GenResult addPlanet(GenContext context, PlanetGenDataSpec planetData, boolean isMoon, boolean addMoons) {
		//float orbitRadius = (orbitIndex + 1f) * 1500 + star.getRadius();
		float radius = getRadius(planetData.getMinRadius(), planetData.getMaxRadius());

		float orbitRadius;

		if (isMoon) {// || context.lagrangeParent != null) {
			//radius *= MOON_RADIUS_MULT;
			float mult = MOON_RADIUS_MIN_FRACTION_OF_NORMAL +
			random.nextFloat() * (MOON_RADIUS_MAX_FRACTION_OF_NORMAL - MOON_RADIUS_MIN_FRACTION_OF_NORMAL);
			radius *= mult;
			if (radius < NEW_MIN_MOON_RADIUS) {
				radius = NEW_MIN_MOON_RADIUS;
			}
			float parentRadius = 100000f;
			if (context.parent != null || context.lagrangeParent != null) {
				PlanetAPI parent = context.parent;
				if (context.lagrangeParent != null) {
					parent = context.lagrangeParent.planet;
				}
				parentRadius = parent.getRadius();
			}
			if (context.parentRadiusOverride > 0) {
				parentRadius = context.parentRadiusOverride;
			}

//			if (parentRadius > MIN_MOON_RADIUS / MOON_RADIUS_MAX_FRACTION_OF_PARENT) {
            float max = parentRadius * NEW_MOON_RADIUS_MAX_FRACTION_OF_PARENT;
            if (radius > max) {
                radius = max;
            }
//			}

            // OrbitRadius = (MIN + MoonRadius + parentRadius|prevRadius) * SizeMult * OrbitMult * rand
            float min = 50;
            float sizeMult = 1 + radius / (2 * max);
            float orbitMult = 1 + context.orbitIndex / 20;
            float rand = 1 + random.nextFloat() / 2;

            orbitRadius = context.currentRadius + (min + radius) * sizeMult * orbitMult * rand;
		} else {
            orbitRadius = context.currentRadius + radius;
        }

		float orbitDays = orbitRadius / (20f + random.nextFloat() * 5f);

		//String planetId = system.getId() + "_planet_" + context.center.getId() + "_" + context.orbitIndex;
		String planetId = context.center.getId() + ":planet_" + context.orbitIndex;
		String planetName = "Planet " + context.orbitIndex;
		if (context.parent != null) {
			planetId = system.getId() + "_moon_" + context.center.getId() + "_" + context.parent.getId() + "_" + context.orbitIndex;
			planetName = context.parent.getName() + " moon " + context.orbitIndex;
		}
		String planetType = planetData.getId();
		SectorEntityToken parent = context.center;
		if (context.parent != null) parent = context.parent;

		float angle = random.nextFloat() * 360f;

		// if adding a moon to a largange point planet, then parentCategory == null
		// will fail and it'll orbit the parent rather than stay at the point
		if (context.parentCategory == null) {
			if (context.lagrangeParent != null && context.lagrangePointType != null) {
				orbitRadius = context.lagrangeParent.orbitRadius;
				orbitDays = context.lagrangeParent.orbitDays;
				float angleOffset = -LAGRANGE_OFFSET;
				if (context.lagrangePointType == LagrangePointType.L5) angleOffset = LAGRANGE_OFFSET;
				angle = context.lagrangeParent.orbitAngle + angleOffset;
				planetName += " " + context.lagrangePointType.name();
				planetId += "_" + context.lagrangePointType.name();
			}
		}

		PlanetAPI planet = system.addPlanet(planetId, parent, planetName, planetType, angle, radius, orbitRadius, orbitDays);
		if (planet.isGasGiant()) {
			if (systemType == StarSystemType.NEBULA) {
				planet.setAutogenJumpPointNameInHyper(system.getBaseName() + ", " + planetName + " Gravity Well");
			}
		}

		float radiusWithMoons = planet.getRadius();
		if (addMoons) {
			boolean hasOrbits = random.nextFloat() < planetData.getProbOrbits();
			float min = planetData.getMinOrbits();
			float max = planetData.getMaxOrbits();
//			double r = random.nextFloat();
//			r *= r;
//			int numOrbits = (int) (min + Math.round((max - min) * r));
			int numOrbits = (int) Math.round(getNormalRandom(min, max));

			if (hasOrbits && numOrbits > 0) {
//				if (!planet.isGasGiant()) {
//					System.out.println("sdfwefew " + star.getId());
//				}
				float startingRadius = 50 + planet.getRadius() + STARTING_RADIUS_MOON_RANGE * random.nextFloat();
				GenContext moonContext = new GenContext(this, context.system, context.center, context.starData, planet, 0, starAge.name(),
														startingRadius, context.maxOrbitRadius, planetData.getCategory(), context.orbitIndex);
				moonContext.multipliers.addAll(context.multipliers);
				// add moons etc
				GenResult moonResult = addOrbitingEntities(moonContext, numOrbits, true, false, false, false);

				context.generatedPlanets.addAll(moonContext.generatedPlanets);

				// move the parent planet out so that there's room for everythnig that was added
				radius = moonResult.orbitalWidth * 0.5f;
				orbitRadius = context.currentRadius + radius;
				orbitDays = orbitRadius / (20f + random.nextFloat() * 5f);

				radiusWithMoons = radius;

				planet.setOrbit(Global.getFactory().createCircularOrbit(context.center, angle, orbitRadius, orbitDays));
			}
		} else if (isMoon) {
			float startingRadius = planet.getRadius() + NEW_STARTING_RADIUS_MOON + STARTING_RADIUS_MOON_RANGE * random.nextFloat();
			GenContext moonContext = new GenContext(this, context.system, context.center, context.starData, planet, 0, starAge.name(),
													startingRadius, context.maxOrbitRadius, planetData.getCategory(), context.orbitIndex);
			moonContext.multipliers.addAll(context.multipliers);
			GenResult moonResult = addOrbitingEntities(moonContext, 1, true, false, true, true);
			context.generatedPlanets.addAll(moonContext.generatedPlanets);

		}


		Color color = getColor(planetData.getMinColor(), planetData.getMaxColor());
		//System.out.println("Setting color: " + color);
		planet.getSpec().setPlanetColor(color);
		if (planet.getSpec().getAtmosphereThickness() > 0) {
			Color atmosphereColor = Misc.interpolateColor(planet.getSpec().getAtmosphereColor(), color, 0.25f);
			atmosphereColor = Misc.setAlpha(atmosphereColor, planet.getSpec().getAtmosphereColor().getAlpha());
			planet.getSpec().setAtmosphereColor(atmosphereColor);

			if (planet.getSpec().getCloudTexture() != null) {
				Color cloudColor = Misc.interpolateColor(planet.getSpec().getCloudColor(), color, 0.25f);
				cloudColor = Misc.setAlpha(cloudColor, planet.getSpec().getCloudColor().getAlpha());
				planet.getSpec().setAtmosphereColor(atmosphereColor);
			}
		}

		float tilt = planet.getSpec().getTilt();
		float pitch = planet.getSpec().getPitch();

//		"tilt" # left-right (>0 tilts to the left)
//		"pitch" # towards-away from the viewer (>0 pitches towards)
		float sign = (float) Math.signum(random.nextFloat() - 0.5f);
		double r = random.nextFloat();
		//r *= r;
		if (sign > 0) {
			tilt += r * TILT_MAX;
		} else {
			tilt += r * TILT_MIN;
		}

		sign = (float) Math.signum(random.nextFloat() - 0.5f);
		r = random.nextFloat();
		//r *= r;
		if (sign > 0) {
			pitch += r * PITCH_MAX;
		} else {
			tilt += r * PITCH_MIN;
		}
		planet.getSpec().setTilt(tilt);
		planet.getSpec().setPitch(pitch);


		if (context.orbitIndex == 0 && context.parent == null && context.orbitIndex < context.starData.getHabZoneStart() &&
				orbitRadius < 1500f + context.starData.getHabZoneStart() * 200f) {
				//&& radiusWithMoons <= planet.getRadius() + 500f) {
			if (planet.getSpec().getAtmosphereThickness() > 0) {
				WeightedRandomPicker<String> glowPicker = new WeightedRandomPicker<String>(random);
				glowPicker.add("banded", 10f);
				glowPicker.add("aurorae", 10f);

				String glow = glowPicker.pick();

				planet.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", glow));
				//system.getLightColor();
				if (context.center instanceof PlanetAPI) {
					planet.getSpec().setGlowColor(((PlanetAPI)context.center).getSpec().getCoronaColor());
				}
				planet.getSpec().setUseReverseLightForGlow(true);
				planet.getSpec().setAtmosphereThickness(0.5f);
				planet.getSpec().setCloudRotation(planet.getSpec().getCloudRotation() * (-1f - 2f * random.nextFloat()));

				if (planet.isGasGiant()) {// && radiusWithMoons <= planet.getRadius() + 500f) {
					system.addCorona(planet, Terrain.CORONA_AKA_MAINYU,
							300f + 200f * random.nextFloat(), // radius outside planet
							5f, // burn level of "wind"
							0f, // flare probability
							1f // CR loss mult while in it
							);
				}
			}
		}

		planet.applySpecChanges();

		PlanetConditionGenerator.generateConditionsForPlanet(context, planet);


		GeneratedPlanet generatedPlanetData = new GeneratedPlanet(parent, planet, isMoon, orbitDays, orbitRadius, angle);
		context.generatedPlanets.add(generatedPlanetData);

		// need to add this here because planet might have been moved after adding moons
		//if (context.parentCategory == null && context.lagrangeParent == null && planet.isGasGiant()) {
		if (!isMoon && context.lagrangeParent == null) {// && planet.isGasGiant()) {
			addStuffAtLagrangePoints(context, generatedPlanetData);
		}

		GenResult result = new GenResult();
		result.orbitalWidth = radius * 2f;
		result.onlyIncrementByWidth = false;
		result.entities.add(planet);
		return result;

    }

}
