package campaign.procgen;

import campaign.ids.SPP_Conditions;
import static campaign.ids.SPP_Planets.*;
import campaign.ids.SPP_Tags;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import util.SPP_Misc;

/**
 * Author: SafariJohn
 */
public class SPP_CrushingGravityScript {
    public static final float MIN = 200;

    public static final Map<String, Float> planetTypes = new HashMap<>();

    static {
        planetTypes.put(GAS_GIANT, 1f);
        planetTypes.put(ICE_GIANT, 1f);
        planetTypes.put(TOXIC_WORLD, 1f);
        planetTypes.put(ROCKY_METALLIC, 1f);
        planetTypes.put(ROCKY_UNSTABLE, 1f);
    }

    public static void run(SectorAPI sector) {
        List<StarSystemAPI> systems = sector.getStarSystems();
        List<PlanetAPI> planets = new ArrayList<>();
        for (StarSystemAPI system : systems) {
            planets.addAll(system.getPlanets());
        }

        for (PlanetAPI planet : planets) {
            if (planet.isStar()) continue;
            if (planet.isSystemCenter()) continue;

//            if (planetTypes.containsKey(planet.getTypeId())
//                        && planetTypes.get(planet.getTypeId()) > new Random().nextFloat()) {

                if (planet.getRadius() < MIN) continue;

                MarketAPI market = planet.getMarket();
                if (market == null) market = SPP_Misc.createPlanetConditionMarket(planet);

                if (!market.isPlanetConditionMarketOnly()) continue;
                if (market.hasCondition(Conditions.HABITABLE)) continue;
                if (market.hasCondition(Conditions.LOW_GRAVITY)) continue;
                if (market.hasCondition(SPP_Conditions.CLOUD_SEA)) continue;
                if (market.hasCondition(SPP_Conditions.CRUSHING_GRAVITY)) continue;
                if (market.getMemoryWithoutUpdate().getBoolean(SPP_Tags.MEMKEY_NO_CRUSHING)) continue;

                market.removeCondition(Conditions.HIGH_GRAVITY);
                MarketConditionAPI mc = market.getSpecificCondition(market.addCondition(SPP_Conditions.CRUSHING_GRAVITY));
                mc.setSurveyed(true);

                // Need to remove ruins and populations
//                market.removeCondition(Conditions.DECIVILIZED);
//                market.removeCondition(SPP_Conditions.PRIMITIVES);
//                market.removeCondition(SPP_Conditions.NATION_STATES);
//                market.removeCondition(SPP_Conditions.XENOPHOBES);
//                market.removeCondition(SPP_Conditions.XENOPHOBES_SUBDUED);

//                int population = SPP_PortFunctions.getPopulationSize(market);
//                if (population > 0) {
//                    market.removeCondition(SPP_PortFunctions.getPopulationConditionId(population));
//                    String token = market.addCondition(SPP_Conditions.POPULATION_0);
//                    if (market.getSurveyLevel() == MarketAPI.SurveyLevel.FULL) market.getSpecificCondition(token).setSurveyed(true);
//                }

                market.removeCondition(Conditions.RUINS_SCATTERED);
                market.removeCondition(Conditions.RUINS_WIDESPREAD);
                market.removeCondition(Conditions.RUINS_EXTENSIVE);
                market.removeCondition(Conditions.RUINS_VAST);

                market.removeCondition(Conditions.DECIVILIZED);

                market.reapplyConditions();
//            }
        }

    }
}
