package campaign.procgen;

import campaign.ids.SPP_Conditions;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignTerrainAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin;
import java.util.ArrayList;
import java.util.List;
import util.SPP_Misc;

/**
 * Author: SafariJohn
 */
public class SPP_MagneticFieldScript {

    public static void run(SectorAPI sector) {
        List<StarSystemAPI> systems = sector.getStarSystems();
        List<SectorEntityToken> entities = new ArrayList<>();
        for (StarSystemAPI system : systems) {
            entities.addAll(system.getEntitiesWithTag(Tags.TERRAIN));
        }

        for (SectorEntityToken entity : entities) {
            if (entity instanceof CampaignTerrainAPI) {

                if (((CampaignTerrainAPI) entity).getPlugin() instanceof MagneticFieldTerrainPlugin) {

                    if (!(entity.getOrbitFocus() instanceof PlanetAPI)) continue;

                    PlanetAPI focus = (PlanetAPI) entity.getOrbitFocus();
                    if (focus.isStar() || focus.isSystemCenter()) continue;

                    MarketAPI market = focus.getMarket();
                    if (market == null) market = SPP_Misc.createPlanetConditionMarket(focus);

                    if (!focus.getTypeId().equals("irradiated") && market.hasCondition(Conditions.IRRADIATED)) {
                        market.removeCondition(Conditions.IRRADIATED);
                    }

                    MarketConditionAPI mc = market.getSpecificCondition(market.addCondition(SPP_Conditions.MAGNETIC_FIELD));
                    mc.setSurveyed(true);

                    market.reapplyConditions();
                }
            }
        }

    }
}
