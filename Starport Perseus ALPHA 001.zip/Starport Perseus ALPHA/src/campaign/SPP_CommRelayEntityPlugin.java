package campaign;

import com.fs.starfarer.api.impl.campaign.CommRelayEntityPlugin;
import com.fs.starfarer.api.impl.campaign.econ.CommRelayCondition;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

public class SPP_CommRelayEntityPlugin extends CommRelayEntityPlugin {

    @Override
	public void printEffect(TooltipMakerAPI text, float pad) {
//		int bonus = Math.abs(Math.round(
//					CommRelayCondition.NO_RELAY_PENALTY - CommRelayCondition.COMM_RELAY_BONUS));
//		if (isMakeshift()) {
//			bonus = Math.abs(Math.round(
//					CommRelayCondition.NO_RELAY_PENALTY - CommRelayCondition.MAKESHIFT_COMM_RELAY_BONUS));
//		}
		int bonus = Math.abs(Math.round(
				CommRelayCondition.COMM_RELAY_BONUS));
		if (isMakeshift()) {
			bonus = Math.abs(Math.round(
					CommRelayCondition.MAKESHIFT_COMM_RELAY_BONUS));
		}
		text.addPara(BaseIntelPlugin.INDENT + "%s stability for same-faction ports in system",
				pad, Misc.getHighlightColor(), "+" + bonus);
	}

    @Override
	public void addHackStatusToTooltip(TooltipMakerAPI text, float pad) {
//		int bonus = Math.abs(Math.round(
//				CommRelayCondition.NO_RELAY_PENALTY - CommRelayCondition.COMM_RELAY_BONUS));
//		if (isMakeshift()) {
//			bonus = Math.abs(Math.round(
//				CommRelayCondition.NO_RELAY_PENALTY - CommRelayCondition.MAKESHIFT_COMM_RELAY_BONUS));
//		}
		int bonus = Math.abs(Math.round(
				CommRelayCondition.COMM_RELAY_BONUS));
		if (isMakeshift()) {
			bonus = Math.abs(Math.round(
					CommRelayCondition.MAKESHIFT_COMM_RELAY_BONUS));
		}

		if (isHacked()) {
			text.addPara("%s stability for in-system ports",
					 pad, Misc.getHighlightColor(), "+" + bonus);
			text.addPara("Comm sniffer installed", Misc.getTextColor(), pad);
		} else {
			text.addPara("%s stability for same-faction ports in-system",
					 pad, Misc.getHighlightColor(), "+" + bonus);

		}
	}

}



