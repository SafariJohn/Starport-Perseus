package campaign;

import campaign.econ.SPP_OrbitalBlockCondition;
import campaign.econ.SPP_PlanetBlockCondition;
import campaign.econ.SPP_ResourceDepositsCondition;
import campaign.ids.SPP_Conditions;
import campaign.ids.SPP_Industries;
import campaign.ids.SPP_MemKeys;
import campaign.ids.SPP_Tags;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.econ.EconomyAPI.EconomyUpdateListener;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;
import java.util.ArrayList;
import java.util.List;
import util.SPP_Misc;

/**
 * Author: SafariJohn
 */
public class SPP_CoreColonizationCleanup implements EconomyUpdateListener {
    public static final String CLEANED_MARKET = "$SPP_cleanedMarket";

    @Override
    public void commodityUpdated(String commodityId) {}

    @Override
    public void economyUpdated() {
        List<MarketAPI> markets = Global.getSector().getEconomy().getMarketsCopy();

        for (MarketAPI market : markets) {
            if (market.getMemoryWithoutUpdate().getBoolean(CLEANED_MARKET)) continue;

            // Flag original markets during new game creation
            if (Global.getSector().isInNewGameAdvance()) {
                market.getMemoryWithoutUpdate().set(CLEANED_MARKET, true);
            }


            // Find new player market
            if (market.isPlayerOwned()) {
                // Flag it
                market.getMemoryWithoutUpdate().set(CLEANED_MARKET, true);

                // Adjust size to 1
                market.setSize(1);

                // Remove false Pop3 condition
                MarketConditionAPI real = null;
                MarketConditionAPI fake = null;

                for (MarketConditionAPI mc : market.getConditions()) {
                    if (mc.getId().equals("population_3") && fake == null) {
                        fake = mc;
                    } else if (mc.getId().contains("population_")) {
                        real = mc;
                    }
                }

                if (fake != null && real != null) {
                    market.removeSpecificCondition(fake.getId());

                    if (real.getId().equals(fake.getId())) {
                        market.addCondition(real);
                    }
                }

                // Finish Population industry construction
                Industry population = market.getIndustry(SPP_Industries.LOCAL_ECONOMY);
                if (population == null) {
                    market.addIndustry(SPP_Industries.LOCAL_ECONOMY);
                    population = market.getIndustry(SPP_Industries.LOCAL_ECONOMY);
                    population.finishBuildingOrUpgrading();
                } else {
                    population.finishBuildingOrUpgrading();
                }

                // Attach moon/parent
                PlanetAPI other = SPP_Misc.getMoonOrParent(market.getPlanetEntity());
                if (other != null) {
                    MarketAPI oMarket = other.getMarket();
                    // Check if can be part of a market
                    // Station block + port block = nope
                    boolean orbitAllowed = true;
                    boolean planetAllowed = true;
                    for (MarketConditionAPI mc : oMarket.getConditions()) {
                        if (mc.getPlugin() instanceof SPP_PlanetBlockCondition) {
                            planetAllowed = false;
                        }

                        if (mc.getPlugin() instanceof SPP_OrbitalBlockCondition) {
                            orbitAllowed = false;
                        }

                        if (mc.getId().equals(SPP_Conditions.CLOSE_MOON)
                                    || mc.getId().equals(SPP_Conditions.MOON)) {
                            orbitAllowed = false;
                        }
                    }

                    if (orbitAllowed || planetAllowed) {
                        // Save conditions
                        List<String> savedConditions = new ArrayList<>();
                        for (MarketConditionAPI mc : oMarket.getConditions()) {
                            if (!(mc.getPlugin() instanceof SPP_ResourceDepositsCondition)) {
                                // Store in memory
                                savedConditions.add(mc.getId());
                            }
                        }
                        other.getMemoryWithoutUpdate().set(SPP_MemKeys.LUNAR_CONDITIONS, savedConditions);

                        // Attach
                        other.setFaction(market.getFactionId());
                        other.setMarket(market);
                        market.getConnectedEntities().add(other);
                    }
                }

                SPP_ImmigrationScript script = new SPP_ImmigrationScript(market);
                market.getContainingLocation().addScript(script);
                market.getMemoryWithoutUpdate().set(SPP_ImmigrationScript.MEM_KEY, script);
                market.getMemoryWithoutUpdate().set(SPP_Tags.MEMKEY_POP_GROWTH, true);

                // Anything else?
            }
        }
    }

    @Override
    public boolean isEconomyListenerExpired() {
        return false;
    }

}
