package campaign;

import campaign.econ.SPP_ShipQuality;
import campaign.intel.SPP_PersonBountyIntel;
import campaign.intel.SPP_PersonBountyManager;
import campaign.intel.bases.*;
import campaign.intel.deciv.SPP_DecivTracker;
import campaign.intel.punitive.SPP_PunitiveExpeditionManager;
import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.GenericPluginManagerAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.listeners.CoreDiscoverEntityPlugin;
import com.fs.starfarer.api.impl.campaign.*;
import com.fs.starfarer.api.impl.campaign.command.WarSimScript;
import com.fs.starfarer.api.impl.campaign.fleets.CustomFleets;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.intel.*;
import com.fs.starfarer.api.impl.campaign.intel.inspection.HegemonyInspectionManager;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.SalvageGenFromSeed;
import com.fs.starfarer.api.plugins.impl.CoreBuildObjectiveTypePicker;
import com.thoughtworks.xstream.XStream;

public class SPP_CoreLifecyclePluginImpl extends CoreLifecyclePluginImpl {

    @Override
    public void onGameLoad(boolean newGame) {
		econPostSaveRestore();

		// the token replacement generators don't get saved
		// add them on every game load
		Global.getSector().getRules().addTokenReplacementGenerator(new SPP_CoreRuleTokenReplacementGeneratorImpl());

		if (!newGame) {
			addJunk();
			regenAsteroids();
		}

		addScriptsIfNeeded();

		verifyFactionData();
    }

    @Override
    protected void addScriptsIfNeeded() {
		SPP_ShipQuality.getInstance();
		//ConditionManager.getInstance();

		SectorAPI sector = Global.getSector();
		GenericPluginManagerAPI plugins = sector.getGenericPlugins();
		if (!plugins.hasPlugin(SalvageGenFromSeed.SalvageDefenderModificationPluginImpl.class)) {
			plugins.addPlugin(new SalvageGenFromSeed.SalvageDefenderModificationPluginImpl(), true);
		}
		if (!plugins.hasPlugin(CoreDiscoverEntityPlugin.class)) {
			plugins.addPlugin(new CoreDiscoverEntityPlugin(), true);
		}
		if (!plugins.hasPlugin(CoreBuildObjectiveTypePicker.class)) {
			plugins.addPlugin(new CoreBuildObjectiveTypePicker(), true);
		}
		if (!plugins.hasPlugin(SPP_AbandonMarketPluginImpl.class)) {
			plugins.addPlugin(new SPP_AbandonMarketPluginImpl(), true);
		}
		if (!plugins.hasPlugin(SPP_StabilizeMarketPluginImpl.class)) {
			plugins.addPlugin(new SPP_StabilizeMarketPluginImpl(), true);
		}


		if (!sector.hasScript(WarSimScript.class)) {
			sector.addScript(new WarSimScript());
		}
		if (!sector.hasScript(SPP_PersonBountyManager.class)) {
			sector.addScript(new SPP_PersonBountyManager());
		}
		if (!sector.hasScript(SystemBountyManager.class)) {
			sector.addScript(new SystemBountyManager());
		}

		if (!sector.hasScript(SPP_MinorMoonHidingScript.class)) {
			sector.addScript(new SPP_MinorMoonHidingScript());
		}

//		if (!sector.hasScript(SPP_FactionEventManager.class)) {
//            SPP_FactionEventManager script = new SPP_FactionEventManager();
//			sector.addScript(script);
//            Global.getSector().getMemoryWithoutUpdate().set(SPP_FactionEventManager.KEY, script);
//		}

		if (!sector.hasScript(SPP_PirateBaseManager.class)) {
            SPP_PirateBaseManager script = new SPP_PirateBaseManager();
            script.init();
            sector.addScript(script);
		}
		if (!sector.hasScript(SPP_PlayerRelatedPirateBaseManager.class)) {
            SPP_PlayerRelatedPirateBaseManager script = new SPP_PlayerRelatedPirateBaseManager();
            script.init();
            sector.addScript(script);
		}

		if (!sector.hasScript(SPP_LuddicPathCampManager.class)) {
			sector.addScript(new SPP_LuddicPathCampManager());
		}
		if (!sector.hasScript(HegemonyInspectionManager.class)) {
			sector.addScript(new HegemonyInspectionManager());
		}
		if (!sector.hasScript(SPP_PunitiveExpeditionManager.class)) {
			sector.addScript(new SPP_PunitiveExpeditionManager());
		}
		if (!sector.hasScript(SPP_DecivTracker.class)) {
			sector.addScript(new SPP_DecivTracker());
		}

		if (!sector.hasScript(FactionHostilityManager.class)) {
			sector.addScript(new FactionHostilityManager());

			FactionHostilityManager.getInstance().startHostilities(Factions.HEGEMONY, Factions.TRITACHYON);
			FactionHostilityManager.getInstance().startHostilities(Factions.HEGEMONY, Factions.PERSEAN);
			FactionHostilityManager.getInstance().startHostilities(Factions.TRITACHYON, Factions.LUDDIC_CHURCH);
		}


		if (!sector.hasScript(GenericMissionManager.class)) {
			sector.addScript(new GenericMissionManager());
		}
		GenericMissionManager manager = GenericMissionManager.getInstance();
		if (!manager.hasMissionCreator(ProcurementMissionCreator.class)) {
			manager.addMissionCreator(new ProcurementMissionCreator());
		}
		if (!manager.hasMissionCreator(AnalyzeEntityIntelCreator.class)) {
			manager.addMissionCreator(new AnalyzeEntityIntelCreator());
		}
		if (!manager.hasMissionCreator(SurveyPlanetIntelCreator.class)) {
			manager.addMissionCreator(new SurveyPlanetIntelCreator());
		}

		addBarEvents();

		if (!sector.hasScript(SmugglingScanScript.class)) {
			sector.addScript(new SmugglingScanScript());
		}
    }

	@Override
	public void onNewGameAfterTimePass() {
		new CustomFleets().spawn();


		EveryFrameScript script = new AnalyzeEntityIntelCreator().createMissionIntel();
		if (script instanceof BaseIntelPlugin) {
			((BaseIntelPlugin)script).setPostingLocation(null);
			GenericMissionManager.getInstance().addActive(script);
		}

		script = new SurveyPlanetIntelCreator().createMissionIntel();
		if (script instanceof BaseIntelPlugin) {
			((BaseIntelPlugin)script).setPostingLocation(null);
			GenericMissionManager.getInstance().addActive(script);
		}



		for (EveryFrameScript s : SPP_PersonBountyManager.getInstance().getActive()) {
			SPP_PersonBountyIntel intel = (SPP_PersonBountyIntel) s;
			intel.setElapsedDays(intel.getElapsedDays() * (float) Math.random() * 0.25f);
		}

		// only leave bounties at ancyra, jangala, and one other market at game start
		boolean first = true;
		for (EveryFrameScript s : SystemBountyManager.getInstance().getActive()) {
			SystemBountyIntel intel = (SystemBountyIntel) s;
			if (intel.getMarket().getId().equals("ancyra_market") ||
					intel.getMarket().getId().equals("jangala")) {
				intel.setElapsedDays(intel.getElapsedDays() * (float) Math.random() * 0.25f);
				continue;
			}

			if (first) {
				first = false;
				intel.setElapsedDays(intel.getElapsedDays() * (float) Math.random() * 0.25f);
				continue;
			}

			intel.endImmediately();
		}


		MarketAPI jangala = Global.getSector().getEconomy().getMarket("jangala");
		if (jangala != null) {
			SystemBountyManager.getInstance().addOrResetBounty(jangala);
		}
	}

    @Override
    public void configureXStream(XStream x) {
        super.configureXStream(x);
		x.alias("DecivTracker", SPP_DecivTracker.class);
		x.alias("MonthlyReportNodeTooltipCreator", SPP_MonthlyReportNodeTooltipCreator.class);

		x.alias("NearbyEventsEvent", SPP_NearbyEventsEvent.class);
		x.aliasAttribute(SPP_NearbyEventsEvent.class, "derelictShipInterval", "dSI");
		x.aliasAttribute(SPP_NearbyEventsEvent.class, "distressCallInterval", "dCI");
		x.aliasAttribute(SPP_NearbyEventsEvent.class, "skipForDistressCalls", "sFDC");
    }

}
