package campaign.intel.bar;

import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.impl.campaign.intel.bar.PortsideBarData;
import java.util.*;
import org.apache.log4j.Logger;

/**
 * Author: SafariJohn
 */
public class SPP_MeetingManager {
    // When a mission intel wants to show a bar meeting, it makes a request to the meeting manager.
    // The meeting manager then makes sure that faction's representatives hang out at the bar until all
    // of that faction's missions have finished/canceled their meetings.

    private final Map<String, Map> meetingRequests;
    private final Map<String, SPP_RepresentativeBarEvent> representativesAtBar;

    public SPP_MeetingManager() {
        meetingRequests = new HashMap<>();
        representativesAtBar = new HashMap<>();
    }

    /**
     * Requests a meeting at the bar with the faction's representatives
     * @param faction
     * @param id A unique id for the meeting request
     * @param topicCreator
     */
    public void requestMeeting(FactionAPI faction, String id, SPP_RepMeetingTopicCreator topicCreator) {
        Map<String, SPP_RepMeetingTopicCreator> requests = meetingRequests.get(faction.getId());
        // Make sure List exists, add request to it later
        if (requests == null) {
            requests = new HashMap<>();
            meetingRequests.put(faction.getId(), requests);
        }

        if (requests.keySet().contains(id)) return;

        // If the rep is not at the bar, send them there.
        if (requests.isEmpty()) {
            SPP_RepresentativeBarEvent event = new SPP_RepresentativeBarEvent(faction);
            PortsideBarData.getInstance().addEvent(event);
            representativesAtBar.put(faction.getId(), event);
        }

        requests.put(id, topicCreator);
    }

    /**
     * Ends the meeting request
     * @param faction
     * @param id The meeting request's unique id
     */
    public void endRequest(FactionAPI faction, String id) {
        Map<String, SPP_RepMeetingTopicCreator> requests = meetingRequests.get(faction.getId());
        if (requests != null) {
            requests.remove(id);

            // If that was the last, rep leaves the bar.
            if (requests.isEmpty()) {
                SPP_RepresentativeBarEvent event = representativesAtBar.get(faction.getId());
                PortsideBarData.getInstance().removeEvent(event);
                representativesAtBar.remove(faction.getId());
            }
        }
    }

    /**
     * @param faction
     * @return list of faction's missions that are requesting a meeting
     */
    public Map<String, SPP_RepMeetingTopicCreator> getRequestingPlugins(FactionAPI faction) {
        Map<String, SPP_RepMeetingTopicCreator> requests = meetingRequests.get(faction.getId());
        // Make sure List exists, add request to it later
        if (requests == null) {
            requests = new HashMap<>();
            meetingRequests.put(faction.getId(), requests);
        }

        Logger.getLogger(SPP_MeetingManager.class).info(requests.size());

        return requests;
    }

    public SPP_RepMeetingTopicCreator getRequestingPlugin(FactionAPI faction, String id) {
        return getRequestingPlugins(faction).get(id);
    }
}
