package campaign.intel.bar.factionEvents;

import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.RepLevel;

/**
 * Author: SafariJohn
 */
public class SPP_SurveySaleEventGenerator implements SPP_FactionEventGenerator {
    private final RepLevel minimumRep;


    public SPP_SurveySaleEventGenerator() {
        minimumRep = RepLevel.FAVORABLE;
    }

    public SPP_SurveySaleEventGenerator(RepLevel minimumRep) {
        this.minimumRep = minimumRep;
    }

    @Override
    public SPP_BaseFactionEvent createEvent(FactionAPI faction) {
        return new SPP_SurveySaleEvent(faction, minimumRep);
    }

}
