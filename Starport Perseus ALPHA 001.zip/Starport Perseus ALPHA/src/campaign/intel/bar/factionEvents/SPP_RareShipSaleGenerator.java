package campaign.intel.bar.factionEvents;

import campaign.ids.SPP_MemKeys;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.util.WeightedRandomPicker;

/**
 * Author: SafariJohn
 */
public class SPP_RareShipSaleGenerator implements SPP_FactionEventGenerator {
    private final RepLevel minimumRep; // Available at any rep ATM


    public SPP_RareShipSaleGenerator() {
        minimumRep = RepLevel.FAVORABLE;
    }

//    public SPP_RareShipSaleGenerator(RepLevel minimumRep) {
//        this.minimumRep = minimumRep;
//    }

    @Override
    public SPP_BaseFactionEvent createEvent(FactionAPI faction) {
        // Pick a representative for this event
        WeightedRandomPicker<PersonAPI> picker = new WeightedRandomPicker<>();
        for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
            PersonAPI rep = (PersonAPI) market.getMemoryWithoutUpdate().get(SPP_MemKeys.FACTION_REP + "_" + faction.getId());
            if (rep == null) continue;

            picker.add(rep, 11 - market.getStabilityValue());
        }

        PersonAPI seller = picker.pick();

        return new SPP_RareShipSaleEvent(faction, seller, minimumRep);
    }

}
