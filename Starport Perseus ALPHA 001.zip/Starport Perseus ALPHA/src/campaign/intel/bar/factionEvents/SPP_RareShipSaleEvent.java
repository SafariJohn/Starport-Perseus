package campaign.intel.bar.factionEvents;

import campaign.intel.bar.SPP_RepresentativeMeeting;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.ImportantPeopleAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.combat.ShipHullSpecAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import java.util.HashMap;
import java.util.Map;

/**
 * Author: SafariJohn
 */
public class SPP_RareShipSaleEvent extends SPP_BaseFactionEvent {
    // Ship
    private final FleetMemberAPI ship;
    private final float price;
//    private final float repChange;
    private final PersonAPI seller;
    private final RepLevel minimumRep;

    public SPP_RareShipSaleEvent(FactionAPI faction, PersonAPI seller, RepLevel minimumRep) {
        super(faction);
        this.seller = seller;
        this.minimumRep = minimumRep;

        ship = pickShip();
        String shipName = faction.pickRandomShipName();
//        shipName = shipName.replaceFirst(faction.getEntityNamePrefix() + " ", "");
        ship.setShipName(shipName);
        if (ship == null) ended = true;

        price = calculatePrice();
    }

    private FleetMemberAPI pickShip() {
        Map<String, Float> ships = new HashMap<>();
        float total = 0;
        for (ShipHullSpecAPI spec : Global.getSettings().getAllShipHullSpecs()) {
            if (!faction.knowsShip(spec.getHullId())) continue;

            float sizeMult = 0;
            switch (spec.getHullSize()) {
                case CAPITAL_SHIP: sizeMult = 0.45f; break;
                case CRUISER: sizeMult = 0.9f; break;
                case DESTROYER: sizeMult = 5; break;
                case FRIGATE: sizeMult = 20; break;
            }

            float weight = spec.getBaseValue() * sizeMult; // Size multiplier - carefully adjusted in Excel
            weight *= weight; // Value^2 so more bigger, rarer ships are more likely

            ships.put(spec.getHullId() + "_Hull", weight);
            total += weight;
        }

        // Filter out ships below the average weight.
        WeightedRandomPicker<String> picker = new WeightedRandomPicker();
        float average = total / ships.size();
        for (String variantId : ships.keySet()) {
            float weight = ships.get(variantId);

            if (weight > average) {
                picker.add(variantId, weight);
            }
        }


        FleetMemberAPI pick = Global.getFactory().createFleetMember(FleetMemberType.SHIP, picker.pick());

        return pick;
    }

    private float calculatePrice() {
        if (ship == null) return -1;

        float value = ship.getBaseBuyValue();
//        value *= 1 + faction.getTariffFraction();
//        value *= 1.5f;

        return value;
    }

    @Override
    public void createConversationPlugin(SPP_RepresentativeMeeting plugin, Map<String, MemoryAPI> memoryMap) {
        topicPlugin = new SPP_RareShipSaleTopic(plugin, memoryMap, id, faction);
        ((SPP_RareShipSaleTopic) topicPlugin).init(ship, price);

        // Extend duration if very short
        if (getDurationRemaining() < 1) {
            setDuration(1);
        }
    }

    @Override
    protected void notifyEnded() {
        super.notifyEnded();

        ImportantPeopleAPI ip = Global.getSector().getImportantPeople();
        ip.returnPerson(seller, "bribe");
    }

    @Override
    public boolean shouldShow() {
        return seller == representative;
    }

}
