/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package campaign.intel.bar.factionEvents;

import com.fs.starfarer.api.campaign.FactionAPI;

/**
 *
 * @author SafariJohn
 */
public interface SPP_FactionEventGenerator {
    public SPP_BaseFactionEvent createEvent(FactionAPI faction);
}
