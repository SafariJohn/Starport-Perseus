package campaign.intel.bar.factionEvents;

import campaign.ids.SPP_MemKeys;
import campaign.intel.bar.SPP_MeetingManager;
import campaign.intel.bar.SPP_RepMeetingTopicPlugin;
import campaign.intel.bar.SPP_RepresentativeMeeting;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.OptionPanelAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.combat.EngagementResultAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.RepActionEnvelope;
import com.fs.starfarer.api.impl.campaign.rulecmd.AddRemoveCommodity;
import com.fs.starfarer.api.ui.LabelAPI;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import java.util.Map;
import org.lwjgl.input.Keyboard;

/**
 * Author: SafariJohn
 */
public class SPP_RareShipSaleTopic implements SPP_RepMeetingTopicPlugin {
    private static final String ACCEPT = "accept";
    private static final String GO_BACK = "back";

    private static final float REP_CHANGE = 0.02f;

    protected final String id;
    protected final FactionAPI faction;

    private SPP_RepresentativeMeeting meetingPlugin;
    private final Map<String, MemoryAPI> memoryMap;

    transient private InteractionDialogAPI dialog;
    transient private TextPanelAPI text;
    transient private OptionPanelAPI options;

    private FleetMemberAPI ship;
    private float price;
    private PersonAPI person;

    public SPP_RareShipSaleTopic(SPP_RepresentativeMeeting originalPlugin,
                Map<String, MemoryAPI> memoryMap, String id, FactionAPI faction) {
        meetingPlugin = originalPlugin;
        this.memoryMap = memoryMap;

        this.id = id;
        this.faction = faction;
    }

    @Override
    public void init(InteractionDialogAPI dialog) {
        this.dialog = dialog;
        text = dialog.getTextPanel();
        options = dialog.getOptionPanel();

        person = dialog.getInteractionTarget().getActivePerson();

        dialog.getVisualPanel().showFleetMemberInfo(ship);

		Color h = Misc.getHighlightColor();
		Color n = Misc.getNegativeHighlightColor();

        text.addPara(Misc.ucFirst("\"The " + ship.getShipName() + " is a pristine " + ship.getHullSpec().getNameWithDesignationWithDashClass()+ ",\" says "
                    + person.getRank()) + " " + person.getName().getLast() + ". \"It has been earmarked for sale at-cost to certain operators, "
                    + "such as yourself.\"");

		CargoAPI cargo = Global.getSector().getPlayerFleet().getCargo();
		int credits = (int) cargo.getCredits().get();
        boolean canAccept = price <= credits;
        LabelAPI label = text.addPara("You recall that a " + ship.getHullSpec().getHullName() + " costs about %s. You have %s available.",
                h,
                Misc.getDGSCredits(price),
                Misc.getDGSCredits(credits));
        label.setHighlightColors(canAccept ? h : n, h);
        label.setHighlight(Misc.getDGSCredits(price), Misc.getDGSCredits(credits));

        showOptions();
    }

    public void init(FleetMemberAPI ship, float price) {
        this.ship = ship;
        this.price = price;
    }

    @Override
    public void addOptionAndPrompt(InteractionDialogAPI dialog) {
        dialog.getTextPanel().addPara("A tripad lists off the specs for a " + ship.getHullSpec().getNameWithDesignationWithDashClass()+ ".");
        dialog.getOptionPanel().addOption("Ship Sale - " + ship.getHullSpec().getNameWithDesignationWithDashClass(), id);
    }

    @Override
    public void setMeetingPlugin(SPP_RepresentativeMeeting plugin) {
        meetingPlugin = plugin;
    }

    @Override
    public void optionSelected(String optionText, Object optionData) {
        dialog.getTextPanel().addParagraph(optionText, Global.getSettings().getColor("buttonText"));

        if (optionData == ACCEPT) {
            text.addPara("You transfer the credits and admire your new " + ship.getHullSpec().getHullName()+ ".");

            if (!Global.getSettings().isDevMode()) {
                Global.getSector().getPlayerFleet().getCargo().getCredits().subtract((int) price);
            }
            AddRemoveCommodity.addCreditsLossText((int) price, dialog.getTextPanel());

            // Add ship to fleet
            Global.getSector().getPlayerFleet().getFleetData().addFleetMember(ship);
            text.addPara("Gained " + ship.getHullSpec().getNameWithDesignationWithDashClass(), Misc.getPositiveHighlightColor());

            // Raise reputation with faction
            CoreReputationPlugin.CustomRepImpact impact = new CoreReputationPlugin.CustomRepImpact();
            impact.limit = RepLevel.COOPERATIVE;
            impact.delta = REP_CHANGE * 2 / 100;
            RepActionEnvelope envelope = new RepActionEnvelope(CoreReputationPlugin.RepActions.CUSTOM, impact, null, dialog.getTextPanel(), true);
            Global.getSector().adjustPlayerReputation(envelope, dialog.getInteractionTarget().getActivePerson());

            SPP_MeetingManager meetMan = (SPP_MeetingManager) Global.getSector()
                        .getMemoryWithoutUpdate().get(SPP_MemKeys.MEETING_MANAGER);
            ((SPP_RareShipSaleEvent) meetMan.getRequestingPlugin(faction, id)).endImmediately();
            meetMan.endRequest(faction, id);

            dialog.getVisualPanel().showPersonInfo(person);

            meetingPlugin.returnFromTopic(false);
            meetingPlugin = null;
        }



        if (optionData == GO_BACK) {
            dialog.getVisualPanel().showPersonInfo(person);

            meetingPlugin.returnFromTopic(false);
            meetingPlugin = null;
        }

    }

    private void showOptions() {
        options.clearOptions();

        options.addOption("Buy the " + ship.getShipName(), ACCEPT);

        int maxShips = Global.getSettings().getMaxShipsInFleet();
        int playerShips = Global.getSector().getPlayerFleet().getFleetData().getMembersListCopy().size();

        boolean fleetAtMaxSize = playerShips >= maxShips;

        if (fleetAtMaxSize || (Global.getSector().getPlayerFleet().getCargo().getCredits().get() < price
                    && !Global.getSettings().isDevMode())) {
            options.setEnabled(ACCEPT, false);

            if (fleetAtMaxSize) {
                options.setTooltip(ACCEPT, "You have too many ships in your fleet");
                options.setTooltipHighlights(ACCEPT, "You have too many ships in your fleet");
                options.setTooltipHighlightColors(ACCEPT, Misc.getNegativeHighlightColor());
            }
        }

        options.addOption("Back", GO_BACK);
        options.setShortcut(GO_BACK, Keyboard.KEY_ESCAPE, false, false, false, true);
    }

    public void optionMousedOver(String optionText, Object optionData) {}
    public void advance(float amount) {}
    public void backFromEngagement(EngagementResultAPI battleResult) {}
    public Object getContext() { return null; }

    @Override
    public Map<String, MemoryAPI> getMemoryMap() {
        return memoryMap;
    }

}
