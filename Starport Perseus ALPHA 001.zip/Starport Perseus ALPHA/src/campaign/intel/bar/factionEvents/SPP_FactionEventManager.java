package campaign.intel.bar.factionEvents;

import campaign.ids.SPP_Factions;
import campaign.intel.bar.factionEvents.bribery.SPP_OrphanageDonationEventGenerator;
import campaign.ids.SPP_MemKeys;
import campaign.intel.bar.SPP_MeetingManager;
import campaign.intel.bar.factionEvents.bribery.SPP_BribeEventGenerator;
import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.intel.BaseEventManager;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Author: SafariJohn
 */
public class SPP_FactionEventManager extends BaseEventManager {
    public static final WeightedRandomPicker<String> factions = new WeightedRandomPicker<>();
    static {
        factions.add(Factions.HEGEMONY, 1);
        factions.add(Factions.TRITACHYON, 1);
        factions.add(Factions.PERSEAN, 1);
        factions.add(Factions.DIKTAT, 1);
        factions.add(Factions.LUDDIC_CHURCH, 1);
        factions.add(Factions.LUDDIC_PATH, 1);
        // Mercenaries
        factions.add(SPP_Factions.BLACK_COMPANY, 1);
        factions.add(SPP_Factions.DAREDEVILS, 1);
        factions.add(SPP_Factions.DYNASTY, 1);
        // Independents
        factions.add(SPP_Factions.KO_COMBINE, 1);
    }

    public static final float DEFAULT_EVENT_WEIGHT = 10f;
    private static final Map<String, WeightedRandomPicker> eventGeneratorPickers = new LinkedHashMap<>();
    static {
        FactionAPI faction = Global.getSector().getFaction(Factions.HEGEMONY);
        addEventGenerator(faction, new SPP_SurveySaleEventGenerator());
        addEventGenerator(faction, new SPP_OrphanageDonationEventGenerator());
        addEventGenerator(faction, new SPP_BribeEventGenerator());
        addEventGenerator(faction, new SPP_RareShipSaleGenerator());

        faction = Global.getSector().getFaction(Factions.TRITACHYON);
        addEventGenerator(faction, new SPP_SurveySaleEventGenerator(RepLevel.SUSPICIOUS));
        addEventGenerator(faction, new SPP_BribeEventGenerator());
        addEventGenerator(faction, new SPP_RareShipSaleGenerator());

        faction = Global.getSector().getFaction(Factions.PERSEAN);
        addEventGenerator(faction, new SPP_SurveySaleEventGenerator());
        addEventGenerator(faction, new SPP_OrphanageDonationEventGenerator(), DEFAULT_EVENT_WEIGHT / 2);
        addEventGenerator(faction, new SPP_BribeEventGenerator());
        addEventGenerator(faction, new SPP_RareShipSaleGenerator());

        faction = Global.getSector().getFaction(Factions.DIKTAT);
        addEventGenerator(faction, new SPP_SurveySaleEventGenerator());
        addEventGenerator(faction, new SPP_BribeEventGenerator());
        addEventGenerator(faction, new SPP_RareShipSaleGenerator());

        faction = Global.getSector().getFaction(Factions.LUDDIC_CHURCH);
        addEventGenerator(faction, new SPP_SurveySaleEventGenerator());
        addEventGenerator(faction, new SPP_BribeEventGenerator());
        addEventGenerator(faction, new SPP_RareShipSaleGenerator());

        faction = Global.getSector().getFaction(Factions.LUDDIC_PATH);
        addEventGenerator(faction, new SPP_SurveySaleEventGenerator(RepLevel.INHOSPITABLE));
        addEventGenerator(faction, new SPP_BribeEventGenerator());
        addEventGenerator(faction, new SPP_RareShipSaleGenerator());

        faction = Global.getSector().getFaction(SPP_Factions.BLACK_COMPANY);
        addEventGenerator(faction, new SPP_BribeEventGenerator());
        addEventGenerator(faction, new SPP_RareShipSaleGenerator());

        faction = Global.getSector().getFaction(SPP_Factions.DAREDEVILS);
        addEventGenerator(faction, new SPP_BribeEventGenerator());
        addEventGenerator(faction, new SPP_RareShipSaleGenerator());

        faction = Global.getSector().getFaction(SPP_Factions.DYNASTY);
        addEventGenerator(faction, new SPP_BribeEventGenerator());
        addEventGenerator(faction, new SPP_RareShipSaleGenerator());

        faction = Global.getSector().getFaction(SPP_Factions.KO_COMBINE);
        addEventGenerator(faction, new SPP_SurveySaleEventGenerator(RepLevel.SUSPICIOUS));
        addEventGenerator(faction, new SPP_BribeEventGenerator());
        addEventGenerator(faction, new SPP_RareShipSaleGenerator());
    }

    public static WeightedRandomPicker<SPP_FactionEventGenerator> getEventPicker(FactionAPI faction) {
        return eventGeneratorPickers.get(faction.getId());
    }

    public static void addEventGenerator(FactionAPI faction, SPP_FactionEventGenerator event) {
        addEventGenerator(faction, event, DEFAULT_EVENT_WEIGHT);
    }

    public static void addEventGenerator(FactionAPI faction, SPP_FactionEventGenerator event, float weight) {
        WeightedRandomPicker picker = eventGeneratorPickers.get(faction.getId());
        if (picker == null) {
            picker = new WeightedRandomPicker();
            eventGeneratorPickers.put(faction.getId(), picker);
        }

        picker.add(event, weight);
    }


	public static final String KEY = "$SPP_factionEventGenerator";

	public static SPP_FactionEventManager getInstance() {
		Object test = Global.getSector().getMemoryWithoutUpdate().get(KEY);
		return (SPP_FactionEventManager) test;
	}

	@Override
	protected EveryFrameScript createEvent() {
		if ((float) Math.random() < 0.75f) return null;

        // Pick a faction
        FactionAPI faction = Global.getSector().getFaction(factions.pick());

        // Pick an event
        SPP_BaseFactionEvent event = pickEvent(faction);

        // Check for failed construction
		if (event == null || event.isDone()) return null;

        // Request meeting
        SPP_MeetingManager meetMan = (SPP_MeetingManager) Global.getSector()
                    .getMemoryWithoutUpdate().get(SPP_MemKeys.MEETING_MANAGER);
        meetMan.requestMeeting(faction, event.getId(), event);

		return event;
	}

    private SPP_BaseFactionEvent pickEvent(FactionAPI faction) {
        WeightedRandomPicker<SPP_FactionEventGenerator> picker = getEventPicker(faction);
        SPP_FactionEventGenerator gen = picker.pick();
        return gen.createEvent(faction);
    }

	@Override
	protected int getMinConcurrent() {
		return Global.getSettings().getInt("minPersonBounties") * 5;
	}
	@Override
	protected int getMaxConcurrent() {
		return Global.getSettings().getInt("maxPersonBounties") * 5;
	}

}
