package campaign.intel.bar.factionEvents.bribery;

import campaign.intel.bar.SPP_RepresentativeMeeting;
import campaign.intel.bar.factionEvents.SPP_BaseFactionEvent;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.ImportantPeopleAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import java.util.Map;
import java.util.Random;

/**
 * Author: SafariJohn
 */
public class SPP_BribeEvent extends SPP_BaseFactionEvent {
    protected enum BriberyType {
        EXPENSIVE, // Raises prices
        EXPENSIVE_HAUGHTY, // As above, but ends event if offered cheap option
        EXPENSIVE_SAFE, // Keeps price the same
        AVERAGE_SAFE, // Identical to above, but accepts average option
        AVERAGE, // Raises prices if offered cheap option
        CHEAP // Accepts first offer
    }

    private final float price;
    private final float repChange;
    private final PersonAPI bribeTarget;
    private BriberyType type;

    public SPP_BribeEvent(FactionAPI faction, PersonAPI bribeTarget) {
        super(faction);

        this.bribeTarget = bribeTarget;

        Random rand = new Random();

        repChange = 2 + rand.nextInt(4);

        // Price is randomized and more expensive the higher (or lower) rep you have.
        float personRep = Math.abs(bribeTarget.getRelToPlayer().getRel());
        float factionRep = Math.abs(faction.getRelToPlayer().getRel());

        float p = repChange * 2 + rand.nextInt(4);
        p *= 10 * (1 + ((personRep + factionRep) / 2));
        price = 1000 * (int) p;

        int r = new Random().nextInt(6);
        switch (r) {
            case 0: type = BriberyType.CHEAP;
                break;
            case 1: type = BriberyType.AVERAGE_SAFE;
                break;
            case 2: type = BriberyType.AVERAGE;
                break;
            case 3: type = BriberyType.EXPENSIVE_SAFE;
                break;
            case 4: type = BriberyType.EXPENSIVE_HAUGHTY;
                break;
            case 5: type = BriberyType.EXPENSIVE;
        }
    }

    @Override
    public void createConversationPlugin(SPP_RepresentativeMeeting plugin, Map<String, MemoryAPI> memoryMap) {
        topicPlugin = new SPP_BribeTopic(plugin, memoryMap, id, faction);
        ((SPP_BribeTopic) topicPlugin).init(price, repChange, type);

        // Extend duration if very short
        if (getDurationRemaining() < 1) {
            setDuration(1);
        }
    }

    @Override
    protected void notifyEnded() {
        super.notifyEnded();

        ImportantPeopleAPI ip = Global.getSector().getImportantPeople();
        ip.returnPerson(bribeTarget, "bribe");
    }

    @Override
    public boolean shouldShow() {
        return bribeTarget == representative;
    }
}
