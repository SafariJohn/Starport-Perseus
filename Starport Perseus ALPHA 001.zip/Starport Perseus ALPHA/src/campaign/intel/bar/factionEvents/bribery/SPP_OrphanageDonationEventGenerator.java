package campaign.intel.bar.factionEvents.bribery;

import campaign.ids.SPP_MemKeys;
import campaign.intel.bar.factionEvents.SPP_BaseFactionEvent;
import campaign.intel.bar.factionEvents.SPP_FactionEventGenerator;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.characters.ImportantPeopleAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.util.WeightedRandomPicker;

/**
 * Author: SafariJohn
 */
public class SPP_OrphanageDonationEventGenerator implements SPP_FactionEventGenerator {
    @Override
    public SPP_BaseFactionEvent createEvent(FactionAPI faction) {
        // Pick a representative for this event
        ImportantPeopleAPI ip = Global.getSector().getImportantPeople();
        WeightedRandomPicker<PersonAPI> picker = new WeightedRandomPicker<>();
        for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
            PersonAPI rep = (PersonAPI) market.getMemoryWithoutUpdate().get(SPP_MemKeys.FACTION_REP + "_" + faction.getId());
            if (rep == null) continue;
            if (!ip.canCheckOutPerson(rep, "bribe")) continue;

            picker.add(rep, 11 - market.getStabilityValue());
        }

        PersonAPI bribeTarget = picker.pick();
        ip.checkOutPerson(bribeTarget, "bribe");

        return new SPP_OrphanageDonationEvent(faction, bribeTarget);
    }
}
