package campaign.intel.bar.factionEvents.bribery;

import campaign.intel.bar.SPP_RepresentativeMeeting;
import campaign.intel.bar.factionEvents.SPP_BaseFactionEvent;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.ImportantPeopleAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import java.util.Map;
import java.util.Random;

/**
 * Author: SafariJohn
 */
public class SPP_OrphanageDonationEvent extends SPP_BaseFactionEvent {
    private final float price;
    private final float repChange;
    private final PersonAPI bribeTarget;

    public SPP_OrphanageDonationEvent(FactionAPI faction, PersonAPI bribeTarget) {
        super(faction);

        this.bribeTarget = bribeTarget;

        Random rand = new Random();

        repChange = 2 + rand.nextInt(4);

        // Price is randomized and more expensive the higher (or lower) rep you have.
        float personRep = Math.abs(bribeTarget.getRelToPlayer().getRel());
        float factionRep = Math.abs(faction.getRelToPlayer().getRel());

        float p = repChange * 2 + rand.nextInt(4);
        p *= 10 * (1 + ((personRep + factionRep) / 2));
        price = 1000 * (int) p;
    }

    @Override
    public void createConversationPlugin(SPP_RepresentativeMeeting plugin, Map<String, MemoryAPI> memoryMap) {
        topicPlugin = new SPP_OrphanageDonationTopic(plugin, memoryMap, id, faction);
        ((SPP_OrphanageDonationTopic) topicPlugin).init(price, repChange);

        // Extend duration if very short
        if (getDurationRemaining() < 1) {
            setDuration(1);
        }
    }

    @Override
    protected void notifyEnded() {
        super.notifyEnded();

        ImportantPeopleAPI ip = Global.getSector().getImportantPeople();
        ip.returnPerson(bribeTarget, "bribe");
    }

    @Override
    public boolean shouldShow() {
        return bribeTarget == representative;
    }
}
