package campaign.intel.bar.factionEvents.bribery;

import campaign.ids.SPP_MemKeys;
import campaign.intel.bar.SPP_MeetingManager;
import campaign.intel.bar.SPP_RepMeetingTopicPlugin;
import campaign.intel.bar.SPP_RepresentativeMeeting;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.OptionPanelAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.combat.EngagementResultAPI;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.CustomRepImpact;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.RepActionEnvelope;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.RepActions;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.rulecmd.AddRemoveCommodity;
import com.fs.starfarer.api.util.Misc;
import java.util.Map;
import org.lwjgl.input.Keyboard;

/**
 * Author: SafariJohn
 */
public class SPP_OrphanageDonationTopic implements SPP_RepMeetingTopicPlugin {
    private static final String ACCEPT = "accept";
    private static final String GO_BACK = "back";

    protected final String id;
    protected final FactionAPI faction;

    private SPP_RepresentativeMeeting meetingPlugin;
    private final Map<String, MemoryAPI> memoryMap;

    transient private InteractionDialogAPI dialog;
    transient private TextPanelAPI text;
    transient private OptionPanelAPI options;

    private float price;
    private float repChange;
    private PersonAPI person;

    public SPP_OrphanageDonationTopic(SPP_RepresentativeMeeting originalPlugin,
                Map<String, MemoryAPI> memoryMap, String id, FactionAPI faction) {
        meetingPlugin = originalPlugin;
        this.memoryMap = memoryMap;

        this.id = id;
        this.faction = faction;
    }

    @Override
    public void init(InteractionDialogAPI dialog) {
        this.dialog = dialog;
        text = dialog.getTextPanel();
        options = dialog.getOptionPanel();

        person = dialog.getInteractionTarget().getActivePerson();

        // Adjust price slightly based on person's relation?
//        price *= 1 - (person.getRelToPlayer().getRel() / 10);

        text.addPara(Misc.ucFirst(person.getRank()) + " " + person.getName().getLast() + " says, \"Would you "
                    + "consider a small donation to the " + faction.getDisplayName()  + " Orphanages Association? " + Misc.getWithDGS(price) + " credits "
                    + "would be appropriate.\" ");
        text.highlightInLastPara(Misc.getWithDGS(price));

        String navy = "navy";
        if (faction.getId().equals(Factions.HEGEMONY)) navy = "Armada";
        if (faction.getId().equals(Factions.PERSEAN)) navy = "Kazeron Academy";

        text.addPara("The Orphanages Association — raising war orphans to join the " + navy + " since Cycle 73. Making a "
                    + "donation would look good, at least.");

        showOptions();
    }

    public void init(float price, float repChange) {
        this.price = price;
        this.repChange = repChange;
    }

    @Override
    public void addOptionAndPrompt(InteractionDialogAPI dialog) {
        dialog.getTextPanel().addPara("An ad-holo displays a loop of pitiful-looking orphans.");

        dialog.getOptionPanel().addOption("Examine the holographic guilt-trip", id);
    }

    @Override
    public void setMeetingPlugin(SPP_RepresentativeMeeting plugin) {
        meetingPlugin = plugin;
    }

    @Override
    public void optionSelected(String optionText, Object optionData) {
        dialog.getTextPanel().addParagraph(optionText, Global.getSettings().getColor("buttonText"));

        if (optionData == ACCEPT) {

            if (!Global.getSettings().isDevMode()) {
                Global.getSector().getPlayerFleet().getCargo().getCredits().subtract((int) price);
            }
			AddRemoveCommodity.addCreditsLossText((int) price, dialog.getTextPanel());

            // Raise reputation with faction
            CustomRepImpact impact = new CustomRepImpact();
            impact.limit = RepLevel.FRIENDLY;
            impact.delta = repChange / 100;
            RepActionEnvelope envelope = new RepActionEnvelope(RepActions.CUSTOM, impact, null, dialog.getTextPanel(), true);
            Global.getSector().adjustPlayerReputation(envelope, faction.getId());

            // Raise reputation with representative
            impact = new CustomRepImpact();
            impact.limit = RepLevel.COOPERATIVE;
            impact.delta = repChange * 2 / 100;
            envelope = new RepActionEnvelope(RepActions.CUSTOM, impact, null, dialog.getTextPanel(), true);
            Global.getSector().adjustPlayerReputation(envelope, dialog.getInteractionTarget().getActivePerson());

            SPP_MeetingManager meetMan = (SPP_MeetingManager) Global.getSector()
                        .getMemoryWithoutUpdate().get(SPP_MemKeys.MEETING_MANAGER);
            ((SPP_OrphanageDonationEvent) meetMan.getRequestingPlugin(faction, id)).endImmediately();
            meetMan.endRequest(faction, id);

            meetingPlugin.returnFromTopic(true);
            meetingPlugin = null;
        }

        if (optionData == GO_BACK) {
            meetingPlugin.returnFromTopic(false);
            meetingPlugin = null;
        }
    }

    protected void showOptions() {
        options.clearOptions();

        options.addOption("\"Donate\" " + Misc.getWithDGS(price) + " credits", ACCEPT);
        if (Global.getSector().getPlayerFleet().getCargo().getCredits().get() < price
                    && !Global.getSettings().isDevMode()) {
            options.setEnabled(ACCEPT, false);
        }

        options.addOption("Back", GO_BACK);
        options.setShortcut(GO_BACK, Keyboard.KEY_ESCAPE, false, false, false, true);
    }

    public void optionMousedOver(String optionText, Object optionData) {}
    public void advance(float amount) {}
    public void backFromEngagement(EngagementResultAPI battleResult) {}
    public Object getContext() { return null; }

    @Override
    public Map<String, MemoryAPI> getMemoryMap() {
        return memoryMap;
    }


}
