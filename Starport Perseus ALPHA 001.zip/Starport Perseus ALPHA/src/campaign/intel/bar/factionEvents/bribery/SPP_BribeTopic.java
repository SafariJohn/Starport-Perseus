package campaign.intel.bar.factionEvents.bribery;

import campaign.ids.SPP_MemKeys;
import campaign.intel.bar.SPP_MeetingManager;
import campaign.intel.bar.SPP_RepMeetingTopicPlugin;
import campaign.intel.bar.SPP_RepresentativeMeeting;
import campaign.intel.bar.factionEvents.bribery.SPP_BribeEvent.BriberyType;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.OptionPanelAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.FullName;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.combat.EngagementResultAPI;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.CustomRepImpact;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.RepActionEnvelope;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.RepActions;
import com.fs.starfarer.api.impl.campaign.rulecmd.AddRemoveCommodity;
import com.fs.starfarer.api.util.Misc;
import java.util.Map;
import org.lwjgl.input.Keyboard;

/**
 * Author: SafariJohn
 */
public class SPP_BribeTopic implements SPP_RepMeetingTopicPlugin {
    private static final String HIGH = "high";
    private static final String PAY_CONTINUE = "pay";
    private static final String MEDIUM = "medium";
    private static final String LOW = "low";
    private static final String GO_BACK = "back";

    protected final String id;
    protected final FactionAPI faction;


    private SPP_RepresentativeMeeting meetingPlugin;
    private final Map<String, MemoryAPI> memoryMap;

    transient private InteractionDialogAPI dialog;
    transient private TextPanelAPI text;
    transient private OptionPanelAPI options;

    private float price;
    private float repChange;
    private PersonAPI person;
    private BriberyType type;

    private boolean raisedLow;
    private boolean raisedMedium;

    public SPP_BribeTopic(SPP_RepresentativeMeeting originalPlugin,
                Map<String, MemoryAPI> memoryMap, String id, FactionAPI faction) {
        meetingPlugin = originalPlugin;
        this.memoryMap = memoryMap;

        this.id = id;
        this.faction = faction;

        raisedLow = false;
        raisedMedium = false;
    }

    @Override
    public void init(InteractionDialogAPI dialog) {
        this.dialog = dialog;
        text = dialog.getTextPanel();
        options = dialog.getOptionPanel();

        person = dialog.getInteractionTarget().getActivePerson();

        text.addPara(Misc.ucFirst(person.getRank()) + " " + person.getName().getLast() + " waits for you to continue.");

        showOptions();
    }

    public void init(float price, float repChange, BriberyType type) {
        this.price = price;
        this.repChange = repChange;
        this.type = type;
    }

    @Override
    public void addOptionAndPrompt(InteractionDialogAPI dialog) {
        dialog.getTextPanel().addPara("You notice a conspicuous TriAnon account number.");

        dialog.getOptionPanel().addOption("Start a credit transfer", id);
    }

    @Override
    public void setMeetingPlugin(SPP_RepresentativeMeeting plugin) {
        meetingPlugin = plugin;
    }

    @Override
    public void optionSelected(String optionText, Object optionData) {
        dialog.getTextPanel().addParagraph(optionText, Global.getSettings().getColor("buttonText"));

        if (optionData == HIGH) {
//            if (type == BriberyType.CHEAP) {
//                text.addPara(person.getRank() + " " + person.getName().getLast() + " appears shocked.");
//            }

            completeTransaction(optionData);
            return;
        }

        if (optionData == PAY_CONTINUE) {
            completeTransaction(optionData);
        }

        if (optionData == MEDIUM) {
            switch (type) {
                case AVERAGE:
                case AVERAGE_SAFE:
                case CHEAP:
                    completeTransaction(optionData);
                    break;
                case EXPENSIVE_HAUGHTY:
                case EXPENSIVE: price *= 1.5f;
                case EXPENSIVE_SAFE:
                    if (raisedLow && !raisedMedium) text.addPara(person.getRank() + " " + person.getName().getLast() + " raises " + getHisOrHer() + " eyebrow even higher.");
                    else text.addPara(person.getRank() + " " + person.getName().getLast() + " raises an eyebrow.");
                    raisedMedium = true;
                    raisedLow = true;
                    showOptions();
            }

            return;
        }

        if (optionData == LOW) {
            switch (type) {
                case EXPENSIVE_HAUGHTY:
                    text.addPara(person.getRank() + " " + person.getName().getLast() + " snorts derisively.");
                    cutTransaction();
                    break;
                case EXPENSIVE:
                case AVERAGE: price *= 1.5f;
                case EXPENSIVE_SAFE:
                case AVERAGE_SAFE:
                    raisedLow = true;
                    text.addPara(person.getRank() + " " + person.getName().getLast() + " raises an eyebrow.");
                    showOptions();
                    break;
                case CHEAP: completeTransaction(optionData);
            }

            return;
        }

        if (optionData == GO_BACK) {
            meetingPlugin.returnFromTopic(false);
            meetingPlugin = null;
        }
    }

    private String getHisOrHer() {
        if (person.getGender() == FullName.Gender.FEMALE) return "her";
        else return "his";
    }

    private void completeTransaction(Object optionData) {
        if (optionData == HIGH)  {
            price *= 1.5f;
            optionData = PAY_CONTINUE;
        }
        if (optionData == LOW) price *= 0.5f;

        if (optionData != PAY_CONTINUE) {
            text.addPara(person.getRank() + " " + person.getName().getLast() + " shows " + getHisOrHer() + " approval.");

            options.clearOptions();
            options.addOption("Pay " + Misc.getWithDGS(price) + " credits", PAY_CONTINUE);
            return;
        }

        text.addPara("You complete the transfer.");

        if (!Global.getSettings().isDevMode()) {
            Global.getSector().getPlayerFleet().getCargo().getCredits().subtract((int) price);
        }
        AddRemoveCommodity.addCreditsLossText((int) price, dialog.getTextPanel());

        text.addPara(person.getRank() + " " + person.getName().getLast() + " looks down at " + getHisOrHer() + " tripad and smiles.");

        // Raise reputation with faction
        CustomRepImpact impact = new CustomRepImpact();
        impact.limit = RepLevel.FRIENDLY;
        impact.delta = repChange / 100;
        RepActionEnvelope envelope = new RepActionEnvelope(RepActions.CUSTOM, impact, null, dialog.getTextPanel(), true);
        Global.getSector().adjustPlayerReputation(envelope, faction.getId());

        // Raise reputation with representative
        impact = new CustomRepImpact();
        impact.limit = RepLevel.COOPERATIVE;
        impact.delta = repChange * 2 / 100;
        envelope = new RepActionEnvelope(RepActions.CUSTOM, impact, null, dialog.getTextPanel(), true);
        Global.getSector().adjustPlayerReputation(envelope, dialog.getInteractionTarget().getActivePerson());


        SPP_MeetingManager meetMan = (SPP_MeetingManager) Global.getSector()
                    .getMemoryWithoutUpdate().get(SPP_MemKeys.MEETING_MANAGER);
        ((SPP_BribeEvent) meetMan.getRequestingPlugin(faction, id)).endImmediately();
        meetMan.endRequest(faction, id);

        meetingPlugin.returnFromTopic(true);
        meetingPlugin = null;
    }

    private void cutTransaction() {
        // Lower reputation with faction and representative
        faction.getRelToPlayer().adjustRelationship(-repChange / 2 / 100, RepLevel.INHOSPITABLE);
        dialog.getInteractionTarget().getActivePerson().getRelToPlayer().adjustRelationship(-repChange / 100, RepLevel.HOSTILE);

        SPP_MeetingManager meetMan = (SPP_MeetingManager) Global.getSector()
                    .getMemoryWithoutUpdate().get(SPP_MemKeys.MEETING_MANAGER);
        ((SPP_BribeEvent) meetMan.getRequestingPlugin(faction, id)).endImmediately();
        meetMan.endRequest(faction, id);

        meetingPlugin.returnFromTopic(true);
        meetingPlugin = null;
    }

    protected void showOptions() {
        options.clearOptions();

        options.addOption("Pay " + Misc.getWithDGS(price * 1.5f) + " credits", HIGH);
        if (Global.getSector().getPlayerFleet().getCargo().getCredits().get() < price * 1.5f
                    && !Global.getSettings().isDevMode()) {
            options.setEnabled(HIGH, false);
        }

        if (!raisedMedium) {
            options.addOption("\"" + Misc.getWithDGS(price) + "\"", MEDIUM);
            if (Global.getSector().getPlayerFleet().getCargo().getCredits().get() < price
                        && !Global.getSettings().isDevMode()) {
                options.setEnabled(MEDIUM, false);
            }
        }

        if (!raisedLow) {
            options.addOption("\"" + Misc.getWithDGS(price * 0.5f) + "\"", LOW);
            if (Global.getSector().getPlayerFleet().getCargo().getCredits().get() < price / 2
                        && !Global.getSettings().isDevMode()) {
                options.setEnabled(LOW, false);
            }
        }

        options.addOption("Back", GO_BACK);
        options.setShortcut(GO_BACK, Keyboard.KEY_ESCAPE, false, false, false, true);
    }

    public void optionMousedOver(String optionText, Object optionData) {}
    public void advance(float amount) {}
    public void backFromEngagement(EngagementResultAPI battleResult) {}
    public Object getContext() { return null; }

    @Override
    public Map<String, MemoryAPI> getMemoryMap() {
        return memoryMap;
    }


}
