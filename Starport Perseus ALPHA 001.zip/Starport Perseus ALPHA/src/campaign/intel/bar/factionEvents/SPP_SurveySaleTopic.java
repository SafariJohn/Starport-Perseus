package campaign.intel.bar.factionEvents;

import campaign.ids.SPP_MemKeys;
import campaign.intel.bar.SPP_MeetingManager;
import campaign.intel.bar.SPP_RepMeetingTopicPlugin;
import campaign.intel.bar.SPP_RepresentativeMeeting;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.OptionPanelAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.combat.EngagementResultAPI;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin;
import com.fs.starfarer.api.impl.campaign.rulecmd.AddRemoveCommodity;
import com.fs.starfarer.api.util.Misc;
import java.util.Map;
import org.lwjgl.input.Keyboard;

/**
 * Author: SafariJohn
 */
public class SPP_SurveySaleTopic implements SPP_RepMeetingTopicPlugin {
    private static final String ACCEPT = "accept";
    private static final String GO_BACK = "back";

    private static final float REP_CHANGE = 0.02f;

    protected final String id;
    protected final FactionAPI faction;

    transient private InteractionDialogAPI dialog;
    transient private TextPanelAPI text;
    transient private OptionPanelAPI options;

    private SPP_RepresentativeMeeting meetingPlugin;
    private StarSystemAPI system;
    private float price;
    private RepLevel minimumRep;
    private final Map<String, MemoryAPI> memoryMap;

    public SPP_SurveySaleTopic(SPP_RepresentativeMeeting originalPlugin,
                Map<String, MemoryAPI> memoryMap, String id, FactionAPI faction) {
        meetingPlugin = originalPlugin;
        this.memoryMap = memoryMap;

        this.id = id;
        this.faction = faction;
    }

    @Override
    public void init(InteractionDialogAPI dialog) {
        this.dialog = dialog;
        text = dialog.getTextPanel();
        options = dialog.getOptionPanel();

        showOptions();
    }

    public void init(StarSystemAPI system, float price, RepLevel minimumRep) {
        this.system = system;
        this.price = price;
        this.minimumRep = minimumRep;
    }

    @Override
    public void addOptionAndPrompt(InteractionDialogAPI dialog) {
        dialog.getTextPanel().addPara("You notice a tripad with survey data for the " + system.getNameWithLowercaseType() + ".");

        OptionPanelAPI options = dialog.getOptionPanel();
        options.addOption("Survey Data - " + system.getNameWithLowercaseType(), id);

        if (dialog.getInteractionTarget().getActivePerson().getRelToPlayer().isAtBest(minimumRep.getOneWorse())
                    && faction.getRelToPlayer().isAtBest(minimumRep.getOneWorse())) {

            if (!Global.getSettings().isDevMode()) options.setEnabled(id, false);

            options.setTooltip(id, "Req: " + minimumRep.getDisplayName().toLowerCase());
            options.setTooltipHighlights(id, "Req: " + minimumRep.getDisplayName().toLowerCase());
            options.setTooltipHighlightColors(id, Misc.getNegativeHighlightColor());
        }
    }

    @Override
    public void setMeetingPlugin(SPP_RepresentativeMeeting plugin) {
        meetingPlugin = plugin;
    }

    @Override
    public void optionSelected(String optionText, Object optionData) {
        dialog.getTextPanel().addParagraph(optionText, Global.getSettings().getColor("buttonText"));

        if (optionData == ACCEPT) {
            system.setEnteredByPlayer(true);

            for (PlanetAPI p : system.getPlanets()) {
                if (p.getMarket() == null) continue;

                Misc.setFullySurveyed(p.getMarket(), null, true);

                for (MarketConditionAPI mc : p.getMarket().getConditions()) {
                    if (mc.requiresSurveying()) {
                        mc.setSurveyed(true);
                    }
                }
            }

            if (!Global.getSettings().isDevMode()) {
                Global.getSector().getPlayerFleet().getCargo().getCredits().subtract((int) price);
            }
			AddRemoveCommodity.addCreditsLossText((int) price, dialog.getTextPanel());

//            // Raise reputation with faction
//            CoreReputationPlugin.CustomRepImpact impact = new CoreReputationPlugin.CustomRepImpact();
//            impact.limit = RepLevel.WELCOMING;
//            impact.delta = REP_CHANGE / 100;
//            CoreReputationPlugin.RepActionEnvelope envelope = new CoreReputationPlugin.RepActionEnvelope(CoreReputationPlugin.RepActions.CUSTOM, impact, null, dialog.getTextPanel(), true);
//            Global.getSector().adjustPlayerReputation(envelope, faction.getId());

            // Raise reputation with representative
            CoreReputationPlugin.CustomRepImpact impact = new CoreReputationPlugin.CustomRepImpact();
            impact.limit = RepLevel.FRIENDLY;
            impact.delta = REP_CHANGE * 2 / 100;
            CoreReputationPlugin.RepActionEnvelope envelope = new CoreReputationPlugin.RepActionEnvelope(CoreReputationPlugin.RepActions.CUSTOM, impact, null, dialog.getTextPanel(), true);
            Global.getSector().adjustPlayerReputation(envelope, dialog.getInteractionTarget().getActivePerson());

            SPP_MeetingManager meetMan = (SPP_MeetingManager) Global.getSector()
                        .getMemoryWithoutUpdate().get(SPP_MemKeys.MEETING_MANAGER);
            ((SPP_SurveySaleEvent) meetMan.getRequestingPlugin(faction, id)).endImmediately();
            meetMan.endRequest(faction, id);

            meetingPlugin.returnFromTopic(true);
            meetingPlugin = null;
        }

        if (optionData == GO_BACK) {
            meetingPlugin.returnFromTopic(false);
            meetingPlugin = null;
        }
    }

    protected void showOptions() {
        options.clearOptions();

        options.addOption("Pay " + Misc.getWithDGS(price) + " credits", ACCEPT);
        if (Global.getSector().getPlayerFleet().getCargo().getCredits().get() < price
                    && !Global.getSettings().isDevMode()) {
            options.setEnabled(ACCEPT, false);
        }

        options.addOption("Back", GO_BACK);
        options.setShortcut(GO_BACK, Keyboard.KEY_ESCAPE, false, false, false, true);
    }

    public void optionMousedOver(String optionText, Object optionData) {}
    public void advance(float amount) {}
    public void backFromEngagement(EngagementResultAPI battleResult) {}
    public Object getContext() { return null; }

    @Override
    public Map<String, MemoryAPI> getMemoryMap() {
        return memoryMap;
    }


}
