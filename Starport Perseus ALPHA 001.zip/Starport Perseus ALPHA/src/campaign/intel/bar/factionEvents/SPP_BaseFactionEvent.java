package campaign.intel.bar.factionEvents;

import campaign.ids.SPP_MemKeys;
import campaign.intel.bar.SPP_MeetingManager;
import campaign.intel.bar.SPP_RepMeetingTopicCreator;
import campaign.intel.bar.SPP_RepMeetingTopicPlugin;
import campaign.intel.bar.SPP_RepresentativeMeeting;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.util.Misc;
import java.util.Map;
import java.util.Random;

/**
 * Author: SafariJohn
 */
public abstract class SPP_BaseFactionEvent extends BaseIntelPlugin implements SPP_RepMeetingTopicCreator {
    protected final String id;
    protected final FactionAPI faction;

    protected PersonAPI representative;
    protected SPP_RepMeetingTopicPlugin topicPlugin;

    private float duration; // Days

    public SPP_BaseFactionEvent(FactionAPI faction) {
        id = Misc.genUID();
        this.faction = faction;

        duration = new Random().nextInt(10) + 20;
    }

    @Override
    protected void advanceImpl(float amount) {
        if (Global.getSector().isPaused()) return;

        float days = Global.getSector().getClock().convertToDays(amount);
        duration -= days;

        if (duration <= 0) {
            endImmediately();
        }
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public void setRepresentative(PersonAPI representative) {
        this.representative = representative;
    }

    @Override
    public PersonAPI getRepresentative() {
        return representative;
    }

    @Override
    public abstract void createConversationPlugin(SPP_RepresentativeMeeting plugin, Map<String, MemoryAPI> memoryMap);

    @Override
    public SPP_RepMeetingTopicPlugin getTopicPlugin() {
        return topicPlugin;
    }

    @Override
    public boolean shouldShow() {
        return true;
    }

    public float getDurationRemaining() {
        return duration;
    }

    public void setDuration(float duration) {
        this.duration = duration;
    }

    @Override
    protected void notifyEnded() {
        SPP_MeetingManager meetMan = (SPP_MeetingManager) Global.getSector()
                    .getMemoryWithoutUpdate().get(SPP_MemKeys.MEETING_MANAGER);
        meetMan.endRequest(faction, id);
    }

}
