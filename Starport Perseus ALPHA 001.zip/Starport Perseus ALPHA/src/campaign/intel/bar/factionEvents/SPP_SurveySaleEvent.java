package campaign.intel.bar.factionEvents;

import campaign.ids.SPP_MemKeys;
import campaign.intel.bar.SPP_MeetingManager;
import campaign.intel.bar.SPP_RepMeetingTopicPlugin;
import campaign.intel.bar.SPP_RepresentativeMeeting;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.procgen.themes.DerelictThemeGenerator;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import java.util.Map;

/**
 * Author: SafariJohn
 */
public class SPP_SurveySaleEvent extends SPP_BaseFactionEvent {
    private StarSystemAPI system;
    private float price;
    private RepLevel minimumRep;

    public SPP_SurveySaleEvent(FactionAPI faction, RepLevel minimumRep) {
        super(faction);

        this.minimumRep = minimumRep;

        pickSystem();
        if (system == null) ended = true;

        calculatePrice();
    }

    @Override
    protected void advanceImpl(float amount) {
        if (price == 0) endImmediately();

        super.advanceImpl(amount);
    }

    @Override
    public SPP_RepMeetingTopicPlugin getTopicPlugin() {
        calculatePrice();
        return topicPlugin;
    }

    @Override
    public void createConversationPlugin(SPP_RepresentativeMeeting plugin, Map<String, MemoryAPI> memoryMap) {
        calculatePrice();
        topicPlugin = new SPP_SurveySaleTopic(plugin, memoryMap, id, faction);
        ((SPP_SurveySaleTopic) topicPlugin).init(system, price, minimumRep);

        // Extend duration if very short
        if (getDurationRemaining() < 1) {
            setDuration(1);
        }
    }

    /**
     * Picks an unsurveyed or partially surveyed system.
     */
    private void pickSystem() {
        WeightedRandomPicker<StarSystemAPI> picker = new WeightedRandomPicker<>();
        for (StarSystemAPI s : Global.getSector().getStarSystems()) {
            if (s.getTags().contains(Tags.SYSTEM_CUT_OFF_FROM_HYPER)) continue;
            if (s.getTags().contains(Tags.THEME_DERELICT)) continue;
            if (s.getTags().contains(Tags.THEME_REMNANT_MAIN)) continue;
            if (s.getTags().contains(Tags.THEME_REMNANT_RESURGENT)) continue;
            if (s.getTags().contains(Tags.THEME_REMNANT_SECONDARY)) continue;
            if (s.getTags().contains(Tags.THEME_REMNANT_SUPPRESSED)) continue;

            boolean enteredByPlayer = s.isEnteredByPlayer();
            float totalHazard = 0;
            for (PlanetAPI p : s.getPlanets()) {
                if (p.getMarket() == null) continue;

                switch (p.getMarket().getSurveyLevel()) {
                    case FULL: break;
                    case NONE:
                    case SEEN:
                    case PRELIMINARY: totalHazard += p.getMarket().getHazardValue();
                }
            }

            s.setEnteredByPlayer(enteredByPlayer);

            if (totalHazard > 0) {
                float weight = totalHazard / s.getPlanets().size();
                picker.add(s, weight);
            }
        }

        system = picker.pick();
    }

    public StarSystemAPI getSystem() {
        return system;
    }

    private void calculatePrice() {
        if (system == null) return;

        float total = 0;
        for (PlanetAPI planet : system.getPlanets()) {
            if (planet.getMarket() == null) continue;

            int count = 0;
            float value = 0;
            for (MarketConditionAPI mc : planet.getMarket().getConditions()) {
                if (DerelictThemeGenerator.interestingConditionsWithRuins.contains(mc.getId())) {
                    count++;
                }
                if (mc.getGenSpec() != null) {
                    //value += mc.getGenSpec().getXpMult();
                    value += mc.getGenSpec().getRank();
                }
            }

            if (planet.getMarket().hasCondition(Conditions.HABITABLE)) {
                value += 4f;
            }

            float hazard = planet.getMarket().getHazardValue();
            value -= (hazard - 1f) * 2f;

            String type;
            if (value <= 5) type = Commodities.SURVEY_DATA_1;
            else if (value <= 8) type = Commodities.SURVEY_DATA_2;
            else if (value <= 11 && count <= 1) type = Commodities.SURVEY_DATA_3;
            else if (value <= 14 && count <= 2) type = Commodities.SURVEY_DATA_4;
            else type = Commodities.SURVEY_DATA_5;


            CommoditySpecAPI data = Global.getSettings().getCommoditySpec(type);
            if (data != null) {
                total += data.getBasePrice();
            }
        }

        price = total * (1 + faction.getTariffFraction());
    }

    @Override
    public PersonAPI getRepresentative() {
        return representative;
    }

    @Override
    public void setRepresentative(PersonAPI representative) {
        this.representative = representative;
    }

    @Override
    public boolean shouldShow() {
        return true;
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    protected void notifyEnded() {
        SPP_MeetingManager meetMan = (SPP_MeetingManager) Global.getSector()
                    .getMemoryWithoutUpdate().get(SPP_MemKeys.MEETING_MANAGER);
        meetMan.endRequest(faction, id);
    }

}
