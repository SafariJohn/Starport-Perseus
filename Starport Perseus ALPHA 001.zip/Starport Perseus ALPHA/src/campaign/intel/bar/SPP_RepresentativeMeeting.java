package campaign.intel.bar;

import campaign.ids.SPP_MemKeys;
import campaign.intel.bar.SPP_RepresentativeBarEvent.OptionAndPrompt;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.InteractionDialogPlugin;
import com.fs.starfarer.api.campaign.OptionPanelAPI;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.FullName.Gender;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.combat.EngagementResultAPI;
import com.fs.starfarer.api.impl.campaign.intel.bar.BarEventDialogPlugin;
import com.fs.starfarer.api.util.Misc;
import java.util.*;
import org.lwjgl.input.Keyboard;

/**
 * Author: SafariJohn
 */
public class SPP_RepresentativeMeeting implements InteractionDialogPlugin {
    private static final String CONTINUE = "continue";
    private static final String LEAVE = "leave";

    private final InteractionDialogPlugin originalPlugin;
    private final OptionAndPrompt optionPrompt;
	private final Map<String, MemoryAPI> memoryMap;

	private InteractionDialogAPI dialog;
	private TextPanelAPI text;
	private OptionPanelAPI options;

    protected PersonAPI person;
    private final Map<String, SPP_RepMeetingTopicCreator> creators;

    public SPP_RepresentativeMeeting(InteractionDialogPlugin originalPlugin,
                OptionAndPrompt optionPrompt, PersonAPI person) {
        this.originalPlugin = originalPlugin;
        this.optionPrompt = optionPrompt;
        memoryMap = originalPlugin.getMemoryMap();

        this.person = person;
        SPP_MeetingManager meetMan = (SPP_MeetingManager) Global.getSector()
                    .getMemoryWithoutUpdate().get(SPP_MemKeys.MEETING_MANAGER);
        creators = meetMan.getRequestingPlugins(person.getFaction());
    }

    @Override
    public void init(InteractionDialogAPI dialog) {
		this.dialog = dialog;
		text = dialog.getTextPanel();
		options = dialog.getOptionPanel();

        text.addPara(replaceTokens(optionPrompt.transferText));

        showOptions(false);
    }

    @Override
    public void optionSelected(String optionText, Object optionData) {
        if (optionText != null) dialog.getTextPanel().addParagraph(optionText, Global.getSettings().getColor("buttonText"));

        if (optionData.equals(CONTINUE)) {
//            if (!optionPrompt.topicBackText.isEmpty()) text.addPara(replaceTokens(optionPrompt.topicBackText));

            showOptions(true);

            return;
        }

        if (optionData.equals(LEAVE)) {
            if (!optionPrompt.returnText.isEmpty()) text.addPara(replaceTokens(optionPrompt.returnText));

            dialog.getInteractionTarget().setActivePerson(null);

            options.clearOptions();
            dialog.setPlugin(originalPlugin);
            originalPlugin.optionSelected(null, null); // End the event

            return;
        }

        for (String key : creators.keySet()) {
            if (optionData.equals(key)) {
                // Load the topic plugin
                SPP_RepMeetingTopicCreator c = creators.get(key);

                SPP_RepMeetingTopicPlugin topic = c.getTopicPlugin();
                topic.setMeetingPlugin(this);
                dialog.setPlugin(topic);
                topic.init(dialog);
                break;
            }
        }

    }

    public void returnFromTopic(boolean endWithContinue) {
        dialog.setPlugin(this);

        if (endWithContinue) {
			options.clearOptions();
			options.addOption("Continue", CONTINUE);

            return;
        }

//        if (!optionPrompt.topicBackText.isEmpty()) text.addPara(replaceTokens(optionPrompt.topicBackText));

        showOptions(true);
    }

    private void showOptions(boolean returningFromTopic) {
        options.clearOptions();

        // Loop through faction missions and show available ones
        boolean addedSomething = false;
        for (String key : creators.keySet()) {
            SPP_RepMeetingTopicCreator c = creators.get(key);
            c.setRepresentative(person);

            if (!c.shouldShow()) continue;

            SPP_RepMeetingTopicPlugin topic = c.getTopicPlugin();
            if (topic == null) {
                c.createConversationPlugin(this, memoryMap);
                topic = c.getTopicPlugin();
            }

            topic.setMeetingPlugin(null);
            topic.addOptionAndPrompt(dialog);
            addedSomething = true;
        }

        if (!addedSomething) {
            optionSelected(null, LEAVE);
            return;
        }

        options.addOption("Leave", LEAVE);
        options.setShortcut(LEAVE, Keyboard.KEY_ESCAPE, false, false, false, true);
    }

    public Map<String, SPP_RepMeetingTopicCreator> getCreators() {
        return creators;
    }

    @Override
    public void optionMousedOver(String optionText, Object optionData) {}

    @Override
    public void advance(float amount) {}

    @Override
    public void backFromEngagement(EngagementResultAPI battleResult) {}

    @Override
    public Object getContext() { return null; }

    @Override
    public Map<String, MemoryAPI> getMemoryMap() { return memoryMap; }

    private String replaceTokens(String text) {
        text = text.replaceAll("\\$rank", person.getRank());
        text = text.replaceAll("\\$Rank", Misc.ucFirst(person.getRank()));

        text = text.replaceAll("\\$name", person.getNameString());
        text = text.replaceAll("\\$Name", person.getNameString());

        text = text.replaceAll("\\$firstName", person.getName().getFirst());
        text = text.replaceAll("\\$FirstName", person.getName().getFirst());

        text = text.replaceAll("\\$lastName", person.getName().getLast());
        text = text.replaceAll("\\$LastName", person.getName().getLast());

        if (person.getGender() == Gender.FEMALE) {
            text = text.replaceAll("\\$heShe", "she");
            text = text.replaceAll("\\$HeShe", "She");
            text = text.replaceAll("\\$himHer", "her");
            text = text.replaceAll("\\$HimHer", "Her");
            text = text.replaceAll("\\$hisHers", "hers");
            text = text.replaceAll("\\$HisHers", "Hers");
            text = text.replaceAll("\\$hisHer", "her");
            text = text.replaceAll("\\$HisHer", "Her");
        } else {
            text = text.replaceAll("\\$heShe", "he");
            text = text.replaceAll("\\$HeShe", "He");
            text = text.replaceAll("\\$himHer", "him");
            text = text.replaceAll("\\$HimHer", "Him");
            text = text.replaceAll("\\$hisHers", "his");
            text = text.replaceAll("\\$HisHers", "His");
            text = text.replaceAll("\\$hisHer", "his");
            text = text.replaceAll("\\$HisHer", "His");
        }

        return text;
    }
}
