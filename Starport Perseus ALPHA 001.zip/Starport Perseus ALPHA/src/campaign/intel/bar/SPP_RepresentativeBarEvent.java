package campaign.intel.bar;

import campaign.ids.SPP_MemKeys;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.characters.FullName;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.impl.campaign.intel.bar.events.BaseBarEventWithPerson;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import java.awt.Color;
import java.io.IOException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Author: SafariJohn
 */
public class SPP_RepresentativeBarEvent extends BaseBarEventWithPerson {
    public static class OptionAndPrompt {
        public String id;
        public float weight;
        public String promptText;
        public String optionText;
        public String transferText;
        public String topicBackText;
        public String returnText;
    }

    // Key: faction id; data: List of Strings
    private static final Map<String, WeightedRandomPicker> optionsAndPrompts = new HashMap<>();
    private static final Map<String, Color> colors = new HashMap<>();

    public static void addOptionAndPrompt(FactionAPI faction, OptionAndPrompt option) {
        List<OptionAndPrompt> options = new ArrayList<>();
        options.add(option);
        addOptionsAndPrompts(faction, options);
    }

    public static void addOptionsAndPrompts(FactionAPI faction, List<OptionAndPrompt> options) {
        WeightedRandomPicker picker = optionsAndPrompts.get(faction.getId());
        if (picker == null) {
            picker = new WeightedRandomPicker();
            optionsAndPrompts.put(faction.getId(), picker);
        }

        picker.addAll(options);
    }

    public static void addColor(FactionAPI faction, Color color) {
        colors.put(faction.getId(), color);
    }

    static {
        try {
            JSONArray csv = Global.getSettings().getMergedSpreadsheetDataForMod("id", "data/strings/representativeMeetingText.csv", "SPP");
            for (int i = 0; i < csv.length(); i++) {
                JSONObject obj = csv.getJSONObject(i);
                FactionAPI faction = Global.getSector().getFaction(obj.getString("faction"));
                if (faction == null) continue;
                OptionAndPrompt option = new OptionAndPrompt();
                option.id = obj.getString("id");
                option.weight = (float) obj.getDouble("weight");
                option.promptText = obj.getString("prompt");
                option.optionText = obj.getString("option");
                option.transferText = obj.getString("transfer");
                option.topicBackText = obj.getString("topicBack");
                option.returnText = obj.getString("return");

                addOptionAndPrompt(faction, option);
                addColor(faction, faction.getColor());
            }
        } catch (IOException | JSONException ex) {
            Logger.getLogger(SPP_RepresentativeBarEvent.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    protected final FactionAPI faction;
    protected OptionAndPrompt optionPrompt;

    public SPP_RepresentativeBarEvent(FactionAPI faction) {
        super();

        this.faction = faction;
    }

    @Override
    public void init(InteractionDialogAPI dialog) {
        super.init(dialog);


		done = false;
        if (person == null) createPerson();
        dialog.getInteractionTarget().setActivePerson(person);
		dialog.getVisualPanel().showPersonInfo(person, false);

		optionSelected(null, optionPrompt);
    }

    @Override
    public void addPromptAndOption(InteractionDialogAPI dialog) {
		regen(dialog.getInteractionTarget().getMarket());

        WeightedRandomPicker picker = optionsAndPrompts.get(faction.getId());
        if (picker == null) return;
        optionPrompt = (OptionAndPrompt) picker.pick();
        if (optionPrompt == null) return;

		TextPanelAPI text = dialog.getTextPanel();
		text.addPara(optionPrompt.promptText);

		dialog.getOptionPanel().addOption(optionPrompt.optionText, this, colors.get(faction.getId()), null);
    }

    @Override
    public void optionSelected(String optionText, Object optionData) {
        if (optionData instanceof OptionAndPrompt) {
            SPP_RepresentativeMeeting plugin;
            plugin = new SPP_RepresentativeMeeting(dialog.getPlugin(), optionPrompt, person);
            dialog.setPlugin(plugin);
            plugin.init(dialog);
        } else {
            done = true;
        }
    }

//    @Override
//    public boolean shouldRemoveEvent() {
//        return super.shouldRemoveEvent(); //To change body of generated methods, choose Tools | Templates.
//    }

    @Override
    protected void regen(MarketAPI market) {
        super.regen(market);
    }

    @Override
    protected PersonAPI createPerson() {
        person = (PersonAPI) market.getMemoryWithoutUpdate().get(SPP_MemKeys.FACTION_REP + "_" + faction.getId());
        return person;
    }

    protected String getPersonPost() { return person.getPost(); }
    protected FullName.Gender getPersonGender() { return person.getGender(); }
    protected String getPersonRank() { return person.getRank(); }
    protected String getPersonFaction() { return faction.getId(); }
    protected String getPersonPortrait() { return person.getPortraitSprite(); }

    @Override
    public boolean shouldShowAtMarket(MarketAPI market) {
        boolean isRep = market.getMemoryWithoutUpdate().get(SPP_MemKeys.FACTION_REP + "_" + faction.getId()) != null;
        boolean willSeeYou = false;
        if (isRep) {
            PersonAPI rep = (PersonAPI) market.getMemoryWithoutUpdate().get(SPP_MemKeys.FACTION_REP + "_" + faction.getId());
            SPP_MeetingManager meetMan = (SPP_MeetingManager) Global.getSector()
                        .getMemoryWithoutUpdate().get(SPP_MemKeys.MEETING_MANAGER);

            Map<String, SPP_RepMeetingTopicCreator> events = meetMan.getRequestingPlugins(faction);

            for (String key : meetMan.getRequestingPlugins(faction).keySet()) {
                SPP_RepMeetingTopicCreator c = events.get(key);
                c.setRepresentative(rep);

                if (!c.shouldShow()) continue;

                willSeeYou = true;
                break;
            }

        }
        return isRep && willSeeYou;
    }

    @Override
    public boolean endWithContinue() {
        return false;
    }

}
