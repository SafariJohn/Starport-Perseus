/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package campaign.intel.bar;

import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.InteractionDialogPlugin;

/**
 *
 * @author SafariJohn
 */
public interface SPP_RepMeetingTopicPlugin extends InteractionDialogPlugin {
    public void addOptionAndPrompt(InteractionDialogAPI dialog);
    public void setMeetingPlugin(SPP_RepresentativeMeeting plugin);
}
