/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package campaign.intel.bar;

import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import java.util.Map;

/**
 *
 * @author SafariJohn
 */
public interface SPP_RepMeetingTopicCreator {
    public String getId();
    public void setRepresentative(PersonAPI representative);
    public PersonAPI getRepresentative();
    public void createConversationPlugin(SPP_RepresentativeMeeting plugin, Map<String, MemoryAPI> memoryMap);
    public SPP_RepMeetingTopicPlugin getTopicPlugin();
    public boolean shouldShow();
}
