package campaign.intel.factionMissions;

import campaign.ids.SPP_Factions;
import campaign.ids.SPP_MemKeys;
import campaign.ids.SPP_Missions;
import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.intel.BaseEventManager;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import java.io.IOException;
import org.apache.log4j.Level;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class SPP_FactionMissionManager extends BaseEventManager {
    public static final WeightedRandomPicker<String> factions = new WeightedRandomPicker<>();
    static {
        factions.add(Factions.HEGEMONY, 1);
        factions.add(Factions.TRITACHYON, 1);
//        factions.add(Factions.PERSEAN, 1);
//        factions.add(Factions.DIKTAT, 1);
//        factions.add(Factions.LUDDIC_CHURCH, 1);
//        factions.add(Factions.LUDDIC_PATH, 1);
        // Mercenaries
//        factions.add(SPP_Factions.BLACK_COMPANY, 1);
//        factions.add(SPP_Factions.DAREDEVILS, 1);
//        factions.add(SPP_Factions.KANTAS_BROOD, 1);
        // Independents
//        factions.add(SPP_Factions.KO_COMBINE, 1);
    }


	public static final String KEY = "$SPP_factionMissionManager";

	public static SPP_FactionMissionManager getInstance() {
		Object test = Global.getSector().getMemoryWithoutUpdate().get(KEY);
		return (SPP_FactionMissionManager) test;
	}

	public SPP_FactionMissionManager() {
		super();
		Global.getSector().getMemoryWithoutUpdate().set(KEY, this);
	}

	@Override
	protected EveryFrameScript createEvent() {
		if ((float) Math.random() < 0.75f) return null;

        Global.getSector().getMemoryWithoutUpdate().set(SPP_MemKeys.FACTION_REP_KNOWN, true); // temp

        // If the player hasn't met any faction reps
        if (!Global.getSector().getMemoryWithoutUpdate().getBoolean(SPP_MemKeys.FACTION_REP_KNOWN)) return null;

        // Pick a faction
        FactionAPI faction;
        do {
            faction = Global.getSector().getFaction(factions.pick());
        } while (!hasMetRepresentative(faction));

        // Pick one of that faction's missions
        WeightedRandomPicker<String> missions = getMissionsList(faction);
        String mission = missions.pick();

        // Create the mission
        BaseIntelPlugin intel = null;
        switch (mission) {
            case SPP_Missions.ASSASSINATION:
                intel = new SPP_AssassinationIntel(faction);
                break;
            case SPP_Missions.COURIER:
            case SPP_Missions.ESCORT:
            case SPP_Missions.THEFT:
            case SPP_Missions.SALVAGE:
            case SPP_Missions.DARE:
            case SPP_Missions.BAD_BLOOD:
        }


		if (intel != null && intel.isDone()) intel = null;

		return intel;
	}

    public static boolean hasMetRepresentative(FactionAPI faction) {
        return true;
//        return faction.getMemoryWithoutUpdate().getBoolean(SPP_MemKeys.FACTION_REP_KNOWN);
    }

    private WeightedRandomPicker<String> getMissionsList(FactionAPI faction) {
        WeightedRandomPicker<String> picker = new WeightedRandomPicker<>();
        try {
            JSONArray csv = Global.getSettings().getMergedSpreadsheetDataForMod("id", "data/world/factions/faction_missions.csv", "SPP");

            for (int i = 0; i < csv.length(); i++) {
                JSONObject obj = csv.getJSONObject(i);

                if (!obj.getString("faction").equals(faction.getId())) continue;

                String mission = obj.getString("missionId");
                int weight = obj.getInt("weight");

                picker.add(mission, weight);
            }
        } catch (IOException | JSONException | NullPointerException ex) {
            Global.getLogger(SPP_FactionMissionManager.class).log(Level.WARN, null, ex);
        }

        return picker;
    }

	@Override
	protected int getMinConcurrent() {
		return Global.getSettings().getInt("minPersonBounties");
	}
	@Override
	protected int getMaxConcurrent() {
		return Global.getSettings().getInt("maxPersonBounties");
	}

}
