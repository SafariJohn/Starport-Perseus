package campaign.intel.factionMissions;

import campaign.intel.bar.SPP_MeetingManager;
import campaign.intel.bar.SPP_RepresentativeMeeting;
import campaign.ids.SPP_MemKeys;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.ReputationActionResponsePlugin.ReputationAdjustmentResult;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.MissionCompletionRep;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.RepActionEnvelope;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.RepActions;
import com.fs.starfarer.api.impl.campaign.intel.BaseMissionIntel;
import com.fs.starfarer.api.util.Misc;
import java.util.Map;

/**
 * Author: SafariJohn
 */
public class SPP_BaseFactionMission extends BaseMissionIntel {
    public static final float DEFAULT_TIMEOUT_PENALTY = -5;
    public static final float DEFAULT_ABANDON_PENALTY = -5;

    protected final String id;
    protected final FactionAPI faction;

    // "POSTED" stage to start with
    // Player can learn about the mission from representatives at bars.
    // Mission brief enters player intel after meeting
    // Mission can be accepted in person or remotely
    // If remotely, person rep goes to last representative player spoke to about it
    protected SPP_BaseMissionBriefingPlugin briefing;
    private PersonAPI representative;

    // Mission stage(s)

    public SPP_BaseFactionMission(FactionAPI faction) {
        initRandomCancel();

        id = Misc.genUID();
        this.faction = faction;

        setHidden(true);
    }

    public String getId() {
        return id;
    }

    public FactionAPI getFaction() {
        return faction;
    }

    @Override
    public void missionAccepted() {
        ((SPP_MeetingManager) Global.getSector().getMemoryWithoutUpdate()
                    .get(SPP_MemKeys.MEETING_MANAGER)).endRequest(faction, id);
    }

    public SPP_BaseMissionBriefingPlugin getBriefing() {
        return briefing;
    }

    public void createBriefing(SPP_RepresentativeMeeting originalPlugin,
                Map<String, MemoryAPI> memoryMap) {
        briefing = new SPP_BaseMissionBriefingPlugin(originalPlugin, memoryMap, id, faction);
        setHidden(false);
        Global.getSector().getIntelManager().addIntel(this);
    }

    public PersonAPI getRepresentative() {
        return representative;
    }

    public void setRepresentative(PersonAPI representative) {
        this.representative = representative;
    }

    @Override
    public void advanceImpl(float amount) {
        // If the mission has been placed and a representative selected
        if (representative != null && briefing != null) {
            // Add mission to player's intel
            setHidden(false);
            Global.getSector().getIntelManager().addIntel(this);
        }

        super.advanceImpl(amount);
    }

    @Override
    public void advanceMission(float amount) {}

    @Override
    public void endMission() {
        if (missionState == MissionState.POSTED) {
            ((SPP_MeetingManager) Global.getSector().getMemoryWithoutUpdate()
                        .get(SPP_MemKeys.MEETING_MANAGER)).endRequest(faction, id);
        }
    }

    @Override
    protected MissionResult createTimeRanOutFailedResult() {
        if (getTimeoutPenalty() != 0) {
			MissionCompletionRep completionRep = new MissionCompletionRep(0, RepLevel.WELCOMING, getTimeoutPenalty(), RepLevel.INHOSPITABLE);
            RepActionEnvelope action = new RepActionEnvelope(RepActions.MISSION_FAILURE, completionRep, null, true);
			ReputationAdjustmentResult repF = Global.getSector().adjustPlayerReputation(action, faction.getId());
            return new MissionResult(0, repF);
        }

        return new MissionResult();
    }

    @Override
    protected MissionResult createAbandonedResult(boolean withPenalty) {
        if (getAbandonPenalty() != 0) {
			MissionCompletionRep completionRep = new MissionCompletionRep(0, RepLevel.INHOSPITABLE, getAbandonPenalty(), RepLevel.INHOSPITABLE);
            RepActionEnvelope action = new RepActionEnvelope(RepActions.MISSION_FAILURE, completionRep, null, true);
			ReputationAdjustmentResult repF = Global.getSector().adjustPlayerReputation(action, faction.getId());

            return new MissionResult(0, repF);
        }

        return new MissionResult();
    }

    public float getTimeoutPenalty() {
        return DEFAULT_TIMEOUT_PENALTY;
    }

    public float getAbandonPenalty() {
        return DEFAULT_ABANDON_PENALTY;
    }

}
