package campaign.intel.factionMissions;

import campaign.intel.bar.SPP_RepresentativeMeeting;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import java.util.Map;

/**
 * Author: SafariJohn
 */
class SPP_AssassinationBriefing extends SPP_BaseMissionBriefingPlugin {
    // What's needed?
    // Assassination target
    // Their flagship
    // Target's fleet
    // Target's location

    public SPP_AssassinationBriefing(SPP_RepresentativeMeeting originalPlugin,
                Map<String, MemoryAPI> memoryMap, String id, FactionAPI faction) {
        super(originalPlugin, memoryMap, id, faction);
    }

    @Override
    protected void printBriefing() {
        text.addPara("Assasinate X.");
    }

    @Override
    protected String getAcceptText() {
        return "Agree to the hit";
    }

    @Override
    protected String getBackText() {
        return super.getBackText();
    }
}
