package campaign.intel.factionMissions;

import campaign.intel.bar.SPP_RepresentativeMeeting;
import campaign.intel.bases.SPP_PirateBaseManager;
import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BattleAPI;
import com.fs.starfarer.api.campaign.CampaignEventListener;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.FleetAssignment;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.ReputationActionResponsePlugin;
import com.fs.starfarer.api.campaign.ReputationActionResponsePlugin.ReputationAdjustmentResult;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.listeners.FleetEventListener;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.events.OfficerManagerEvent;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactoryV3;
import com.fs.starfarer.api.impl.campaign.fleets.FleetParamsV3;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.FleetTypes;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.shared.PersonBountyEventData;
import com.fs.starfarer.api.impl.campaign.shared.SharedData;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import java.util.Map;
import java.util.Random;
import org.apache.log4j.Logger;
import util.SPP_PortFunctions;

/**
 * Author: SafariJohn
 */
public class SPP_AssassinationMission extends SPP_BaseFactionMission implements FleetEventListener {
	public static Logger log = Global.getLogger(SPP_AssassinationMission.class);

	public static float MAX_TIME_BASED_ADDED_LEVEL = 3;

	private float bountyCredits = 0;

    private FactionAPI target;
	private PersonAPI person;
	private CampaignFleetAPI fleet;
	private FleetMemberAPI flagship;

	private SectorEntityToken hideoutLocation = null;

	private int level = 0;

	protected AssassinationResult result = null;

	public static enum AssassinationResultType {
		END_ASSASSINATION,
		END_NO_PAYOUT,
		END_NO_REWARD,
		END_OTHER,
		END_TIME,
	}


	public static class AssassinationResult {
		public AssassinationResultType type;
		public int payment;
		public ReputationActionResponsePlugin.ReputationAdjustmentResult rep;
		public AssassinationResult(AssassinationResultType type, int payment, ReputationAdjustmentResult rep) {
			this.type = type;
			this.payment = payment;
			this.rep = rep;
		}
	}

    public SPP_AssassinationMission(FactionAPI faction) {
        super(faction);

		pickLevel();

        pickTargetFaction();

		initBountyAmount();

		pickHideoutLocation();
		if (isDone()) return;

		initPerson();
		if (isDone()) return;

		generateFleet();
		if (isDone()) return;

		log.info(String.format("Starting assasination mission by faction [%s] for person %s", faction.getDisplayName(), person.getName().getFullName()));

		Global.getSector().getIntelManager().queueIntel(this);
    }

	protected void pickLevel() {
		int base = getSharedData().getLevel();

        float timeFactor = (SPP_PirateBaseManager.getInstance().getDaysSinceStart() - 180f) / (365f * 2f);
        if (timeFactor < 0) timeFactor = 0;
        if (timeFactor > 1) timeFactor = 1;

        int add = (int) Math.round(MAX_TIME_BASED_ADDED_LEVEL * timeFactor);
        base += add;

		if (base > 10) base = 10;

		boolean hasLow = false;
		boolean hasHigh = false;
		for (EveryFrameScript s : SPP_FactionMissionManager.getInstance().getActive()) {
			SPP_AssassinationIntel bounty = (SPP_AssassinationIntel) s;

			int curr = bounty.getLevel();

			if (curr < base || curr == 0) hasLow = true;
			if (curr > base) hasHigh = true;
		}

		level = base;
		if (!hasLow) {
			level -= new Random().nextInt(2) + 1;
//			level = 0;
		} else if (!hasHigh) {
			level += new Random().nextInt(3) + 2;
		}

		if (level < 0) level = 0;
	}

    private void pickTargetFaction() {
		WeightedRandomPicker<MarketAPI> picker = new WeightedRandomPicker<MarketAPI>();
		for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
            if (!faction.isHostileTo(market.getFactionId())) continue;
			if (!getSharedData().isParticipating(market.getFactionId())) continue;
			if (market.isHidden()) continue;
			if (market.getFaction().isPlayerFaction()) continue;

			float weight = market.getSize() + SPP_PortFunctions.getPopulationSize(market);

			if (market.getFaction() != null) {
				if (market.getFaction().isHostileTo(Global.getSector().getPlayerFaction())) {
					weight *= 1.5f;
				}
			}

            picker.add(market, weight);
		}

		if (picker.isEmpty()) {
			endImmediately();
			return;
		}

		MarketAPI market = picker.pick();
		target = market.getFaction();
    }

	private void initBountyAmount() {
		float base = Global.getSettings().getFloat("basePersonBounty");
		float perLevel = Global.getSettings().getFloat("personBountyPerLevel");

		float random = perLevel * (int)(Math.random() * 15) / 15f;

		bountyCredits = (int) (base + perLevel * level + random);
	}

	protected void pickHideoutLocation() {
		WeightedRandomPicker<StarSystemAPI> systemPicker = new WeightedRandomPicker<StarSystemAPI>();
		for (StarSystemAPI system : Global.getSector().getStarSystems()) {
			float mult = 0f;

			if (system.hasPulsar()) continue;

			if (system.hasTag(Tags.THEME_MISC_SKIP)) {
				mult = 1f;
			} else if (system.hasTag(Tags.THEME_MISC)) {
				mult = 3f;
			} else if (system.hasTag(Tags.THEME_REMNANT_NO_FLEETS)) {
				mult = 3f;
			} else if (system.hasTag(Tags.THEME_RUINS)) {
				mult = 5f;
			} else if (system.hasTag(Tags.THEME_REMNANT_DESTROYED)) {
				mult = 3f;
			} else if (system.hasTag(Tags.THEME_CORE_UNPOPULATED)) {
				mult = 1f;
			}

			for (MarketAPI market : Misc.getMarketsInLocation(system)) {
				if (market.isHidden()) continue;
				mult = 0f;
				break;
			}

			float distToPlayer = Misc.getDistanceToPlayerLY(system.getLocation());
			float noSpawnRange = Global.getSettings().getFloat("personBountyNoSpawnRangeAroundPlayerLY");
			if (distToPlayer < noSpawnRange) mult = 0f;

			if (mult <= 0) continue;

			float weight = system.getPlanets().size();
			for (PlanetAPI planet : system.getPlanets()) {
				if (planet.isStar()) continue;
				if (planet.getMarket() != null) {
					float h = planet.getMarket().getHazardValue();
					if (h <= 0f) weight += 5f;
					else if (h <= 0.25f) weight += 3f;
					else if (h <= 0.5f) weight += 1f;
				}
			}

			float dist = system.getLocation().length();
			float distMult = Math.max(0, 50000f - dist);

			systemPicker.add(system, weight * mult * distMult);
		}

		StarSystemAPI system = systemPicker.pick();

		if (system != null) {
			WeightedRandomPicker<SectorEntityToken> picker = new WeightedRandomPicker<SectorEntityToken>();
			for (SectorEntityToken planet : system.getPlanets()) {
				if (planet.isStar()) continue;
				if (planet.getMarket() != null &&
						!planet.getMarket().isPlanetConditionMarketOnly()) continue;

				picker.add(planet);
			}
			hideoutLocation = picker.pick();
		}


		if (hideoutLocation == null) {
			endImmediately();
		}
	}

	private void initPerson() {
		String factionId = target.getId();
		int personLevel = (int) (5 + level * 1.5f);
		person = OfficerManagerEvent.createOfficer(Global.getSector().getFaction(factionId),
												   personLevel, true, false);
	}

    private void generateFleet() {
		String fleetFactionId = target.getId();

		float qf = (float) level / 10f;
		if (qf > 1) qf = 1;

		String fleetName = "";

		fleetName = person.getName().getLast() + "'s" + " Fleet";

		float fp = (5 + level * 5) * 5f;
		fp *= 0.75f + (float) Math.random() * 0.25f;

		if (level >= 7) {
			fp += 20f;
		}
		if (level >= 8) {
			fp += 30f;
		}
		if (level >= 9) {
			fp += 50f;
		}
		if (level >= 10) {
			fp += 50f;
		}

		FleetParamsV3 params = new FleetParamsV3(
				null,
				hideoutLocation.getLocationInHyperspace(),
				fleetFactionId,
				qf + 0.2f, // qualityOverride
				FleetTypes.PERSON_BOUNTY_FLEET,
				fp, // combatPts
				0, // freighterPts
				0, // tankerPts
				0f, // transportPts
				0f, // linerPts
				0f, // utilityPts
				0f // qualityMod
				);
		params.ignoreMarketFleetSizeMult = true;
//		if (route != null) {
//			params.timestamp = route.getTimestamp();
//		}
		//params.random = random;
		fleet = FleetFactoryV3.createFleet(params);
		if (fleet == null || fleet.isEmpty()) {
			endImmediately();
			return;
		}

		fleet.setCommander(person);
		fleet.getFlagship().setCaptain(person);
//		fleet.getFleetData().setSyncNeeded();
//		fleet.getFleetData().syncIfNeeded();
		FleetFactoryV3.addCommanderSkills(person, fleet, null);

		//Misc.getSourceMarket(fleet).getStats().getDynamic().getValue(Stats.OFFICER_LEVEL_MULT);

		Misc.makeImportant(fleet, id, duration + 20f);
//		fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_PIRATE, true);
		fleet.getMemoryWithoutUpdate().set(MemFlags.FLEET_NO_MILITARY_RESPONSE, true);

		fleet.setNoFactionInName(true);
		fleet.setFaction(Factions.NEUTRAL, true);
		fleet.setName(fleetName);

		fleet.addEventListener(this);


		flagship = fleet.getFlagship();
    }

    @Override
    public void reportFleetDespawnedToListener(CampaignFleetAPI fleet, CampaignEventListener.FleetDespawnReason reason, Object param) { }

    @Override
    public void reportBattleOccurred(CampaignFleetAPI fleet, CampaignFleetAPI primaryWinner, BattleAPI battle) { }

	public static PersonBountyEventData getSharedData() {
		return SharedData.getData().getPersonBountyEventData();
	}

    /*
     * UI/Display methods:
     */

    @Override
    public void createBriefing(SPP_RepresentativeMeeting originalPlugin, Map<String, MemoryAPI> memoryMap) {
        // Spawn fleet
		LocationAPI location = hideoutLocation.getContainingLocation();
		location.addEntity(fleet);
		fleet.setLocation(hideoutLocation.getLocation().x - 500, hideoutLocation.getLocation().y + 500);
		fleet.getAI().addAssignment(FleetAssignment.ORBIT_PASSIVE, hideoutLocation, 1000000f, null);

        briefing = new SPP_AssassinationBriefing(originalPlugin, memoryMap, id, faction);
    }

    @Override
    public boolean hasSmallDescription() {
        return true;
    }

    @Override
    public String getSmallDescriptionTitle() {
		String n = person.getName().getFullName();

		if (result != null) {
			switch (result.type) {
                case END_ASSASSINATION:
                case END_NO_PAYOUT:
                case END_NO_REWARD:
                    return "Assassination Completed - " + n;
                case END_OTHER:
                case END_TIME:
                    return "Assassination Ended - " + n;
            }
		}

		return "Assassination - " + n;
    }

    @Override
    public void createSmallDescription(TooltipMakerAPI info, float width, float height) {
        super.createSmallDescription(info, width, height); //To change body of generated methods, choose Tools | Templates.
    }

}
