package campaign.intel.factionMissions;

import campaign.intel.bar.SPP_RepresentativeMeeting;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.InteractionDialogPlugin;
import com.fs.starfarer.api.campaign.OptionPanelAPI;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.combat.EngagementResultAPI;
import java.util.Map;
import org.lwjgl.input.Keyboard;

/**
 * Author: SafariJohn
 */
public class SPP_BaseMissionBriefingPlugin implements InteractionDialogPlugin {
    protected static final String ACCEPT = "accept";
    protected static final String GO_BACK = "goBack";

    protected final String id;
    protected final FactionAPI faction;

    protected SPP_RepresentativeMeeting meetingPlugin;
	protected Map<String, MemoryAPI> memoryMap;

	protected InteractionDialogAPI dialog;
	protected TextPanelAPI text;
	protected OptionPanelAPI options;

    public SPP_BaseMissionBriefingPlugin(SPP_RepresentativeMeeting originalPlugin,
                Map<String, MemoryAPI> memoryMap, String id, FactionAPI faction) {
        this.id = id;
        this.faction = faction;
        this.meetingPlugin = originalPlugin;
        this.memoryMap = memoryMap;
    }

    /**
     * Adds this mission to the list shown when you meet a representative.
     * @param dialog
     */
    public void addOptionAndPrompt(InteractionDialogAPI dialog) {
        dialog.getTextPanel().addPara("\"Mission " + id + " may be of interest to you.\"");
        dialog.getOptionPanel().addOption("Mission - " + id, id);
    }

    @Override
    public void init(InteractionDialogAPI dialog) {
        this.dialog = dialog;
        text = dialog.getTextPanel();
        options = dialog.getOptionPanel();

        printBriefing();
        showOptions();
    }

    protected void printBriefing() {
        text.addPara("Example briefing for Mission - " + id);
    }

    protected void showOptions() {
        options.clearOptions();

        options.addOption(getAcceptText(), ACCEPT);

        options.addOption(getBackText(), GO_BACK);
        options.setShortcut(GO_BACK, Keyboard.KEY_ESCAPE, false, false, false, true);
    }

    @Override
    public void optionSelected(String optionText, Object optionData) {
        if (optionData.equals(ACCEPT)) {
//            SPP_BaseFactionMission mission = ((SPP_MeetingManager) Global.getSector()
//                        .getMemoryWithoutUpdate().get(SPP_MemKeys.MEETING_MANAGER)).getRequestingPlugin(faction, id);
//
//			mission.setImportant(true);
//			mission.setMissionState(MissionState.ACCEPTED);
//            mission.missionAccepted();

            returnToMeetingPlugin();
            return;
        }

        if (optionData.equals(GO_BACK)) {
            returnToMeetingPlugin();
        }
    }

    protected String getAcceptText() {
        return "Accept mission";
    }

    protected String getBackText() {
        return "Back";
    }

    protected final void returnToMeetingPlugin() {
        meetingPlugin.returnFromTopic(false);
        meetingPlugin = null; // Avoid circular references
    }

    /* Handled by SPP_RepresentativeMeeting. */
    public void setMeetingPlugin(SPP_RepresentativeMeeting plugin) {
        this.meetingPlugin = plugin;
    }

    public void optionMousedOver(String optionText, Object optionData) {}
    public void advance(float amount) {}
    public void backFromEngagement(EngagementResultAPI battleResult) {}
    public Object getContext() { return null; }
    public Map<String, MemoryAPI> getMemoryMap() { return memoryMap; }

    public String getId() {
        return id;
    }
}
