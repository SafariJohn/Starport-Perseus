package campaign.intel.factionMissions.courierRun;

import campaign.ids.SPP_MemKeys;
import campaign.intel.bar.SPP_RepresentativeMeeting;
import campaign.intel.factionMissions.SPP_BaseFactionMission;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.ImportantPeopleAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.impl.campaign.ids.Ranks;
import com.fs.starfarer.api.impl.campaign.intel.bar.PortsideBarData;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Author: SafariJohn
 * Description:
 */
public class SPP_CourierMission extends SPP_BaseFactionMission {
    // What needed?
    // Destination
    // Reward
    // Rep reward - faction & representative

    // Opposing fleet
    // Composition
    // Spawn location
    // Interception logic?

    private SectorEntityToken destination;
    private PersonAPI recipient;

	private float creditReward = 0;

    public SPP_CourierMission(FactionAPI faction) {
        super(faction);
    }

    @Override
    public void createBriefing(SPP_RepresentativeMeeting originalPlugin, Map<String, MemoryAPI> memoryMap) {
        init();
        SPP_CourierBriefing brief = new SPP_CourierBriefing(originalPlugin, memoryMap, id, faction);
        brief.init(destination, recipient, creditReward);
        briefing = brief;

    }

    private void init() {
        pickLocation();
        createRecipient(destination.getMarket());

        initCreditReward();
    }

    private void pickLocation() {
        List<StarSystemAPI> repSystems = new ArrayList<>();
        List<MarketAPI> targets = new ArrayList<>();

        for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
            if (repSystems.contains(market.getStarSystem())) continue;

            if (market.getMemoryWithoutUpdate().contains(SPP_MemKeys.FACTION_REP + "_" + faction.getId())) {
                repSystems.add(market.getStarSystem());
                continue;
            }

            targets.add(market);
        }

        MarketAPI target = targets.get(new Random().nextInt(targets.size()));

        destination = target.getPrimaryEntity();
    }

    private void createRecipient(MarketAPI market) {
        PersonAPI contact = faction.createRandomPerson();
        contact.setPostId(Ranks.POST_CITIZEN);
        contact.setRankId(null);
        market.addPerson(contact);

		ImportantPeopleAPI ip = Global.getSector().getImportantPeople();
        ip.addPerson(contact);
        ip.getData(contact).getLocation().setMarket(market);

        recipient = contact;
    }

	private void initCreditReward() {
		float base = Global.getSettings().getFloat("basePersonBounty");
		float perLevel = Global.getSettings().getFloat("personBountyPerLevel");

		float random = perLevel * (int)(Math.random() * 15) / 15f;

		creditReward = (int) (base + perLevel + random);
	}

    @Override
    public void missionAccepted() {
        super.missionAccepted();

        PortsideBarData.getInstance().addEvent(new SPP_CourierReceivingPlugin(recipient, destination, this));
    }

    public void completeRun() {
        setMissionState(MissionState.COMPLETED);
        missionResult = new MissionResult((int) creditReward, null);
        endMission();
        setImportant(false);
    }

	public String getName() {
		if (isAccepted() || isPosted()) {
			return "Courier Run - " + destination.getName();
		}

		return "Courier Run" + getPostfixForState();
	}

    @Override
    public String getSmallDescriptionTitle() {
		return getName();
    }

    @Override
    public boolean hasSmallDescription() {
        return true;
    }

    @Override
    public void createSmallDescription(TooltipMakerAPI info, float width, float height) {
        getSmallDescriptionTitle();
    }

    @Override
    public void createIntelInfo(TooltipMakerAPI info, ListInfoMode mode) {
		info.addPara(getName(), 0f);
    }
}
