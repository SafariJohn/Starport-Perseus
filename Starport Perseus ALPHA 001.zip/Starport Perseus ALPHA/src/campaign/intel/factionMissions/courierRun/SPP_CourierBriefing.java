package campaign.intel.factionMissions.courierRun;

import campaign.intel.bar.SPP_RepresentativeMeeting;
import campaign.intel.factionMissions.SPP_BaseMissionBriefingPlugin;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.util.Misc;
import java.util.Map;

/**
 * Author: SafariJohn
 */
public class SPP_CourierBriefing extends SPP_BaseMissionBriefingPlugin {

    private SectorEntityToken destination;
    private PersonAPI recipient;
    private float reward;

    public SPP_CourierBriefing(SPP_RepresentativeMeeting originalPlugin,
                Map<String, MemoryAPI> memoryMap, String id, FactionAPI faction) {
        super(originalPlugin, memoryMap, id, faction);
    }

    public void init(SectorEntityToken destination, PersonAPI recipient, float reward) {
        this.destination = destination;
        this.recipient = recipient;
        this.reward = reward;
    }

    @Override
    public void addOptionAndPrompt(InteractionDialogAPI dialog) {
        dialog.getOptionPanel().addOption("Courier Run - " + destination.getName(), id);
    }

    @Override
    protected void printBriefing() {
        text.addPara("Deliver an encrypted TriPad to " + recipient.getNameString() + " at " + destination.getName() + "."
                    + " The reward is " + Misc.getDGSCredits(reward) + " credits.");
    }

    @Override
    protected String getAcceptText() {
        return "Take the TriPad";
    }

    @Override
    protected String getBackText() {
        return super.getBackText();
    }

}
