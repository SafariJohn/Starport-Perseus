package campaign.intel.factionMissions.courierRun;

import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.impl.campaign.intel.bar.PortsideBarData;
import com.fs.starfarer.api.impl.campaign.intel.bar.events.BaseBarEventWithPerson;
import com.fs.starfarer.api.util.Misc;

/**
 * Author: SafariJohn
 */
public class SPP_CourierReceivingPlugin extends BaseBarEventWithPerson {
    private final SectorEntityToken destination;
    private SPP_CourierMission mission;

    public SPP_CourierReceivingPlugin(PersonAPI recipient, SectorEntityToken destination, SPP_CourierMission mission) {
        person = recipient;
        this.destination = destination;
        this.mission = mission;
    }

    @Override
    public void addPromptAndOption(InteractionDialogAPI dialog) {
        dialog.getTextPanel().addPara("You see your contact sitting at the bar.");
        dialog.getOptionPanel().addOption("Sit beside your contact and order a \"tall one\"", this, person.getFaction().getColor(), null);
    }

	@Override
	public void init(InteractionDialogAPI dialog) {
		super.init(dialog);

		done = false;

		dialog.getVisualPanel().showPersonInfo(person, true);

		optionSelected(null, "crm");
	}

    @Override
    public void optionSelected(String optionText, Object optionData) {
        if (optionData == "crm") {
            // Finish courier mission
            dialog.getTextPanel().addPara(Misc.ucFirst(getHeOrShe()) + " correctly orders one \"on the rocks\". You set the encrypted TriPad on the bar and walk away.");
            mission.completeRun();

            mission = null;
            
			noContinue = false;
			done = true;
            PortsideBarData.getInstance().removeEvent(this);
        }
    }

    @Override
    public boolean shouldShowAtMarket(MarketAPI market) {
        return market.getPrimaryEntity() == destination;
    }

}
