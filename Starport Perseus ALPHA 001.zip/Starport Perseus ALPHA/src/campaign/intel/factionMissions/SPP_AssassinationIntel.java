package campaign.intel.factionMissions;

import campaign.intel.SPP_PersonBountyIntel.BountyType;
import campaign.intel.bases.SPP_PirateBaseManager;
import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BattleAPI;
import com.fs.starfarer.api.campaign.CampaignEventListener;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.FleetAssignment;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.ReputationActionResponsePlugin;
import com.fs.starfarer.api.campaign.ReputationActionResponsePlugin.ReputationAdjustmentResult;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.listeners.FleetEventListener;
import com.fs.starfarer.api.characters.FullName.Gender;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.RepActionEnvelope;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.RepActions;
import com.fs.starfarer.api.impl.campaign.DebugFlags;
import com.fs.starfarer.api.impl.campaign.events.OfficerManagerEvent;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactoryV3;
import com.fs.starfarer.api.impl.campaign.fleets.FleetParamsV3;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.FleetTypes;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.intel.BaseMissionIntel;
import com.fs.starfarer.api.impl.campaign.procgen.Constellation;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.special.BreadcrumbSpecial;
import com.fs.starfarer.api.impl.campaign.shared.PersonBountyEventData;
import com.fs.starfarer.api.impl.campaign.shared.SharedData;
import com.fs.starfarer.api.ui.SectorMapAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Set;
import org.apache.log4j.Logger;
import util.SPP_PortFunctions;


// Phase one: intel tells player to meet rep
// Phase two: rep gives player mission
// Phase three: mission (assassination, in this case)

public class SPP_AssassinationIntel extends BaseMissionIntel implements EveryFrameScript, FleetEventListener {
	public static Logger log = Global.getLogger(SPP_AssassinationIntel.class);

	public static float MAX_TIME_BASED_ADDED_LEVEL = 3;

	private float bountyCredits = 0;

    private final FactionAPI faction;
    private FactionAPI target;
	private PersonAPI person;
	private CampaignFleetAPI fleet;
	private FleetMemberAPI flagship;

	private SectorEntityToken hideoutLocation = null;

	private int level = 0;

	protected BountyResult result = null;

	public static enum BountyResultType {
		END_PLAYER_BOUNTY,
		END_PLAYER_NO_BOUNTY,
		END_PLAYER_NO_REWARD,
		END_OTHER,
		END_TIME,
	}

	public static class BountyResult {
		public BountyResultType type;
		public int payment;
		public ReputationActionResponsePlugin.ReputationAdjustmentResult rep;
		public BountyResult(BountyResultType type, int payment, ReputationActionResponsePlugin.ReputationAdjustmentResult rep) {
			this.type = type;
			this.payment = payment;
			this.rep = rep;
		}
	}

	public static PersonBountyEventData getSharedData() {
		return SharedData.getData().getPersonBountyEventData();
	}

    public SPP_AssassinationIntel(FactionAPI faction) {
        this.faction = faction;

		pickLevel();

        pickTargetFaction();

		initBountyAmount();

		pickHideoutLocation();
		if (isDone()) return;

		initPerson();
		if (isDone()) return;

		generateFleet();
		if (isDone()) return;

		log.info(String.format("Starting assasination mission by faction [%s] for person %s", faction.getDisplayName(), person.getName().getFullName()));

		Global.getSector().getIntelManager().queueIntel(this);
    }

	protected void pickLevel() {
		int base = getSharedData().getLevel();

        float timeFactor = (SPP_PirateBaseManager.getInstance().getDaysSinceStart() - 180f) / (365f * 2f);
        if (timeFactor < 0) timeFactor = 0;
        if (timeFactor > 1) timeFactor = 1;

        int add = (int) Math.round(MAX_TIME_BASED_ADDED_LEVEL * timeFactor);
        base += add;

		if (base > 10) base = 10;

		boolean hasLow = false;
		boolean hasHigh = false;
		for (EveryFrameScript s : SPP_FactionMissionManager.getInstance().getActive()) {
			SPP_AssassinationIntel bounty = (SPP_AssassinationIntel) s;

			int curr = bounty.getLevel();

			if (curr < base || curr == 0) hasLow = true;
			if (curr > base) hasHigh = true;
		}

		level = base;
		if (!hasLow) {
			level -= new Random().nextInt(2) + 1;
//			level = 0;
		} else if (!hasHigh) {
			level += new Random().nextInt(3) + 2;
		}

		if (level < 0) level = 0;
	}

    private void pickTargetFaction() {
		WeightedRandomPicker<MarketAPI> picker = new WeightedRandomPicker<MarketAPI>();
		for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
            if (!faction.isHostileTo(market.getFactionId())) continue;
			if (!getSharedData().isParticipating(market.getFactionId())) continue;
			if (market.isHidden()) continue;
			if (market.getFaction().isPlayerFaction()) continue;

			float weight = market.getSize() + SPP_PortFunctions.getPopulationSize(market);

			if (market.getFaction() != null) {
				if (market.getFaction().isHostileTo(Global.getSector().getPlayerFaction())) {
					weight *= 1.5f;
				}
			}

            picker.add(market, weight);
		}

		if (picker.isEmpty()) {
			endImmediately();
			return;
		}

		MarketAPI market = picker.pick();
		target = market.getFaction();
    }

	private void initBountyAmount() {
		float base = Global.getSettings().getFloat("basePersonBounty");
		float perLevel = Global.getSettings().getFloat("personBountyPerLevel");

		float random = perLevel * (int)(Math.random() * 15) / 15f;

		bountyCredits = (int) (base + perLevel * level + random);
	}

	protected void pickHideoutLocation() {
		WeightedRandomPicker<StarSystemAPI> systemPicker = new WeightedRandomPicker<StarSystemAPI>();
		for (StarSystemAPI system : Global.getSector().getStarSystems()) {
			float mult = 0f;

			if (system.hasPulsar()) continue;

			if (system.hasTag(Tags.THEME_MISC_SKIP)) {
				mult = 1f;
			} else if (system.hasTag(Tags.THEME_MISC)) {
				mult = 3f;
			} else if (system.hasTag(Tags.THEME_REMNANT_NO_FLEETS)) {
				mult = 3f;
			} else if (system.hasTag(Tags.THEME_RUINS)) {
				mult = 5f;
			} else if (system.hasTag(Tags.THEME_REMNANT_DESTROYED)) {
				mult = 3f;
			} else if (system.hasTag(Tags.THEME_CORE_UNPOPULATED)) {
				mult = 1f;
			}

			for (MarketAPI market : Misc.getMarketsInLocation(system)) {
				if (market.isHidden()) continue;
				mult = 0f;
				break;
			}

			float distToPlayer = Misc.getDistanceToPlayerLY(system.getLocation());
			float noSpawnRange = Global.getSettings().getFloat("personBountyNoSpawnRangeAroundPlayerLY");
			if (distToPlayer < noSpawnRange) mult = 0f;

			if (mult <= 0) continue;

			float weight = system.getPlanets().size();
			for (PlanetAPI planet : system.getPlanets()) {
				if (planet.isStar()) continue;
				if (planet.getMarket() != null) {
					float h = planet.getMarket().getHazardValue();
					if (h <= 0f) weight += 5f;
					else if (h <= 0.25f) weight += 3f;
					else if (h <= 0.5f) weight += 1f;
				}
			}

			float dist = system.getLocation().length();
			float distMult = Math.max(0, 50000f - dist);

			systemPicker.add(system, weight * mult * distMult);
		}

		StarSystemAPI system = systemPicker.pick();

		if (system != null) {
			WeightedRandomPicker<SectorEntityToken> picker = new WeightedRandomPicker<SectorEntityToken>();
			for (SectorEntityToken planet : system.getPlanets()) {
				if (planet.isStar()) continue;
				if (planet.getMarket() != null &&
						!planet.getMarket().isPlanetConditionMarketOnly()) continue;

				picker.add(planet);
			}
			hideoutLocation = picker.pick();
		}


		if (hideoutLocation == null) {
			endImmediately();
		}
	}

	private void initPerson() {
		String factionId = Factions.PIRATES;
		int personLevel = (int) (5 + level * 1.5f);
		person = OfficerManagerEvent.createOfficer(Global.getSector().getFaction(factionId),
												   personLevel, true, false);
	}

    private void generateFleet() {
		String fleetFactionId = target.getId();

		float qf = (float) level / 10f;
		if (qf > 1) qf = 1;

		String fleetName = "";

		fleetName = person.getName().getLast() + "'s" + " Fleet";

		float fp = (5 + level * 5) * 5f;
		fp *= 0.75f + (float) Math.random() * 0.25f;

		if (level >= 7) {
			fp += 20f;
		}
		if (level >= 8) {
			fp += 30f;
		}
		if (level >= 9) {
			fp += 50f;
		}
		if (level >= 10) {
			fp += 50f;
		}

		FleetParamsV3 params = new FleetParamsV3(
				null,
				hideoutLocation.getLocationInHyperspace(),
				fleetFactionId,
				qf + 0.2f, // qualityOverride
				FleetTypes.PERSON_BOUNTY_FLEET,
				fp, // combatPts
				0, // freighterPts
				0, // tankerPts
				0f, // transportPts
				0f, // linerPts
				0f, // utilityPts
				0f // qualityMod
				);
		params.ignoreMarketFleetSizeMult = true;
//		if (route != null) {
//			params.timestamp = route.getTimestamp();
//		}
		//params.random = random;
		fleet = FleetFactoryV3.createFleet(params);
		if (fleet == null || fleet.isEmpty()) {
			endImmediately();
			return;
		}

		fleet.setCommander(person);
		fleet.getFlagship().setCaptain(person);
//		fleet.getFleetData().setSyncNeeded();
//		fleet.getFleetData().syncIfNeeded();
		FleetFactoryV3.addCommanderSkills(person, fleet, null);

		//Misc.getSourceMarket(fleet).getStats().getDynamic().getValue(Stats.OFFICER_LEVEL_MULT);

		Misc.makeImportant(fleet, "pbe", duration + 20f);
//		fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_PIRATE, true);
		fleet.getMemoryWithoutUpdate().set(MemFlags.FLEET_NO_MILITARY_RESPONSE, true);

		fleet.setNoFactionInName(true);
		fleet.setFaction(Factions.NEUTRAL, true);
		fleet.setName(fleetName);

		fleet.addEventListener(this);


		flagship = fleet.getFlagship();
    }

    @Override
    public void missionAccepted() {
        // Spawn fleet
		LocationAPI location = hideoutLocation.getContainingLocation();
		location.addEntity(fleet);
		fleet.setLocation(hideoutLocation.getLocation().x - 500, hideoutLocation.getLocation().y + 500);
		fleet.getAI().addAssignment(FleetAssignment.ORBIT_PASSIVE, hideoutLocation, 1000000f, null);
    }

    @Override
    public void advanceMission(float amount) {
		float days = Global.getSector().getClock().convertToDays(amount);
		//days *= 60f;

		elapsedDays += days;

		if (elapsedDays >= duration && !isDone()) {
			boolean canEnd = fleet == null || !fleet.isInCurrentLocation();
			if (canEnd) {
				log.info(String.format("Ending assassination on %s by %s", person.getName().getFullName(), faction.getDisplayName()));
				result = new BountyResult(BountyResultType.END_TIME, 0, null);
				sendUpdateIfPlayerHasIntel(result, true);
				cleanUpFleetAndEndIfNecessary();
				return;
			}
		}

		if (fleet == null) return;

		if (fleet.isInCurrentLocation() && !fleet.getFaction().getId().equals(target.getId())) {
			fleet.setFaction(target.getId(), true);
		} else if (!fleet.isInCurrentLocation() && !fleet.getFaction().getId().equals(Factions.NEUTRAL)) {
			fleet.setFaction(Factions.NEUTRAL, true);
		}

		if (fleet.getFlagship() == null || fleet.getFlagship().getCaptain() != person) {
			result = new BountyResult(BountyResultType.END_OTHER, 0, null);
			boolean current = fleet.isInCurrentLocation();
			sendUpdateIfPlayerHasIntel(result, !current);
			cleanUpFleetAndEndIfNecessary();
			return;
		}
    }

	public boolean runWhilePaused() {
		return false;
	}

	protected void addBulletPoints(TooltipMakerAPI info, ListInfoMode mode) {
		Color h = Misc.getHighlightColor();
		Color g = Misc.getGrayColor();
		float pad = 3f;
		float opad = 10f;

		float initPad = pad;
		if (mode == ListInfoMode.IN_DESC) initPad = opad;

		Color tc = getBulletColorForMode(mode);

		bullet(info);
		boolean isUpdate = getListInfoParam() != null;

		if (result == null) {
//			RepLevel level = Global.getSector().getPlayerFaction().getRelationshipLevel(faction.getId());
//			Color relColor = faction.getRelColor(Factions.PLAYER);
//			String rel = level.getDisplayName().toLowerCase();

			if (mode == ListInfoMode.IN_DESC) {
//				if (!willRepIncrease()) {
//					LabelAPI label = info.addPara("No reward or rep increase (" + rel + ")", bodyColor, initPad);
//					label.setHighlight("(" + rel + ")");
//					label.setHighlightColors(relColor);
//				} else if (!willPay()) {
//					LabelAPI label = info.addPara("No reward (" + rel + ")", bodyColor, initPad);
//					label.setHighlight("(" + rel + ")");
//					label.setHighlightColors(relColor);
//				} else {
					info.addPara("%s reward", initPad, tc, h, Misc.getDGSCredits(bountyCredits));
//				}
				int days = (int) (duration - elapsedDays);
				if (days <= 1) {
					days = 1;
				}
				addDays(info, "remaining", days, tc);
			} else {
				info.addPara("Faction: " + faction.getDisplayName(), initPad, tc,
						 faction.getBaseUIColor(), faction.getDisplayName());
				if (!isEnding()) {
					int days = (int) (duration - elapsedDays);
					String daysStr = "days";
					if (days <= 1) {
						days = 1;
						daysStr = "day";
					}
					info.addPara("%s reward, %s " + daysStr + " remaining", 0f, tc,
							h, Misc.getDGSCredits(bountyCredits), "" + days);
				}
			}
			unindent(info);
			return;
		}

		switch (result.type) {
		case END_PLAYER_BOUNTY:
			info.addPara("%s received", initPad, tc, h, Misc.getDGSCredits(result.payment));
			CoreReputationPlugin.addAdjustmentMessage(result.rep.delta, faction, null,
					null, null, info, tc, isUpdate, 0f);
			break;
		case END_PLAYER_NO_BOUNTY:
			CoreReputationPlugin.addAdjustmentMessage(result.rep.delta, faction, null,
					null, null, info, tc, isUpdate, 0f);
			break;
		case END_PLAYER_NO_REWARD:
			CoreReputationPlugin.addAdjustmentMessage(result.rep.delta, faction, null,
					null, null, info, tc, isUpdate, 0f);
			break;
		case END_TIME:
			break;
		case END_OTHER:
			break;

		}

		unindent(info);
	}

	public void createIntelInfo(TooltipMakerAPI info, ListInfoMode mode) {
		Color h = Misc.getHighlightColor();
		Color g = Misc.getGrayColor();
		Color c = getTitleColor(mode);
		float pad = 3f;
		float opad = 10f;

		info.addPara(getName(), c, 0f);

		addBulletPoints(info, mode);

	}
	public String getSortString() {
		return "Assassination";
	}

	public String getName() {
		String n = person.getName().getFullName();

		if (result != null) {
			switch (result.type) {
                case END_PLAYER_BOUNTY:
                case END_PLAYER_NO_BOUNTY:
                case END_PLAYER_NO_REWARD:
                    return "Assassination Completed - " + n;
                case END_OTHER:
                case END_TIME:
                    return "Assassination Ended - " + n;
			}
		}

		return "Assassination - " + n;
	}

	@Override
	public FactionAPI getFactionForUIColors() {
		return faction;
	}

	public String getSmallDescriptionTitle() {
		return getName();
		//return null;
	}

	public void createSmallDescription(TooltipMakerAPI info, float width, float height) {
		Color h = Misc.getHighlightColor();
		Color g = Misc.getGrayColor();
		float pad = 3f;
		float opad = 10f;

		info.addImage(person.getPortraitSprite(), width, 128, opad);

		String has = faction.getDisplayNameHasOrHave();
		info.addPara(Misc.ucFirst(faction.getDisplayNameWithArticle()) + " " + has +
				" given you the mission to kill " + person.getName().getFullName() + ".",
				opad, faction.getBaseUIColor(), faction.getDisplayNameWithArticleWithoutArticle());

		if (result != null) {
			if (result.type == BountyResultType.END_PLAYER_BOUNTY) {
				info.addPara("You have successfully completed this mission.", opad);
			} else if (result.type == BountyResultType.END_PLAYER_NO_BOUNTY) {
				info.addPara("You have successfully completed this mission, but received no " +
						"credit reward because of your standing with " +
						Misc.ucFirst(faction.getDisplayNameWithArticle()) + ".",
						opad, faction.getBaseUIColor(), faction.getDisplayNameWithArticleWithoutArticle());
			} else if (result.type == BountyResultType.END_PLAYER_NO_REWARD) {
				info.addPara("You have successfully completed this mission, but received no " +
						"reward because of your standing with " +
						Misc.ucFirst(faction.getDisplayNameWithArticle()) + ".",
						opad, faction.getBaseUIColor(), faction.getDisplayNameWithArticleWithoutArticle());
			} else {
				info.addPara("This mission is no longer on offer.", opad);
			}
		}

		addBulletPoints(info, ListInfoMode.IN_DESC);
		if (result == null) {
//			String targetDesc = getTargetDesc();
//			if (targetDesc != null) {
//				info.addPara(targetDesc, opad);
//			}

			if (hideoutLocation != null) {
				SectorEntityToken fake = hideoutLocation.getContainingLocation().createToken(0, 0);
				fake.setOrbit(Global.getFactory().createCircularOrbit(hideoutLocation, 0, 1000, 100));

				String loc = BreadcrumbSpecial.getLocatedString(fake);
				loc = loc.replaceAll("orbiting", "hiding out near");
				loc = loc.replaceAll("located in", "hiding out in");
				String heOrSheIs = "She is";
				if (person.getGender() == Gender.MALE) heOrSheIs = "He is";
				info.addPara(heOrSheIs + " rumored to be " + loc + ".", opad);
			}


			int cols = 7;
			float iconSize = width / cols;


			if (DebugFlags.PERSON_BOUNTY_DEBUG_INFO) {
				boolean deflate = false;
				if (!fleet.isInflated()) {
					fleet.setFaction(Factions.PIRATES, true);
					fleet.inflateIfNeeded();
					deflate = true;
				}

				String hisOrHer = "her";
				if (person.getGender() == Gender.MALE) hisOrHer = "his";
				info.addPara("The mission briefing also contains partial intel on the ships under " + hisOrHer + " command. (DEBUG: full info)", opad);
				info.addShipList(cols, 3, iconSize, getFactionForUIColors().getBaseUIColor(), fleet.getMembersWithFightersCopy(), opad);

				info.addPara("level: " + level, 3f);

				if (deflate) {
					fleet.deflate();
				}
			} else {
				boolean deflate = false;
				if (!fleet.isInflated()) {
					fleet.setFaction(Factions.PIRATES, true);
					fleet.inflateIfNeeded();
					deflate = true;
				}

				List<FleetMemberAPI> list = new ArrayList<FleetMemberAPI>();
				Random random = new Random(person.getNameString().hashCode() * 170000);

				List<FleetMemberAPI> members = fleet.getFleetData().getMembersListCopy();
				int max = 7;
				for (FleetMemberAPI member : members) {
					if (list.size() >= max) break;

					if (member.isFighterWing()) continue;

					float prob = (float) member.getFleetPointCost() / 20f;
					prob += (float) max / (float) members.size();
					if (member.isFlagship()) prob = 1f;
					//if (members.size() <= max) prob = 1f;

					if (random.nextFloat() > prob) continue;

					FleetMemberAPI copy = Global.getFactory().createFleetMember(FleetMemberType.SHIP, member.getVariant());
					if (member.isFlagship()) {
						copy.setCaptain(person);
					}
					list.add(copy);
				}

				if (!list.isEmpty()) {
					String hisOrHer = "her";
					if (person.getGender() == Gender.MALE) hisOrHer = "his";
					info.addPara("The mission briefing also contains partial intel on some of the ships under " + hisOrHer + " command.", opad);
					info.addShipList(cols, 1, iconSize, getFactionForUIColors().getBaseUIColor(), list, opad);

					int num = members.size() - list.size();
					num = Math.round((float)num * (1f + random.nextFloat() * 0.5f));

					if (num < 5) num = 0;
					else if (num < 10) num = 5;
					else if (num < 20) num = 10;
					else num = 20;

					if (num > 1) {
						info.addPara("The intel assessment notes the fleet may contain upwards of %s other ships" +
								" of lesser significance.", opad, h, "" + num);
					} else {
						info.addPara("The intel assessment notes the fleet may contain several other ships" +
								" of lesser significance.", opad);
					}
				}

				if (deflate) {
					fleet.deflate();
				}
			}
		}
	}

	public String getIcon() {
		return person.getPortraitSprite();
	}

	public Set<String> getIntelTags(SectorMapAPI map) {
		Set<String> tags = super.getIntelTags(map);
		tags.add(Tags.INTEL_BOUNTY);
		tags.add(faction.getId());
		return tags;
	}

	@Override
	public SectorEntityToken getMapLocation(SectorMapAPI map) {
		Constellation c = hideoutLocation.getConstellation();
		SectorEntityToken entity = null;
		if (c != null && map != null) {
			entity = map.getConstellationLabelEntity(c);
		}
		if (entity == null) entity = hideoutLocation;
		return entity;
	}

	@Override
	protected void notifyEnding() {
		super.notifyEnding();
		cleanUpFleetAndEndIfNecessary();
	}

	protected void cleanUpFleetAndEndIfNecessary() {
		if (fleet != null) {
			Misc.makeUnimportant(fleet, "pbe");
			fleet.clearAssignments();
			if (hideoutLocation != null) {
				fleet.getAI().addAssignment(FleetAssignment.GO_TO_LOCATION_AND_DESPAWN, hideoutLocation, 1000000f, null);
			} else {
				fleet.despawn();
			}
			fleet = null; //can't null it because description uses it
		}
		if (!isEnding() && !isEnded()) {
			endAfterDelay();
		}
	}

    @Override
    public void endMission() {}

    @Override
    protected MissionResult createTimeRanOutFailedResult() { return null; }

    @Override
    protected MissionResult createAbandonedResult(boolean withPenalty) { return null; }

    @Override
    public void reportFleetDespawnedToListener(CampaignFleetAPI fleet, CampaignEventListener.FleetDespawnReason reason, Object param) {
		if (isDone() || result != null) return;

		if (this.fleet == fleet) {
			fleet.setCommander(fleet.getFaction().createRandomPerson());
			result = new BountyResult(BountyResultType.END_OTHER, 0, null);
			sendUpdateIfPlayerHasIntel(result, true);
			cleanUpFleetAndEndIfNecessary();
		}
    }

    @Override
    public void reportBattleOccurred(CampaignFleetAPI fleet, CampaignFleetAPI primaryWinner, BattleAPI battle) {
		if (isDone() || result != null) return;

		if (battle.isInvolved(fleet) && !battle.isPlayerInvolved()) {
			if (fleet.getFlagship() == null || fleet.getFlagship().getCaptain() != person) {
				fleet.setCommander(fleet.getFaction().createRandomPerson());
				//Global.getSector().reportEventStage(this, "other_end", market.getPrimaryEntity(), messagePriority);
				result = new BountyResult(BountyResultType.END_OTHER, 0, null);
				sendUpdateIfPlayerHasIntel(result, true);
				cleanUpFleetAndEndIfNecessary();
				return;
			}
		}

		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		if (!battle.isPlayerInvolved() || !battle.isInvolved(fleet) || battle.onPlayerSide(fleet)) {
			return;
		}

		 // didn't destroy the original flagship
		if (fleet.getFlagship() != null && fleet.getFlagship().getCaptain() == person) return;

		int payment = (int) (bountyCredits * battle.getPlayerInvolvementFraction());
		if (payment <= 0) {
			result = new BountyResult(BountyResultType.END_OTHER, 0, null);
			sendUpdateIfPlayerHasIntel(result, true);
			cleanUpFleetAndEndIfNecessary();
			return;
		}

		if (willPay()) {
			log.info(String.format("Paying bounty of %d from faction [%s]", (int) payment, faction.getDisplayName()));

			playerFleet.getCargo().getCredits().add(payment);
			ReputationAdjustmentResult rep = Global.getSector().adjustPlayerReputation(
					new RepActionEnvelope(RepActions.PERSON_BOUNTY_REWARD, null, null, null, true, false),
					faction.getId());
			result = new BountyResult(BountyResultType.END_PLAYER_BOUNTY, payment, rep);
			sendUpdateIfPlayerHasIntel(result, false);
		} else if (willRepIncrease()) {
			log.info(String.format("Not paying bounty, but improving rep with faction [%s]", faction.getDisplayName()));
			ReputationAdjustmentResult rep = Global.getSector().adjustPlayerReputation(
								new RepActionEnvelope(RepActions.PERSON_BOUNTY_REWARD, null, null, null, true, false),
								faction.getId());
			result = new BountyResult(BountyResultType.END_PLAYER_NO_BOUNTY, payment, rep);
			sendUpdateIfPlayerHasIntel(result, false);
		} else {
			log.info(String.format("Not paying bounty or improving rep with faction [%s]", faction.getDisplayName()));
			result = new BountyResult(BountyResultType.END_PLAYER_NO_REWARD, 0, null);
			sendUpdateIfPlayerHasIntel(result, false);
		}


		getSharedData().reportSuccess();
		//removeBounty();

		cleanUpFleetAndEndIfNecessary();
    }

	protected boolean willPay() {
		if (true) return true;
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		RepLevel rep = playerFleet.getFaction().getRelationshipLevel(faction);
		return rep.isAtWorst(RepLevel.SUSPICIOUS);
	}

	protected boolean willRepIncrease() {
		if (true) return true;
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		RepLevel rep = playerFleet.getFaction().getRelationshipLevel(faction);
		return rep.isAtWorst(RepLevel.HOSTILE);
	}

    public int getLevel() {
        return level;
    }

}


