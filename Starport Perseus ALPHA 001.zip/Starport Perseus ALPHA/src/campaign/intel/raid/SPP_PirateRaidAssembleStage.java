package campaign.intel.raid;

import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;

public class SPP_PirateRaidAssembleStage extends SPP_AssembleStage {

	protected BaseIntelPlugin base;

	public SPP_PirateRaidAssembleStage(SPP_RaidIntel raid, SectorEntityToken gatheringPoint, BaseIntelPlugin base) {
		super(raid, gatheringPoint);
		this.base = base;
	}

	@Override
	public boolean isSourceKnown() {
		return base.isPlayerVisible();
	}


}






