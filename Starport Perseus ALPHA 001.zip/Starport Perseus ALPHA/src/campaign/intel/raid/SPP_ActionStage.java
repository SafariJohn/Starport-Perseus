package campaign.intel.raid;


public abstract class SPP_ActionStage extends SPP_BaseRaidStage {

	public SPP_ActionStage(SPP_RaidIntel raid) {
		super(raid);
	}

	@Override
	public void notifyStarted() {
		updateRoutes();
	}

	protected void updateRoutes() {
	}

	@Override
	protected void updateStatus() {
		super.updateStatus();
	}


	public void advance(float amount) {
		super.advance(amount);
	}

	public abstract boolean isPlayerTargeted();
}
