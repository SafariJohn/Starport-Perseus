package campaign.intel.bases;

import campaign.econ.industries.SPP_MilitantCamp;
import campaign.ids.SPP_Industries;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.comm.IntelInfoPlugin;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import static com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin.addMarketToList;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.SectorMapAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import java.util.List;
import java.util.Set;

/**
 * Author: SafariJohn
 */
public class SPP_LuddicPathCampIntel extends BaseIntelPlugin {
	protected MarketAPI market;

    public SPP_LuddicPathCampIntel(MarketAPI market) {
        this.market = market;
    }

	public MarketAPI getMarket() {
		return market;
	}

    public SPP_MilitantCamp getMilitantCamp() {
        return (SPP_MilitantCamp) market.getIndustry(SPP_Industries.MILITANT_CAMP);
    }

	@Override
	public FactionAPI getFactionForUIColors() {
		return Global.getSector().getFaction(Factions.LUDDIC_PATH);
	}

	@Override
	public void createIntelInfo(TooltipMakerAPI info, ListInfoMode mode) {
		Color c = getTitleColor(mode);
		info.addPara("Militant Camp - " + market.getName(), c, 0f);
	}

	public String getSmallDescriptionTitle() {
		return "Militant Camp - " + market.getName();
	}

	public void createSmallDescription(TooltipMakerAPI info, float width, float height) {
		Color h = Misc.getHighlightColor();
		Color g = Misc.getGrayColor();
		Color tc = Misc.getTextColor();
		float pad = 3f;
		float opad = 10f;

		FactionAPI faction = Global.getSector().getFaction(Factions.LUDDIC_PATH);

		info.addImage(faction.getLogo(), width, 128, opad);

		String has = faction.getDisplayNameHasOrHave();

		info.addPara(Misc.ucFirst(Misc.ucFirst(faction.getPersonNamePrefixAOrAn()) + " " + faction.getPersonNamePrefix()) + " militant camp is operating at " +
				market.getName() + ". "
                    + "The camp serves to provide material support to active Pather cells at nearby ports, enabling them "
                    + "to cause widespread damage and destruction.",
				opad, faction.getBaseUIColor(), faction.getPersonNamePrefix());

		info.addSectionHeading("Recent events",
							   faction.getBaseUIColor(), faction.getDarkUIColor(), Alignment.MID, opad);

		List<SPP_LuddicPathCellsIntel> cells = SPP_LuddicPathCellsIntel.getCellsForCamp(this, false);
		if (!cells.isEmpty()) {
			float initPad = opad;

			info.addPara("This camp is known to be providing support to active Pather cells at the following ports:", opad);
			for (SPP_LuddicPathCellsIntel intel : cells) {
				addMarketToList(info, intel.getMarket(), initPad);
				initPad = 0f;
			}
			initPad = 0f;
		} else if (!getMilitantCamp().isFunctional()) {
            float days = getMilitantCamp().getDisruptedDays();
			info.addPara("This camp has been disrupted for at least the next " + (int) days + " days.", opad);
        } else {
			info.addPara("You do not know of any active pather cells this camp might be providing support to.", opad);
		}
	}

	public String getIcon() {
		return Global.getSettings().getSpriteName("intel", "pather_base");
		//return market.getFaction().getCrest();
	}

	public Set<String> getIntelTags(SectorMapAPI map) {
		Set<String> tags = super.getIntelTags(map);
		tags.add(Tags.INTEL_EXPLORATION);

		for (SPP_LuddicPathCellsIntel cell : SPP_LuddicPathCellsIntel.getCellsForCamp(this, true)) {
			if (cell.getMarket().isPlayerOwned()) {
				tags.add(Tags.INTEL_COLONIES);
				break;
			}
		}

		tags.add(Factions.LUDDIC_PATH);
		return tags;
	}

	@Override
	public SectorEntityToken getMapLocation(SectorMapAPI map) {
		if (market.getPrimaryEntity().isDiscoverable()) {
			return market.getStarSystem().getCenter();
		}
		return market.getPrimaryEntity();
	}

	public List<ArrowData> getArrowData(SectorMapAPI map) {
		return null;
	}


    public static SPP_LuddicPathCampIntel getIntelForCamp(MarketAPI market) {
        for (IntelInfoPlugin intel : Global.getSector().getIntelManager().getIntel(SPP_LuddicPathBaseIntel.class)) {
            SPP_LuddicPathCampIntel curr = (SPP_LuddicPathCampIntel) intel;

            if (curr.getMarket() == market) return curr;
        }

        return null;
    }
}
