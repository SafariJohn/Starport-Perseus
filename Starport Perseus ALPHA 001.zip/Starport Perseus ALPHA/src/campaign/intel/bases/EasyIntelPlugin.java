package campaign.intel.bases;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.ui.SectorMapAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import java.util.Set;

/**
 * Author: SafariJohn
 */
public class EasyIntelPlugin extends BaseIntelPlugin {

    public void showIntelToPlayer(boolean show) {
        if (show) Global.getSector().getIntelManager().addIntel(this);
        else Global.getSector().getIntelManager().removeIntel(this);
    }

    @Override
    public String getIcon() {
        return super.getIcon(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void createIntelInfo(TooltipMakerAPI info, ListInfoMode mode) {
        super.createIntelInfo(info, mode); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getSmallDescriptionTitle() {
        return super.getSmallDescriptionTitle(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void createSmallDescription(TooltipMakerAPI info, float width, float height) {
        super.createSmallDescription(info, width, height); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Set<String> getIntelTags(SectorMapAPI map) {
        return super.getIntelTags(map); //To change body of generated methods, choose Tools | Templates.
    }
}
