package campaign.intel;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.impl.campaign.intel.BaseEventManager;

public class SPP_PersonBountyManager extends BaseEventManager {

	public static final String KEY = "$core_personBountyManager";

	public static SPP_PersonBountyManager getInstance() {
		Object test = Global.getSector().getMemoryWithoutUpdate().get(KEY);
		return (SPP_PersonBountyManager) test;
	}

	public SPP_PersonBountyManager() {
		super();
		Global.getSector().getMemoryWithoutUpdate().set(KEY, this);
	}

	@Override
	protected int getMinConcurrent() {
		return Global.getSettings().getInt("minPersonBounties");
	}
	@Override
	protected int getMaxConcurrent() {
		return Global.getSettings().getInt("maxPersonBounties");
	}

	@Override
	protected float getIntervalRateMult() {
//		if (true) {
//			currMax = 200;
//			return 1000f;
//		}
		return super.getIntervalRateMult();
	}

	@Override
	protected EveryFrameScript createEvent() {
		if ((float) Math.random() < 0.75f) return null;

		      SPP_PersonBountyIntel intel = new SPP_PersonBountyIntel();
		if (intel.isDone()) intel = null;

		return intel;
	}

}
