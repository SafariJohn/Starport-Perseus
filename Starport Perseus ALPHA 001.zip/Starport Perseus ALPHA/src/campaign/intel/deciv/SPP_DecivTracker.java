package campaign.intel.deciv;

import campaign.SPP_ImmigrationScript;
import campaign.econ.SPP_NativePopCondition;
import campaign.econ.industries.SPP_Spaceport;
import campaign.ids.SPP_Conditions;
import campaign.ids.SPP_MemKeys;
import campaign.ids.SPP_Tags;
import campaign.rulecmd.SPP_MarketCMD;
import static campaign.rulecmd.SPP_MarketCMD.addBombardVisual;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Random;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.impl.campaign.DebugFlags;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.TimeoutTracker;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import util.SPP_Misc;
import util.SPP_PortFunctions;

public class SPP_DecivTracker implements EveryFrameScript {

	public static final String KEY = "$core_decivTracker";

	public static final String NO_DECIV_KEY = "$core_noDeciv";

	public static class MarketDecivData {
		MarketAPI market;
		List<Float> stabilityHistory = new ArrayList<Float>();
	}


	public static SPP_DecivTracker getInstance() {
		Object test = Global.getSector().getMemoryWithoutUpdate().get(KEY);
		return (SPP_DecivTracker) test;
	}

	public SPP_DecivTracker() {
		super();
		Global.getSector().getMemoryWithoutUpdate().set(KEY, this);
	}

	protected LinkedHashMap<MarketAPI, MarketDecivData> decivData = new LinkedHashMap<MarketAPI, MarketDecivData>();
	protected IntervalUtil sampler = new IntervalUtil(20f, 40f);
	protected IntervalUtil checker = new IntervalUtil(5f, 15f);
	protected TimeoutTracker<String> sentWarning = new TimeoutTracker<String>();
	protected Random random = new Random();


	protected Object readResolve() {
		if (sentWarning == null) {
			sentWarning = new TimeoutTracker<String>();
		}
		return this;
	}

	public void advance(float amount) {

		float days = Misc.getDays(amount);
		if (DebugFlags.DECIV_DEBUG) {
			days *= 1000f;
		}

		sentWarning.advance(days);

		sampler.advance(days);
		if (sampler.intervalElapsed()) {
			updateSamples();
		}
		checker.advance(days);
		if (checker.intervalElapsed()) {
			checkDeciv();
		}
	}

	public MarketDecivData getDataFor(MarketAPI market) {
		MarketDecivData data = decivData.get(market);
		if (data == null) {
			data = new MarketDecivData();
			data.market = market;
			decivData.put(market, data);
		}
		return data;
	}

	public static int getMaxMonths() {
		return Global.getSettings().getInt("decivSamplingMonths");
	}
	public static int getMinStreak() {
		return Global.getSettings().getInt("decivMinStreak");
	}
	public static float getProbPerMonth() {
		return Global.getSettings().getFloat("decivProbPerMonthOverStreak");
	}
	public static float getMinFraction() {
		return Global.getSettings().getFloat("decivZeroStabilityMinFraction");
	}


	protected void updateSamples() {

		for (MarketAPI market : new ArrayList<MarketAPI>(decivData.keySet())) {
			if (!market.isInEconomy()) {
				decivData.remove(market);
			}
		}

		int maxSamples = getMaxMonths();
		for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
			MarketDecivData data = getDataFor(market);

			data.stabilityHistory.add(market.getStabilityValue());
			while (data.stabilityHistory.size() > maxSamples && !data.stabilityHistory.isEmpty()) {
				data.stabilityHistory.remove(0);
			}
		}
	}

	protected void checkDeciv() {
		for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
			if (checkDeciv(market)) break;
		}
	}


	protected boolean checkDeciv(MarketAPI market) {
		MarketDecivData data = getDataFor(market);

		int max = getMaxMonths();
		int min = getMinStreak();
		float per = getProbPerMonth();
		float fraction = getMinFraction();

		if (data.stabilityHistory.size() < max) return false;
		if (data.stabilityHistory.get(0) > 0) return false;

		float streak = 0;
		float zeroCount = 0;
		boolean streakEnded = false;
		for (int i = data.stabilityHistory.size() - 1; i >= 0; i--) {
			Float curr = data.stabilityHistory.get(i);
			if (curr <= 0) {
				zeroCount++;
				if (!streakEnded) streak++;
			} else {
				streakEnded = true;
			}
		}

		if (streak < min) return false;
		if (zeroCount / max < fraction) return false;

		float prob = (streak - min) * per;


		String id = market.getId();
		if (!sentWarning.contains(id)) {
			sendWarning(market);
			sentWarning.add(id, 180f);
			return false;
		}
//		if (prob == 0f) {
//			sendWarning(market);
//			return false;
//		}

		if (random.nextFloat() >= prob) return false;

        boolean destroy = false;

        if (market.getSize() < SPP_Spaceport.SPACEPORT_SIZE) destroy = true;
        if (market.hasCondition(SPP_Conditions.ORBITAL_STATION)) destroy = true;

		decivilize(market, destroy);
		return true;
	}

	public static void decivilize(MarketAPI market, boolean fullDestroy) {
		decivilize(market, fullDestroy, true);
	}

	public static void decivilize(MarketAPI market, boolean fullDestroy, boolean withIntel) {
		if (market.getMemoryWithoutUpdate().getBoolean(NO_DECIV_KEY)) return;

		if (market.getPrimaryEntity().isDiscoverable()) withIntel = false;

		if (withIntel) {
			SPP_DecivIntel intel = new SPP_DecivIntel(market, market.getPrimaryEntity(), fullDestroy, false);
			Global.getSector().getIntelManager().addIntel(intel);
		}

        convertToConditionMarket(market);

        if (SPP_Misc.getStation(market.getPrimaryEntity()) != null) removeStation(market);

        decivilizePopulation(market);

		Global.getSector().getEconomy().removeMarket(market);

		market.advance(0f);

//		Misc.removeRadioChatter(market);
//        if (moon != null) {
//            Misc.removeRadioChatter(moon.getMarket());
//            moon.getMarket().advance(0f);
//        }

	}

    public static void destroyPort(MarketAPI market) {

    }

    private static void convertToConditionMarket(MarketAPI market) {
		market.setPlanetConditionMarketOnly(true);
		market.setFactionId(Factions.NEUTRAL);

		market.setSize(1);

		for (SectorEntityToken entity : market.getConnectedEntities()) {
			entity.setFaction(Factions.NEUTRAL);

            if (entity == market.getPrimaryEntity()) continue;

            // Detach minor moons
            if (entity instanceof PlanetAPI && !entity.getOrbitFocus().isStar()
                        && entity.getOrbitFocus() instanceof PlanetAPI) {
                MarketAPI mMarket = Global.getFactory().createMarket("SPP_market_" + entity.getId(), entity.getName(), 1);
                //market = Global.getFactory().createConditionMarket("market_" + planet.getId(), planet.getName(), 1);
                mMarket.setPlanetConditionMarketOnly(true);
                mMarket.setPrimaryEntity(entity);
                mMarket.setFactionId(Factions.NEUTRAL);
                entity.setMarket(mMarket);

                entity.addTag(SPP_Tags.NO_INTERACTION);
            }
		}

        market.setPlayerOwned(false);

		market.setAdmin(null);

		market.getCommDirectory().clear();
		for (PersonAPI person : market.getPeopleCopy()) {
			market.removePerson(person);
            // VIP stuff
		}

		for (MarketConditionAPI mc : new ArrayList<MarketConditionAPI>(market.getConditions())) {
			if (mc.getSpec().isDecivRemove()) {
				market.removeSpecificCondition(mc.getIdForPluginModifications());
			}
		}

		market.clearCommodities();

		for (Industry ind : new ArrayList<Industry>(market.getIndustries())) {
			market.removeIndustry(ind.getId(), null, false);
		}

		market.getMemoryWithoutUpdate().set("$wasCivilized", true);

		SectorEntityToken primary = market.getPrimaryEntity();
        if (primary != null) {
            market.getConnectedEntities().clear();
            market.setPrimaryEntity(primary);
        }

		Global.getSector().getEconomy().removeMarket(market);

        // Check for moon entity
        PlanetAPI moon = SPP_Misc.getMoon(market.getPrimaryEntity());
        // Create condition market for moon
        if (moon != null && market.getConnectedEntities().contains(moon)) {
            market.getConnectedEntities().remove(moon);

            MarketAPI mMarket = Global.getFactory().createMarket(moon.getId() + "_market", moon.getName(), 0);
            mMarket.setPlanetConditionMarketOnly(true);
            mMarket.setFactionId(Factions.NEUTRAL);

            mMarket.setSurveyLevel(MarketAPI.SurveyLevel.FULL);
            mMarket.setPrimaryEntity(moon);

            for (String mcId : (List<String>) moon.getMemoryWithoutUpdate().get(SPP_MemKeys.LUNAR_CONDITIONS)) {
                String token = mMarket.addCondition(mcId);
                mMarket.getSpecificCondition(token).setSurveyed(true);
            }

            mMarket.getMemoryWithoutUpdate().set("$wasCivilized", true);

            moon.setMarket(mMarket);
        }
    }

    private static void removeStation(MarketAPI market) {
        SectorEntityToken station = SPP_Misc.getStation(market.getPrimaryEntity());

		if (station != null) {
            if (station.getMemoryWithoutUpdate().getBoolean(SPP_Tags.DO_NOT_DESTROY)) {
                SPP_Misc.setAbandonedStationMarket(station.getId() + "_market", station);
            } else {
                addBombardVisual(station);
                Misc.fadeAndExpire(station, 1f);
            }
		}

        PlanetAPI moon = SPP_Misc.getMoon(market.getPrimaryEntity());

        market.getPrimaryEntity().getMemoryWithoutUpdate().unset(SPP_Tags.MEMKEY_ORBITAL_STATION_ID);
        if (moon != null) moon.getMemoryWithoutUpdate().unset(SPP_Tags.MEMKEY_ORBITAL_STATION_ID);
    }

    private static void decivilizePopulation(MarketAPI market) {
        int population = SPP_PortFunctions.getPopulationSize(market);

		market.getPopulation().setWeight(SPP_ImmigrationScript.getWeightForPopulationSizeStatic(population));
		market.getPopulation().normalize();

        for (MarketConditionAPI mc : market.getConditions()) {
            if (mc.getPlugin() instanceof SPP_NativePopCondition) return;
        }

        // Random population loss?

        // Random result:
        WeightedRandomPicker<String> picker = new WeightedRandomPicker();
        // Abandoned
        if (population < SPP_MarketCMD.ATROCITY_SCALE) picker.add("abandoned", SPP_MarketCMD.ATROCITY_SCALE - population);

        // Primitives or Nation-States?
//        if (population > 3) {
//            if (market.hasCondition(Conditions.HABITABLE)) picker.add(SPP_Conditions.PRIMITIVES, population);
//            if (market.getHazard().getModifiedValue() <= 2f) picker.add(SPP_Conditions.NATION_STATES, population);
//        }

        // Decivilized
        if (population < 5) picker.add(SPP_Conditions.DECIVILIZED, population);

        // Xenophobes take over
        picker.add(SPP_Conditions.WORLD_ORDER);
        // Population becomes xenophobic
        picker.add(SPP_Conditions.XENOPHOBES);

        String condId = picker.pick();

        PlanetAPI moon = SPP_Misc.getMoon(market.getPrimaryEntity());

        if (condId.equals("abandoned")) {
            condId = SPP_PortFunctions.getPopulationConditionId(population);
            market.removeCondition(condId);
            market.addCondition(SPP_Conditions.POPULATION_0);
            if (moon != null) {
                moon.getMarket().removeCondition(condId);
                moon.getMarket().addCondition(SPP_Conditions.POPULATION_0);
            }
        } else {
            market.addCondition(condId);
            if (moon != null) moon.getMarket().addCondition(condId);
        }
    }


    // Lunar+planet ports, station ports, lunar+station+planet ports
	public static void removePort(MarketAPI market, boolean withRuins) {
		if (market.getMemoryWithoutUpdate().getBoolean(NO_DECIV_KEY)) return;

        convertToConditionMarket(market);

        if (SPP_Misc.getStation(market.getPrimaryEntity()) != null) removeStation(market);

        removePopulation(market);

		Global.getSector().getEconomy().removeMarket(market);

		market.advance(0f);
	}

    private static void removePopulation(MarketAPI market) {
        int population = SPP_PortFunctions.getPopulationSize(market);

		market.getPopulation().setWeight(SPP_ImmigrationScript.getWeightForPopulationSizeStatic(population));
		market.getPopulation().normalize();

        // Native pops stay
        for (MarketConditionAPI mc : market.getConditions()) {
            if (mc.getPlugin() instanceof SPP_NativePopCondition) return;
        }

        if (population >= SPP_MarketCMD.ATROCITY_SCALE) {
            decivilizePopulation(market);
            return;
        }

        PlanetAPI moon = SPP_Misc.getMoon(market.getPrimaryEntity());

        String condId = SPP_PortFunctions.getPopulationConditionId(population);
        market.removeCondition(condId);
        market.addCondition(SPP_Conditions.POPULATION_0);
        if (moon != null) {
            moon.getMarket().removeCondition(condId);
            moon.getMarket().addCondition(SPP_Conditions.POPULATION_0);
        }
    }

	public static void sendWarning(MarketAPI market) {
		SPP_DecivIntel intel = new SPP_DecivIntel(market, market.getPrimaryEntity(), false, true);
		Global.getSector().getIntelManager().addIntel(intel);
	}

	public boolean isDone() {
		return false;
	}

	public boolean runWhilePaused() {
		return false;
	}

}















