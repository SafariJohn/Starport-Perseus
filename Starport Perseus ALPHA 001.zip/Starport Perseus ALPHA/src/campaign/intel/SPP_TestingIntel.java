package campaign.intel;

import campaign.ids.SPP_Conditions;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.ui.TooltipMakerAPI;

/**
 * Author: SafariJohn
 */
public class SPP_TestingIntel extends BaseIntelPlugin {

    @Override
    public boolean isImportant() {
        return true;
    }

    @Override
    public boolean isPlayerVisible() {
        return true;
//        return Global.getSettings().isDevMode();
    }


    @Override
    public void createSmallDescription(TooltipMakerAPI info, float width, float height) {
        info.addPara("Nothing atm", 0f);

//        for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
//            if (market.hasCondition(SPP_Conditions.CLOUD_SEA)) {
//                info.addPara(market.getName() + " in the " + market.getStarSystem().getNameWithLowercaseType(), 3f);
//            }
//        }

//        float smallest = 10000;
        for (StarSystemAPI system : Global.getSector().getStarSystems()) {
            for (PlanetAPI planet : system.getPlanets()) {
                if (planet.getMarket() == null) continue;

                if (planet.getMarket().hasCondition(SPP_Conditions.MOON_SIPHON)) {
                    info.addPara(planet.getName() + " in the " + system.getNameWithLowercaseType(), 3f);
                }
            }
        }
//
//        info.addPara("Smallest is " + smallest, 0);

//        for (StarSystemAPI system : Global.getSector().getStarSystems()) {
//            for (PlanetAPI planet : system.getPlanets()) {
//                if (planet.getOrbitFocus() == null) continue;
//                if (planet.getOrbitFocus().isStar()) continue;
//                if (planet.getOrbitFocus().isSystemCenter()) continue;
//                if (planet.getOrbitFocus().getRadius() <= 180 &&
//                planet.getOrbitFocus().getRadius() * 0.5 < planet.getRadius()) {
////                if (planet.getRadius() < StarSystemGenerator.MIN_MOON_RADIUS) {
//                    info.addPara(planet.getName() + " in the " + system.getNameWithLowercaseType(), 3f);
//                }
//            }
//        }
    }

}
