package campaign.intel;

import campaign.fleets.SPP_SystemWarFleetRouteManager;
import campaign.ids.SPP_Industries;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.econ.impl.MilitaryBase.PatrolFleetData;
import com.fs.starfarer.api.impl.campaign.fleets.RouteManager.RouteData;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.LabelAPI;
import com.fs.starfarer.api.ui.SectorMapAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import java.awt.Color;
import java.util.List;
import java.util.Set;
import util.SPP_Misc;
import util.SPP_PortFunctions;

/**
 * Author: SafariJohn
 */
public class SPP_SystemControlIntel extends BaseIntelPlugin {

    protected StarSystemAPI system;

    public SPP_SystemControlIntel(StarSystemAPI system) {
        this.system = system;
    }

    @Override
    public boolean isHidden() {
        return SPP_Misc.getSystemClaimants(system).isEmpty();
    }

    @Override
    public Set<String> getIntelTags(SectorMapAPI map) {
        Set<String> tags = super.getIntelTags(map);
        List<FactionAPI> factions = SPP_Misc.getSystemClaimants(system);

        for (FactionAPI faction : factions) {
            tags.add(faction.getId());
        }

        if (factions.size() > 1) tags.add("Disputed Systems");

        tags.add("Claimed Systems");

        return tags;
    }

    @Override
    public FactionAPI getFactionForUIColors() {
        List<FactionAPI> factions = SPP_Misc.getSystemClaimants(system);

        if (factions.size() == 1) {
            return factions.get(0);
        }

        return Global.getSector().getFaction(Factions.NEUTRAL);
    }

    @Override
    public String getIcon() {
        List<FactionAPI> factions = SPP_Misc.getSystemClaimants(system);

        if (factions.isEmpty()) return Global.getSector().getFaction(Factions.NEUTRAL).getCrest();
        if (factions.size() == 1) return factions.get(0).getCrest();

		return Global.getSettings().getSpriteName("intel", "hostilities");
    }

    @Override
    public void createIntelInfo(TooltipMakerAPI info, ListInfoMode mode) {

        FactionAPI uiFaction = getFactionForUIColors();
        float pad = 3f;
		Color tc = getBulletColorForMode(mode);

		Color c = getTitleColor(mode);
		info.addPara(system.getName(), c, 0f);
//        info.addTitle(system.getNameWithLowercaseType(), uiFaction.getBaseUIColor());

		bullet(info);

        // Merge port owners and claimants
        List<FactionAPI> factions = SPP_Misc.getSystemClaimants(system);

//        for (MarketAPI port : Global.getSector().getEconomy().getMarkets(system)) {
//            if (!factions.contains(port.getFaction())) factions.add(port.getFaction());
//        }

        for (FactionAPI faction : factions) {
            info.addPara(faction.getDisplayName(), 0f, tc,
                         faction.getBaseUIColor(), faction.getDisplayName());
        }

		unindent(info);
    }

    @Override
    public SectorEntityToken getMapLocation(SectorMapAPI map) {
        return system.getHyperspaceAnchor();
    }

    @Override
    public void createSmallDescription(TooltipMakerAPI info, float width, float height) {
		Color h = SPP_Misc.getHighlightColor();
		float pad = 3f;
		float opad = 10f;

        FactionAPI uiFaction = getFactionForUIColors();

        info.addSectionHeading(system.getName(),
                    uiFaction.getBaseUIColor(), uiFaction.getDarkUIColor(),
                    Alignment.MID, pad);

        // Need to display system owner/claimants
        List<FactionAPI> factions = SPP_Misc.getSystemClaimants(system);
        if (factions.size() == 1) {

            String control = "control";
            if (uiFaction.getDisplayNameIsOrAre().equals("is")) control = "controls";

            info.addImage(uiFaction.getLogo(), width, opad);
            info.addPara(SPP_Misc.ucFirst(uiFaction.getDisplayNameWithArticle()) + " "
                        + control + " the " + system.getName()+ ".",
                        opad, uiFaction.getBaseUIColor(),
                        uiFaction.getDisplayNameWithArticleWithoutArticle());
        } else {
            // Go 2 by 2?

//            String[] crests = new String[factions.size()];
//            for (FactionAPI faction : factions) {
//                crests[factions.indexOf(faction)] = faction.getCrest();
//            }
//
//            info.addImages(width, 128, pad, pad, crests);
        }


        // Discuss system defense fleets here?
        // Count fleets and compare as % to max fleets? "Defense Fleet Readiness" or something
        // Or readiness % of your portion of defense fleets (min 1)
//        info.addSectionHeading("Military Activity",
//                    uiFaction.getBaseUIColor(), uiFaction.getDarkUIColor(),
//                    Alignment.MID, opad);

//        int currFleets = 0;
        int currFP = 0;
//        int spawnFP = 0;
//
        SPP_SystemWarFleetRouteManager fleets = SPP_Misc.getWarFleetRouteManager(system);
        boolean playerFleets = uiFaction == Global.getSector().getPlayerFaction();
        for (RouteData route : fleets.getSourcesByRouteCopy().keySet()) {
            if (!route.getFactionId().equals(Factions.PLAYER)) continue;
            if (!(route.getCustom() instanceof PatrolFleetData)) continue;

            playerFleets = true;

            PatrolFleetData custom = (PatrolFleetData) route.getCustom();

            currFP += route.getActiveFleet().getFleetPoints();
//            spawnFP += custom.spawnFP;
        }

        if (!playerFleets) return;

//        float percentFP = currFP / spawnFP;
//        float percentFleets = currFleets / (fleets.getMaxFleets());
//        float readiness = percentFP * percentFleets;
//        String readinessStr = (int) (percentFP * 100f) + "%";

        LabelAPI label = info.addPara("Your system defense fleet strength: " + currFP, opad);
        label.setHighlightColors(Global.getSector().getPlayerFaction().getBaseUIColor(), h);
        label.setHighlight("Your", "" + currFP);

//        bullet(info);
//
//        info.addPara("War fleet strength: " + currFP, pad, h, "" + currFP);
//        info.addPara("Military power: N/A", pad);

        // Diplay info on ports in system
//        info.addSectionHeading("Local Ports",
//                    uiFaction.getBaseUIColor(), uiFaction.getDarkUIColor(),
//                    Alignment.MID, opad);
//
//        List<MarketAPI> ports = Global.getSector().getEconomy().getMarkets(system);
//        // Would be nice to sort by size
//
//        for (MarketAPI port : ports) {
//            if (port.getPrimaryEntity().isDiscoverable()) continue;
//
//            Color color = port.getFaction().getBaseUIColor();
//
//            info.addPara("  " + port.getName() + " - " + port.getFaction().getDisplayName(),
//                        color, pad);
//
//            String type = "";
//
//            SectorEntityToken entity = port.getPrimaryEntity();
//            if (entity instanceof PlanetAPI) {
//                PlanetAPI planet = (PlanetAPI) entity;
//                type = planet.getTypeNameWithLowerCaseWorld();
//                if (planet.isMoon()) type = type.replace("world", "moon");
//            } else {
//                PlanetAPI parent = SPP_Misc.getParent(entity);
//
//                if (parent != null) {
//                    type = "Orbital station over " + parent.getTypeNameWithLowerCaseWorld();
//
//                    if (parent.isMoon()) {
//                        type = type.replace("world", "moon");
//                    }
//                } else {
//                    type = "Orbital station";
//                }
//            }
//
//            if (!type.isEmpty()) info.addPara("   " + SPP_Misc.ucFirst(type.toLowerCase()), pad);
//
//            bullet(info);
//
//            info.addPara(getPortText(port),
//                        pad, h, "" + port.getSize());
//            info.addPara(getPopulationText(port), pad,
//                        SPP_Misc.getHighlightColor(), "" +  SPP_PortFunctions.getPopulationSize(port));
//
//            addNotableIndustries(info, port);
//
//            unindent(info);
//        }
    }

    private String getPortText(MarketAPI port) {
        Industry ind = port.getIndustry(SPP_Industries.SPACEPORT);

        return "Level " + port.getSize() + " " + ind.getCurrentName().toLowerCase();
    }

    private String getPopulationText(MarketAPI port) {
        int population = SPP_PortFunctions.getPopulationSize(port);

        String text;

        switch (population) {
            case 0: text = "none"; break;
            case 1: text = "tens"; break;
            case 2: text = "hundreds"; break;
            case 3: text = "thousands"; break;
            case 4: text = "tens of thousands"; break;
            case 5: text = "hundreds of thousands"; break;
            case 6: text = "millions"; break;
            case 7: text = "tens of millions"; break;
            case 8: text = "hundreds of millions"; break;
            case 9: text = "billions"; break;
            case 10:
            default: text = "tens of billions"; break;
        }

        return "Pop scale " + population + ", " + text;
    }


    private void addNotableIndustries(TooltipMakerAPI info, MarketAPI port) {
		float pad = 3f;
		float opad = 10f;

        for (Industry ind : port.getIndustries()) {
            if (ind.getSpec().hasTag("notable")) {
                info.addPara(ind.getCurrentName(), pad);
            }
        }
    }
}
