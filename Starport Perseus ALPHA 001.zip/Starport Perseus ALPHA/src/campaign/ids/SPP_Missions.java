package campaign.ids;

/**
 * Author: SafariJohn
 */
public class SPP_Missions {
    public static final String ASSASSINATION = "assassination";
    public static final String ESCORT = "escort";
    public static final String COURIER = "courier";
    public static final String THEFT = "theft";
    public static final String SALVAGE = "salvage";
    public static final String BAD_BLOOD = "badBlood";
    public static final String DARE = "dare";
}
