package campaign.ids;

/**
 * Author: SafariJohn
 */
public class SPP_FleetTypes {

    public static final String CUTTER = "SPP_cutterFleet";


    public static final String WAR_FLEET_PATROL = "patrol";
    public static final String WAR_FLEET_MILITARY = "military";
    public static final String WAR_FLEET_MERC = "mercenary";
    public static final String WAR_FLEET_RAIDER = "raider";


    public static final String MILITARY_SMALL = "militarySmall";
    public static final String MILITARY_MEDIUM = "militaryMedium";
    public static final String MILITARY_LARGE = "militaryLarge";

    public static final String RAIDER_SMALL = "raiderSmall";
    public static final String RAIDER_MEDIUM = "raiderMedium";
    public static final String RAIDER_LARGE = "raiderLarge";
}
