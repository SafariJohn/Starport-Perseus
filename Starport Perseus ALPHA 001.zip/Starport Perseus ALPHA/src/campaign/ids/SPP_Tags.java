package campaign.ids;

/**
 * Author: SafariJohn
 */
public class SPP_Tags {
	public static final String INTEL_COLONIES = "Port threats"; // Need to replace vanilla tag usages

    public static final String NO_INTERACTION = "no_interaction";

    public static final String MEMKEY_ORBITAL_STATION_ID = "$SPP_orbitalEntityId";
    public static final String MEMKEY_ORBITAL_PLANET_ID = "$SPP_orbitalPlanetId";
    public static final String MEMKEY_CLOSE_MOON_ID = "$SPP_closeMoonId";

    public static final String MEMKEY_NO_CRUSHING = "$SPP_skipCrushGrav";
    public static final String MEMKEY_POP_GROWTH = "$SPP_enablePopGrowth";

    public static final String DO_NOT_DESTROY = "$SPP_doNotDestroy";

    public static final String MEMKEY_SIPHON_MOON = "$SPP_siphonMoon"; // PlanetAPI on target, boolean on moon
    public static final String MEMKEY_TAP_TARGET = "$SPP_tapTarget";
}
