package campaign.ids;

import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import java.util.HashMap;
import java.util.Map;

/**
 * Author: SafariJohn
 */
public class SPP_Planets {
    public static final String CAT_GIANT = "cat_giant";

    public static final String CAT_HAB5 = "cat_hab5";
    public static final String CAT_HAB4 = "cat_hab4";
    public static final String CAT_HAB3 = "cat_hab3";
    public static final String CAT_HAB2 = "cat_hab2";
    public static final String CAT_HAB1 = "cat_hab1";

    public static final String CAT_LAVA = "cat_lava";
    public static final String CAT_BARREN = "cat_barren";

    public static final String CAT_CRYO = "cat_cryovolcanic";
    public static final String CAT_FROZEN = "cat_frozen";

    public static final String CAT_RAD = "cat_irradiated";
    public static final String CAT_TOXIC = "cat_toxic";

    public static final String GAS_GIANT = "gas_giant";
    public static final String ICE_GIANT = "ice_giant";
    public static final String TOXIC_WORLD = "toxic";
    public static final String ROCKY_METALLIC = "rocky_metallic";
    public static final String ROCKY_UNSTABLE = "rocky_unstable";


    public static final Map<String, String> CATEGORIES = new HashMap<>();
    static {
        CATEGORIES.put(GAS_GIANT, CAT_GIANT);
        CATEGORIES.put(ICE_GIANT, CAT_GIANT);

        CATEGORIES.put(StarTypes.PLANET_TERRAN, CAT_HAB4);

        CATEGORIES.put(StarTypes.PLANET_TERRAN_ECCENTRIC, CAT_HAB3);
        CATEGORIES.put(StarTypes.PLANET_WATER, CAT_HAB3);
        CATEGORIES.put("tundra", CAT_HAB3);
        CATEGORIES.put("arid", CAT_HAB3);
        CATEGORIES.put("jungle", CAT_HAB3);

        CATEGORIES.put(StarTypes.PLANET_LAVA, CAT_LAVA);
        CATEGORIES.put(StarTypes.PLANET_LAVA_MINOR, CAT_LAVA);

        CATEGORIES.put("barren", CAT_BARREN);
        CATEGORIES.put("barren_castiron", CAT_BARREN);
        CATEGORIES.put("barren2", CAT_BARREN);
        CATEGORIES.put("barren3", CAT_BARREN);
        CATEGORIES.put("barren_venuslike", CAT_BARREN);
        CATEGORIES.put(ROCKY_METALLIC, CAT_BARREN);
        CATEGORIES.put(ROCKY_UNSTABLE, CAT_BARREN);
        CATEGORIES.put("rocky_ice", CAT_BARREN);
        CATEGORIES.put("barren-bombarded", CAT_BARREN);

        CATEGORIES.put("frozen", CAT_FROZEN);
        CATEGORIES.put("frozen1", CAT_FROZEN);
        CATEGORIES.put("frozen2", CAT_FROZEN);
        CATEGORIES.put("frozen3", CAT_FROZEN);

        CATEGORIES.put("cryovolcanic", CAT_CRYO);

        CATEGORIES.put("irradiated", CAT_RAD);

        CATEGORIES.put(TOXIC_WORLD, CAT_TOXIC);
        CATEGORIES.put("toxic_cold", CAT_TOXIC);

        CATEGORIES.put("desert", CAT_HAB2);
        CATEGORIES.put("desert1", CAT_HAB2);

        CATEGORIES.put("barren-desert", CAT_HAB1);
    }

}
