package campaign.ids;

/**
 * Author: SafariJohn
 */
public class SPP_Events {
    public static final String SURVEY_SALE = "surveySale";
}
