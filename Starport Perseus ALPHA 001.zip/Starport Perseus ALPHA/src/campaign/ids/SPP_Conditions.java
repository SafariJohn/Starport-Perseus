package campaign.ids;

import com.fs.starfarer.api.impl.campaign.ids.Conditions;

/**
 * Author: SafariJohn
 */
public class SPP_Conditions {
    public static final String POPULATION_0 = "SPP_population_0";

    public static final String MICROGRAVITY = "SPP_micrograv";
    public static final String CLOUD_SEA = "SPP_cloudSea";

    public static final String DECIVILIZED = "spp_decivilized";
    public static final String PRIMITIVES = "SPP_primitives";
    public static final String NATION_STATES = "SPP_nationStates";
    public static final String XENOPHOBES = "SPP_xenophobes";
    public static final String WORLD_ORDER = "SPP_worldOrder";
    public static final String MOON_PORT = "SPP_moonPort";

    public static final String SIPHON_TAPPED = "SPP_siphonTap";
    public static final String MOON_SIPHON = "SPP_moonSiphon";

    // Uninhabitable conditions
    public static final String CRUSHING_GRAVITY = "SPP_extremeGrav";

    // Station blocking conditions
    public static final String ABANDONED_STATION = "SPP_abandonedStation";
    public static final String WARNING_BEACON = "SPP_warningBeacon";
    public static final String MAGNETIC_FIELD = "SPP_magneticField";
    public static final String MOON = "SPP_moon";
    public static final String FULL_ORBIT = "SPP_fourMoons";

    // Lunar Base conditions
    public static final String CLOSE_MOON = "SPP_closeMoon";
    public static final String TIGHT_MOON = "SPP_tightMoon";
    public static final String LUNAR_ORBIT = "SPP_closeParent";
    public static final String TIGHT_ORBIT = "SPP_tightOrbit";

    public static final String ORBITAL_STATION = "SPP_station"; // Hazard condition for stations
    public static final String PORT_IN_ORBIT = "SPP_stationPort"; // Controls building a port on planet
    public static final String HIDDEN_STATION = "SPP_stationPort_hidden"; // For undiscovered ports

    public static final String GRAVEYARD = "SPP_graveyard";
    public static final String BONEYARD = "SPP_boneyard";

    public static final String CRYOVAULT = "SPP_cryosanctum";
    public static final String HIVE_CITIES = "SPP_hiveCities";
    public static final String SYNCHROTRON = "SPP_fuelFactory";


    // Orbital versions of resources
//	public static final String WATER_SURFACE_ORBITAL = "SPP_ruins_scattered";
//
//	public static final String RUINS_SCATTERED_ORBITAL = "SPP_ruins_scattered";
//	public static final String RUINS_WIDESPREAD_ORBITAL = "SPP_ruins_widespread";
//	public static final String RUINS_EXTENSIVE_ORBITAL = "SPP_ruins_extensive";
//	public static final String RUINS_VAST_ORBITAL = "SPP_ruins_vast";
//
//	public static final String ORE_SPARSE_ORBITAL = "SPP_ore_sparse";
//	public static final String ORE_MODERATE_ORBITAL = "SPP_ore_moderate";
//	public static final String ORE_ABUNDANT_ORBITAL = "SPP_ore_abundant";
//	public static final String ORE_RICH_ORBITAL = "SPP_ore_rich";
//	public static final String ORE_ULTRARICH_ORBITAL = "SPP_ore_ultrarich";
//
//	public static final String RARE_ORE_SPARSE_ORBITAL = "SPP_rare_ore_sparse";
//	public static final String RARE_ORE_MODERATE_ORBITAL = "SPP_rare_ore_moderate";
//	public static final String RARE_ORE_ABUNDANT_ORBITAL = "SPP_rare_ore_abundant";
//	public static final String RARE_ORE_RICH_ORBITAL = "SPP_rare_ore_rich";
//	public static final String RARE_ORE_ULTRARICH_ORBITAL = "SPP_rare_ore_ultrarich";
//
//	public static final String VOLATILES_TRACE_ORBITAL = Conditions.VOLATILES_TRACE;
//	public static final String VOLATILES_DIFFUSE_ORBITAL = Conditions.VOLATILES_DIFFUSE;
//	public static final String VOLATILES_ABUNDANT_ORBITAL = "SPP_volatiles_abundant";
//	public static final String VOLATILES_PLENTIFUL_ORBITAL = "SPP_volatiles_plentiful";
//
//	public static final String ORGANICS_TRACE_ORBITAL = "SPP_organics_trace";
//	public static final String ORGANICS_COMMON_ORBITAL = "SPP_organics_common";
//	public static final String ORGANICS_ABUNDANT_ORBITAL = "SPP_organics_abundant";
//	public static final String ORGANICS_PLENTIFUL_ORBITAL = "SPP_organics_plentiful";
//
//	public static final String FARMLAND_POOR_ORBITAL = "SPP_farmland_poor";
//	public static final String FARMLAND_ADEQUATE_ORBITAL = "SPP_farmland_adequate";
//	public static final String FARMLAND_RICH_ORBITAL = "SPP_farmland_rich";
//	public static final String FARMLAND_BOUNTIFUL_ORBITAL = "SPP_farmland_bountiful";
}
