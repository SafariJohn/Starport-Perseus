package campaign.ids;

/**
 * Author: SafariJohn
 */
public class SPP_MemKeys {
    public static final String LUNAR_CONDITIONS = "$SPP_lunarConditions"; // List<String> condition ids
    public static final String ORBITAL_CONDITIONS = "$SPP_orbitalConditions"; // Set<String> condition ids, replacing X_orbital conditions

    public static final String SIPHON_SAVED_COND = "$SPP_savedSiphonCondition"; // Condition id or empty String

    public static final String FACTION_REP = "$SPP_factionRep"; // Person's key = FACTION_REP + faction's id
    public static final String FACTION_REP_KNOWN = "$SPP_factionRepKnown";
    public static final String MEETING_MANAGER = "$SPP_meetingManager";

    public static final String TRADE_FLEET_WEIGHT = "$SPP_tradeFleetWeight"; // Mutable stat - chance for trade fleets to spawn at a given market
    public static final String MERC_FLEET_WEIGHT = "$SPP_mercFleetWeight"; // Mutable stat - chance for mercenary fleets to spawn at a given market

    public static final String FACTION_ACCESS_BONUS = "$SPP_factionAccessBonus"; // float

    // Booleans for whether or not faction fleets can spawn at a given market
    public static final String SPAWN_TRADE_FLEETS = "$SPP_spawnTradeFleets";
    public static final String SPAWN_SMUGGLER_FLEETS = "$SPP_spawnSmugglerFleets";
    public static final String SPAWN_MERCENARY_FLEETS = "$SPP_spawnMercenaryFleets";
    public static final String SPAWN_RAIDER_FLEETS = "$SPP_spawnRaiderFleets";

    public static final String SYSTEM_WAR_FLEET_MANAGER = "$SPP_systemWarFleetManager";

    public static final String FACTION_WAR_FLEET_SOURCES = "$SPP_warFleetSpawnWeights"; // List<SPP_WarFleetRouteSource> in faction memory
    public static final String FACTION_WAR_FLEET_BONUS_FLEETS = "$SPP_warFleetBonusFleets"; // Map<String, Integer> in faction memory

    public static final String POP_PROTECTED = "$SPP_populationProtected"; // Population cannot be reduced by bombardments.
}
