package campaign.ids;

/**
 * Author: SafariJohn
 */
public class SPP_Ranks {
    public static final String FACTION_REP = "SPP_representative";
    public static final String POST_FACTION_REP = "SPP_representative";
}
