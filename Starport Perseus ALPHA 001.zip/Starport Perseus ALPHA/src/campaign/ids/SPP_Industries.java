package campaign.ids;

import com.fs.starfarer.api.impl.campaign.ids.Industries;

/**
 * Author: SafariJohn
 */
public class SPP_Industries {
    public static final String TAG_SPACEPORT = "SPP_spaceport";

    public static final String TAG_INDUSTRIAL_POP = "popInd";

    // BASE INDUSTRIES
//    public static final String MAKESHIFT_PORT = "SPP_makeshiftPort";
    public static final String SPACEPORT = Industries.POPULATION;
//    public static final String MEGAPORT = "SPP_megaport";
//    public static final String MAKESHIFT_STATION = "SPP_makeshiftStation";
//    public static final String SPACE_STATION = "SPP_spaceStation";
//    public static final String MEGASTATION = "SPP_megastation";
    public static final String LOCAL_ECONOMY = Industries.SPACEPORT;

    // T1 INDUSTRIES
    // FLAT
    public static final String CRAWLERS = "SPP_crawlers";
    public static final String SIPHON_PLATFORM = "SPP_siphonPlatform";
    public static final String HYDROPONICS = "SPP_hydroponics";
    public static final String MIMIR_SIPHON = "SPP_mimirSiphon";

    public static final String GROUND_DEFENSES = Industries.GROUNDDEFENSES;

    // T2 INDUSTRIES
    // FLAT
    public static final String TECH_MINING = Industries.TECHMINING; // T1 on small ruins

    public static final String RAIDER_CAMP = "SPP_raiderBase";
    public static final String MERCENARY_BASE = "SPP_mercenaryBase";
    public static final String AUXILIARY_DEPOT = "SPP_auxilliaryDepot";
    public static final String MILITANT_CAMP = "SPP_militantCamp";

    public static final String HEAVY_BATTERIES = Industries.HEAVYBATTERIES;

    // SCALING
    public static final String LIGHT_INDUSTRY = Industries.LIGHTINDUSTRY;
    public static final String REFINING = Industries.REFINING;
    public static final String HEAVY_INDUSTRY = "SPP_heavyIndustry";
    public static final String SHIPBREAKERS = "SPP_shipbreakers";
    public static final String COLONY_PROGRAM = "SPP_colonyProgram";

    public static final String TRADE_CENTER = "commerce";
    public static final String SMUGGLING_NETWORK = "SPP_frontCompany";

    // T3 INDUSTRIES
    // FLAT
    public static final String PLANETARY_SHIELD = Industries.PLANETARYSHIELD;

    public static final String COMMAND_BASE = "SPP_commandBase";
    public static final String MILITARY_BASE = "SPP_militaryBase";
    public static final String CORPORATE_HQ = "SPP_corporateHQ";
    public static final String CORPORATE_HQ_TEMP = "SPP_corporateHQ_cb";
    public static final String RAIDER_FORTRESS = "SPP_raiderFortress";
    public static final String RAIDER_FORTRESS_TEMP = "SPP_raiderFortress_cb";

    // SCALING
    public static final String SHIPYARD = Industries.HEAVYINDUSTRY; // "SPP_shipyard";
    public static final String FUEL_PROD = Industries.FUELPROD;
    public static final String DOMAIN_FUEL = "SPP_advFuelProd";

    public static final String BONEYARD = "SPP_boneyard";
    public static final String CRYOREVIVAL = "cryorevival";
    public static final String CRYOSANCTUM = Industries.CRYOSANCTUM;

    // SPECIAL INDUSTRIES
    public static final String CONSUMPTION = "SPP_conspicuousConsumptionism";

    public static final String LIONS_GUARD = "lionsguard";
    public static final String ACADEMY = "SPP_academy";
    public static final String STRATEGIC_MODELER = "SPP_strategicModeler";

    // UNUSED
    public static final String CONSULATE = "SPP_consulate";
    public static final String SUBSIDIARY = "SPP_subsidiary";
    public static final String EMBASSY = "SPP_embassy";
    public static final String MONASTERY = "SPP_monastery";
    public static final String LION_CLUB = "SPP_lionClub";
    public static final String LIONS_GUARD_HQ = "lionsguard";
    public static final String CASINO = "SPP_daredevilsCasino";
    public static final String DEPOT = "SPP_kantaDepot";
    public static final String MANSION = "SPP_blackStarMansion";
    public static final String EMPORIUM = "SPP_ibrahimEmporium";
    public static final String DEALER = "SPP_koDealer";

}
