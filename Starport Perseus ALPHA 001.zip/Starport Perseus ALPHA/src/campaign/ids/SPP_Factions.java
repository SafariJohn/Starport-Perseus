package campaign.ids;

/**
 * Author: SafariJohn
 */
public class SPP_Factions {
    public static final String BLACK_COMPANY = "blackCompany";
    public static final String DAREDEVILS = "daredevils";
    public static final String DYNASTY = "dynasty";
    public static final String KO_COMBINE = "koCombine";
}
