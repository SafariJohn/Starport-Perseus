package campaign;

import com.fs.starfarer.api.campaign.econ.MonthlyReport;

public class SPP_MonthlyReport extends MonthlyReport {

	private SPP_MonthlyReportNodeTooltipCreator monthlyReportTooltip;
    @Override
	public SPP_MonthlyReportNodeTooltipCreator getMonthlyReportTooltip() {
		if (monthlyReportTooltip == null) {
			monthlyReportTooltip = new SPP_MonthlyReportNodeTooltipCreator();
		}
		return monthlyReportTooltip;
	}

    @Override
	public FDNode getColoniesNode() {
		FDNode marketsNode = getNode(MonthlyReport.OUTPOSTS);
		if (marketsNode.name == null) {
			marketsNode.name = "Ports";
			marketsNode.custom = MonthlyReport.OUTPOSTS;
			marketsNode.tooltipCreator = getMonthlyReportTooltip();
		}
		return marketsNode;
	}
}





