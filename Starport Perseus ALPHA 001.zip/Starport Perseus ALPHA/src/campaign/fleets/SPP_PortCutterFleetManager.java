package campaign.fleets;

import campaign.ids.SPP_FleetTypes;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FleetAssignment;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.fleets.BaseLimitedFleetManager;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactoryV3;
import com.fs.starfarer.api.impl.campaign.fleets.FleetParamsV3;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.impl.campaign.ids.Ranks;
import com.fs.starfarer.api.impl.campaign.ids.ShipRoles;
import com.fs.starfarer.api.util.Misc;
import static com.fs.starfarer.api.util.Misc.random;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import org.lwjgl.util.vector.Vector2f;

/**
 * Author: SafariJohn
 */
public class SPP_PortCutterFleetManager extends BaseLimitedFleetManager {

    String marketId;

    public SPP_PortCutterFleetManager(MarketAPI market) {
        marketId = market.getId();
    }

    @Override
    public void advance(float amount) {
        super.advance(amount);

        MarketAPI market = Global.getSector().getEconomy().getMarket(marketId);

        Vector2f marketLoc = market.getLocationInHyperspace();
        Vector2f playerLoc = Global.getSector().getPlayerFleet().getLocationInHyperspace();

        // If player is > 2 ly away, despawn fleets
        if (Misc.getDistance(marketLoc, playerLoc) > 4000) {
            for (ManagedFleetData data : active) {
                data.fleet.despawn();
            }
        }
    }

    @Override
    protected int getMaxFleets() {
        MarketAPI market = Global.getSector().getEconomy().getMarket(marketId);
        if (market == null || market.isFreePort()) {
            return 0;
        }

//        int cutters = 0;
//        if (market.getSize() >= SPP_Spaceport.SPACEPORT_SIZE) cutters = 2;
//        if (market.getSize() >= 5) cutters++;
//        if (market.getSize() >= 7) cutters++;
        int cutters = (market.getSize() - 1) / 2;

        return cutters;
    }

    @Override
    protected float getSpawnRateMult() {
        MarketAPI market = Global.getSector().getEconomy().getMarket(marketId);

        Vector2f marketLoc = market.getLocationInHyperspace();
        Vector2f playerLoc = Global.getSector().getPlayerFleet().getLocationInHyperspace();

        float dist = Misc.getDistance(marketLoc, playerLoc);
        if (4000 > dist && dist > 100) return 1000f; // spawn fleets very rapidly as player closes in.

        return super.getSpawnRateMult();
    }

    @Override
    protected CampaignFleetAPI spawnFleet() {
        MarketAPI market = Global.getSector().getEconomy().getMarket(marketId);

        Vector2f marketLoc = market.getLocationInHyperspace();
        Vector2f playerLoc = Global.getSector().getPlayerFleet().getLocationInHyperspace();
        if (Misc.getDistance(marketLoc, playerLoc) > 4000) return null; // Don't spawn fleets when player is far away.

        // market, fleetType, factionId, shipRole(s?)
        FleetParamsV3 params = new FleetParamsV3(market, market.getLocationInHyperspace(), market.getFactionId(), null, SPP_FleetTypes.CUTTER, 0, 0, 0, 0, 0, 0, 0);
        CampaignFleetAPI fleet = FleetFactoryV3.createEmptyFleet(market.getFactionId(), params.fleetType, market);
        params.mode = Misc.getShipPickMode(market, market.getFactionId());
        if (random.nextFloat() > 0.9f) FleetFactoryV3.addToFleet(ShipRoles.COMBAT_MEDIUM, market, random, fleet, 100, params); // ~10% chance for a destroyer
        else FleetFactoryV3.addToFleet(ShipRoles.COMBAT_SMALL_FOR_SMALL_FLEET, market, random, fleet, 100, params); // Otherwise a frigate
        FleetFactoryV3.addCommanderAndOfficers(fleet, params, random);

		if (fleet == null || fleet.isEmpty()) return null;

        fleet.setName(market.getName() + " " + fleet.getFaction().getFleetTypeName(SPP_FleetTypes.CUTTER));
        fleet.setNoFactionInName(true);

        fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_PATROL_FLEET, true);
//        fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_CUSTOMS_INSPECTOR, true);
        fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_ALLOW_LONG_PURSUIT, false);
//        fleet.getMemoryWithoutUpdate().set(MemFlags.FLEET_NO_MILITARY_RESPONSE, true);

		String postId = Ranks.POST_PATROL_COMMANDER;
		String rankId = Ranks.SPACE_LIEUTENANT;

		fleet.getCommander().setPostId(postId);
		fleet.getCommander().setRankId(rankId);

        WeightedRandomPicker<SectorEntityToken> picker = new WeightedRandomPicker<>();
        picker.add(market.getPrimaryEntity(), 20);
        // Anywhere else cutters might patrol?
        // Jump points?
        // Other factions' ports? Particularly indie ports
        // Economic zones???

        SectorEntityToken patrolSpace = picker.pick();

        // Randomize patrol time to avoid all going in at once
        float patrolLength = 25 + random.nextFloat() * 10;

        fleet.addAssignment(FleetAssignment.DEFEND_LOCATION, patrolSpace, patrolLength, "patrolling " + market.getPrimaryEntity().getName());
        fleet.addAssignment(FleetAssignment.STANDING_DOWN, market.getPrimaryEntity(), 3f);
        fleet.addAssignment(FleetAssignment.GO_TO_LOCATION_AND_DESPAWN, market.getPrimaryEntity(), 1000f);

        fleet.addScript(new SPP_PortCutterAI(fleet, marketId));

        market.getContainingLocation().addEntity(fleet);
        fleet.setLocation(market.getPrimaryEntity().getLocation().x, market.getPrimaryEntity().getLocation().y);

		return fleet;
    }
}
