package campaign.fleets;


import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.impl.campaign.fleets.EconomyFleetAssignmentAI;
import com.fs.starfarer.api.impl.campaign.fleets.RouteManager;

public class SPP_EconomyFleetAssignmentAI extends EconomyFleetAssignmentAI {

    public SPP_EconomyFleetAssignmentAI(CampaignFleetAPI fleet, RouteManager.RouteData route) {
        super(fleet, route);
    }

	public void doSmugglingFactionChangeCheck(float amount) {}

}










