package campaign.fleets;

import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.fleets.RouteManager.RouteData;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author SafariJohn
 */
public abstract class SPP_WarFleetRouteSource {
    private final Map<String, Float> fleetWeights = new HashMap<>();
    private final Map<String, Integer> bonusFleets = new HashMap<>();

    public abstract FactionAPI getFaction();
    public abstract RouteData createRoute(StarSystemAPI system, String fleetType);
    public abstract CampaignFleetAPI spawnFleet(RouteData route);

    protected void addFleetType(String type, float weight, int bonusFleets) {
        fleetWeights.put(type, weight);
        this.bonusFleets.put(type, bonusFleets);
    }

    public Map<String, Float> getFleetWeights() {
        return fleetWeights;
    }
    public Map<String, Integer> getBonusFleets() {
        return bonusFleets;
    }
}
