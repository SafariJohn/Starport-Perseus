package campaign.fleets;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BattleAPI;
import com.fs.starfarer.api.campaign.CampaignEventListener.FleetDespawnReason;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.listeners.FleetEventListener;
import com.fs.starfarer.api.impl.campaign.DebugFlags;
import com.fs.starfarer.api.impl.campaign.econ.impl.MilitaryBase.PatrolFleetData;
import com.fs.starfarer.api.impl.campaign.fleets.BaseRouteFleetManager;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactory.PatrolType;
import com.fs.starfarer.api.impl.campaign.fleets.RouteManager;
import com.fs.starfarer.api.impl.campaign.fleets.RouteManager.RouteData;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import java.util.*;
import org.apache.log4j.Logger;
import util.SPP_Misc;

/**
 * Author: SafariJohn
 */
public class SPP_SystemWarFleetRouteManager extends BaseRouteFleetManager implements FleetEventListener {
	public static final String SOURCE_ID = "SPP_systemWarFleets";
    public static final float STANDARD_WEIGHT = 5f;

    private static final Logger log = Global.getLogger(SPP_SystemWarFleetRouteManager.class);

	public static class WarFleetData extends PatrolFleetData {
        public String warFleetType;

		public WarFleetData(PatrolType type, String warFleetType) {
			super(type);

            this.warFleetType = warFleetType;
		}
	}

    private final StarSystemAPI system;
    private final List<SPP_WarFleetRouteSource> sources;
    private final Map<SectorEntityToken, Integer> warPorts; // "Port" entity and its "port size" 0-10
    private final Map<RouteData, SPP_WarFleetRouteSource> sourcesByRoute;

    public SPP_SystemWarFleetRouteManager(StarSystemAPI system) {
        super(Global.getSettings().getFloat("averagePatrolSpawnInterval") * 0.7f,
                    Global.getSettings().getFloat("averagePatrolSpawnInterval") * 1.3f);
//        super(0.7f, 1.3f);

        this.system = system;
        sources = new ArrayList<>();
        warPorts = new HashMap<>();
        sourcesByRoute = new HashMap<>();
    }

    public List<SPP_WarFleetRouteSource> getRouteSources() {
        return sources;
    }

    public Map<SectorEntityToken, Integer> getWarPorts() {
        return warPorts;
    }

    @Override
    public String getRouteSourceId() {
		return SOURCE_ID + "_" + system.getId();
    }

	protected float returningPatrolValue = 0f;

    @Override
    public void advance(float amount) {

//		if (Global.getSector().getEconomy().isSimMode()) return;

		float days = Global.getSector().getClock().convertToDays(amount);

//		float stability = market.getPrevStability();
//		float spawnRate = 1f + (stability - 5) * 0.2f;
//		if (spawnRate < 0.5f) spawnRate = 0.5f;

		float spawnRate = 1f;
//		float rateMult = system.getStats().getDynamic().getStat(Stats.COMBAT_FLEET_SPAWN_RATE_MULT).getModifiedValue();
//		spawnRate *= rateMult;

		if (Global.getSector().isInNewGameAdvance()) {
			spawnRate *= 1000f;
		}

		float extraTime = 0f;
		if (returningPatrolValue > 0) {
			// apply "returned patrols" to spawn rate, at a maximum rate of 1 interval per day
			float i = interval.getIntervalDuration();
			extraTime = i * days;
			returningPatrolValue -= days;
			if (returningPatrolValue < 0) returningPatrolValue = 0;
		}
//		interval.advance(days * spawnRate + extraTime);

		//DebugFlags.FAST_PATROL_SPAWN = true;
		if (DebugFlags.FAST_PATROL_SPAWN) {
			interval.advance(days * spawnRate * 100f);
		}

        super.advance(days * spawnRate + extraTime);
    }

    @Override
    public int getMaxFleets() {
        Set<FactionAPI> factions = new HashSet<>();
        for (SectorEntityToken port : warPorts.keySet()) {
            factions.add(port.getFaction());
        }

        int bonusFleets = 0;

        // Get bonus fleets from in-system structures
        Map<String, Integer> fleetTypes = new HashMap<>();
        for (SPP_WarFleetRouteSource source : sources) {
            for (String fleetType : source.getFleetWeights().keySet()) {
                Integer num = fleetTypes.get(fleetType);
                if (num == null) num = 0;
                Integer bonus = source.getBonusFleets().get(fleetType);
                if (bonus == null) bonus = 0;

                if (num < bonus) fleetTypes.put(fleetType, bonus);
            }
        }
        for (String fleetType : fleetTypes.keySet()) {
            bonusFleets += fleetTypes.get(fleetType);
        }

        // Get bonus fleets from faction-wide structures
        fleetTypes.clear();
        for (FactionAPI faction : factions) {
            Map<String, String> factionBonusFleets = SPP_Misc.getFactionWarFleetBonusFleets(faction);
            if (factionBonusFleets == null) continue;

            for (String key : factionBonusFleets.keySet()) {
                String fleetType = factionBonusFleets.get(key);
                fleetTypes.put(fleetType, 1);
            }
        }
        for (String fleetType : fleetTypes.keySet()) {
            bonusFleets += fleetTypes.get(fleetType);
        }

        // Targets around 10 fleets if there is a size 10 port.
        // Maxes out around 15, typically
        return getNumFleetsFromPorts() + bonusFleets;
    }

    public int getNumFleetsFromPorts() {
        // Find size of largest port in system
        float sizeMax = 0;
        // Find total size of all ports in system
        float sizeTotal = 0;
        // Find # of ports in system
        float numPorts = 0;

        for (SectorEntityToken port : warPorts.keySet()) {
            int size = warPorts.get(port);
            if (size > sizeMax) sizeMax = size;
            sizeTotal += size;
            numPorts++;
        }

        // These mults give 1 fleet for a single size 2 port,
        // 2 fleets for a single size 3 port,
        // and 9 fleets for a single size 10 port.
        // Bonus fleets then raise it up to a max of about 15.
        float magicMult = 1.572f; // 11/7
        float portsMod = sizeTotal + numPorts + sizeMax;
        magicMult -= 4 / portsMod;

        sizeMax *= 2/3; // Most of the fleets come from the largest port.

        return (int) (sizeMax * magicMult);
    }

    @Override
    protected void addRouteFleetIfPossible() {
        // Pick faction
        WeightedRandomPicker picker = new WeightedRandomPicker();
        List<FactionAPI> factions = new ArrayList<>();
        for (SPP_WarFleetRouteSource s : sources) {
            FactionAPI faction = s.getFaction();
            if (factions.contains(faction)) continue;
            factions.add(faction);

            // Add up all source weights for the faction
            float weight = 0;
            for (SPP_WarFleetRouteSource source : sources) {
                if (source.getFaction() != faction) continue;

                for (String key : source.getFleetWeights().keySet()) {
                    weight += source.getFleetWeights().get(key);
                }
            }

            // And add faction-wide source weights
            List<SPP_WarFleetRouteSource> factionSources = SPP_Misc.getFactionWarFleetSources(faction);
            if (factionSources != null) {
                for (SPP_WarFleetRouteSource source : factionSources) {
                    for (String fleetType : source.getFleetWeights().keySet()) {
                        weight += source.getFleetWeights().get(fleetType);
                    }
                }
            }

            // Huge weight mult if faction has no fleets out
            boolean found = false;
            for (RouteData key : sourcesByRoute.keySet()) {
                if (sourcesByRoute.get(key).getFaction().getId().equals(faction.getId())) {
                    found = true;
                    break;
                }
            }
            if (!found) weight *= 100;

            picker.add(faction, weight);
        }

        FactionAPI faction = (FactionAPI) picker.pick();

        if (faction == null) {
            log.info("null faction at " + system);
            return;
        }


        // Pick source/fleet type
        picker.clear();
        for (SPP_WarFleetRouteSource source : sources) {
            if (source.getFaction() != faction) continue;

            for (String fleetType : source.getFleetWeights().keySet()) {
                picker.add(fleetType, source.getFleetWeights().get(fleetType));
            }
        }

        List<SPP_WarFleetRouteSource> factionSources = SPP_Misc.getFactionWarFleetSources(faction);
        if (factionSources != null) {
            for (SPP_WarFleetRouteSource source : factionSources) {
                for (String fleetType : source.getFleetWeights().keySet()) {
                    picker.add(fleetType, source.getFleetWeights().get(fleetType));
                }
            }
        }

        String fleetType = (String) picker.pick();


        // Pick source
        picker.clear();
        for (SPP_WarFleetRouteSource source : sources) {
            if (source.getFaction() != faction) continue;
            if (!source.getFleetWeights().keySet().contains(fleetType)) continue;

            picker.add(source, source.getFleetWeights().get(fleetType));
        }

        if (factionSources != null) {
            for (SPP_WarFleetRouteSource source : factionSources) {
                if (!source.getFleetWeights().keySet().contains(fleetType)) continue;

                picker.add(source, source.getFleetWeights().get(fleetType));
            }
        }

        SPP_WarFleetRouteSource source = (SPP_WarFleetRouteSource) picker.pick();


        // Source creates the route
        RouteData route = source.createRoute(system, fleetType);

        if (route == null) {
            log.info("null route at " + system + " from " + source.getFaction());
            return;
        }

        sourcesByRoute.put(route, source);
    }

    @Override
    public CampaignFleetAPI spawnFleet(RouteData route) {
        // Get fleet from source
        SPP_WarFleetRouteSource source = sourcesByRoute.get(route);
        CampaignFleetAPI fleet = source.spawnFleet(route);

        if (fleet == null) {
            log.info("null fleet at " + system + " from " + route.getFactionId());
            return null;
        }

        if (route.getCustom() instanceof PatrolFleetData) {
            PatrolFleetData custom = (PatrolFleetData) route.getCustom();
            if (custom.spawnFP <= 0) {
                custom.spawnFP = fleet.getFleetPoints();
            }
        }

        fleet.addEventListener(this);
        return fleet;
    }
	public void reportBattleOccurred(CampaignFleetAPI fleet, CampaignFleetAPI primaryWinner, BattleAPI battle) {

	}

	public void reportFleetDespawnedToListener(CampaignFleetAPI fleet, FleetDespawnReason reason, Object param) {
        RouteData route = RouteManager.getInstance().getRoute(getRouteSourceId(), fleet);

		if (reason == FleetDespawnReason.REACHED_DESTINATION) {
			if (route.getCustom() instanceof PatrolFleetData) {
				PatrolFleetData custom = (PatrolFleetData) route.getCustom();
				if (custom.spawnFP > 0) {
					float fraction  = fleet.getFleetPoints() / custom.spawnFP;
					returningPatrolValue += fraction;
				}
			}
		}

        if (reason != FleetDespawnReason.PLAYER_FAR_AWAY) {
            sourcesByRoute.remove(route);
        }
	}

    public Map<RouteData, SPP_WarFleetRouteSource> getSourcesByRouteCopy() {
        return new HashMap<>(sourcesByRoute);
    }

    public boolean shouldCancelRouteAfterDelayCheck(RouteData route) { return false; }
    public boolean shouldRepeat(RouteData route) { return false; }
    public void reportAboutToBeDespawnedByRouteManager(RouteData route) {}
}
