package campaign.fleets;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FleetAssignment;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.rules.MemKeys;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.util.Misc;

/**
 * Author: SafariJohn
 */
public class SPP_PortCutterAI implements EveryFrameScript {
    CampaignFleetAPI fleet;
    String marketId;

    public SPP_PortCutterAI(CampaignFleetAPI fleet, String marketId) {
        this.fleet = fleet;
        this.marketId = marketId;
    }

    @Override
    public boolean isDone() {
        return !fleet.isAlive() || fleet.isExpired();
    }

    @Override
    public boolean runWhilePaused() {
        return false;
    }

    @Override
    public void advance(float f) {
        if (isDone()) return;

        MarketAPI market = Global.getSector().getEconomy().getMarket(marketId);

        if (fleet.isCurrentAssignment(FleetAssignment.PATROL_SYSTEM)) {
            fleet.clearAssignments();
            fleet.addAssignment(FleetAssignment.DEFEND_LOCATION, market.getPrimaryEntity(), 10f, "patrolling " + market.getPrimaryEntity().getName());
            fleet.addAssignment(FleetAssignment.STANDING_DOWN, market.getPrimaryEntity(), 3f);
            fleet.addAssignment(FleetAssignment.GO_TO_LOCATION_AND_DESPAWN, market.getPrimaryEntity(), 1000f);

            return;
        }

        if (fleet.isCurrentAssignment(FleetAssignment.DEFEND_LOCATION)) {
//            fleet.getMemoryWithoutUpdate().set(MemFlags.FLEET_NO_MILITARY_RESPONSE, true);
        } else {
            fleet.getMemoryWithoutUpdate().unset(MemFlags.FLEET_NO_MILITARY_RESPONSE);
        }

        // Leash fleet to market
//        if (!fleet.isCurrentAssignment(FleetAssignment.GO_TO_LOCATION)
//                    && 500 < Misc.getDistance(fleet, market.getPrimaryEntity())) {
//            fleet.clearAssignments();
//            fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, market.getPrimaryEntity(), 1000f);
//            fleet.addAssignment(FleetAssignment.PATROL_SYSTEM, market.getPrimaryEntity(), 10f);
//        }
    }

}
