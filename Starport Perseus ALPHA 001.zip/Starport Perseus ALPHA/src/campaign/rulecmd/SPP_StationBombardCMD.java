package campaign.rulecmd;

import campaign.econ.industries.SPP_Spaceport;
import campaign.ids.SPP_Conditions;
import campaign.ids.SPP_Tags;
import campaign.intel.deciv.SPP_DecivTracker;
import static campaign.rulecmd.SPP_MarketCMD.ATROCITY_SCALE;
import static campaign.rulecmd.SPP_MarketCMD.BOMBARD_COST_DESC;
import static campaign.rulecmd.SPP_MarketCMD.BOMBARD_COST_ID;
import static campaign.rulecmd.SPP_MarketCMD.BOMBARD_COST_MOD;
import static campaign.rulecmd.SPP_MarketCMD.DEFENDER_PREPAREDNESS;
import static campaign.rulecmd.SPP_MarketCMD.RAID_GO_BACK;
import static campaign.rulecmd.SPP_MarketCMD.addBombardVisual;
import static campaign.rulecmd.SPP_MarketCMD.getBombardmentCost;
import static campaign.rulecmd.SPP_MarketCMD.getDefenderIncreaseValue;
import static campaign.rulecmd.SPP_MarketCMD.statPrinter;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.OptionPanelAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.combat.StatBonus;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin;
import com.fs.starfarer.api.impl.campaign.DebugFlags;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.impl.campaign.rulecmd.AddRemoveCommodity;
import com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.MarketCMD;
import com.fs.starfarer.api.ui.LabelAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

import java.awt.Color;
import java.util.*;
import org.lwjgl.input.Keyboard;
import util.SPP_Misc;
import util.SPP_PortFunctions;

/**
 * Author: SafariJohn
 */
public class SPP_StationBombardCMD extends BaseCommandPlugin {
    public static final String MENU = "bombardMenu";
    public static final String DESTROY = "bombardDestroy";
    public static final String CONFIRM = "bombardConfirm";

	public static final String BOMBARD_DESTROY = "mktBombardDestroy";
	public static final String BOMBARD_CONFIRM = "mktBombardDestroyConfirm";

    public static final String NEUTRAL_MENU = "bombardNeutralMenu";
    public static final String NEUTRAL_CONFIRM = "bombardNeutralConfirm";

	public static final String DESTROY_NEUTRAL = "neutralBombardDestroy";

    public static final int NEUTRAL_DESTROY_COST = 100;

	protected CampaignFleetAPI playerFleet;
	protected SectorEntityToken entity;
	protected FactionAPI playerFaction;
	protected FactionAPI entityFaction;
	protected TextPanelAPI text;
	protected OptionPanelAPI options;
	protected CargoAPI playerCargo;
	protected MemoryAPI memory;
	protected MarketAPI market;
	protected InteractionDialogAPI dialog;
	protected Map<String, MemoryAPI> memoryMap;
	protected FactionAPI faction;

	protected MarketCMD.TempData temp = new MarketCMD.TempData();

	private void init(SectorEntityToken entity) {

		memory = entity.getMemoryWithoutUpdate();
		this.entity = entity;
		playerFleet = Global.getSector().getPlayerFleet();
		playerCargo = playerFleet.getCargo();

		playerFaction = Global.getSector().getPlayerFaction();
		entityFaction = entity.getFaction();

		faction = entity.getFaction();

		market = entity.getMarket();

        if (market != null) {
            String key = "$MarketCMD_temp";
            MemoryAPI mem = market.getMemoryWithoutUpdate();
            if (mem.contains(key)) {
                temp = (MarketCMD.TempData) mem.get(key);
            } else {
                mem.set(key, temp, 0f);
            }
        }
	}

    @Override
    public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Misc.Token> params, Map<String, MemoryAPI> memoryMap) {
		this.dialog = dialog;
		this.memoryMap = memoryMap;

		String command = params.get(0).getString(memoryMap);
		if (command == null) return false;

		entity = dialog.getInteractionTarget();
		init(entity);

		memory = getEntityMemory(memoryMap);

		text = dialog.getTextPanel();
		options = dialog.getOptionPanel();

        if (command.equals(MENU)) bombardMenu();
        else if (command.equals(DESTROY)) bombardDestroy();
        else if (command.equals(CONFIRM)) bombardConfirm();
        else if (command.equals(NEUTRAL_MENU)) neutralMenu();
        else if (command.equals(NEUTRAL_CONFIRM)) destroyNeutral();

        return true;
    }

    private void bombardMenu() {
		float width = 350;
		float opad = 10f;
		float small = 5f;

		Color h = Misc.getHighlightColor();
		Color b = Misc.getNegativeHighlightColor();

		dialog.getVisualPanel().showImagePortion("illustrations", "bombard_prepare", 640, 400, 0, 0, 480, 300);

		StatBonus defender = market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD);
		float added = getDefenderIncreaseValue(market);
		if (added > 0) {
			defender.modifyFlat(DEFENDER_PREPAREDNESS, added, "Increased defender preparedness");
		}

		float bombardBonus = Misc.getFleetwideTotalMod(playerFleet, Stats.FLEET_BOMBARD_COST_REDUCTION, 0f);
		String increasedBombardKey = "core_addedBombard";
		StatBonus bombardBonusStat = new StatBonus();
		if (bombardBonus > 0) {
			bombardBonusStat.modifyFlat(increasedBombardKey, -bombardBonus, "Specialized fleet bombardment capability");
		}

        // Ground defense is doubled against bombardments
        defender.modifyMult(BOMBARD_COST_ID, BOMBARD_COST_MOD, BOMBARD_COST_DESC);

		float defenderStr = (int) Math.round(defender.computeEffective(0f));
		defenderStr -= bombardBonus;
		if (defenderStr < 0) defenderStr = 0;

		temp.defenderStr = defenderStr;

		TooltipMakerAPI info = text.beginTooltip();

		info.setParaSmallInsignia();

		String has = faction.getDisplayNameHasOrHave();
		String is = faction.getDisplayNameIsOrAre();
		boolean hostile = faction.isHostileTo(Factions.PLAYER);
		boolean tOn = playerFleet.isTransponderOn();
		float initPad = 0f;
		if (!hostile) {
			if (tOn) {
				info.addPara(Misc.ucFirst(faction.getDisplayNameWithArticle()) + " " + is +
						" not currently hostile. A bombardment is a major enough hostile action that it can't be concealed, " +
						"regardless of transponder status.",
						initPad, faction.getBaseUIColor(), faction.getDisplayNameWithArticleWithoutArticle());
			}
			initPad = opad;
		}

        if (market.getSize() >= SPP_Spaceport.SPACEPORT_SIZE) {
            info.addPara("Starship fuel can be easily destabilized, unlocking the destructive " +
                    "potential of the antimatter it contains. Station defenses can counter " +
                    "a bombardment, though in practice it only means that more fuel is required to achieve " +
                    "the same result.", initPad);


            if (bombardBonus > 0) {
                info.addPara("Effective station defense strength: %s", opad, h, "" + (int)defenderStr);
            } else {
                info.addPara("Station defense strength: %s", opad, h, "" + (int)defenderStr);
            }
            info.addStatModGrid(width, 50, opad, small, defender, true, statPrinter(true));
            if (!bombardBonusStat.isUnmodified()) {
                info.addStatModGrid(width, 50, opad, 3f, bombardBonusStat, true, statPrinter(false));
            }
        } else {
            info.addPara(market.getName() + " is small enough to be destroyed with a conventional bombardment.", initPad);
        }

        text.addTooltip();

		temp.bombardCost = getBombardmentCost(market, playerFleet);

        // Remove bombardment cost increase
        defender.unmodifyMult(BOMBARD_COST_ID);
		defender.unmodifyFlat(DEFENDER_PREPAREDNESS);

		int fuel = (int) playerFleet.getCargo().getFuel();
		boolean canBombard = fuel >= temp.bombardCost;

        if (market.getSize() >= SPP_Spaceport.SPACEPORT_SIZE) {
            LabelAPI label = text.addPara("A bombardment requires %s fuel. " +
                                          "You have %s fuel.",
                    h, "" + temp.bombardCost, "" + fuel);
            label.setHighlight("" + temp.bombardCost, "" + fuel);
            label.setHighlightColors(canBombard ? h : b, h);
        } else {
            canBombard = true;
            temp.bombardCost = 0;
        }

		options.clearOptions();

		options.addOption("Prepare a bombardment", BOMBARD_DESTROY);

		if (DebugFlags.MARKET_HOSTILITIES_DEBUG) {
			canBombard = true;
		}
		if (!canBombard) {
			options.setEnabled(BOMBARD_DESTROY, false);
			options.setTooltip(BOMBARD_DESTROY, "Not enough fuel.");
		}

		options.addOption("Go back", RAID_GO_BACK);
		options.setShortcut(RAID_GO_BACK, Keyboard.KEY_ESCAPE, false, false, false, true);
    }

	protected void bombardDestroy() {

		temp.bombardType = MarketCMD.BombardType.SATURATION;

		temp.willBecomeHostile.clear();
		temp.willBecomeHostile.add(faction);

		List<FactionAPI> nonHostile = new ArrayList<FactionAPI>();
        if (SPP_PortFunctions.getPopulationSize(market) >= ATROCITY_SCALE) {
            for (FactionAPI faction : Global.getSector().getAllFactions()) {
                if (temp.willBecomeHostile.contains(faction)) continue;

                if (faction.getCustomBoolean(Factions.CUSTOM_CARES_ABOUT_ATROCITIES)) {
                    boolean hostile = faction.isHostileTo(Factions.PLAYER);
                    temp.willBecomeHostile.add(faction);
                    if (!hostile) {
                        nonHostile.add(faction);
                    }
                }

            }
        }

		float opad = 10f;
		float small = 5f;

		Color h = Misc.getHighlightColor();
		Color b = Misc.getNegativeHighlightColor();


		int fuel = (int) playerFleet.getCargo().getFuel();
        text.addPara("Bombarding " + market.getName() + " will destroy it.");

        if (SPP_PortFunctions.getPopulationSize(market) >= ATROCITY_SCALE) {
            if (nonHostile.isEmpty()) {
                text.addPara("An atrocity of this scale can not be hidden, but any factions that would " +
                        "be dismayed by such actions are already hostile to you.");
            } else {
                text.addPara("An atrocity of this scale can not be hidden, " +
                             "and will make the following factions hostile:");
            }
        }

		if (!nonHostile.isEmpty()) {
			TooltipMakerAPI info = text.beginTooltip();
			info.setParaFontDefault();

			info.setBulletedListMode(BaseIntelPlugin.INDENT);
			float initPad = 0f;
			for (FactionAPI fac : nonHostile) {
				info.addPara(Misc.ucFirst(fac.getDisplayName()), fac.getBaseUIColor(), initPad);
				initPad = 3f;
			}
			info.setBulletedListMode(null);

			text.addTooltip();
		}

        if (temp.bombardCost > 0) {
            text.addPara("The bombardment requires %s fuel. " +
                         "You have %s fuel.",
                         h, "" + temp.bombardCost, "" + fuel);
        }

		addBombardConfirmOptions();
	}

	protected void addBombardConfirmOptions() {
		options.clearOptions();
		options.addOption("Destroy " + market.getName(), BOMBARD_CONFIRM);
		options.addOption("Go back", RAID_GO_BACK);
		options.setShortcut(RAID_GO_BACK, Keyboard.KEY_ESCAPE, false, false, false, true);

		List<FactionAPI> nonHostile = new ArrayList<FactionAPI>();
		for (FactionAPI faction : temp.willBecomeHostile) {
			boolean hostile = faction.isHostileTo(Factions.PLAYER);
			if (!hostile) {
				nonHostile.add(faction);
			}
		}

		if (nonHostile.size() == 1) {
			FactionAPI faction = nonHostile.get(0);
			options.addOptionConfirmation(BOMBARD_CONFIRM,
					"The " + faction.getDisplayNameLong() +
					" " + faction.getDisplayNameIsOrAre() +
					" not currently hostile, and will become hostile if you carry out the bombardment. " +
					"Are you sure?", "Yes", "Never mind");
		} else if (nonHostile.size() > 1) {
			options.addOptionConfirmation(BOMBARD_CONFIRM,
					"Multiple factions that are not currently hostile " +
					"will become hostile if you carry out the bombardment. " +
					"Are you sure?", "Yes", "Never mind");
		}
	}

	protected void bombardConfirm() {

		if (temp.bombardType == null) {
			bombardNeverMind();
			return;
		}

        if (market.getSize() >= SPP_Spaceport.SPACEPORT_SIZE) {
            playerFleet.getCargo().removeFuel(temp.bombardCost);
            AddRemoveCommodity.addCommodityLossText(Commodities.FUEL, temp.bombardCost, text);
        }

		for (FactionAPI curr : temp.willBecomeHostile) {
			CoreReputationPlugin.CustomRepImpact impact = new CoreReputationPlugin.CustomRepImpact();
			impact.delta = market.getSize() * -0.01f * 1f;
			impact.ensureAtBest = RepLevel.HOSTILE;
			if (temp.bombardType == MarketCMD.BombardType.SATURATION) {
				if (curr == faction) {
					impact.ensureAtBest = RepLevel.VENGEFUL;
				}
				impact.delta = market.getSize() * -0.01f * 1f;
			}
			Global.getSector().adjustPlayerReputation(
				new CoreReputationPlugin.RepActionEnvelope(CoreReputationPlugin.RepActions.CUSTOM,
					impact, null, text, true, true),
					curr.getId());
		}

        // Destroy the Station
        SPP_DecivTracker.decivilize(market, true);
//        addBombardVisual(entity);
//		Misc.fadeAndExpire(entity, 1f);
//        Global.getSoundPlayer().playSound("hit_heavy", 1, 1, Global.getSoundPlayer().getListenerPos(), new Vector2f());

        // (Re)create station-port buildable location

        // Dismiss the dialog
        dialog.dismiss();
	}


	protected void bombardNeverMind() {
		bombardMenu();
	}

    private void neutralMenu() {
		float width = 350;
		float opad = 10f;
		float small = 5f;

		Color h = Misc.getHighlightColor();
		Color b = Misc.getNegativeHighlightColor();

		dialog.getVisualPanel().showImagePortion("illustrations", "bombard_prepare", 640, 400, 0, 0, 480, 300);

		float bombardBonus = Misc.getFleetwideTotalMod(playerFleet, Stats.FLEET_BOMBARD_COST_REDUCTION, 0f);
		String increasedBombardKey = "core_addedBombard";
		StatBonus bombardBonusStat = new StatBonus();
		if (bombardBonus > 0) {
			bombardBonusStat.modifyFlat(increasedBombardKey, -bombardBonus, "Specialized fleet bombardment capability");
		}

		TooltipMakerAPI info = text.beginTooltip();

		info.setParaSmallInsignia();

		String has = faction.getDisplayNameHasOrHave();
		String is = faction.getDisplayNameIsOrAre();
		boolean hostile = faction.isHostileTo(Factions.PLAYER);
		boolean tOn = playerFleet.isTransponderOn();
		float initPad = 0f;
		if (!hostile && !faction.isNeutralFaction()) {
			if (tOn) {
				info.addPara(Misc.ucFirst(faction.getDisplayNameWithArticle()) + " " + is +
						" not currently hostile. Destroying " + entity.getName() + " will make them hostile.",
						initPad, faction.getBaseUIColor(), faction.getDisplayNameWithArticleWithoutArticle());
			}
			initPad = opad;
		}

        info.addPara("Starship fuel can be easily destabilized, unlocking the destructive " +
                "potential of the antimatter it contains.", initPad);

        text.addTooltip();

		int fuel = (int) playerFleet.getCargo().getFuel();
		boolean canBombard = fuel >= NEUTRAL_DESTROY_COST || Global.getSettings().isDevMode();

        LabelAPI label = text.addPara("Destroying " + entity.getName() + " requires %s fuel. " +
                                      "You have %s fuel.",
                h, "" + NEUTRAL_DESTROY_COST, "" + fuel);
        label.setHighlight("" + NEUTRAL_DESTROY_COST, "" + fuel);
        label.setHighlightColors(canBombard ? h : b, h);

		options.clearOptions();

		options.addOption("Destroy " + entity.getName(), DESTROY_NEUTRAL);
        if (!hostile && tOn && !faction.isNeutralFaction()) {
            options.addOptionConfirmation(DESTROY_NEUTRAL,
                    "The " + faction.getDisplayNameLong() +
                    " " + faction.getDisplayNameIsOrAre() +
                    " not currently hostile, and will become hostile if you destroy " + entity.getName() + ". " +
                    "Are you sure?", "Yes", "Never mind");
        }

		if (!canBombard) {
			options.setEnabled(DESTROY_NEUTRAL, false);
			options.setTooltip(DESTROY_NEUTRAL, "Not enough fuel.");
		}

		options.addOption("Leave", "defaultLeave");
		options.setShortcut("defaultLeave", Keyboard.KEY_ESCAPE, false, false, false, true);
    }

    private void destroyNeutral() {
        if (!Global.getSettings().isDevMode()) {
            playerFleet.getCargo().removeFuel(NEUTRAL_DESTROY_COST);
            AddRemoveCommodity.addCommodityLossText(Commodities.FUEL, NEUTRAL_DESTROY_COST, text);
        }

		boolean hostile = faction.isHostileTo(Factions.PLAYER);
		boolean tOn = playerFleet.isTransponderOn();
		if (!hostile && !faction.isNeutralFaction() && tOn) {
			CoreReputationPlugin.CustomRepImpact impact = new CoreReputationPlugin.CustomRepImpact();
			impact.delta = 4 * -0.01f * 1f;
			impact.ensureAtBest = RepLevel.HOSTILE;
			Global.getSector().adjustPlayerReputation(
				new CoreReputationPlugin.RepActionEnvelope(CoreReputationPlugin.RepActions.CUSTOM,
					impact, null, text, true, true),
					faction.getId());
		}


        PlanetAPI planet = SPP_Misc.getParent(entity);
        if (planet != null) {
            planet.getMarket().removeCondition(SPP_Conditions.ABANDONED_STATION);
            planet.getMarket().removeCondition(SPP_Conditions.WARNING_BEACON);

            planet.getMemoryWithoutUpdate().unset(SPP_Tags.MEMKEY_ORBITAL_STATION_ID);
        }

        // Destroy the Station
        addBombardVisual(entity);
		Misc.fadeAndExpire(entity, 1f);
//        Global.getSoundPlayer().playSound("hit_heavy", 1, 1, Global.getSoundPlayer().getListenerPos(), new Vector2f());

        // Dismiss the dialog
        dialog.dismiss();
    }

}
