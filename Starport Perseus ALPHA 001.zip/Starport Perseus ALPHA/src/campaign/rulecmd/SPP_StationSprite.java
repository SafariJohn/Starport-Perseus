package campaign.rulecmd;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CustomEntitySpecAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.impl.campaign.DevMenuOptions;
import com.fs.starfarer.api.impl.campaign.rulecmd.DumpMemory;
import com.fs.starfarer.api.impl.campaign.rulecmd.FireAll;
import com.fs.starfarer.api.impl.campaign.rulecmd.PaginatedOptions;
import static com.fs.starfarer.api.impl.campaign.rulecmd.PaginatedOptions.OPTION_NEXT_PAGE;
import static com.fs.starfarer.api.impl.campaign.rulecmd.PaginatedOptions.OPTION_PREV_PAGE;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import java.util.List;
import java.util.Map;

/**
 * Author: SafariJohn
 */
public class SPP_StationSprite extends PaginatedOptions {
    public static final String KEY = "$spp_selectedSprite";

    public static final String MINING_STATION = "station_mining00";
    public static final String SIDE_1 = "station_side00";
    public static final String SIDE_2 = "station_side02";
    public static final String SIDE_3 = "station_side03";
    public static final String SIDE_4 = "station_side04";
    public static final String SIDE_5 = "station_side05";
    public static final String SIDE_6 = "station_side06";
    public static final String SIDE_7 = "station_side07";
    public static final String BATTLESTATION = "station_built_from_industry";

    @Override
    public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Misc.Token> params, Map<String, MemoryAPI> memoryMap) {
        super.execute(ruleId, dialog, params, memoryMap);

		optionsPerPage = 5;

        populateOptions();

        showOptions();

        return true;
    }

    private void populateOptions() {
        addOption("Mining Station", MINING_STATION);
        addOption("Side Station 1", SIDE_1);
        addOption("Side Station 2", SIDE_2);
        addOption("Side Station 3", SIDE_3);
        addOption("Side Station 4", SIDE_4);
        addOption("Side Station 5", SIDE_5);
        addOption("Side Station 6", SIDE_6);
        addOption("Side Station 7", SIDE_7);
//        addOption("Station Fleet", BATTLESTATION);
    }

    @Override
    public void optionSelected(String optionText, Object optionData) {
		if (optionData == OPTION_PREV_PAGE) {
			currPage--;
			showOptions();
			return;
		}
		if (optionData == OPTION_NEXT_PAGE) {
			currPage++;
			showOptions();
			return;
		}

		if (optionText != null) {
			dialog.getTextPanel().addParagraph(optionText, Global.getSettings().getColor("buttonText"));
		}

		if (optionData == DumpMemory.OPTION_ID) {
			new DumpMemory().execute(null, dialog, null, getMemoryMap());
			return;
		} else if (DevMenuOptions.isDevOption(optionData)) {
			DevMenuOptions.execute(dialog, (String) optionData);
			return;
		}

        String option = (String) optionData;
        getEntityMemory(memoryMap).set(KEY, option);

        TooltipMakerAPI tooltip = dialog.getTextPanel().beginTooltip();
        CustomEntitySpecAPI spec = Global.getSettings().getCustomEntitySpec(option);
        tooltip.addImage(spec.getSpriteName(), spec.getSpriteWidth(), spec.getSpriteHeight(), 2f);
        dialog.getTextPanel().addTooltip();

		dialog.setPlugin(originalPlugin);


        FireAll.fire("SPP_buildOrbitalStationPortSelectSprite",
                    dialog, memoryMap, "SPP_OrbitalStationConstructionConfirmOptions");
    }
}
