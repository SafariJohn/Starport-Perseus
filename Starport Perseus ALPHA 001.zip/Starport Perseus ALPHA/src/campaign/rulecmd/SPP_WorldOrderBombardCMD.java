package campaign.rulecmd;

import campaign.SPP_ImmigrationScript;
import campaign.SPP_SurveyPluginImpl;
import static campaign.SPP_SurveyPluginImpl.MAX_PLANET_RADIUS;
import static campaign.SPP_SurveyPluginImpl.MIN_PLANET_RADIUS;
import static campaign.SPP_SurveyPluginImpl.MULT_AT_MAX_PLANET_RADIUS;
import campaign.econ.industries.SPP_GroundDefenses;
import static campaign.econ.industries.SPP_GroundDefenses.DEFENSE_BONUS_BATTERIES;
import campaign.econ.industries.SPP_Spaceport;
import campaign.ids.SPP_Conditions;
import campaign.ids.SPP_MemKeys;
import static campaign.rulecmd.SPP_MarketCMD.ATROCITY_SCALE;
import static campaign.rulecmd.SPP_MarketCMD.BOMBARD_COST_DESC;
import static campaign.rulecmd.SPP_MarketCMD.BOMBARD_COST_ID;
import static campaign.rulecmd.SPP_MarketCMD.BOMBARD_COST_MOD;
import static campaign.rulecmd.SPP_MarketCMD.addBombardVisual;
import static campaign.rulecmd.SPP_MarketCMD.getBombardmentCost;
import static campaign.rulecmd.SPP_MarketCMD.statPrinter;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.listeners.ListenerUtil;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.combat.StatBonus;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.CustomRepImpact;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.RepActionEnvelope;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.RepActions;
import com.fs.starfarer.api.impl.campaign.DebugFlags;
import com.fs.starfarer.api.impl.campaign.ids.*;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.impl.campaign.rulecmd.AddRemoveCommodity;
import com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.MarketCMD;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.MarketCMD.BombardType;
import com.fs.starfarer.api.ui.LabelAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import org.lwjgl.input.Keyboard;
import util.SPP_Misc;
import util.SPP_PortFunctions;

/**
 * Author: SafariJohn
 */
public class SPP_WorldOrderBombardCMD extends BaseCommandPlugin {
    public static final String MENU = "bombardMenu";
    public static final String DESTROY = "bombardDestroy";
    public static final String CONFIRM = "bombardConfirm";

	public static final String BOMBARD_DESTROY = "owoBombardDestroy";
	public static final String BOMBARD_CONFIRM = "owoBombardDestroyConfirm";
    public static final String BOMBARD_RESULT = "owoBombardResult";

    public static final String LEAVE = "defaultLeave";

    public static final float DESTROY_COST_MULT = 100f;

	protected CampaignFleetAPI playerFleet;
	protected SectorEntityToken entity;
	protected FactionAPI playerFaction;
	protected FactionAPI entityFaction;
	protected TextPanelAPI text;
	protected OptionPanelAPI options;
	protected CargoAPI playerCargo;
	protected MemoryAPI memory;
	protected MarketAPI market;
	protected InteractionDialogAPI dialog;
	protected Map<String, MemoryAPI> memoryMap;
	protected FactionAPI faction;

	protected MarketCMD.TempData temp = new MarketCMD.TempData();

	private void init(SectorEntityToken entity) {

        if (SPP_PortFunctions.getOrbitalConditions(entity).contains(SPP_Conditions.WORLD_ORDER)) {
            entity = SPP_Misc.getMoonOrParent(entity);
        }

		memory = entity.getMemoryWithoutUpdate();
		this.entity = entity;
		playerFleet = Global.getSector().getPlayerFleet();
		playerCargo = playerFleet.getCargo();

		playerFaction = Global.getSector().getPlayerFaction();
		entityFaction = entity.getFaction();

		faction = entity.getFaction();
		market = entity.getMarket();

        if (market != null) {
            String key = "$MarketCMD_temp";
            MemoryAPI mem = market.getMemoryWithoutUpdate();
            if (mem.contains(key)) {
                temp = (MarketCMD.TempData) mem.get(key);
            } else {
                mem.set(key, temp, 0f);
            }

        }
	}

    @Override
    public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Misc.Token> params, Map<String, MemoryAPI> memoryMap) {
		this.dialog = dialog;
		this.memoryMap = memoryMap;

		String command = params.get(0).getString(memoryMap);
		if (command == null) return false;

		entity = dialog.getInteractionTarget();
		init(entity);

		memory = getEntityMemory(memoryMap);

		text = dialog.getTextPanel();
		options = dialog.getOptionPanel();

        if (command.equals(MENU)) bombardMenu();
//        else if (command.equals(DESTROY)) bombardSaturation();
        else if (command.equals(CONFIRM)) bombardConfirm();

        return true;
    }

    private void bombardMenu() {
		float width = 350;
		float opad = 10f;
		float small = 5f;

		Color h = Misc.getHighlightColor();
		Color b = Misc.getNegativeHighlightColor();

		dialog.getVisualPanel().showImagePortion("illustrations", "bombard_prepare", 640, 400, 0, 0, 480, 300);

		StatBonus defender = market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD);

        int population = SPP_PortFunctions.getPopulationSize(market);

        float base = SPP_GroundDefenses.DEFENSE_BONUS_BASE;
        float pop = 0;
        if (population >= ATROCITY_SCALE) pop = SPP_GroundDefenses.DEFENSE_BONUS_BATTERIES - base;

        base *= SPP_SurveyPluginImpl.getSizeMulitiplier(market.getPlanetEntity());
        base /= 2;

        defender.modifyFlat(SPP_Conditions.WORLD_ORDER, base,
                    "Domain defense system");

        if (pop > 0) defender.modifyFlat(SPP_Conditions.WORLD_ORDER + "_pop", pop,
                        "Large population");

//        if (market.hasCondition(SPP_Conditions.TIGHT_MOON) || market.hasCondition(SPP_Conditions.TIGHT_ORBIT)) {
//            defender.modifyFlat(SPP_Conditions.WORLD_ORDER + "_moon",
//                        base, "Lunar fire base");
//        }


		float bombardBonus = Misc.getFleetwideTotalMod(playerFleet, Stats.FLEET_BOMBARD_COST_REDUCTION, 0f);
		String increasedBombardKey = "core_addedBombard";
		StatBonus bombardBonusStat = new StatBonus();
		if (bombardBonus > 0) {
			bombardBonusStat.modifyFlat(increasedBombardKey, -bombardBonus, "Specialized fleet bombardment capability");
		}

        // Ground defense is doubled against bombardments
        defender.modifyMult(BOMBARD_COST_ID, BOMBARD_COST_MOD, BOMBARD_COST_DESC);

		float defenderStr = (int) Math.round(defender.computeEffective(0f));
		defenderStr -= bombardBonus;
		if (defenderStr < 0) defenderStr = 0;

		temp.defenderStr = defenderStr;

		TooltipMakerAPI info = text.beginTooltip();

		info.setParaSmallInsignia();

		float initPad = 0f;
//		if (!hostile) {
//			if (tOn) {
//				info.addPara(Misc.ucFirst(faction.getDisplayNameWithArticle()) + " " + is +
//						" not currently hostile. A bombardment is a major enough hostile action that it can't be concealed, " +
//						"regardless of transponder status.",
//						initPad, faction.getBaseUIColor(), faction.getDisplayNameWithArticleWithoutArticle());
//			}
//			initPad = opad;
//		}

//        if (market.getSize() >= SPP_Spaceport.SPACEPORT_SIZE) {
            info.addPara("Starship fuel can be easily destabilized, unlocking the destructive " +
                    "potential of the antimatter it contains. Planetary defenses can counter " +
                    "a bombardment, though in practice it only means that more fuel is required to achieve " +
                    "the same result.", initPad);


            if (bombardBonus > 0) {
                info.addPara("Effective ground defense strength: %s", opad, h, "" + (int)defenderStr);
            } else {
                info.addPara("Ground defense strength: %s", opad, h, "" + (int)defenderStr);
            }
            info.addStatModGrid(width, 50, opad, small, defender, true, statPrinter(true));
            if (!bombardBonusStat.isUnmodified()) {
                info.addStatModGrid(width, 50, opad, 3f, bombardBonusStat, true, statPrinter(false));
            }
//        } else {
//            info.addPara(market.getName() + " is small enough to be destroyed with a conventional bombardment.", initPad);
//        }

        text.addTooltip();

		temp.bombardCost = (int) defenderStr;

        // Remove bombardment cost increase
        defender.unmodifyMult(BOMBARD_COST_ID);
        defender.unmodifyFlat(SPP_Conditions.WORLD_ORDER);
        defender.unmodifyFlat(SPP_Conditions.WORLD_ORDER + "_pop");
        defender.unmodifyFlat(SPP_Conditions.WORLD_ORDER + "_moon");

		temp.willBecomeHostile.clear();

		List<FactionAPI> nonHostile = new ArrayList<FactionAPI>();
        if (SPP_PortFunctions.getPopulationSize(market) >= ATROCITY_SCALE) {
            for (FactionAPI faction : Global.getSector().getAllFactions()) {
                if (temp.willBecomeHostile.contains(faction)) continue;

                if (faction.getCustomBoolean(Factions.CUSTOM_CARES_ABOUT_ATROCITIES)) {
                    boolean hostile = faction.isHostileTo(Factions.PLAYER);
                    temp.willBecomeHostile.add(faction);
                    if (!hostile) {
                        nonHostile.add(faction);
                    }
                }
            }
        }

        boolean popProtected = market.getMemoryWithoutUpdate().getBoolean(SPP_MemKeys.POP_PROTECTED);

		if (popProtected) {
			text.addPara("A bombardment will destroy "
                        + "the Domain defense system and give you "
                        + "access to the planet.");
        } else {
			text.addPara("A bombardment will destroy "
                        + "the Domain defense system, reduce the "
                        + "planet's population, and give you access "
                        + "to the planet.");
		}

        if (SPP_PortFunctions.getPopulationSize(market) >= ATROCITY_SCALE) {
            if (nonHostile.isEmpty()) {
                text.addPara("An atrocity of this scale can not "
                            + "be hidden, but any factions that "
                            + "would be dismayed by such actions "
                            + "are already hostile to you.");
            } else if (playerFleet.isTransponderOn()) {
                text.addPara("An atrocity of this scale can not be hidden, "
                            + "especially with your transponder on, "
                            + "and will make the following factions hostile:");
            } else {
                text.addPara("An atrocity of this scale can not be hidden, " +
                             "but the isolated position of " + market.getName()
                            + "means it cannot be pinned on you "
                            + "with your transponder off. It will "
                            + "still make the following factions "
                            + "more suspicous of you:");
            }
        }

		if (!nonHostile.isEmpty()) {
			info = text.beginTooltip();
			info.setParaFontDefault();

			info.setBulletedListMode(BaseIntelPlugin.INDENT);
			for (FactionAPI fac : nonHostile) {
				info.addPara(Misc.ucFirst(fac.getDisplayName()), fac.getBaseUIColor(), initPad);
				initPad = 3f;
			}
			info.setBulletedListMode(null);

			text.addTooltip();
		}

		int fuel = (int) playerFleet.getCargo().getFuel();
		boolean canBombard = fuel >= temp.bombardCost;

//        if (market.getSize() >= SPP_Spaceport.SPACEPORT_SIZE) {
            LabelAPI label = text.addPara("A bombardment requires %s fuel. " +
                                          "You have %s fuel.",
                    h, "" + temp.bombardCost, "" + fuel);
            label.setHighlight("" + temp.bombardCost, "" + fuel);
            label.setHighlightColors(canBombard ? h : b, h);
//        } else {
//            canBombard = true;
//            temp.bombardCost = 0;
//        }

		options.clearOptions();

		addBombardConfirmOptions();
    }

	protected void bombardConfirm() {

        dialog.getVisualPanel().showImagePortion("illustrations", "bombard_saturation_result", 640, 400, 0, 0, 480, 300);

		playerFleet.getCargo().removeFuel(temp.bombardCost);
		AddRemoveCommodity.addCommodityLossText(Commodities.FUEL, temp.bombardCost, text);

		for (FactionAPI curr : temp.willBecomeHostile) {
			CustomRepImpact impact = new CustomRepImpact();
			impact.delta = SPP_PortFunctions.getPopulationSize(market) * -0.01f;
			if (playerFleet.isTransponderOn()) impact.ensureAtBest = RepLevel.HOSTILE;
			Global.getSector().adjustPlayerReputation(
				new RepActionEnvelope(RepActions.CUSTOM,
					impact, null, text, true, true),
					curr.getId());
		}

        boolean popProtected = market.getMemoryWithoutUpdate().getBoolean(SPP_MemKeys.POP_PROTECTED);

		if (market.hasCondition(Conditions.HABITABLE) && !market.hasCondition(Conditions.POLLUTION)) {
			market.addCondition(Conditions.POLLUTION);
		}

        replaceWorldOrder();

        int prevPop = SPP_PortFunctions.getPopulationSize(market);
        if (!popProtected) SPP_ImmigrationScript.reducePopulationSize(market, market.getPopulation());
        if (prevPop == SPP_PortFunctions.getPopulationSize(market)) {
            text.addPara("Domain defense system destroyed.");
        } else if (market.getSurveyLevel() == MarketAPI.SurveyLevel.FULL) {
            text.addPara("Domain defense system destroyed. Population "
                        + "reduced to %s.",
                    Misc.getHighlightColor()
                    , "" + SPP_PortFunctions.getPopulationSize(market));
        } else {
            text.addPara("Domain defense system destroyed. Population "
                        + "reduced.");
        }

        ListenerUtil.reportSaturationBombardmentFinished(dialog, market, temp);

		if (dialog != null && dialog.getPlugin() instanceof RuleBasedDialog) {
			if (dialog.getInteractionTarget() != null &&
					dialog.getInteractionTarget().getMarket() != null) {
				Global.getSector().setPaused(false);
				dialog.getInteractionTarget().getMarket().getMemoryWithoutUpdate().advance(0.0001f);
				Global.getSector().setPaused(true);
			}
			((RuleBasedDialog) dialog.getPlugin()).updateMemory();
		}

        if (dialog != null && dialog.getPlugin() instanceof RuleBasedDialog) {
            ((RuleBasedDialog) dialog.getPlugin()).updateMemory();
//				market.getMemoryWithoutUpdate().unset("$tradeMode");
//				entity.getMemoryWithoutUpdate().unset("$tradeMode");
        }

		addBombardVisual(market.getPrimaryEntity());

		addBombardContinueOption();
	}

    protected void replaceWorldOrder() {
        PlanetAPI planet = null;
        PlanetAPI moon = null;
        // Get planet and moon
        if (market.hasCondition(SPP_Conditions.CLOSE_MOON)) {
            moon = SPP_Misc.getMoon(market.getPrimaryEntity());
        } else if (market.hasCondition(SPP_Conditions.LUNAR_ORBIT)
                        || market.hasCondition(SPP_Conditions.TIGHT_ORBIT)) {
            planet = SPP_Misc.getParent(market.getPrimaryEntity());
        } else if (market.hasCondition(SPP_Conditions.ORBITAL_STATION)) {
            planet = SPP_Misc.getParent(market.getPrimaryEntity());
        }

        String condId = SPP_Conditions.WORLD_ORDER;

        boolean orbital = false;
        boolean pOrbital = false;
        boolean mOrbital = false;

        market.removeCondition(condId);
        orbital = SPP_PortFunctions.getOrbitalConditions(market).remove(condId);

        if (planet != null && planet.getMarket() != market) {
            planet.getMarket().removeCondition(condId);
            pOrbital = SPP_PortFunctions.getOrbitalConditions(planet).remove(condId);
        }
        if (moon != null && moon.getMarket() != market) {
            moon.getMarket().removeCondition(condId);
            mOrbital = SPP_PortFunctions.getOrbitalConditions(moon).remove(condId);
        }

        // If pop is zeroed out, no native pop type
        int population = SPP_PortFunctions.getPopulationSize(market);
        if (population < 1) return;

        float hazard = market.getHazardValue();

        WeightedRandomPicker<String> picker = new WeightedRandomPicker<>();
        if (market.hasCondition(Conditions.HABITABLE) && population > 3
                    && hazard < 1.6) picker.add(SPP_Conditions.PRIMITIVES, 10);
        if (population > 3 && hazard < 2.1) picker.add(SPP_Conditions.NATION_STATES, 5);
        if (population < 5 && hazard < 2.1) picker.add(Conditions.DECIVILIZED, 10);
        picker.add(SPP_Conditions.XENOPHOBES, 1);

        condId = picker.pick();

        String token = "";
        String pToken = "";
        String mToken = "";

		token = market.addCondition(condId);
        if (orbital) SPP_PortFunctions.getOrbitalConditions(market).add(condId);

        if (planet != null && planet.getMarket() != market) {
            pToken = planet.getMarket().addCondition(condId);
            if (pOrbital) SPP_PortFunctions.getOrbitalConditions(planet).add(condId);
        }
        if (moon != null && moon.getMarket() != market) {
            mToken = moon.getMarket().addCondition(condId);
            if (mOrbital) SPP_PortFunctions.getOrbitalConditions(moon).add(condId);
        }

        boolean surveyed = market.getSurveyLevel() == MarketAPI.SurveyLevel.FULL;
        surveyed |= !condId.equals(SPP_Conditions.PRIMITIVES);

		market.getSpecificCondition(token).setSurveyed(surveyed);
        if (planet != null && planet.getMarket() != market) planet.getMarket().getSpecificCondition(pToken).setSurveyed(surveyed);
        if (moon != null && moon.getMarket() != market) moon.getMarket().getSpecificCondition(mToken).setSurveyed(surveyed);
    }

	protected void addBombardConfirmOptions() {
		options.clearOptions();
		options.addOption("Bombard " + market.getName(), BOMBARD_CONFIRM);
		options.addOption("Leave", LEAVE);
		options.setShortcut(LEAVE, Keyboard.KEY_ESCAPE, false, false, false, true);

		int fuel = (int) playerFleet.getCargo().getFuel();
		boolean canBombard = fuel >= temp.bombardCost;

        if (!canBombard && !Global.getSettings().isDevMode()) {
            options.setEnabled(BOMBARD_CONFIRM, false);
        }

		List<FactionAPI> nonHostile = new ArrayList<FactionAPI>();
		for (FactionAPI faction : temp.willBecomeHostile) {
			boolean hostile = faction.isHostileTo(Factions.PLAYER);
			if (!hostile) {
				nonHostile.add(faction);
			}
		}

		if (nonHostile.size() == 1) {
			FactionAPI faction = nonHostile.get(0);
			options.addOptionConfirmation(BOMBARD_CONFIRM,
					"The " + faction.getDisplayNameLong() +
					" " + faction.getDisplayNameIsOrAre() +
					" not currently hostile, and will become hostile if you carry out the bombardment. " +
					"Are you sure?", "Yes", "Never mind");
		} else if (nonHostile.size() > 1) {
			options.addOptionConfirmation(BOMBARD_CONFIRM,
					"Multiple factions that are not currently hostile " +
					"will become hostile if you carry out the bombardment. " +
					"Are you sure?", "Yes", "Never mind");
		}
	}

	protected void bombardNeverMind() {
		bombardMenu();
	}

	protected void addBombardContinueOption() {
		addBombardContinueOption(null);
	}
	protected void addBombardContinueOption(String text) {
		if (text == null) text = "Continue";
		options.clearOptions();
		options.addOption(text, BOMBARD_RESULT);
	}

	protected Random getRandom() {
		String key = "$raid_random";
		MemoryAPI mem = market.getMemoryWithoutUpdate();
		Random random = null;
		if (mem.contains(key)) {
			random = (Random) mem.get(key);
		} else {
			if (market.getPrimaryEntity() != null) {
				long seed = Misc.getSalvageSeed(market.getPrimaryEntity());
				seed *= (Global.getSector().getClock().getMonth() + 10);
				random = new Random(seed);
			} else {
				random = new Random();
			}
		}
		mem.set(key, random, 30f);

		return random;
	}
}
