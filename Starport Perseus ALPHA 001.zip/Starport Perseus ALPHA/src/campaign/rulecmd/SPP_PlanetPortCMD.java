package campaign.rulecmd;

import campaign.SPP_ImmigrationScript;
import campaign.econ.SPP_ResourceDepositsCondition;
import campaign.econ.SPP_PlanetBlockCondition;
import campaign.fleets.SPP_SystemWarFleetRouteManager;
import campaign.ids.SPP_Conditions;
import campaign.ids.SPP_Industries;
import campaign.ids.SPP_MemKeys;
import campaign.ids.SPP_Tags;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.OptionPanelAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.ResourceCostPanelAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.impl.campaign.rulecmd.AddRemoveCommodity;
import com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin;
import static com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin.getEntityMemory;
import com.fs.starfarer.api.impl.campaign.submarkets.StoragePlugin;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import util.SPP_Misc;
import util.SPP_PortFunctions;

/**
 * Author: SafariJohn
 */
public class SPP_PlanetPortCMD extends BaseCommandPlugin {
    public static final String PLANET_PORT_OPTION = "planetPort";

    public static final String ORBIT_CONTROL = "printOrbitControl";
    public static final String IS_LOCATION = "isLoc";
    public static final String CAN_BUILD = "canBuild";
    public static final String CAN_AFFORD = "canAfford";
    public static final String INFO = "info";
    public static final String BUILD = "build";

	private static final float COST_HEIGHT = 75;

	protected CampaignFleetAPI playerFleet;
	protected SectorEntityToken planet;
	protected TextPanelAPI text;
	protected OptionPanelAPI options;
	protected CargoAPI playerCargo;
	protected MemoryAPI memory;
	protected InteractionDialogAPI dialog;
	protected Map<String, MemoryAPI> memoryMap;

    @Override
    public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Misc.Token> params, Map<String, MemoryAPI> memoryMap) {
		this.dialog = dialog;
		this.memoryMap = memoryMap;

		String command = params.get(0).getString(memoryMap);
		if (command == null) return false;

        // Assume this is a close moon and try to get parent
        planet = SPP_Misc.getParent(dialog.getInteractionTarget());

        // If that fails or we aren't at a close moon, get the interaction target
        if (planet == null || (!dialog.getInteractionTarget().getMarket().hasCondition(SPP_Conditions.LUNAR_ORBIT)
                    && !dialog.getInteractionTarget().getMarket().hasCondition(SPP_Conditions.TIGHT_ORBIT))) {
            planet = dialog.getInteractionTarget();
        }

		memory = getEntityMemory(memoryMap);

		text = dialog.getTextPanel();
		options = dialog.getOptionPanel();

        playerFleet = Global.getSector().getPlayerFleet();
        playerCargo = playerFleet.getCargo();

        switch (command) {
            case ORBIT_CONTROL: printOrbitControl(); break;
            case IS_LOCATION: return isLocation();
            case CAN_AFFORD: return canAfford(SPP_PortFunctions.getPlanetBuildCost((PlanetAPI) planet));
            case CAN_BUILD: checkCanBuild(); break;
            case INFO: displayInfo(); break;
            case BUILD: buildPort(); break;
        }

        return true;
    }

    private boolean isLocation() {
        if (planet == null) return false;
        if (planet.getMarket() == null) return false;

        // Can't try to build at faction controlled site
        FactionAPI faction = planet.getFaction();
        if (faction != null && !faction.isNeutralFaction()) return false;

        return planet instanceof PlanetAPI;
    }

    private void printOrbitControl() {
        SectorEntityToken orbital = SPP_Misc.getOther(planet);
        if (orbital == null) return;

        if (orbital.getFaction().isNeutralFaction()) return;

        String playerOrbital = "Your station, " + orbital.getName() + ",";
        String otherOrbital = orbital.getName() + ", a station of " + orbital.getFaction().getDisplayNameWithArticle() + ",";
        if (orbital.getMarket().getPrimaryEntity() instanceof PlanetAPI) {
            playerOrbital = "Your port on " + orbital.getName();
            otherOrbital = "The port on " + orbital.getName() + ", belonging to " + orbital.getFaction().getDisplayNameWithArticle() + ",";
        }

        if (orbital.getMarket().isPlayerOwned()) {
            text.addPara(playerOrbital + " controls the orbit of " + planet.getName() + ".");
            text.highlightInLastPara(orbital.getFaction().getBaseUIColor(), orbital.getName());
        } else {
            text.addPara(otherOrbital + " controls the orbit of " + planet.getName() + ".");
            text.highlightInLastPara(orbital.getFaction().getBaseUIColor(), orbital.getName(), orbital.getFaction().getDisplayNameWithArticleWithoutArticle());
            text.addPara("You cannot construct a port here.", Misc.getNegativeHighlightColor());
        }

    }

    private void checkCanBuild() {
        MarketAPI market = planet.getMarket();
        if (market == null) return;

        // Can't build port if orbital port already here, unless you are station owner
        SectorEntityToken orbital = SPP_Misc.getOther(planet);
        if (orbital != null && orbital.getMarket() != null && !orbital.getMarket().isPlayerOwned()
                    && !orbital.getMarket().getFaction().isNeutralFaction()) {
            FactionAPI faction = orbital.getFaction();

            options.setEnabled(PLANET_PORT_OPTION, false);
            options.setTooltip(PLANET_PORT_OPTION, Misc.ucFirst(faction.getDisplayNameWithArticle()) + " controls the orbit of " + planet.getName() + ".");
            options.setTooltipHighlights(PLANET_PORT_OPTION, faction.getDisplayNameWithArticleWithoutArticle());
            options.setTooltipHighlightColors(PLANET_PORT_OPTION, faction.getBaseUIColor());
            return;
        }

        // Can't build port if Uninhabitable condition, such as Crushing Gravity
        boolean uninhabitable = false;
        List<MarketConditionAPI> mcs = new ArrayList<>();
        for (MarketConditionAPI mc : market.getConditions()) {
            if (mc.getPlugin() instanceof SPP_PlanetBlockCondition) {
                uninhabitable = true;
                mcs.add(mc);
            }
        }
        if (uninhabitable) {
            options.setEnabled(PLANET_PORT_OPTION, false);

            String tip = "Construction is blocked by ";
            for (int i = 0; i < mcs.size(); i++) {
                if (mcs.size() == 2 && i == 1) tip += " ";
                else if (0 < i && i < mcs.size() - 1) tip += ", ";

                if (mcs.size() > 1 && i == mcs.size() - 1) tip += "and ";

                tip += mcs.get(i).getName();
            }
            tip += ".";

            options.setTooltip(PLANET_PORT_OPTION, tip);
            options.setTooltipHighlights(PLANET_PORT_OPTION, tip);
            options.setTooltipHighlightColors(PLANET_PORT_OPTION, Misc.getNegativeHighlightColor());
            return;
        }

        // Skip cost if dev mode
//        Map<String, Integer> costs = SPP_PortFunctions.getPlanetBuildCost((PlanetAPI) planet);
//        if (!canAfford(costs) && !Global.getSettings().isDevMode()) {
//            options.setEnabled(PLANET_PORT_OPTION, false);
//            String tip = "You do not have the required resources.";
//            options.setTooltip(PLANET_PORT_OPTION, tip);
//            options.setTooltipHighlights(PLANET_PORT_OPTION, tip);
//            options.setTooltipHighlightColors(PLANET_PORT_OPTION, Misc.getNegativeHighlightColor());
//        }
    }

    private void displayInfo() {
        Map<String, Integer> costs = SPP_PortFunctions.getPlanetBuildCost((PlanetAPI) planet);
        boolean canAfford = canAfford(costs);

        String surveyAndCost = "You have full survey data for " + planet.getName();
        if (canAfford) surveyAndCost += ", as well as the required resources, allowing you to construct a port here.";
        else surveyAndCost += ", but not the resources that would allow you to construct a port here.";

        text.addPara(surveyAndCost);

        FactionAPI claimant = SPP_Misc.getClaimingFaction(planet);
        if (claimant != null) {
            text.addPara("This star system is claimed by " + claimant.getDisplayNameWithArticle()
                        + ", and a port constructed here would likely be destroyed in short order.");
            text.highlightFirstInLastPara(claimant.getDisplayNameWithArticleWithoutArticle(), claimant.getColor());
        }

        String hazard = "" + (int) (planet.getMarket().getHazardValue() * 100) + "%";
        text.addPara(planet.getName() + " has a hazard rating of " + hazard + ". "
                    + "The upkeep cost of any structures built here will be increased by that percentage.");
        text.highlightInLastPara(hazard);

        text.addPara("A port will allow access to planet-side resources and the construction of useful structures.");

        // Not going to worry about accessibility right now.
//        String access = "" + (entity.getMarket().getAccessibilityMod().computeEffective(0f) * 100f) + "%";
//        text.addPara("A port built here would have an accessibility of " + access + ", assuming it is developed into a spaceport.");
//        text.highlightInLastPara(access);

        // getShippingCapacity

        // If you have an orbital port here, mention benefits
        SectorEntityToken orbital = SPP_Misc.getOther(planet);
        if (orbital != null) {
            if (planet.getMarket().hasCondition(SPP_Conditions.PORT_IN_ORBIT)) {
                text.addPara("Your existing station port will merge with this port.");
            } else if (planet.getMarket().hasCondition(SPP_Conditions.CLOSE_MOON)) {
                text.addPara("Your existing lunar port will merge with this port.");
            }
        }

        // Reduce cost if ruins? IDK

        // Display costs
        Color color = Global.getSector().getFaction(Factions.NEUTRAL).getBrightUIColor();
        Object[] keys = costs.keySet().toArray();
        for (int i = 0; i < costs.keySet().size() / 3f; i++) {
            ResourceCostPanelAPI req;
            if (i == 0) req = text.addCostPanel("Required (available)", COST_HEIGHT, color, color);
            else req = text.addCostPanel(null, COST_HEIGHT, color, color);
            req.setNumberOnlyMode(true);
            req.setWithBorder(false);
            req.setAlignment(Alignment.LMID);

            int remainder = (costs.keySet().size() - i * 3);
            if (remainder > 3) remainder = 3;
            for (int j = 0; j < remainder; j++) {
                String commodityId = (String) keys[j + (i * 3)];
                int required = costs.get(commodityId);
                int available = (int) playerCargo.getCommodityQuantity(commodityId);
                Color curr = color;
                if (required > playerCargo.getQuantity(CargoAPI.CargoItemType.RESOURCES, commodityId)) {
                    curr = Misc.getNegativeHighlightColor();
                }
                req.addCost(commodityId, "×" + required + " (" + available + ")", curr);
            }
            req.update();
        }
    }

    private boolean canAfford(Map<String, Integer> costs) {
        if (Global.getSettings().isDevMode()) return true;

        boolean hasRequired = true;
		for (String commodityId : costs.keySet()) {
			int required = costs.get(commodityId);

			if (required > playerCargo.getQuantity(CargoAPI.CargoItemType.RESOURCES, commodityId)) {
                hasRequired = false;
			}
		}

        return hasRequired;
    }

    private void buildPort() {
        // Create market
        MarketAPI market = planet.getMarket();
        // If station port here, get its market instead and make planet the primary
        SectorEntityToken orbital = SPP_Misc.getOther(planet);
        if (orbital != null && orbital.getMarket().isPlayerOwned()) {
            convertOrbitalPort(market, orbital.getMarket());
            return;
        }

        // Add buildings, conditions, and scripts
        market.setSize(1);
        market.setFactionId(Factions.PLAYER);
        market.setPlayerOwned(true);
        market.setPlanetConditionMarketOnly(false);
        market.setAdmin(Global.getSector().getPlayerPerson());

        // Attach minor moons if any exist
        for (PlanetAPI moon : planet.getStarSystem().getPlanets()) {
            if (moon.hasTag(SPP_Tags.NO_INTERACTION)
                        && moon.getOrbitFocus() == planet) {
                moon.setMarket(market);
                market.getConnectedEntities().add(moon);
                moon.setFaction(market.getFactionId());
                moon.removeTag(SPP_Tags.NO_INTERACTION);
            }
        }


//        PlanetAPI moon = SPP_Misc.getMoon(planet);
//        if (moon != null) {
//            moon.setFaction(market.getFactionId());
//
//            List<String> lunarConditions = new ArrayList<>();
//            for (MarketConditionAPI mc : moon.getMarket().getConditions()) {
//                if (!(mc.getPlugin() instanceof SPP_ResourceDepositsCondition)) {
//                    // Store in memory
//                    lunarConditions.add(mc.getId());
//                }
//            }
//            if (!lunarConditions.isEmpty()) {
//                moon.getMemoryWithoutUpdate().set(SPP_MemKeys.LUNAR_CONDITIONS, lunarConditions);
//            }
//
//            moon.setMarket(market);
//            market.getConnectedEntities().add(moon);
//        }

        SPP_ImmigrationScript script = new SPP_ImmigrationScript(market);
        market.getContainingLocation().addScript(script);
        market.getMemoryWithoutUpdate().set(SPP_ImmigrationScript.MEM_KEY, script);
        market.getMemoryWithoutUpdate().set(SPP_Tags.MEMKEY_POP_GROWTH, true);

        if (market.hasCondition(Conditions.DECIVILIZED)) {
            market.removeCondition(Conditions.DECIVILIZED);
            market.addCondition(Conditions.DECIVILIZED_SUBPOP);
        }

        market.addIndustry(SPP_Industries.SPACEPORT);
        market.addIndustry(SPP_Industries.LOCAL_ECONOMY);

        market.addSubmarket(Submarkets.LOCAL_RESOURCES);
        market.getSubmarket(Submarkets.LOCAL_RESOURCES).getCargo();
//        market.getSubmarket(Submarkets.LOCAL_RESOURCES).setFaction(Global.getSector().getPlayerFaction());
        market.addSubmarket(Submarkets.SUBMARKET_STORAGE);
        StoragePlugin storage = (StoragePlugin) market.getSubmarket(Submarkets.SUBMARKET_STORAGE).getPlugin();
        if (storage != null) storage.setPlayerPaidToUnlock(true);

        Global.getSector().getEconomy().addMarket(market, true);
        market.getPrimaryEntity().setFaction(Factions.PLAYER);

        // Deduct resource cost
        // dev mode skips costs
        if (!Global.getSettings().isDevMode()) {
            Map<String, Integer> costs = SPP_PortFunctions.getPlanetBuildCost((PlanetAPI) planet);

            for (String commodityId : costs.keySet()) {
                int consumed = costs.get(commodityId);
                playerCargo.removeCommodity(commodityId, consumed);
                AddRemoveCommodity.addCommodityLossText(commodityId, consumed, text);
            }
        }

        SPP_PortFunctions.establishPlayerFaction(false);
        SPP_PortFunctions.playColonyEstablishedSound();
    }

    private void convertOrbitalPort(MarketAPI pMarket, MarketAPI orbital) {
        SectorEntityToken temp = orbital.getPrimaryEntity();

        // Link up planet
        orbital.getConnectedEntities().add(planet);
        orbital.setPrimaryEntity(planet);
        planet.setMarket(orbital);
        planet.setFaction(Factions.PLAYER);

        // Update WarPort entity
        SPP_SystemWarFleetRouteManager manager = SPP_Misc.getWarFleetRouteManager(orbital.getStarSystem());
        manager.getWarPorts().remove(temp);
        manager.getWarPorts().put(planet, orbital.getSize());

        // Need to remove station and lunar conditions
        // Lunar conditions need to be stored for if the market is destroyed
        List<String> lunarConditions = new ArrayList<>();
        List<String> toRemove = new ArrayList<>();
        for (MarketConditionAPI mc : orbital.getConditions()) {
            if (pMarket.hasCondition(SPP_Conditions.CLOSE_MOON)) {
                // Store in memory
                lunarConditions.add(mc.getId());
            }

            toRemove.add(mc.getId());
//            orbital.removeCondition(mc.getId());
        }
        if (!lunarConditions.isEmpty()) {
            orbital.getMemoryWithoutUpdate().set(SPP_MemKeys.LUNAR_CONDITIONS, lunarConditions);
        }

        for (String condId: toRemove) {
            orbital.removeCondition(condId);
        }

        // Add planet conditions
        for (MarketConditionAPI mc : pMarket.getConditions()) {
            if (mc.getId().equals(SPP_Conditions.PORT_IN_ORBIT)) continue;

            orbital.addCondition(mc);
        }

        if (orbital.hasCondition(Conditions.DECIVILIZED)) {
            orbital.removeCondition(Conditions.DECIVILIZED);
            orbital.addCondition(Conditions.DECIVILIZED_SUBPOP);
        }


        // Add benefits from having orbital port in place
        // Add Trade Station?

        // Deduct resource cost
        // dev mode skips costs
        if (!Global.getSettings().isDevMode()) {
            Map<String, Integer> costs = SPP_PortFunctions.getPlanetBuildCost((PlanetAPI) planet);
            // Get conversion cost instead of planetBuild cost?

            for (String commodityId : costs.keySet()) {
                int consumed = costs.get(commodityId);
                playerCargo.removeCommodity(commodityId, consumed);
                AddRemoveCommodity.addCommodityLossText(commodityId, consumed, text);
            }
        }
    }

}
