package campaign.rulecmd;

import campaign.SPP_SurveyPluginImpl;
import campaign.econ.SPP_NativePopCondition;
import campaign.econ.SPP_OrbitalBlockCondition;
import campaign.econ.SPP_PlanetBlockCondition;
import campaign.econ.SPP_ResourceDepositsCondition;
import campaign.ids.SPP_Conditions;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.combat.MutableStat;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.procgen.ConditionGenDataSpec;
import com.fs.starfarer.api.impl.campaign.rulecmd.AddRemoveCommodity;
import com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin;
import static com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin.getEntityMemory;
import com.fs.starfarer.api.impl.campaign.rulecmd.FireBest;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import java.util.*;
import util.SPP_Misc;
import util.SPP_PortFunctions;

/**
 * Author: SafariJohn
 */
public class SPP_SurveyCMD extends BaseCommandPlugin {
    private static final String BLOCKED = "blocked";
    private static final String BLOCKED_SURVEY = "blockedSurvey";
    private static final String COST = "printCost";
    private static final String CAN_SURVEY = "canSurvey";
    private static final String SURVEY = "survey";
    private static final String INFO = "info";
    private static final String EXPLORED = "setOtherRuinsExplored";

	private static final float COST_HEIGHT = 75;

	protected CampaignFleetAPI playerFleet;
	protected PlanetAPI planet;
	protected FactionAPI playerFaction;
	protected TextPanelAPI text;
	protected OptionPanelAPI options;
	protected CargoAPI cargo;
	protected MemoryAPI memory;
	protected InteractionDialogAPI dialog;
	protected Map<String, MemoryAPI> memoryMap;

    @Override
    public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Misc.Token> params, Map<String, MemoryAPI> memoryMap) {
		this.dialog = dialog;
		this.memoryMap = memoryMap;

		String command = params.get(0).getString(memoryMap);
		if (command == null) return false;

		planet = (PlanetAPI) dialog.getInteractionTarget();

		memory = getEntityMemory(memoryMap);

		text = dialog.getTextPanel();
		options = dialog.getOptionPanel();

        playerFaction = Global.getSector().getPlayerFaction();
        playerFleet = Global.getSector().getPlayerFleet();
        cargo = playerFleet.getCargo();

        switch (command) {
            case BLOCKED: return blocked();
            case BLOCKED_SURVEY: blockedSurvey(); break;
            case COST: printCost(); break;
            case CAN_SURVEY: return canSurvey();
            case SURVEY: survey(); break;
            case INFO: info(); break;
            case EXPLORED: setOtherRuinsExplored(); break;
        }

        return true;
    }

    /**
     * Also removes surveyable conditions from blocked planets
     * @return true if planet (and moon) cannot have a port built at them.
     */
    private boolean blocked() {
        // Get planet and moon sorted
        PlanetAPI moon = null;
        PlanetAPI temp = planet;
        if (temp.getMarket().hasCondition(SPP_Conditions.CLOSE_MOON)) {
            planet = (PlanetAPI) temp;
            moon = SPP_Misc.getMoon(planet);
        }
//        } else if (temp.getMarket().hasCondition(SPP_Conditions.LUNAR_ORBIT)
//                    || temp.getMarket().hasCondition(SPP_Conditions.TIGHT_ORBIT)) {
//            moon = (PlanetAPI) temp;
//            planet = SPP_Misc.getParent(moon);
//        }

        // Check if planet is blocked
        boolean planetUninhabitable = false;
        boolean planetBlocked = false;
        boolean abandonedStation = false;
        for (MarketConditionAPI mc : planet.getMarket().getConditions()) {
            if (mc.getPlugin() instanceof SPP_PlanetBlockCondition) planetUninhabitable = true;
            if (mc.getPlugin() instanceof SPP_OrbitalBlockCondition) {
                if (mc.getId().equals(SPP_Conditions.ABANDONED_STATION)
                            && !planetBlocked) {
                    abandonedStation = true;
                    planetBlocked = true;
                } else {
                    abandonedStation = false;
                    planetBlocked = true;
                }


            }

            if (planetBlocked && planetUninhabitable) break;
        }
        planetBlocked = planetBlocked && planetUninhabitable;

        // Check if moon is blocked
//        boolean moonUninhabitable = false;
//        boolean moonBlocked = false;
//        if (moon != null) {
//            for (MarketConditionAPI mc : moon.getMarket().getConditions()) {
//                if (mc.getPlugin() instanceof SPP_PlanetBlockCondition) moonUninhabitable = true;
//                if (mc.getPlugin() instanceof SPP_OrbitalBlockCondition) moonBlocked = true;
//
//                if (moonBlocked && moonUninhabitable) break;
//            }
//            moonBlocked = moonBlocked && moonUninhabitable;
//        } else {
//            moonBlocked = true;
//        }

        // If planet (and moon) blocked, remove surveyable conditions
        // Unless the planet's orbit block is an abandoned station
        if (planetBlocked && !abandonedStation) {
//            if (moon != null) {
//                List<MarketConditionAPI> toRemove = new ArrayList<>();
//                for (MarketConditionAPI mc : moon.getMarket().getConditions()) {
//                    if (mc.requiresSurveying()) toRemove.add(mc);
//                }
//                moon.getMarket().getConditions().removeAll(toRemove);
//            }

            List<MarketConditionAPI> toRemove = new ArrayList<>();
            for (MarketConditionAPI mc : planet.getMarket().getConditions()) {
                if (mc.requiresSurveying()) toRemove.add(mc);
            }
            planet.getMarket().getConditions().removeAll(toRemove);
        }


        return planetBlocked && !abandonedStation;
    }

    private void blockedSurvey() {
        // Display hazards
		Color color = Global.getSector().getFaction(Factions.NEUTRAL).getBrightUIColor();
		Color bad = Misc.getNegativeHighlightColor();
		Color highlight = Misc.getHighlightColor();

		float pad = 3f;
		float opad = 10f;
		float small = 5f;

        text.addPara(planet.getName() + " has a hazard rating of "
                    + (int) (planet.getMarket().getHazardValue() * 100) + "% on the standard scale.");
        text.highlightFirstInLastPara((int) (planet.getMarket().getHazardValue() * 100) + "%", highlight);

        text.addPara("The following contributing factors were identified:");
        final List<String> blocks = getStandardBlocks(planet.getMarket().getConditions());

        // Grid of hazard ratings - base rating is always listed
        TooltipMakerAPI panel = text.beginTooltip();
        panel.addStatModGrid(300, 50, opad, pad, planet.getMarket().getHazard(), true, new TooltipMakerAPI.StatModValueGetter() {
				public String getPercentValue(MutableStat.StatMod mod) { return null; }
				public String getMultValue(MutableStat.StatMod mod) { return null; }
				public Color getModColor(MutableStat.StatMod mod) {
                    if (blocks.contains(mod.getSource())) return Misc.getNegativeHighlightColor();
                    return null;
                }
				public String getFlatValue(MutableStat.StatMod mod) {
                    float hazard = mod.value;
                    if (hazard != 0) {
                        String pct = "" + (int)(hazard * 100f) + "%";
                        if (hazard > 0) pct = "+" + pct;
                        return pct;
                    }

                    return "" + hazard;
				}
        });

        text.addTooltip();

        // If planet/moon pair
        if (planet.getMarket().hasCondition(SPP_Conditions.CLOSE_MOON)) {
            PlanetAPI moon = SPP_Misc.getMoon(planet);

            if (moon != null) {
                text.addPara("The closely orbiting moon of " + moon.getName() + " has a hazard rating of "
                            + (int) (moon.getMarket().getHazardValue() * 100) + "% on the standard scale.");
                text.highlightFirstInLastPara((int) (moon.getMarket().getHazardValue() * 100) + "%", highlight);

                text.addPara("The following contributing factors were identified:");

                blocks.clear();
                blocks.addAll(getStandardBlocks(planet.getMarket().getConditions()));

                // Grid of hazard ratings - base rating is always listed
                panel = text.beginTooltip();
                panel.addStatModGrid(300, 50, opad, pad, moon.getMarket().getHazard(), true, new TooltipMakerAPI.StatModValueGetter() {
                        public String getPercentValue(MutableStat.StatMod mod) { return null; }
                        public String getMultValue(MutableStat.StatMod mod) { return null; }
                        public Color getModColor(MutableStat.StatMod mod) {
                            if (blocks.contains(mod.getSource())) return Misc.getNegativeHighlightColor();
                            return null;
                        }
                        public String getFlatValue(MutableStat.StatMod mod) {
                            float hazard = mod.value;
                            if (hazard != 0) {
                                String pct = "" + (int)(hazard * 100f) + "%";
                                if (hazard > 0) pct = "+" + pct;
                                return pct;
                            }

                            return "" + hazard;
                        }
                });

                text.addTooltip();
            }
        } else if (planet.getMarket().hasCondition(SPP_Conditions.LUNAR_ORBIT)
                    || planet.getMarket().hasCondition(SPP_Conditions.TIGHT_ORBIT)) {
            PlanetAPI parent = SPP_Misc.getParent(planet);

            if (parent != null) {
                text.addPara(parent.getName() + ", the parent of " + planet.getName() + ", has a hazard rating of "
                            + (int) (parent.getMarket().getHazardValue() * 100) + "% on the standard scale.");
                text.highlightFirstInLastPara((int) (parent.getMarket().getHazardValue() * 100) + "%", highlight);

                text.addPara("The following contributing factors were identified:");

                blocks.clear();
                blocks.addAll(getStandardBlocks(planet.getMarket().getConditions()));

                // Grid of hazard ratings - base rating is always listed
                panel = text.beginTooltip();
                panel.addStatModGrid(300, 50, opad, pad, parent.getMarket().getHazard(), true, new TooltipMakerAPI.StatModValueGetter() {
                        public String getPercentValue(MutableStat.StatMod mod) { return null; }
                        public String getMultValue(MutableStat.StatMod mod) { return null; }
                        public Color getModColor(MutableStat.StatMod mod) {
                            if (blocks.contains(mod.getSource())) return Misc.getNegativeHighlightColor();
                            return null;
                        }
                        public String getFlatValue(MutableStat.StatMod mod) {
                            float hazard = mod.value;
                            if (hazard != 0) {
                                String pct = "" + (int)(hazard * 100f) + "%";
                                if (hazard > 0) pct = "+" + pct;
                                return pct;
                            }

                            return "" + hazard;
                        }
                });

                text.addTooltip();
            }
        }

        SPP_SurveyPluginImpl plugin = new SPP_SurveyPluginImpl();
        plugin.init(playerFleet, planet);

        // No cost

		Misc.setFullySurveyed(planet.getMarket(), null, false);

        // Discoveries!!!
        for (MarketConditionAPI mc : planet.getMarket().getConditions()) {
            if (mc.requiresSurveying()) {
                mc.setSurveyed(true);
    //            text.addPara("Found " + mc.getName(), Misc.getHighlightColor(), mc.getName());
                text.addPara("Found: " + mc.getName());
            }
        }

        if (planet.getMarket().hasCondition(SPP_Conditions.CLOSE_MOON)) {
            PlanetAPI moon = SPP_Misc.getMoon(planet);

            if (moon != null) {
                moon.getMarket().setSurveyLevel(MarketAPI.SurveyLevel.FULL);

                for (MarketConditionAPI mc : moon.getMarket().getConditions()) {
                    if (mc.requiresSurveying()) {
                        mc.setSurveyed(true);
//                        text.addPara("Found: " + mc.getName());
                    }
                }
            }
        } else if (planet.getMarket().hasCondition(SPP_Conditions.LUNAR_ORBIT)
                    || planet.getMarket().hasCondition(SPP_Conditions.TIGHT_ORBIT)) {
            PlanetAPI parent = SPP_Misc.getParent(planet);

            if (parent != null) {
                parent.getMarket().setSurveyLevel(MarketAPI.SurveyLevel.FULL);

                for (MarketConditionAPI mc : parent.getMarket().getConditions()) {
                    if (mc.requiresSurveying()) {
                        mc.setSurveyed(true);
//                        text.addPara("Found: " + mc.getName());
                    }
                }
            }
        }

        String gains = "";
        // XP
        long xp = plugin.getXP();
		if (xp > 0) {
			Global.getSector().getPlayerPerson().getStats().addXP((long) xp);

            gains += "Gained " + xp + " experience and ";
		}

        // Survey Data
		String dataType = plugin.getSurveyDataType(planet);
        String dataName = Global.getSettings().getCommoditySpec(dataType).getName();
		if (dataType != null) {
			Global.getSector().getPlayerFleet().getCargo().addCommodity(dataType, 1);

            if (gains.isEmpty()) gains += "Gained ";

            gains += dataName;
		}

        text.addPara(gains, Misc.getHighlightColor(), "" + xp, dataName);
    }

    private void printCost() {
        Misc.setPreliminarySurveyed(planet.getMarket(), null, false);

		Color color = Global.getSector().getFaction(Factions.NEUTRAL).getBrightUIColor();
		Color bad = Misc.getNegativeHighlightColor();
		Color highlight = Misc.getHighlightColor();

		float pad = 3f;
		float opad = 10f;
		float small = 5f;

        text.addPara(planet.getName() + " has the following hazardous conditions:");

        List<MarketConditionAPI> marketConditions = new ArrayList<>();
        List<MarketConditionAPI> planetaryConditions = new ArrayList<>();

        for (MarketConditionAPI mc : planet.getMarket().getConditions()) {
            if (mc.requiresSurveying()) continue;
            if (mc.requiresSurveying() && mc.getPlugin() instanceof SPP_NativePopCondition) continue;

            if (mc.isPlanetary()) planetaryConditions.add(mc);
            else marketConditions.add(mc);
        }

        Collections.sort(marketConditions, new MarketConditionSorter());
        Collections.sort(planetaryConditions, new MarketConditionSorter());

        displayMarketConditions(marketConditions);
        displayMarketConditions(planetaryConditions);

        text.addPara("A preliminary survey indicates that " + planet.getName() + " has a hazard rating of "
                    + (int) (planet.getMarket().getHazardValue() * 100) + "% on the standard scale.");
        text.highlightFirstInLastPara((int) (planet.getMarket().getHazardValue() * 100) + "%", highlight);

        text.addPara("The following contributing factors were identified:");
        final List<String> blocks = getStandardBlocks(planet.getMarket().getConditions());

        // Grid of hazard ratings - base rating is always listed
        TooltipMakerAPI panel = text.beginTooltip();

        panel.addStatModGrid(300, 50, opad, pad, planet.getMarket().getHazard(), true, new TooltipMakerAPI.StatModValueGetter() {
				public String getPercentValue(MutableStat.StatMod mod) { return null; }
				public String getMultValue(MutableStat.StatMod mod) { return null; }
				public Color getModColor(MutableStat.StatMod mod) {
                    if (blocks.contains(mod.getSource())) return Misc.getNegativeHighlightColor();
                    return null;
                }
				public String getFlatValue(MutableStat.StatMod mod) {
                    float hazard = mod.value;
                    if (hazard != 0) {
                        String pct = "" + (int)(hazard * 100f) + "%";
                        if (hazard > 0) pct = "+" + pct;
                        return pct;
                    }

                    return "" + hazard;
				}
        });

        text.addTooltip();

        // If planet/moon pair
        if (planet.getMarket().hasCondition(SPP_Conditions.CLOSE_MOON)) {
            PlanetAPI moon = SPP_Misc.getMoon(planet);

            if (moon != null) {
                Misc.setPreliminarySurveyed(moon.getMarket(), null, false);

                text.addPara(moon.getName() + ", closely orbiting moon", Misc.getBasePlayerColor());
//                text.addPara("The closely orbiting moon of " +  + " .");

                marketConditions = new ArrayList<>();
                planetaryConditions = new ArrayList<>();

                for (MarketConditionAPI mc : moon.getMarket().getConditions()) {
                    if (mc.requiresSurveying()) continue;
                    if (mc.getPlugin() instanceof SPP_NativePopCondition) continue;

                    if (mc.isPlanetary()) planetaryConditions.add(mc);
                    else marketConditions.add(mc);
                }

                Collections.sort(marketConditions, new MarketConditionSorter());
                Collections.sort(planetaryConditions, new MarketConditionSorter());

                displayMarketConditions(marketConditions);
                displayMarketConditions(planetaryConditions);

                text.addPara("The survey also indicates that the closely orbiting moon of " + moon.getName() + " has a hazard rating of "
                            + (int) (moon.getMarket().getHazardValue() * 100) + "% on the standard scale.");
                text.highlightFirstInLastPara((int) (moon.getMarket().getHazardValue() * 100) + "%", highlight);

                text.addPara("The following contributing factors were identified:");
                blocks.clear();
                blocks.addAll(getStandardBlocks(moon.getMarket().getConditions()));

                // Grid of hazard ratings - base rating is always listed
                panel = text.beginTooltip();
                panel.addStatModGrid(300, 50, opad, pad, moon.getMarket().getHazard(), true, new TooltipMakerAPI.StatModValueGetter() {
                        public String getPercentValue(MutableStat.StatMod mod) { return null; }
                        public String getMultValue(MutableStat.StatMod mod) { return null; }
                        public Color getModColor(MutableStat.StatMod mod) {
                            if (blocks.contains(mod.getSource())) return Misc.getNegativeHighlightColor();
                            return null;
                        }
                        public String getFlatValue(MutableStat.StatMod mod) {
                            float hazard = mod.value;
                            if (hazard != 0) {
                                String pct = "" + (int)(hazard * 100f) + "%";
                                if (hazard > 0) pct = "+" + pct;
                                return pct;
                            }

                            return "" + hazard;
                        }
                });

                text.addTooltip();
            }
        } else if (planet.getMarket().hasCondition(SPP_Conditions.LUNAR_ORBIT)
                    || planet.getMarket().hasCondition(SPP_Conditions.TIGHT_ORBIT)) {
            PlanetAPI parent = SPP_Misc.getParent(planet);

            if (parent != null) {
                Misc.setPreliminarySurveyed(parent.getMarket(), null, false);

                text.addPara(parent.getName() + ", parent of " + planet.getName(), Misc.getBasePlayerColor());
//                text.addPara("The closely orbiting moon of " +  + " .");

                marketConditions = new ArrayList<>();
                planetaryConditions = new ArrayList<>();

                for (MarketConditionAPI mc : parent.getMarket().getConditions()) {
                    if (mc.requiresSurveying()) continue;
                    if (mc.getPlugin() instanceof SPP_NativePopCondition) continue;

                    if (mc.isPlanetary()) planetaryConditions.add(mc);
                    else marketConditions.add(mc);
                }

                Collections.sort(marketConditions, new MarketConditionSorter());
                Collections.sort(planetaryConditions, new MarketConditionSorter());

                displayMarketConditions(marketConditions);
                displayMarketConditions(planetaryConditions);

                text.addPara("The survey also indicates " + parent.getName() + ", the parent of " + planet.getName() + ", has a hazard rating of "
                            + (int) (parent.getMarket().getHazardValue() * 100) + "% on the standard scale.");
                text.highlightFirstInLastPara((int) (parent.getMarket().getHazardValue() * 100) + "%", highlight);

                text.addPara("The following contributing factors were identified:");
                blocks.clear();
                blocks.addAll(getStandardBlocks(parent.getMarket().getConditions()));

                // Grid of hazard ratings - base rating is always listed
                panel = text.beginTooltip();
                panel.addStatModGrid(300, 50, opad, pad, parent.getMarket().getHazard(), true, new TooltipMakerAPI.StatModValueGetter() {
                        public String getPercentValue(MutableStat.StatMod mod) { return null; }
                        public String getMultValue(MutableStat.StatMod mod) { return null; }
                        public Color getModColor(MutableStat.StatMod mod) {
                            if (blocks.contains(mod.getSource())) return Misc.getNegativeHighlightColor();
                            return null;
                        }
                        public String getFlatValue(MutableStat.StatMod mod) {
                            float hazard = mod.value;
                            if (hazard != 0) {
                                String pct = "" + (int)(hazard * 100f) + "%";
                                if (hazard > 0) pct = "+" + pct;
                                return pct;
                            }

                            return "" + hazard;
                        }
                });

                text.addTooltip();
            }
        }

        if (planet.getMarket().hasCondition(SPP_Conditions.WORLD_ORDER)) {
            String planetName = planet.getName();
            if (SPP_PortFunctions.getOrbitalConditions(planet).contains(SPP_Conditions.WORLD_ORDER)) {
                planetName = SPP_Misc.getMoonOrParent(planet).getName();
            }

            text.addPara(planetName + " is under the dominion of a "
                        + "xenophobic planetary government, backed "
                        + "by a functional Domain defense system. "
                        + "Your hails are ignored. The only way to "
                        + "access this planet is to bombard the "
                        + "natives into submission.");
            return;
        }

        SPP_SurveyPluginImpl plugin = new SPP_SurveyPluginImpl();
        plugin.init(playerFleet, planet);
		Map<String, Integer> requiredRes = plugin.getRequired();

		text.addParagraph("The base resource cost of a survey is modified by the following factors:");

        // Grid for hazard and size multipliers
        panel = text.beginTooltip();
        panel.addStatModGrid(300, 50, opad, pad, plugin.getCostMult(), true, new TooltipMakerAPI.StatModValueGetter() {
				public String getPercentValue(MutableStat.StatMod mod) { return null; }
				public String getMultValue(MutableStat.StatMod mod) {
                    float m = (float) ((int) (mod.value * 100) / 100f);
                    return "×" + m;
                }
				public Color getModColor(MutableStat.StatMod mod) { return null; }
				public String getFlatValue(MutableStat.StatMod mod) { return null; }
        });

        text.addTooltip();

		ResourceCostPanelAPI req = text.addCostPanel("Required (available)", COST_HEIGHT, color, color);
		req.setNumberOnlyMode(true);
		req.setWithBorder(false);
		req.setAlignment(Alignment.LMID);

		for (String commodityId : requiredRes.keySet()) {
			int required = requiredRes.get(commodityId);
			int available = (int) cargo.getCommodityQuantity(commodityId);
			Color curr = color;
			if (required > cargo.getQuantity(CargoAPI.CargoItemType.RESOURCES, commodityId)) {
				curr = bad;
			}
			req.addCost(commodityId, "×" + required + " (" + available + ")", curr);
		}
		req.update();

        requiredRes = plugin.getConsumed();

		ResourceCostPanelAPI cost = text.addCostPanel("Consumed (available)", COST_HEIGHT, color, color);
		cost.setNumberOnlyMode(true);
		cost.setWithBorder(false);
		cost.setAlignment(Alignment.LMID);

		for (String commodityId : requiredRes.keySet()) {
			int required = requiredRes.get(commodityId);
			int available = (int) cargo.getCommodityQuantity(commodityId);
			Color curr = color;
			if (required > cargo.getQuantity(CargoAPI.CargoItemType.RESOURCES, commodityId)) {
				curr = bad;
			}
			cost.addCost(commodityId, "×" + required + " (" + available + ")", curr);
		}
		cost.update();
    }

    private boolean canSurvey() {
        if (Global.getSettings().isDevMode()) return true;

        SPP_SurveyPluginImpl plugin = new SPP_SurveyPluginImpl();
        plugin.init(playerFleet, planet);

		Map<String, Integer> requiredRes = plugin.getRequired();
        boolean hasRequired = true;
		for (String commodityId : requiredRes.keySet()) {
			int required = requiredRes.get(commodityId);

			if (required > cargo.getQuantity(CargoAPI.CargoItemType.RESOURCES, commodityId)) {
                hasRequired = false;
			}
		}

		Map<String, Integer> consumedRes = plugin.getRequired();
//        boolean hasConsumed = true;
		for (String commodityId : consumedRes.keySet()) {
			int required = consumedRes.get(commodityId);

			if (required > cargo.getQuantity(CargoAPI.CargoItemType.RESOURCES, commodityId)) {
                hasRequired = false;
			}
		}

        return hasRequired;
    }

    private void survey() {
        SPP_SurveyPluginImpl plugin = new SPP_SurveyPluginImpl();
        plugin.init(playerFleet, planet);

        // dev mode skips costs
        if (!Global.getSettings().isDevMode()) {
            Map<String, Integer> costs = plugin.getConsumed();

            for (String commodityId : costs.keySet()) {
                int consumed = costs.get(commodityId);
                cargo.removeCommodity(commodityId, consumed);
				AddRemoveCommodity.addCommodityLossText(commodityId, consumed, text);
            }
        }

		Misc.setFullySurveyed(planet.getMarket(), null, false);

        // Discoveries!!!
        for (MarketConditionAPI mc : planet.getMarket().getConditions()) {
            if (mc.requiresSurveying()) {
                mc.setSurveyed(true);
    //            text.addPara("Found " + mc.getName(), Misc.getHighlightColor(), mc.getName());
//                text.addPara("Found: " + mc.getName());
            }
        }

        text.addPara("Discovered the following exploitable conditions:");

        List<MarketConditionAPI> marketConditions = new ArrayList<>();
        List<MarketConditionAPI> planetaryConditions = new ArrayList<>();

        for (MarketConditionAPI mc : planet.getMarket().getConditions()) {
            if (mc.requiresSurveying() && mc.getPlugin() instanceof SPP_NativePopCondition) {
                marketConditions.add(mc);
                continue;
            }
            if (!mc.requiresSurveying()) continue;

            if (mc.isPlanetary()) planetaryConditions.add(mc);
            else marketConditions.add(mc);
        }

        Collections.sort(marketConditions, new MarketConditionSorter());
        Collections.sort(planetaryConditions, new MarketConditionSorter());

        displayMarketConditions(marketConditions);
//        if (!marketConditions.isEmpty() && !planetaryConditions.isEmpty()) text.addPara("");
        displayMarketConditions(planetaryConditions);


        if (planet.getMarket().hasCondition(SPP_Conditions.CLOSE_MOON)) {
            PlanetAPI moon = SPP_Misc.getMoon(planet);

            if (moon != null) {
                moon.getMarket().setSurveyLevel(MarketAPI.SurveyLevel.FULL);

                for (MarketConditionAPI mc : moon.getMarket().getConditions()) {
                    if (mc.requiresSurveying()) {
                        mc.setSurveyed(true);
//                        text.addPara("Found: " + mc.getName());
                    }
                }
            }
        } else if (planet.getMarket().hasCondition(SPP_Conditions.LUNAR_ORBIT)
                    || planet.getMarket().hasCondition(SPP_Conditions.TIGHT_ORBIT)) {
            PlanetAPI parent = SPP_Misc.getParent(planet);

            if (parent != null) {
                parent.getMarket().setSurveyLevel(MarketAPI.SurveyLevel.FULL);

                for (MarketConditionAPI mc : parent.getMarket().getConditions()) {
                    if (mc.requiresSurveying()) {
                        mc.setSurveyed(true);
//                        text.addPara("Found: " + mc.getName());
                    }
                }
            }
        }

        String gains = "";
        // XP
        long xp = plugin.getXP();
		if (xp > 0) {
			Global.getSector().getPlayerPerson().getStats().addXP((long) xp);

            gains += "Gained " + xp + " experience and ";
		}

        // Survey Data
		String dataType = plugin.getSurveyDataType(planet);
        String dataName = Global.getSettings().getCommoditySpec(dataType).getName();
		if (dataType != null) {
			Global.getSector().getPlayerFleet().getCargo().addCommodity(dataType, 1);

            if (gains.isEmpty()) gains += "Gained ";

            gains += dataName;
		}

        text.addPara(gains, Misc.getHighlightColor(), "" + xp, dataName);
    }

    private void info() {
		Color highlight = Misc.getHighlightColor();

		float pad = 3f;
		float opad = 10f;
		float small = 5f;

        List<MarketConditionAPI> marketConditions = new ArrayList<>();
        List<MarketConditionAPI> planetaryConditions = new ArrayList<>();

        for (MarketConditionAPI mc : planet.getMarket().getConditions()) {
            if (mc.requiresSurveying()) continue;
            if (mc.getPlugin() instanceof SPP_NativePopCondition) continue;
            if (mc.getPlugin() instanceof SPP_ResourceDepositsCondition) continue;

            if (mc.isPlanetary()) planetaryConditions.add(mc);
            else marketConditions.add(mc);
        }

        Collections.sort(marketConditions, new MarketConditionSorter());
        Collections.sort(planetaryConditions, new MarketConditionSorter());

        displayMarketConditions(marketConditions);
        displayMarketConditions(planetaryConditions);

        text.addPara(planet.getName() + " has a hazard rating of "
                    + (int) (planet.getMarket().getHazardValue() * 100) + "% on the standard scale.");
        text.highlightFirstInLastPara((int) (planet.getMarket().getHazardValue() * 100) + "%", highlight);

        text.addPara("The following contributing factors are identified:");
        final List<String> blocks = getStandardBlocks(planet.getMarket().getConditions());

        // Grid of hazard ratings - base rating is always listed
        TooltipMakerAPI panel = text.beginTooltip();
        panel.addStatModGrid(300, 50, opad, pad, planet.getMarket().getHazard(), true, new TooltipMakerAPI.StatModValueGetter() {
				public String getPercentValue(MutableStat.StatMod mod) { return null; }
				public String getMultValue(MutableStat.StatMod mod) { return null; }
				public Color getModColor(MutableStat.StatMod mod) {
                    if (blocks.contains(mod.getSource())) return Misc.getNegativeHighlightColor();
                    return null;
                }
				public String getFlatValue(MutableStat.StatMod mod) {
                    float hazard = mod.value;
                    if (hazard != 0) {
                        String pct = "" + (int)(hazard * 100f) + "%";
                        if (hazard > 0) pct = "+" + pct;
                        return pct;
                    }

                    return "" + hazard;
				}
        });

        text.addTooltip();

        // If planet/moon pair
        if (planet.getMarket().hasCondition(SPP_Conditions.CLOSE_MOON)) {
            PlanetAPI moon = SPP_Misc.getMoon(planet);

            if (moon != null) {
                marketConditions.clear();
                planetaryConditions.clear();

                for (MarketConditionAPI mc : moon.getMarket().getConditions()) {
                    if (mc.requiresSurveying()) continue;
                    if (mc.getPlugin() instanceof SPP_NativePopCondition) continue;
                    if (mc.getPlugin() instanceof SPP_ResourceDepositsCondition) continue;

                    if (mc.isPlanetary()) planetaryConditions.add(mc);
                    else marketConditions.add(mc);
                }

                Collections.sort(marketConditions, new MarketConditionSorter());
                Collections.sort(planetaryConditions, new MarketConditionSorter());

                displayMarketConditions(marketConditions);
                displayMarketConditions(planetaryConditions);

                text.addPara("The closely orbiting moon of " + moon.getName() + " has a hazard rating of "
                            + (int) (moon.getMarket().getHazardValue() * 100) + "% on the standard scale.");
                text.highlightFirstInLastPara((int) (moon.getMarket().getHazardValue() * 100) + "%", highlight);

                text.addPara("The following contributing factors are identified:");
                blocks.clear();
                blocks.addAll(getStandardBlocks(moon.getMarket().getConditions()));

                // Grid of hazard ratings - base rating is always listed
                panel = text.beginTooltip();
                panel.addStatModGrid(300, 50, opad, pad, moon.getMarket().getHazard(), true, new TooltipMakerAPI.StatModValueGetter() {
                        public String getPercentValue(MutableStat.StatMod mod) { return null; }
                        public String getMultValue(MutableStat.StatMod mod) { return null; }
                        public Color getModColor(MutableStat.StatMod mod) {
                            if (blocks.contains(mod.getSource())) return Misc.getNegativeHighlightColor();
                            return null;
                        }
                        public String getFlatValue(MutableStat.StatMod mod) {
                            float hazard = mod.value;
                            if (hazard != 0) {
                                String pct = "" + (int)(hazard * 100f) + "%";
                                if (hazard > 0) pct = "+" + pct;
                                return pct;
                            }

                            return "" + hazard;
                        }
                });

                text.addTooltip();
            }
        } else if (planet.getMarket().hasCondition(SPP_Conditions.LUNAR_ORBIT)
                    || planet.getMarket().hasCondition(SPP_Conditions.TIGHT_ORBIT)) {
            PlanetAPI parent = SPP_Misc.getParent(planet);

            if (parent != null) {
                marketConditions.clear();
                planetaryConditions.clear();

                for (MarketConditionAPI mc : parent.getMarket().getConditions()) {
                    if (mc.requiresSurveying()) continue;
                    if (mc.getPlugin() instanceof SPP_NativePopCondition) continue;
                    if (mc.getPlugin() instanceof SPP_ResourceDepositsCondition) continue;

                    if (mc.isPlanetary()) planetaryConditions.add(mc);
                    else marketConditions.add(mc);
                }

                Collections.sort(marketConditions, new MarketConditionSorter());
                Collections.sort(planetaryConditions, new MarketConditionSorter());

                displayMarketConditions(marketConditions);
                displayMarketConditions(planetaryConditions);

                text.addPara(parent.getName() + ", the parent of " + planet.getName() + ", has a hazard rating of "
                            + (int) (parent.getMarket().getHazardValue() * 100) + "% on the standard scale.");
                text.highlightFirstInLastPara((int) (parent.getMarket().getHazardValue() * 100) + "%", highlight);

                text.addPara("The following contributing factors are identified:");
                blocks.clear();
                blocks.addAll(getStandardBlocks(parent.getMarket().getConditions()));

                // Grid of hazard ratings - base rating is always listed
                panel = text.beginTooltip();
                panel.addStatModGrid(300, 50, opad, pad, parent.getMarket().getHazard(), true, new TooltipMakerAPI.StatModValueGetter() {
                        public String getPercentValue(MutableStat.StatMod mod) { return null; }
                        public String getMultValue(MutableStat.StatMod mod) { return null; }
                        public Color getModColor(MutableStat.StatMod mod) {
                            if (blocks.contains(mod.getSource())) return Misc.getNegativeHighlightColor();
                            return null;
                        }
                        public String getFlatValue(MutableStat.StatMod mod) {
                            float hazard = mod.value;
                            if (hazard != 0) {
                                String pct = "" + (int)(hazard * 100f) + "%";
                                if (hazard > 0) pct = "+" + pct;
                                return pct;
                            }

                            return "" + hazard;
                        }
                });

                text.addTooltip();
            }
        }

        marketConditions.clear();
        planetaryConditions.clear();

        for (MarketConditionAPI mc : planet.getMarket().getConditions()) {
            if (mc.getPlugin() instanceof SPP_NativePopCondition) {
                marketConditions.add(mc);
                continue;
            }
//            if (mc.getPlugin() instanceof SPP_ResourceDepositsCondition) {
//                planetaryConditions.add(mc);
//                continue;
//            }
            if (!mc.requiresSurveying()) continue;

            if (mc.isPlanetary()) planetaryConditions.add(mc);
            else marketConditions.add(mc);
        }

        if (!planetaryConditions.isEmpty() || !marketConditions.isEmpty()) {
            text.addPara("");
            text.addPara(planet.getName() + " has the following exploitable conditions:");
        }

        Collections.sort(marketConditions, new MarketConditionSorter());
        displayMarketConditions(marketConditions);

//        if (!marketConditions.isEmpty() && !planetaryConditions.isEmpty()) text.addPara("");

        Collections.sort(planetaryConditions, new MarketConditionSorter());
        displayMarketConditions(planetaryConditions);

        FactionAPI claimant = SPP_Misc.getClaimingFaction(planet);

        if (claimant != null) {
            text.addPara("This star system is claimed by " + claimant.getDisplayNameWithArticle() + ", and a port established here would likely be eradicated in short order.");
            text.highlightFirstInLastPara(claimant.getDisplayNameWithArticleWithoutArticle(), claimant.getBaseUIColor());
        }
    }

    private void setOtherRuinsExplored() {
        PlanetAPI other = SPP_Misc.getMoonOrParent(planet);
        if (other != null) other.getMarket().getMemoryWithoutUpdate().set("$ruinsExplored", true);
    }

    private List<String> getStandardBlocks(List<MarketConditionAPI> conditions) {
        final List<String> blocks = new ArrayList<>();
        for (MarketConditionAPI mc : conditions) {
            if (mc.getPlugin() instanceof SPP_PlanetBlockCondition) blocks.add(mc.getIdForPluginModifications());
            if (mc.getPlugin() instanceof SPP_OrbitalBlockCondition) blocks.add(mc.getIdForPluginModifications());
            if (mc.getId().equals(SPP_Conditions.WORLD_ORDER)) blocks.add(mc.getIdForPluginModifications());
        }

        return blocks;
    }

    private static class MarketConditionSorter implements Comparator<MarketConditionAPI> {
        @Override
        public int compare(MarketConditionAPI o1, MarketConditionAPI o2) {
                float order = o2.getSpec().getOrder() - o1.getSpec().getOrder();
                if (order > 0) order++;
                return (int) order;
        }
    }

    private void displayMarketConditions(List<MarketConditionAPI> conditions) {
        if (conditions == null) conditions = new ArrayList<>();


        TooltipMakerAPI conditionsPanel = text.beginTooltip();
		float pad = 3f;

        for (MarketConditionAPI mc : conditions) {
            String desc = mc.getSpec().getDesc();
            Map<String, String> tokens = mc.getPlugin().getTokenReplacements();
            String specialReplace = "";
            if (tokens != null) {
                for (String token : tokens.keySet()) {
                    String value = tokens.get(token);

                    if (desc.contains("$magnetDefense")) specialReplace = value;

                    desc = desc.replaceAll("(?s)\\" + token, value);
                }
            }

            String hazardText = "";
            ConditionGenDataSpec spec = mc.getGenSpec();
            if (spec == null) continue;

            float hazard = spec.getHazard();
//            Color h = Misc.getHighlightColor();
            if (hazard < -.01) {
                hazardText = "" + (int) (hazard * 100) + "%";
            } else if (hazard > .01) {
                hazardText = "+" + (int) (hazard * 100) + "%";
            }

            Color highlight = Misc.getHighlightColor();
            TooltipMakerAPI image = conditionsPanel.beginImageWithText(mc.getSpec().getIcon(), 40);
            image.addTitle(mc.getSpec().getName());
            image.addPara(desc, pad, highlight, specialReplace);

            String mcModId = mc.getIdForPluginModifications();
            if (getStandardBlocks(conditions).contains(mcModId)) {
                highlight = Misc.getNegativeHighlightColor();
            }

            if (!hazardText.isEmpty()) {
                // Need double % for some reason
                image.addPara(hazardText + "% hazard rating", pad,
                            highlight, hazardText);
            }

            conditionsPanel.addImageWithText(pad);
        }

        text.addTooltip();
    }

}
