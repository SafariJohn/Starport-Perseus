package campaign.rulecmd;

import campaign.SPP_ImmigrationScript;
import campaign.econ.SPP_NativePopCondition;
import campaign.econ.SPP_OrbitalBlockCondition;
import campaign.econ.SPP_PlanetBlockCondition;
import campaign.econ.SPP_PlanetBlockCondition.SPP_StationHazard;
import campaign.ids.SPP_Conditions;
import campaign.ids.SPP_Industries;
import campaign.ids.SPP_Tags;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.OptionPanelAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.ResourceCostPanelAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.impl.campaign.procgen.ConditionGenDataSpec;
import com.fs.starfarer.api.impl.campaign.rulecmd.AddRemoveCommodity;
import com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin;
import static com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin.getEntityMemory;
import com.fs.starfarer.api.impl.campaign.submarkets.StoragePlugin;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import util.SPP_Misc;
import util.SPP_PortFunctions;

/**
 * Author: SafariJohn
 */
public class SPP_OrbitalStationCMD extends BaseCommandPlugin {
    public static final String ORBITAL_PORT_OPTION = "orbitalPort";

    public static final String IS_LOCATION = "isLoc";
    public static final String CAN_BUILD = "canBuild";
    public static final String CAN_AFFORD = "canAfford";
    public static final String INFO = "info";
    public static final String BUILD = "build";

	private static final float COST_HEIGHT = 75;

	protected CampaignFleetAPI playerFleet;
	protected SectorEntityToken entity;
	protected TextPanelAPI text;
	protected OptionPanelAPI options;
	protected CargoAPI playerCargo;
	protected MemoryAPI memory;
	protected InteractionDialogAPI dialog;
	protected Map<String, MemoryAPI> memoryMap;

    @Override
    public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Misc.Token> params, Map<String, MemoryAPI> memoryMap) {
		this.dialog = dialog;
		this.memoryMap = memoryMap;

		String command = params.get(0).getString(memoryMap);
		if (command == null) return false;

		entity = dialog.getInteractionTarget();
        if (entity.getMarket() != null) entity = entity.getMarket().getPrimaryEntity();

		memory = getEntityMemory(memoryMap);

		text = dialog.getTextPanel();
		options = dialog.getOptionPanel();

        playerFleet = Global.getSector().getPlayerFleet();
        playerCargo = playerFleet.getCargo();

        switch (command) {
            case IS_LOCATION: return isLocation();
            case CAN_BUILD: checkCanBuild(); break;
            case CAN_AFFORD: return canAfford(SPP_PortFunctions.getStationBuildCost(entity.getMarket()));
            case INFO: displayInfo(); break;
            case BUILD: buildStation(); break;
        }

        return true;
    }

    private boolean isLocation() {
        // Abandoned stations?

        // Block option if PLANET is controlled by a faction
        // Shouldn't come up, but just in case.
        FactionAPI faction = entity.getFaction();
        if (faction != null && !faction.isNeutralFaction()) return false;

        // Now to check if something invalidates the orbit (not simply blocking it)
        boolean orbitOpen = true;

        // If there could be a lunar port, but it is blocked, check if station is possible
        PlanetAPI planet = null;
        PlanetAPI moon = null;
        // Get planet and moon
        if (entity.getMarket().hasCondition(SPP_Conditions.CLOSE_MOON)) {
            planet = (PlanetAPI) entity;
            moon = SPP_Misc.getMoon(entity);
        } else if (entity.getMarket().hasCondition(SPP_Conditions.LUNAR_ORBIT)
                        || entity.getMarket().hasCondition(SPP_Conditions.TIGHT_ORBIT)) {
            moon = (PlanetAPI) entity;
            planet = SPP_Misc.getParent(entity);
        }

        // If the orbit is blocked, we want to display the (disabled) lunar option instead
        if (planet != null && moon != null) {
            // Check if planet blocks stations
            for (MarketConditionAPI mc : planet.getMarket().getConditions()) {
                if (mc.getPlugin() instanceof SPP_OrbitalBlockCondition) orbitOpen = false;
            }

            // Check if lunar is possible and if lunar blocks stations
            boolean inhabitable = true;
            for (MarketConditionAPI mc : moon.getMarket().getConditions()) {
                if (mc.getPlugin() instanceof SPP_PlanetBlockCondition) inhabitable = false;
                if (mc.getPlugin() instanceof SPP_OrbitalBlockCondition) orbitOpen = false;
            }
            if (inhabitable) return false; // Lunar port is possible
        }


        // Check if the player already has a station here
        if (orbitOpen) {
            SectorEntityToken station = SPP_Misc.getStation(entity);
            if (station != null && station.getMarket().isPlayerOwned()) orbitOpen = false;
        }

        return orbitOpen;
    }

    private void checkCanBuild() {
        MarketAPI market = entity.getMarket();
        if (market == null) return;

        // Can't build two stations
        if (market.hasCondition(SPP_Conditions.PORT_IN_ORBIT)) {
            SectorEntityToken station = SPP_Misc.getStation(entity);
            FactionAPI faction = station.getFaction();

            options.setEnabled(ORBITAL_PORT_OPTION, false);
            // Player-owned should never display
            if (station.getMarket().isPlayerOwned()) options.setTooltip(ORBITAL_PORT_OPTION, "You already control the orbit of " + entity.getName() + ".");
            else {
                options.setTooltip(ORBITAL_PORT_OPTION, Misc.ucFirst(faction.getDisplayNameWithArticle()) + " already controls the orbit of " + entity.getName() + ".");
                options.setTooltipHighlights(ORBITAL_PORT_OPTION, faction.getDisplayNameWithArticleWithoutArticle());
                options.setTooltipHighlightColors(ORBITAL_PORT_OPTION, faction.getBaseUIColor());
            }
            return;
        }

        // Can't build station if blocking condition, such as Strong Magnetic Field
        boolean blocked = false;
        List<MarketConditionAPI> mcs = new ArrayList<>();

        // Moons block orbital ports, but not stations
        if (market.hasCondition(SPP_Conditions.MOON)) {
            blocked = true;
            mcs.add(market.getCondition(SPP_Conditions.MOON));
        }

        for (MarketConditionAPI mc : market.getConditions()) {
            if (mc.getPlugin() instanceof SPP_OrbitalBlockCondition) {
                blocked = true;
                mcs.add(mc);
            }
        }
        if (blocked) {
            options.setEnabled(ORBITAL_PORT_OPTION, false);

            String tip = "Construction is blocked by ";
            for (int i = 0; i < mcs.size(); i++) {
                if (mcs.size() == 2 && i == 1) tip += " ";
                else if (0 < i && i < mcs.size()) tip += ", ";

                if (mcs.size() > 1 && i == mcs.size() - 1) tip += "and ";

                tip += mcs.get(i).getName();
            }
            tip += ".";

            options.setTooltip(ORBITAL_PORT_OPTION, tip);
            options.setTooltipHighlights(ORBITAL_PORT_OPTION, tip);
            options.setTooltipHighlightColors(ORBITAL_PORT_OPTION, Misc.getNegativeHighlightColor());
            return;
        }

        // Skip cost if dev mode
//        Map<String, Integer> costs = SPP_PortFunctions.getStationBuildCost(entity.getMarket());
//        if (!canAfford(costs) && !Global.getSettings().isDevMode()) {
//            options.setEnabled(ORBITAL_PORT_OPTION, false);
//            String tip = "You do not have the required resources.";
//            options.setTooltip(ORBITAL_PORT_OPTION, tip);
//            options.setTooltipHighlights(ORBITAL_PORT_OPTION, tip);
//            options.setTooltipHighlightColors(ORBITAL_PORT_OPTION, Misc.getNegativeHighlightColor());
//        }
    }

    private void displayInfo() {
        Map<String, Integer> costs = SPP_PortFunctions.getStationBuildCost(entity.getMarket());
        boolean canAfford = canAfford(costs);

        // Display pre-port info, such as size 3+ accessibility, construction costs, etc.
        // Don't forget Microgravity's access boost
        String surveyAndCost = "You have full survey data for " + entity.getName();
        if (canAfford) surveyAndCost += ", as well as the required resources, allowing you to construct a station here.";
        else surveyAndCost += ", but not the resources that would allow you to construct a station here.";

        text.addPara(surveyAndCost);

        FactionAPI claimant = SPP_Misc.getClaimingFaction(entity);
        if (claimant != null) {
            text.addPara("This star system is claimed by " + claimant.getDisplayNameWithArticle()
                        + ", and a station constructed here would likely be destroyed in short order.");
            text.highlightFirstInLastPara(claimant.getDisplayNameWithArticleWithoutArticle(), claimant.getColor());
        }

        // Mention station vulnerability to attack and? reduced access to planetary resources?
        text.addPara("Unlike planetary ports, stations are always destroyed by bombardment.");

        // Prominently show station's hazard rating
        int hazard = 200;
        for (MarketConditionAPI mc : entity.getMarket().getConditions()) {
            if (mc.getPlugin() instanceof SPP_StationHazard) {
                Object test = Global.getSettings().getSpec(ConditionGenDataSpec.class, mc.getId(), true);
                if (test instanceof ConditionGenDataSpec) {
                    ConditionGenDataSpec spec = (ConditionGenDataSpec) test;
                    hazard += spec.getHazard();
                }
            }
        }

        String hazardString = "" + hazard + "%";

        text.addPara("A station in orbit of " + entity.getName() + " will have a hazard rating of " + hazardString + ". "
                    + "The upkeep cost of any structures built here will be increased by that percentage.");
        text.highlightInLastPara(hazardString);

        text.addPara("The station port will allow access to planet-side resources and the construction of useful structures.");

        // Display costs
        Color color = Global.getSector().getFaction(Factions.NEUTRAL).getBrightUIColor();
        Object[] keys = costs.keySet().toArray();
        for (int i = 0; i < costs.keySet().size() / 3f; i++) {
            ResourceCostPanelAPI req;
            if (i == 0) req = text.addCostPanel("Required (available)", COST_HEIGHT, color, color);
            else req = text.addCostPanel(null, COST_HEIGHT, color, color);
            req.setNumberOnlyMode(true);
            req.setWithBorder(false);
            req.setAlignment(Alignment.LMID);

            int remainder = (costs.keySet().size() - i * 3);
            if (remainder > 3) remainder = 3;
            for (int j = 0; j < remainder; j++) {
                String commodityId = (String) keys[j + (i * 3)];
                int required = costs.get(commodityId);
                int available = (int) playerCargo.getCommodityQuantity(commodityId);
                Color curr = color;
                if (required > playerCargo.getQuantity(CargoAPI.CargoItemType.RESOURCES, commodityId)) {
                    curr = Misc.getNegativeHighlightColor();
                }
                req.addCost(commodityId, "×" + required + " (" + available + ")", curr);
            }
            req.update();
        }
    }

    private void buildStation() {
        PlanetAPI planet = (PlanetAPI) entity;

        // Create station entity
        String stationSpriteId = (String) memory.get(SPP_StationSprite.KEY);
        memory.expire(SPP_StationSprite.KEY, 0);
        SectorEntityToken station = planet.getContainingLocation()
                    .addCustomEntity(planet.getId() + "_station_"
                    + Misc.genUID(), planet.getName() + " Station",
                    stationSpriteId, Factions.PLAYER);

        // Needs an orbit
        float orbitRadius = planet.getRadius() + 150f;
        station.setCircularOrbitPointingDown(planet, 0, orbitRadius, orbitRadius / 10f);

        // Create market
        MarketAPI market = Global.getFactory().createMarket(
                    planet.getId() + "_stationMarket_" + Misc.genUID(),
                    planet.getName() + " Station", 1);

        market.setSize(1);
        market.setFactionId(Factions.PLAYER);
        market.setPlayerOwned(true);
        market.setPlanetConditionMarketOnly(false);
        market.setSurveyLevel(MarketAPI.SurveyLevel.FULL);
        market.setAdmin(Global.getSector().getPlayerPerson());

        market.setPrimaryEntity(station);
        station.setMarket(market);

        // Copy market data from planet
        MarketAPI planetMarket = planet.getMarket();

        // Add station condition and set it surveyed.
        planetMarket.getSpecificCondition(planetMarket.addCondition(SPP_Conditions.PORT_IN_ORBIT)).setSurveyed(true);
        planet.getMemoryWithoutUpdate().set(SPP_Tags.MEMKEY_ORBITAL_STATION_ID, station.getId());

        planetMarket.reapplyConditions();

        market.getMemoryWithoutUpdate().set(SPP_Tags.MEMKEY_ORBITAL_PLANET_ID, planet.getId());


        // Add buildings, conditions, and scripts
        market.addCondition(SPP_Conditions.MICROGRAVITY);
        market.addCondition(SPP_Conditions.ORBITAL_STATION);

        for (MarketConditionAPI mc : planetMarket.getConditions()) {
            if (mc.getPlugin() instanceof SPP_StationHazard) {
                market.addCondition(mc.getId());
                market.getCondition(mc.getId()).setSurveyed(true);
            }
        }

        String token = market.addCondition(SPP_PortFunctions.getPopulationConditionId(planetMarket));
        market.getSpecificCondition(token).setSurveyed(true);

        for (MarketConditionAPI cond : planetMarket.getConditions()) {
            if (cond.getPlugin() instanceof SPP_NativePopCondition) {

                if (cond.getId().equals(SPP_Conditions.DECIVILIZED)) {
                    market.addCondition(Conditions.DECIVILIZED_SUBPOP);
                    SPP_PortFunctions.getOrbitalConditions(market)
                                .add(Conditions.DECIVILIZED_SUBPOP);
                    break;
                }

                token = market.addCondition(cond.getId());
                market.getSpecificCondition(token).setSurveyed(true);
                SPP_PortFunctions.getOrbitalConditions(market).add(cond.getId());
                break;
            }
        }

        MemoryAPI marketMem = market.getMemoryWithoutUpdate();

        SPP_ImmigrationScript script = new SPP_ImmigrationScript(market);
        market.getContainingLocation().addScript(script);
        marketMem.set(SPP_ImmigrationScript.MEM_KEY, script);
        marketMem.set(SPP_Tags.MEMKEY_POP_GROWTH, true);

        market.addIndustry(SPP_Industries.SPACEPORT);
        market.addIndustry(SPP_Industries.LOCAL_ECONOMY);

        market.addSubmarket(Submarkets.LOCAL_RESOURCES);
        market.getSubmarket(Submarkets.LOCAL_RESOURCES).getCargo();
//        market.getSubmarket(Submarkets.LOCAL_RESOURCES).setFaction(Global.getSector().getPlayerFaction());
        market.addSubmarket(Submarkets.SUBMARKET_STORAGE);
        StoragePlugin storage = (StoragePlugin) market.getSubmarket(Submarkets.SUBMARKET_STORAGE).getPlugin();
        if (storage != null) storage.setPlayerPaidToUnlock(true);

        Global.getSector().getEconomy().addMarket(market, true);
        market.getPrimaryEntity().setFaction(Factions.PLAYER);

        // Deduct resource cost
        // dev mode skips costs
        if (!Global.getSettings().isDevMode()) {
            Map<String, Integer> costs = SPP_PortFunctions.getPlanetBuildCost((PlanetAPI) entity);

            for (String commodityId : costs.keySet()) {
                int consumed = costs.get(commodityId);
                playerCargo.removeCommodity(commodityId, consumed);
                AddRemoveCommodity.addCommodityLossText(commodityId, consumed, text);
            }
        }

        SPP_PortFunctions.establishPlayerFaction(false);
        SPP_PortFunctions.playColonyEstablishedSound();
    }
    //</editor-fold>

    private boolean canAfford(Map<String, Integer> costs) {
        if (Global.getSettings().isDevMode()) return true;

        boolean hasRequired = true;
		for (String commodityId : costs.keySet()) {
			int required = costs.get(commodityId);

			if (required > playerCargo.getQuantity(CargoAPI.CargoItemType.RESOURCES, commodityId)) {
                hasRequired = false;
			}
		}

        return hasRequired;
    }

}
