package campaign.rulecmd;

import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin;
import com.fs.starfarer.api.impl.campaign.rulecmd.missions.Commission;
import static com.fs.starfarer.api.impl.campaign.rulecmd.missions.Commission.COMMISSION_REQ;

/**
 * Author: SafariJohn
 */
public class SPP_Commission extends Commission {
    @Override
	protected void printRequirements() {
		CoreReputationPlugin.addRequiredStanding(faction, COMMISSION_REQ, null, dialog.getTextPanel(), null, null, 0f, true);
		CoreReputationPlugin.addCurrentStanding(faction, null, dialog.getTextPanel(), null, null, 0f);
	}

}
