package campaign.rulecmd;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.OptionPanelAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin;
import static com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin.getEntityMemory;
import com.fs.starfarer.api.util.Misc;
import java.util.List;
import java.util.Map;

/**
 * Author: SafariJohn
 */
public class SPP_FreeStationCMD extends BaseCommandPlugin {
    public static final String ORBITAL_PORT_OPTION = "orbitalPort";

    public static final String IS_LOCATION = "isLoc";
    public static final String CAN_BUILD = "canBuild";
    public static final String CAN_AFFORD = "canAfford";
    public static final String INFO = "info";
    public static final String BUILD = "build";

	private static final float COST_HEIGHT = 75;

	protected CampaignFleetAPI playerFleet;
	protected SectorEntityToken entity;
	protected TextPanelAPI text;
	protected OptionPanelAPI options;
	protected CargoAPI playerCargo;
	protected MemoryAPI memory;
	protected InteractionDialogAPI dialog;
	protected Map<String, MemoryAPI> memoryMap;

    @Override
    public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Misc.Token> params, Map<String, MemoryAPI> memoryMap) {
		this.dialog = dialog;
		this.memoryMap = memoryMap;

		String command = params.get(0).getString(memoryMap);
		if (command == null) return false;

		entity = dialog.getInteractionTarget();

		memory = getEntityMemory(memoryMap);

		text = dialog.getTextPanel();
		options = dialog.getOptionPanel();

        playerFleet = Global.getSector().getPlayerFleet();
        playerCargo = playerFleet.getCargo();

        switch (command) {
            case IS_LOCATION: return false;
//            case CAN_BUILD: checkCanBuild(); break;
//            case CAN_AFFORD: return canAfford(SPP_PortFunctions.getStationBuildCost(entity.getMarket()));
//            case INFO: displayInfo(); break;
//            case BUILD: buildStation(); break;
        }

        return true;
    }

}
