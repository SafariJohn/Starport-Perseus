package campaign.rulecmd;

import campaign.SPP_ImmigrationScript;
import campaign.econ.SPP_OrbitalBlockCondition;
import campaign.econ.SPP_PlanetBlockCondition;
import campaign.ids.SPP_Conditions;
import campaign.ids.SPP_Industries;
import campaign.ids.SPP_Tags;
import static campaign.rulecmd.SPP_PlanetPortCMD.CAN_AFFORD;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.OptionPanelAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.ResourceCostPanelAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.impl.campaign.rulecmd.AddRemoveCommodity;
import com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin;
import static com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin.getEntityMemory;
import com.fs.starfarer.api.impl.campaign.submarkets.StoragePlugin;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import util.SPP_Misc;
import util.SPP_PortFunctions;

/**
 * Author: SafariJohn
 */
public class SPP_MoonBaseCMD extends BaseCommandPlugin {
    public static final String ORBITAL_PORT_OPTION = "orbitalPort";

    public static final String IS_LOCATION = "isLoc";
    public static final String CAN_BUILD = "canBuild";
    public static final String CAN_AFFORD = "canAfford";
    public static final String INFO = "info";
    public static final String BUILD = "build";

	private static final float COST_HEIGHT = 75;

	protected CampaignFleetAPI playerFleet;
	protected PlanetAPI planet;
	protected PlanetAPI moon;
	protected TextPanelAPI text;
	protected OptionPanelAPI options;
	protected CargoAPI playerCargo;
	protected MemoryAPI memory;
	protected InteractionDialogAPI dialog;
	protected Map<String, MemoryAPI> memoryMap;

    @Override
    public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Misc.Token> params, Map<String, MemoryAPI> memoryMap) {
		this.dialog = dialog;
		this.memoryMap = memoryMap;

		String command = params.get(0).getString(memoryMap);
		if (command == null) return false;

        // Need the planet and the moon, if they exist
        SectorEntityToken entity = dialog.getInteractionTarget();
        if (entity instanceof PlanetAPI) {
            if (entity.getMarket().hasCondition(SPP_Conditions.CLOSE_MOON)) {
                planet = (PlanetAPI) entity;
                moon = SPP_Misc.getMoon(planet);
            } else if (entity.getMarket().hasCondition(SPP_Conditions.LUNAR_ORBIT)
                        || entity.getMarket().hasCondition(SPP_Conditions.TIGHT_ORBIT)) {
                moon = (PlanetAPI) entity;
                planet = SPP_Misc.getParent(entity);
            }
        }

		memory = getEntityMemory(memoryMap);

		text = dialog.getTextPanel();
		options = dialog.getOptionPanel();

        playerFleet = Global.getSector().getPlayerFleet();
        playerCargo = playerFleet.getCargo();

        switch (command) {
            case IS_LOCATION: return isLocation();
            case CAN_AFFORD: return canAfford(SPP_PortFunctions.getPlanetBuildCost(moon));
            case CAN_BUILD: checkCanBuild(); break;
            case INFO: displayInfo(); break;
            case BUILD: buildLunarPort(); break;
        }

        return true;
    }

    private boolean isLocation() {
        if (planet == null || moon == null) return false;
        if (moon.getMarket() == null) return false;

        // Can't try to build at faction controlled site
//        FactionAPI faction = moon.getFaction();
//        if (faction != null && !faction.isNeutralFaction()) return false;

        boolean lunarLoc = true;
        boolean orbitOpen = true;
        // Check if planet blocks stations
        for (MarketConditionAPI mc : planet.getMarket().getConditions()) {
            if (mc.getPlugin() instanceof SPP_OrbitalBlockCondition) orbitOpen = false;
        }

        // Check if lunar is possible and if moon blocks stations
        for (MarketConditionAPI mc : moon.getMarket().getConditions()) {
            if (mc.getPlugin() instanceof SPP_PlanetBlockCondition) lunarLoc = false;
            if (mc.getPlugin() instanceof SPP_OrbitalBlockCondition) orbitOpen = false;
        }

        // lunar = true // Show lunar option
        // lunar = false, orbit = false // Show lunar disabled
        // lunar = false, orbit = true // Show orbital station option

        return lunarLoc || (!lunarLoc && !orbitOpen);
    }

    private void checkCanBuild() {
        MarketAPI market = moon.getMarket();
        if (market == null) return;

        // Can't double up, of course
        FactionAPI faction = moon.getFaction();

        if (moon.getMarket().isPlayerOwned()) {
            options.setEnabled(ORBITAL_PORT_OPTION, false);
            options.setTooltip(ORBITAL_PORT_OPTION, "You already have a port on " + moon.getName() + ".");
        }
        else if (faction != null && !faction.isNeutralFaction()) {
            options.setEnabled(ORBITAL_PORT_OPTION, false);
            options.setTooltip(ORBITAL_PORT_OPTION, Misc.ucFirst(faction.getDisplayNameWithArticle()) + " already " + faction.getDisplayNameHasOrHave() +  " a port on " + moon.getName() + ".");
            options.setTooltipHighlights(ORBITAL_PORT_OPTION, faction.getDisplayNameWithArticleWithoutArticle());
            options.setTooltipHighlightColors(ORBITAL_PORT_OPTION, faction.getBaseUIColor());
        }

        // Can't build lunar port if uninhabitable condition
        boolean blocked = false;
        List<MarketConditionAPI> mcs = new ArrayList<>();
        for (MarketConditionAPI mc : market.getConditions()) {
            if (mc.getPlugin() instanceof SPP_PlanetBlockCondition) {
                blocked = true;
                mcs.add(mc);
            }
        }
        if (blocked) {
            options.setEnabled(ORBITAL_PORT_OPTION, false);

            String tip = "Construction is blocked by ";
            for (int i = 0; i < mcs.size(); i++) {
                if (mcs.size() == 2 && i == 1) tip += " ";
                else if (0 < i && i < mcs.size() - 1) tip += ", ";

                if (mcs.size() > 1 && i == mcs.size() - 1) tip += "and ";

                tip += mcs.get(i).getName();
            }
            tip += ".";

            options.setTooltip(ORBITAL_PORT_OPTION, tip);
            options.setTooltipHighlights(ORBITAL_PORT_OPTION, tip);
            options.setTooltipHighlightColors(ORBITAL_PORT_OPTION, Misc.getNegativeHighlightColor());
            return;
        }

        // Skip cost if dev mode
//        Map<String, Integer> costs = SPP_PortFunctions.getPlanetBuildCost((PlanetAPI) moon);
//        if (!canAfford(costs) && !Global.getSettings().isDevMode()) {
//            options.setEnabled(ORBITAL_PORT_OPTION, false);
//            String tip = "You do not have the required resources.";
//            options.setTooltip(ORBITAL_PORT_OPTION, tip);
//            options.setTooltipHighlights(ORBITAL_PORT_OPTION, tip);
//            options.setTooltipHighlightColors(ORBITAL_PORT_OPTION, Misc.getNegativeHighlightColor());
//        }
    }

    private void displayInfo() {
        Map<String, Integer> costs = SPP_PortFunctions.getPlanetBuildCost(moon);
        boolean canAfford = canAfford(costs);

        // Display pre-port info, such as size 3+ accessibility, construction costs, etc.
        // Don't forget Microgravity's access boost
        String surveyAndCost = "You have full survey data for " + planet.getName() + " and " + moon.getName();
        if (canAfford) surveyAndCost += ", as well as the required resources, allowing you to construct a lunar port here.";
        else surveyAndCost += ", but not the resources that would allow you to construct a lunar port here.";

        text.addPara(surveyAndCost);

        FactionAPI claimant = SPP_Misc.getClaimingFaction(moon);
        if (claimant != null) {
            text.addPara("This star system is claimed by " + claimant.getDisplayNameWithArticle()
                        + ", and a lunar port constructed here would likely be destroyed in short order.");
            text.highlightFirstInLastPara(claimant.getDisplayNameWithArticleWithoutArticle(), claimant.getColor());
        }

        // Prominently show port's hazard rating
        String hazardString = "" + (int) (moon.getMarket().getHazardValue() * 100) + "%";

        text.addPara(moon.getName() + " has a hazard rating of " + hazardString + ". "
                    + "The upkeep cost of any structures built here will be increased by that percentage.");
        text.highlightInLastPara(hazardString);

        text.addPara("A lunar port will allow access to planet-side resources and the construction of useful structures.");

        Color color = Global.getSector().getFaction(Factions.NEUTRAL).getBrightUIColor();
        ResourceCostPanelAPI req = text.addCostPanel("Required (available)", COST_HEIGHT, color, color);
        req.setNumberOnlyMode(true);
        req.setWithBorder(false);
        req.setAlignment(Alignment.LMID);

        for (String commodityId : costs.keySet()) {
            int required = costs.get(commodityId);
            int available = (int) playerCargo.getCommodityQuantity(commodityId);
            Color curr = color;
            if (required > playerCargo.getQuantity(CargoAPI.CargoItemType.RESOURCES, commodityId)) {
                curr = Misc.getNegativeHighlightColor();
            }
            req.addCost(commodityId, "×" + required + " (" + available + ")", curr);
        }
        req.update();
    }

    private void buildLunarPort() {
        // Create market
        MarketAPI market = moon.getMarket();

        // Add buildings, conditions, and scripts
        market.setSize(1);
        market.setFactionId(Factions.PLAYER);
        market.setPlayerOwned(true);
        market.setPlanetConditionMarketOnly(false);
        market.setSurveyLevel(MarketAPI.SurveyLevel.FULL);
        market.setAdmin(Global.getSector().getPlayerPerson());

//        market.setPrimaryEntity(entity);

        SPP_ImmigrationScript script = new SPP_ImmigrationScript(market);
        market.getContainingLocation().addScript(script);
        market.getMemoryWithoutUpdate().set(SPP_ImmigrationScript.MEM_KEY, script);
        market.getMemoryWithoutUpdate().set(SPP_Tags.MEMKEY_POP_GROWTH, true);

        if (market.hasCondition(Conditions.DECIVILIZED)) {
            market.removeCondition(Conditions.DECIVILIZED);
            market.addCondition(Conditions.DECIVILIZED_SUBPOP);
        } else if (planet.getMarket().hasCondition(Conditions.DECIVILIZED)) {
            market.addCondition(Conditions.DECIVILIZED_SUBPOP);
        }

        market.addIndustry(SPP_Industries.SPACEPORT);
        market.addIndustry(SPP_Industries.LOCAL_ECONOMY);

        market.addSubmarket(Submarkets.LOCAL_RESOURCES);
        market.getSubmarket(Submarkets.LOCAL_RESOURCES).getCargo();
//        market.getSubmarket(Submarkets.LOCAL_RESOURCES).setFaction(Global.getSector().getPlayerFaction());
        market.addSubmarket(Submarkets.SUBMARKET_STORAGE);
        StoragePlugin storage = (StoragePlugin) market.getSubmarket(Submarkets.SUBMARKET_STORAGE).getPlugin();
        if (storage != null) storage.setPlayerPaidToUnlock(true);

        Global.getSector().getEconomy().addMarket(market, true);
        market.getPrimaryEntity().setFaction(Factions.PLAYER);

        // Deduct resource cost
        // dev mode skips costs
        if (!Global.getSettings().isDevMode()) {
            Map<String, Integer> costs = SPP_PortFunctions.getPlanetBuildCost(moon);

            for (String commodityId : costs.keySet()) {
                int consumed = costs.get(commodityId);
                playerCargo.removeCommodity(commodityId, consumed);
                AddRemoveCommodity.addCommodityLossText(commodityId, consumed, text);
            }
        }

        SPP_PortFunctions.establishPlayerFaction(false);
        SPP_PortFunctions.playColonyEstablishedSound();
    }
    //</editor-fold>

    private boolean canAfford(Map<String, Integer> costs) {
        if (Global.getSettings().isDevMode()) return true;

        boolean hasRequired = true;
		for (String commodityId : costs.keySet()) {
			int required = costs.get(commodityId);

			if (required > playerCargo.getQuantity(CargoAPI.CargoItemType.RESOURCES, commodityId)) {
                hasRequired = false;
			}
		}

        return hasRequired;
    }

}
