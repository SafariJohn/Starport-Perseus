/**
 *
 */
package campaign.shared;

import campaign.SPP_CoreScript;
import campaign.SPP_MonthlyReport;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.impl.campaign.shared.SharedData;

public class SPP_SharedData extends SharedData {

	protected SPP_MonthlyReport previousReport = new SPP_MonthlyReport();
	protected SPP_MonthlyReport currentReport = new SPP_MonthlyReport();

	public SPP_SharedData() {
	}

	public SPP_MonthlyReport getPreviousReport() {
		if (previousReport == null) previousReport = new SPP_MonthlyReport();
		return previousReport;
	}
	public SPP_MonthlyReport getCurrentReport() {
		if (currentReport == null) currentReport = new SPP_MonthlyReport();
		return currentReport;
	}
	public void setCurrentReport(SPP_MonthlyReport currentReport) {
		this.currentReport = currentReport;
	}
	public void setPreviousReport(SPP_MonthlyReport previousReport) {
		this.previousReport = previousReport;
	}

	public void rollOverReport() {
		previousReport = currentReport;
		currentReport = new SPP_MonthlyReport();
	}

	public static SharedData getData() {
		Object data = Global.getSector().getPersistentData().get(SPP_CoreScript.SHARED_DATA_KEY);
		if (data == null) {
			data = new SPP_SharedData();
			Global.getSector().getPersistentData().put(SPP_CoreScript.SHARED_DATA_KEY, data);
		}
		return (SharedData) data;
	}
}




