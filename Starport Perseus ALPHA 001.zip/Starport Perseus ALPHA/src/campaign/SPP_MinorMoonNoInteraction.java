package campaign;

import campaign.ids.SPP_Tags;
import com.fs.starfarer.api.PluginPick;
import com.fs.starfarer.api.campaign.BaseCampaignPlugin;
import com.fs.starfarer.api.campaign.InteractionDialogPlugin;
import com.fs.starfarer.api.campaign.SectorEntityToken;

/**
 * Copied LazyWizard's example code
 */
public class SPP_MinorMoonNoInteraction extends BaseCampaignPlugin {

    @Override public String getId() { return "disable_interaction"; }

    @Override public boolean isTransient() { return false; }

    @Override
    public PluginPick<InteractionDialogPlugin> pickInteractionDialogPlugin(SectorEntityToken sectorEntityToken)
    {
        if (sectorEntityToken.hasTag(SPP_Tags.NO_INTERACTION)) {
            return new PluginPick<>(null, PickPriority.HIGHEST);
        }

        return null;
    }
}
