package campaign;

import campaign.ids.SPP_Tags;
import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import java.util.ArrayList;
import java.util.List;

/**
 * Author: SafariJohn
 */
public class SPP_MinorMoonHidingScript implements EveryFrameScript {
    private IntervalUtil interval =  new IntervalUtil(100, 500);

    @Override
    public void advance(float amount) {
//        interval.advance(amount);
//
//        if (!interval.intervalElapsed()) return;

        List<StarSystemAPI> systems = Global.getSector().getStarSystems();
        List<PlanetAPI> planets = new ArrayList<>();
        for (StarSystemAPI system : systems) {
            planets.addAll(system.getPlanets());
        }

        for (PlanetAPI planet : planets) {
            if (planet.hasTag(SPP_Tags.NO_INTERACTION)) {
                planet.getMarket().setSurveyLevel(MarketAPI.SurveyLevel.NONE);
            }
        }
    }

    public boolean isDone() { return false; }
    public boolean runWhilePaused() { return true; }

}
