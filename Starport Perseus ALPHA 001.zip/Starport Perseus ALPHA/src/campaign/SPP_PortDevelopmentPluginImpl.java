package campaign;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.comm.CommMessageAPI.MessageClickAction;
import com.fs.starfarer.api.campaign.econ.ImmigrationPlugin;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketImmigrationModifier;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.impl.campaign.intel.MessageIntel;
import com.fs.starfarer.api.impl.campaign.population.PopulationComposition;
import com.fs.starfarer.api.util.Misc;

public class SPP_PortDevelopmentPluginImpl implements ImmigrationPlugin {

	//public static float INCENTIVE_USE_FRACTION = 0.15f;
	//public static float INCENTIVE_MIN_PERCENT = 1f;
	public static float INCENTIVE_MIN_PERCENT = 0.2f;

	public static final float FACTION_HOSTILITY_IMPACT = 2f;

	protected MarketAPI market;

	public static float IMMIGRATION_PER_HAZARD = Global.getSettings().getFloat("immigrationPerHazard");

	public SPP_PortDevelopmentPluginImpl(MarketAPI market) {
		this.market = market;
	}

	public void advance(float days, boolean uiUpdateOnly) {

		boolean firstTime = !market.wasIncomingSetBefore() && !market.isPlayerOwned();
		Global.getSettings().profilerBegin("Computing incoming");
		market.setIncoming(computeIncoming());
		Global.getSettings().profilerEnd();

		if (uiUpdateOnly) return;

		float f = days / 30f; // incoming is per month

		int iter = 1;
		if (firstTime) {
			iter = 100;
		}

		for (int i = 0; i < iter; i++) {

            if (iter > 1) {
                f = (iter - i) * 0.1f;
            }

            
            float incentiveCreditsUsed = getIncentivePercentPerMonth() * getCreditsForOnePercentPopulationIncrease();
            incentiveCreditsUsed *= f;
            if (incentiveCreditsUsed <= 0) {
                market.setIncentiveCredits(0f);
            } else {
                market.setIncentiveCredits(Math.max(0, market.getIncentiveCredits() - incentiveCreditsUsed));
            }

            // Don't care about comp
            PopulationComposition pop = market.getPopulation();
            PopulationComposition inc = market.getIncoming();

            for (String id : inc.getComp().keySet()) {
                pop.add(id, inc.get(id) * f);
            }

            float min = getWeightForMarketSize(market.getSize());
            float max = getWeightForMarketSize(market.getSize() + 1);
            //if (market.getSize() >= 10) max = min;


            float newWeight = pop.getWeightValue() + inc.getWeightValue() * f;
            if (newWeight < min || Global.getSector().isInNewGameAdvance()) newWeight = min;
            if (newWeight > max) {
                increaseMarketSize();
                newWeight = max;
            }
            pop.setWeight(newWeight);
            pop.normalize();

            //*******************************

            // up to 5% of the non-faction population gets converted to faction, per month, more or less
            float conversionFraction = 0.05f * market.getStabilityValue() / 10f;
            conversionFraction *= f;
            if (conversionFraction > 0) {
                pop.add(market.getFactionId(), (pop.getWeightValue() - pop.get(market.getFactionId())) * conversionFraction);
            }


            // add some poor/pirate population at stability below 5
            float pirateFraction = 0.01f * Math.max(0, (5f - market.getStabilityValue()) / 5f);
            pirateFraction *= f;
            if (pirateFraction > 0) {
                pop.add(Factions.PIRATES, pop.getWeightValue() * pirateFraction);
                pop.add(Factions.POOR, pop.getWeightValue() * pirateFraction);
            }


            for (String fid : new ArrayList<String>(pop.getComp().keySet())) {
                if (Global.getSector().getFaction(fid) == null) {
                    pop.getComp().remove(fid);
                }
            }

            pop.normalize();

		}
//		market.getPopulation().setWeight(getWeightForMarketSize(market.getSize()));
//		market.getPopulation().normalize();
	}

	public void increaseMarketSize() {
		if (market.getSize() >= 10 || !market.isPlayerOwned()) {
			market.getPopulation().setWeight(getWeightForMarketSizeStatic(market.getSize()));
			market.getPopulation().normalize();
			return;
		}

		increaseMarketSize(market);

		if (market.isPlayerOwned()) {
			MessageIntel intel = new MessageIntel("Port Development - " + market.getName(), Misc.getBasePlayerColor());
			intel.addLine(BaseIntelPlugin.BULLET + "Size increased to %s",
					Misc.getTextColor(),
					new String[] {"" + (int)Math.round(market.getSize())},
					Misc.getHighlightColor());
			intel.setIcon(Global.getSector().getPlayerFaction().getCrest());
			intel.setSound(BaseIntelPlugin.getSoundMajorPosting());
			Global.getSector().getCampaignUI().addMessage(intel, MessageClickAction.COLONY_INFO, market);
		}
	}

	public static void increaseMarketSize(MarketAPI market) {
		if (market.getSize() >= 10) return;

		market.setSize(market.getSize() + 1);
		market.reapplyConditions();
		market.reapplyIndustries();
	}

	public static void reduceMarketSize(MarketAPI market) {
		if (market.getSize() <= 1) {
			return;
		}

		market.setSize(market.getSize() - 1);

		market.reapplyConditions();
		market.reapplyIndustries();

        // Don't care
		market.getPopulation().setWeight(getWeightForMarketSizeStatic(market.getSize()));
		market.getPopulation().normalize();
	}


	public static final float ZERO_STABILITY_PENALTY = -5;
	public static final float MAX_DIST_PENALTY = -5;

	public PopulationComposition computeIncoming() {
		PopulationComposition inc = new PopulationComposition();

//		float stability = market.getStabilityValue();
//
//		if (stability > 0) {
//			inc.getWeight().modifyFlat("inc_st", stability, "Stability");
//		}

//		float a = Math.round(market.getAccessibilityMod().computeEffective(0f) * 100f) / 100f;
//		int accessibilityMod = (int) (a / Misc.PER_UNIT_SHIPPING);
//		inc.getWeight().modifyFlat("inc_access", accessibilityMod, "Accessibility");


		float hazMod = Math.round((market.getHazardValue() - 1f) / IMMIGRATION_PER_HAZARD);
		if (hazMod != 0) {
			inc.getWeight().modifyFlat("inc_hazard", -hazMod, "Hazard rating");
		}

//		MarketAPI biggestInSystem = null;
//		List<MarketAPI> inReach = Global.getSector().getEconomy().getMarketsWithSameGroup(market);
//		//Global.getSettings().profilerEnd();
//		for (MarketAPI curr : inReach) {
//			if (curr == market) continue;
//
//			if (!curr.getFaction().getId().equals(market.getFaction().getId())) continue;
//
//			if (Misc.getDistanceLY(curr.getLocationInHyperspace(), market.getLocationInHyperspace()) <= 0) {
//				if (biggestInSystem == null || curr.getSize() > biggestInSystem.getSize()) {
//					biggestInSystem = curr;
//				}
//			}
//		}

//		if (biggestInSystem != null) {
//			float sDiff = biggestInSystem.getSize() - market.getSize();
//			sDiff *= 2;
//			if (sDiff > 0) {
//				inc.getWeight().modifyFlat("inc_insys", sDiff, "Larger faction port in same system");
//			} else if (sDiff < 0) {
//				//inc.getWeight().modifyFlat("inc_insys", sDiff, "Smaller non-hostile market in same system");
//			}
//		}

        // Reduce development based on size?
//        int size = market.getSize();
//        int sizeMod = 0;
//        if (size > SPP_Spaceport.SPACEPORT_SIZE) sizeMod -= size;
//        if (size > SPP_Spaceport.MEGAPORT_SIZE) sizeMod -= size;
//
//        if (sizeMod != 0) inc.getWeight().modifyFlat("inc_size", sizeMod, "Size");


        // Don't care about comp.

		// so that the "baseline" incoming composition is based on the number of industries
		// thus each industry can use a per-industry modifier without having outsize influence
		// for example Farming can bring in X more Luddic Church immigration, and the impact
		// this has will be diminished if there are more industries beyond Farming
		float numIndustries = market.getIndustries().size();
		inc.add(Factions.PIRATES, 1f * numIndustries);
		inc.add(Factions.POOR, 1f * numIndustries);

		String bulkFaction = Factions.INDEPENDENT;
		if (market.getFaction().isHostileTo(bulkFaction)) {
			bulkFaction = market.getFactionId();
		}
		inc.add(bulkFaction, 10f * numIndustries);

		applyIncentives(inc);


		for (MarketImmigrationModifier mod : market.getAllImmigrationModifiers()) {
			mod.modifyIncoming(market, inc);
		}

//		if (market.getName().equals("Mazalot")) {
//			System.out.println("wefwefwe");
//		}

		for (String fid : new ArrayList<String>(inc.getComp().keySet())) {
			if (Global.getSector().getFaction(fid) == null) {
				inc.getComp().remove(fid);
			}
		}

		inc.normalizeToPositive();

		return inc;
	}

	protected void applyIncentives(PopulationComposition inc) {
		float percent = getIncentivePercentPerMonth();
		if (percent <= 0) return;

		float pts = getPopulationPointsForFraction(0.01f * percent);

		//inc.addWeight(percent * pts);
		inc.getWeight().modifyFlat("inc_incentives", pts, "Investment");
	}

	public float getPopulationPointsForFraction(float fraction) {
		float min = getWeightForMarketSize(market.getSize());
		float max = getWeightForMarketSize(market.getSize() + 1);

		return (max - min) * fraction;
	}

	public float getFractionForPopulationPoints(float points) {
		float min = getWeightForMarketSize(market.getSize());
		float max = getWeightForMarketSize(market.getSize() + 1);

		return points / (max - min);
	}

	public float getCreditsForIncreaseFraction(float fraction) {
		float points = getPopulationPointsForFraction(fraction);
		float cost = points * getCreditsPerPopulationPoint();
		return cost;
	}

	public int getCreditsForOnePercentPopulationIncrease() {
		return (int) getCreditsForIncreaseFraction(0.01f);
	}


	public float getIncentivePercentPerMonth() {
		float incentives = market.getIncentiveCredits();
		if (incentives <= 0) return 0f;

		float per = getCreditsForOnePercentPopulationIncrease();

		float percent = incentives / per;

		float usePercent = percent * getIncentiveUseRate();

		if (usePercent <= INCENTIVE_MIN_PERCENT) {
			//return Math.min(percent, INCENTIVE_MIN_PERCENT);
			return INCENTIVE_MIN_PERCENT;
		}

		return usePercent;
	}


	private static float base = Global.getSettings().getFloat("immigrationIncentiveBaseCost");
	public float getCreditsPerPopulationPoint() {
		//float f = getIncentiveCostDistMult();
		float f = 1f;
		//f /= market.getIncomingImmigrationMod().getMult();
		return base * f;
	}


    // This is cost stuff?
	public static float getWeightForMarketSizeStatic(float size) {
		//return (float) (100f * Math.pow(2, size - 3));
		return (float) (200f * Math.pow(2, size - 3));
	}
	public float getWeightForMarketSize(float size) {
		return getWeightForMarketSizeStatic(size);
//		if (size <= 1) return 100;
//		if (size == 2) return 200;
//		if (size == 3) return 400;
//		if (size == 4) return 800;
//		if (size == 5) return 1600;
//		if (size == 6) return 3200;
//		if (size == 7) return 6400;
//		if (size == 8) return 12800;
//		if (size == 9) return 25600;
//		if (size == 10) return 51200;
//		if (size == 11) return 102400;
//		return 100000;
	}

	public float getIncentiveUseRate() {
		return getIncentiveUseRate(market.getSize());
	}

	public static float [] INCENTIVE_USE_RATE = null;
	public static float getIncentiveUseRate(int size) {
		if (INCENTIVE_USE_RATE == null) {
			try {
				INCENTIVE_USE_RATE = new float [10];
				JSONArray a = Global.getSettings().getJSONArray("immigrationIncentiveUseRatePerMonth");
				for (int i = 0; i < INCENTIVE_USE_RATE.length; i++) {
					INCENTIVE_USE_RATE[i] = (float) a.getDouble(i);
				}
			} catch (JSONException e) {
				throw new RuntimeException(e);
			}
		}
		size--;
		if (size < 0) size = 0;
		if (size > 9) size = 9;
		return INCENTIVE_USE_RATE[size];
//		if (size <= 3) return 1;
//		if (size <= 5) return 2;
//		if (size <= 7) return 3;
//		return 4;
	}
}






