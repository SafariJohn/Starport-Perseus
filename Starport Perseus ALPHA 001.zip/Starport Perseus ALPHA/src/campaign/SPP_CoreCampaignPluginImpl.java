package campaign;

import com.fs.starfarer.api.PluginPick;
import com.fs.starfarer.api.campaign.econ.ImmigrationPlugin;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.CoreCampaignPluginImpl;

public class SPP_CoreCampaignPluginImpl extends CoreCampaignPluginImpl {

	@Override
	public PluginPick<ImmigrationPlugin> pickImmigrationPlugin(MarketAPI market) {
		return new PluginPick<ImmigrationPlugin>(new SPP_PortDevelopmentPluginImpl(market), PickPriority.CORE_GENERAL);
	}
}








