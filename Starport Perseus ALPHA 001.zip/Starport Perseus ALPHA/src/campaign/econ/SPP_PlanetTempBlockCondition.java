package campaign.econ;

/**
 * Author: SafariJohn
 */
public class SPP_PlanetTempBlockCondition extends SPP_BaseHazardCondition {
    // Cannot build a planetary port on this body.
}
