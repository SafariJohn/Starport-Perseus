package campaign.econ;

import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.impl.campaign.econ.BaseHazardCondition;
import java.util.Map;
import java.util.Set;
import util.SPP_Misc;
import util.SPP_PortFunctions;

/**
 * Author: SafariJohn
 */
public class SPP_BaseHazardCondition extends BaseHazardCondition {
    public final static String MARKET = "$market";
    public final static String BOTH = "$bothMarkets";
    public final static String IS_ARE = "$isAre";

	@Override
	public Map<String, String> getTokenReplacements() {
		Map<String, String> map = super.getTokenReplacements();

        SectorEntityToken other = SPP_Misc.getOther(market.getPrimaryEntity());
        if (other != null) {
            Set orbitals = SPP_PortFunctions.getOrbitalConditions(market);
            if (orbitals.contains(condition.getId())) {
                map.remove(MARKET);
                map.put(MARKET, other.getName());

//                // The condition is on the other planet
//                map.put(BOTH, other.getName());
//                map.put(IS_ARE, "is");
            }
//            else if (market != other.getMarket()) {
//                Set otherOrbitals = SPP_PortFunctions.getOrbitalConditions(other.getMarket());
//                // The condition is only on this planet
//                if (otherOrbitals.contains(condition.getId())) {
//                    map.put(BOTH, market.getName());
//                    map.put(IS_ARE, "is");
//                }
//            } else {
//                // The condition is on both planets
//                map.put(BOTH, market.getName() + " and " + other.getName());
//                map.put(IS_ARE, "are");
//            }

            map.put(BOTH, market.getName() + " and " + other.getName());
            map.put(IS_ARE, "are");
        } else {
            map.put(BOTH, market.getName());
            map.put(IS_ARE, "is");
        }

		return map;
    }
}
