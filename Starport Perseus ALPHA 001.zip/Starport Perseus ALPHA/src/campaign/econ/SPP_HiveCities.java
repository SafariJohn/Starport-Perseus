package campaign.econ;

import campaign.ids.SPP_Conditions;
import campaign.ids.SPP_MemKeys;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import java.awt.Color;
import java.util.Map;
import util.SPP_Misc;

/**
 * Author: SafariJohn
 */
public class SPP_HiveCities extends SPP_BaseHazardCondition {

    @Override
    public void apply(String id) {
        super.apply(id);

        SPP_Misc.setFlagWithReason(market.getMemoryWithoutUpdate(),
                    SPP_MemKeys.POP_PROTECTED, getModId(), true, -1f);



        if (market.hasCondition(SPP_Conditions.HIVE_CITIES)) {
            market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD)
						.modifyFlat(getModId(), 1000, "Hive cities");
        }
    }

    @Override
    public void unapply(String id) {
        super.unapply(id);

        SPP_Misc.setFlagWithReason(market.getMemoryWithoutUpdate(),
                    SPP_MemKeys.POP_PROTECTED, getModId(), false, -1f);

		market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodifyMult(getModId());
    }

    @Override
    public Map<String, String> getTokenReplacements() {
        Map<String, String> tokens = super.getTokenReplacements();

        tokens.put("$hiveDefense", "+1000");

        return tokens;
    }

    @Override
    public Color[] getHighlightColors() {
        Color[] c = { SPP_Misc.getHighlightColor() };
        return c;
    }

    @Override
    public String[] getHighlights() {
        String[] s = { "+1000" };
        return s;
    }
}
