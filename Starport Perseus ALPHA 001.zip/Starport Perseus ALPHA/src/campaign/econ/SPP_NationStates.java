package campaign.econ;

/**
 * Author: SafariJohn
 */
public class SPP_NationStates extends SPP_NativePopCondition {
    @Override
    public boolean isAllowedForPopulationSize(int size) {
        return size > 3;
    }
}
