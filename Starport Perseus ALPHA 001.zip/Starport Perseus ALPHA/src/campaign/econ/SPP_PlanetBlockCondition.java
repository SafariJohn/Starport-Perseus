package campaign.econ;

/**
 * Author: SafariJohn
 */
public class SPP_PlanetBlockCondition extends SPP_BaseHazardCondition {
    // Cannot build a planetary port on this body.

    public static interface SPP_StationHazard {}
}
