package campaign.econ;

import campaign.ids.SPP_Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.impl.campaign.ids.Strings;
import java.awt.Color;
import java.util.Map;
import util.SPP_Misc;

/**
 * Author: SafariJohn
 */
public class SPP_MagneticFieldCondition extends SPP_OrbitalBlockCondition {

    @Override
    public void apply(String id) {
        super.apply(id);


        if (market.hasCondition(SPP_Conditions.MAGNETIC_FIELD)) {
            market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD)
						.modifyMult(getModId(), 1.2f, "Magnetic field");
        }
    }

    @Override
    public void unapply(String id) {
        super.unapply(id);

		market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodifyMult(getModId());
    }

    @Override
    public Map<String, String> getTokenReplacements() {
        Map<String, String> tokens = super.getTokenReplacements();

        tokens.put("$magnetDefense", Strings.X + "1.2");

        return tokens;
    }

    @Override
    public Color[] getHighlightColors() {
        Color[] c = { SPP_Misc.getHighlightColor() };
        return c;
    }

    @Override
    public String[] getHighlights() {
        String[] s = { Strings.X + "1.2" };
        return s;
    }

}
