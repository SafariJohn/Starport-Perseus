package campaign.econ;

/**
 * Author: SafariJohn
 */
public class SPP_OrbitalBlockCondition extends SPP_BaseHazardCondition {
    // Cannot build a station port at this planet.
}
