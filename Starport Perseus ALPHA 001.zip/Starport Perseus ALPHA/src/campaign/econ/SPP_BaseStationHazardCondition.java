package campaign.econ;

import campaign.econ.SPP_PlanetBlockCondition.SPP_StationHazard;

/**
 * Author: SafariJohn
 */
public class SPP_BaseStationHazardCondition extends SPP_BaseHazardCondition implements SPP_StationHazard {

}
