package campaign.econ;

/**
 * Author: SafariJohn
 */
public class SPP_NativePopCondition extends SPP_BaseHazardCondition {
    public boolean isAllowedForPopulationSize(int size) {
        return size > 0;
    }
}
