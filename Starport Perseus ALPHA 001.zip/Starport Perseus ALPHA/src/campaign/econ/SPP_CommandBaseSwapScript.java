package campaign.econ;

import campaign.ids.SPP_Industries;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.econ.EconomyAPI;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;

/**
 * Author: SafariJohn
 */
public class SPP_CommandBaseSwapScript implements EconomyAPI.EconomyUpdateListener {

    @Override
    public void economyUpdated() {
        for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
            // Check if a market has the non-upgrade versions of Raider Fortress
            // or Corporate HQ.
            Industry raiderFort = market.getIndustry(SPP_Industries.RAIDER_FORTRESS_TEMP);
            Industry corpHQ = market.getIndustry(SPP_Industries.CORPORATE_HQ_TEMP);

            // If so and it is finished building, replace it with the upgrade version
            if (raiderFort != null && !raiderFort.isBuilding()) {
                market.removeIndustry(SPP_Industries.RAIDER_FORTRESS_TEMP,
                            null, false);
                market.addIndustry(SPP_Industries.RAIDER_FORTRESS);
            }

            if (corpHQ != null && !corpHQ.isBuilding()) {
                market.removeIndustry(SPP_Industries.CORPORATE_HQ_TEMP,
                            null, false);
                market.addIndustry(SPP_Industries.CORPORATE_HQ);
            }
        }
    }


    public boolean isEconomyListenerExpired() { return false; }
    public void commodityUpdated(String commodityId) {}
}
