package campaign.econ;



public class SPP_Decivilized extends SPP_NativePopCondition {
    @Override
    public boolean isAllowedForPopulationSize(int size) {
        return super.isAllowedForPopulationSize(size) && size < 5;
    }

}
