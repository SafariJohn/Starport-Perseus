package campaign.econ;

import campaign.econ.SPP_PlanetBlockCondition.SPP_StationHazard;
import com.fs.starfarer.api.impl.campaign.econ.BaseHazardCondition;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

/**
 * Author: SafariJohn
 */
public class SPP_Microgravity extends BaseHazardCondition implements SPP_StationHazard {
	public static final float ACCESS_BONUS = 20f;

	public void apply(String id) {
		super.apply(id);
		market.getAccessibilityMod().modifyFlat(id, ACCESS_BONUS/100f, "Microgravity");
	}

	public void unapply(String id) {
		super.unapply(id);
		market.getAccessibilityMod().unmodifyFlat(id);
	}

	protected void createTooltipAfterDescription(TooltipMakerAPI tooltip, boolean expanded) {
		super.createTooltipAfterDescription(tooltip, expanded);

		tooltip.addPara("%s accessibility.",
						10f, Misc.getHighlightColor(),
						"+" + (int)ACCESS_BONUS + "%");
    }
}
