package campaign.econ;

import java.util.*;

import campaign.econ.SPP_PlanetBlockCondition.SPP_StationHazard;
import campaign.econ.industries.SPP_BaseIndustry;
import campaign.ids.SPP_Industries;
import util.SPP_PortFunctions;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketImmigrationModifier;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.population.PopulationComposition;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;


public class SPP_ResourceDepositsCondition extends SPP_BaseHazardCondition implements MarketImmigrationModifier, SPP_StationHazard {
    public static final int RESOURCE_STRUCTURE_BASE_SIZE = 3;

	public static final Map<String, String> COMMODITY = new HashMap<String, String>();
	public static final Map<String, Integer> MODIFIER = new HashMap<String, Integer>();
	public static final Map<String, List<String>> INDUSTRY = new HashMap<String, List<String>>();
	public static final Map<String, Integer> BASE_MODIFIER = new HashMap<String, Integer>();
	public static final Map<String, Integer> BASE_SIZE = new HashMap<String, Integer>();
	public static final Set<String> BASE_ZERO  = new HashSet<String>();
	static {
		COMMODITY.put(Conditions.ORE_SPARSE, Commodities.ORE);
		COMMODITY.put(Conditions.ORE_MODERATE, Commodities.ORE);
		COMMODITY.put(Conditions.ORE_ABUNDANT, Commodities.ORE);
		COMMODITY.put(Conditions.ORE_RICH, Commodities.ORE);
		COMMODITY.put(Conditions.ORE_ULTRARICH, Commodities.ORE);

		COMMODITY.put(Conditions.RARE_ORE_SPARSE, Commodities.RARE_ORE);
		COMMODITY.put(Conditions.RARE_ORE_MODERATE, Commodities.RARE_ORE);
		COMMODITY.put(Conditions.RARE_ORE_ABUNDANT, Commodities.RARE_ORE);
		COMMODITY.put(Conditions.RARE_ORE_RICH, Commodities.RARE_ORE);
		COMMODITY.put(Conditions.RARE_ORE_ULTRARICH, Commodities.RARE_ORE);

		COMMODITY.put(Conditions.ORGANICS_TRACE, Commodities.ORGANICS);
		COMMODITY.put(Conditions.ORGANICS_COMMON, Commodities.ORGANICS);
		COMMODITY.put(Conditions.ORGANICS_ABUNDANT, Commodities.ORGANICS);
		COMMODITY.put(Conditions.ORGANICS_PLENTIFUL, Commodities.ORGANICS);

		COMMODITY.put(Conditions.VOLATILES_TRACE, Commodities.VOLATILES);
		COMMODITY.put(Conditions.VOLATILES_DIFFUSE, Commodities.VOLATILES);
		COMMODITY.put(Conditions.VOLATILES_ABUNDANT, Commodities.VOLATILES);
		COMMODITY.put(Conditions.VOLATILES_PLENTIFUL, Commodities.VOLATILES);

		COMMODITY.put(Conditions.FARMLAND_POOR, Commodities.FOOD);
		COMMODITY.put(Conditions.FARMLAND_ADEQUATE, Commodities.FOOD);
		COMMODITY.put(Conditions.FARMLAND_RICH, Commodities.FOOD);
		COMMODITY.put(Conditions.FARMLAND_BOUNTIFUL, Commodities.FOOD);

		COMMODITY.put(Conditions.VOLTURNIAN_LOBSTER_PENS, Commodities.LOBSTER);
		COMMODITY.put(Conditions.WATER_SURFACE, Commodities.FOOD);


		MODIFIER.put(Conditions.ORE_SPARSE, -1);
		MODIFIER.put(Conditions.ORE_MODERATE, 0);
		MODIFIER.put(Conditions.ORE_ABUNDANT, 1);
		MODIFIER.put(Conditions.ORE_RICH, 2);
		MODIFIER.put(Conditions.ORE_ULTRARICH, 3);


		MODIFIER.put(Conditions.RARE_ORE_SPARSE, -1);
		MODIFIER.put(Conditions.RARE_ORE_MODERATE, 0);
		MODIFIER.put(Conditions.RARE_ORE_ABUNDANT, 1);
		MODIFIER.put(Conditions.RARE_ORE_RICH, 2);
		MODIFIER.put(Conditions.RARE_ORE_ULTRARICH, 3);

		MODIFIER.put(Conditions.ORGANICS_TRACE, -1);
		MODIFIER.put(Conditions.ORGANICS_COMMON, 0);
		MODIFIER.put(Conditions.ORGANICS_ABUNDANT, 1);
		MODIFIER.put(Conditions.ORGANICS_PLENTIFUL, 2);

		MODIFIER.put(Conditions.VOLATILES_TRACE, -1);
		MODIFIER.put(Conditions.VOLATILES_DIFFUSE, 0);
		MODIFIER.put(Conditions.VOLATILES_ABUNDANT, 1);
		MODIFIER.put(Conditions.VOLATILES_PLENTIFUL, 2);

		MODIFIER.put(Conditions.FARMLAND_POOR, -1);
		MODIFIER.put(Conditions.FARMLAND_ADEQUATE, 0);
		MODIFIER.put(Conditions.FARMLAND_RICH, 1);
		MODIFIER.put(Conditions.FARMLAND_BOUNTIFUL, 2);

		MODIFIER.put(Conditions.VOLTURNIAN_LOBSTER_PENS, 1);
		MODIFIER.put(Conditions.WATER_SURFACE, 0);

        List<String> commodities = new ArrayList<>();
        commodities.add(Commodities.ORE);
        commodities.add(Commodities.RARE_ORE);
        commodities.add(Commodities.VOLATILES);
        commodities.add(Commodities.ORGANICS);
        commodities.add(Commodities.FOOD);
        commodities.add(Commodities.LOBSTER);
		INDUSTRY.put(SPP_Industries.LOCAL_ECONOMY, commodities);

        commodities = new ArrayList<>();
        commodities.add(Commodities.ORE);
        commodities.add(Commodities.RARE_ORE);
        commodities.add(Commodities.ORGANICS);
		INDUSTRY.put(SPP_Industries.CRAWLERS, commodities);
        BASE_SIZE.put(SPP_Industries.CRAWLERS, RESOURCE_STRUCTURE_BASE_SIZE);

        commodities = new ArrayList<>();
        commodities.add(Commodities.VOLATILES);
		INDUSTRY.put(SPP_Industries.SIPHON_PLATFORM, commodities);
        BASE_SIZE.put(SPP_Industries.SIPHON_PLATFORM, RESOURCE_STRUCTURE_BASE_SIZE);

		INDUSTRY.put(SPP_Industries.MIMIR_SIPHON, commodities);
        BASE_SIZE.put(SPP_Industries.MIMIR_SIPHON, RESOURCE_STRUCTURE_BASE_SIZE + 2);

        commodities = new ArrayList<>();
        commodities.add(Commodities.FOOD);
		INDUSTRY.put(SPP_Industries.HYDROPONICS, commodities);
        BASE_SIZE.put(SPP_Industries.HYDROPONICS, RESOURCE_STRUCTURE_BASE_SIZE);

		BASE_MODIFIER.put(Commodities.ORE, 0);
		BASE_MODIFIER.put(Commodities.RARE_ORE, -2);
		BASE_MODIFIER.put(Commodities.VOLATILES, -2);
		BASE_MODIFIER.put(Commodities.ORGANICS, 0);
		BASE_MODIFIER.put(Commodities.FOOD, 0);

		BASE_MODIFIER.put(Commodities.LOBSTER, 0);
		BASE_ZERO.add(Commodities.LOBSTER);
	}

	public void apply(String id) {
		super.apply(id);

		String commodityId = COMMODITY.get(condition.getId());
		if (commodityId == null) return;

		Integer mod = MODIFIER.get(condition.getId());
		if (mod == null) return;

		Integer baseMod = BASE_MODIFIER.get(commodityId);
		if (baseMod == null) return;

        for (String industryId : INDUSTRY.keySet()) {
            if (!INDUSTRY.get(industryId).contains(commodityId)) continue;

            Industry industry = market.getIndustry(industryId);
            if (industry == null) continue;

            int size = SPP_PortFunctions.getPopulationSize(market);
            int portLimit = SPP_PortFunctions.getPopulationCommoditySize(market);
            int reduction = Math.min(portLimit - size, 0);

            if (BASE_SIZE.containsKey(industryId)) {
                size = BASE_SIZE.get(industryId);
                reduction = 0;
            }
            if (BASE_ZERO.contains(commodityId)) {
                size = 0;
                reduction = 0;
            }

            int base = size + baseMod;

            if (industry.isFunctional()) {
                if (BASE_SIZE.containsKey(industryId)) industry.supply(id + "_0", commodityId, base, "Base value");
                else industry.supply(id + "_0", commodityId, base, SPP_BaseIndustry.BASE_POPULATION_TEXT);
                industry.supply(id + "_1", commodityId, mod, Misc.ucFirst(condition.getName().toLowerCase()));
                industry.supply(id + "_2", commodityId, reduction, "Port size");
            } else {
                industry.getSupply(commodityId).getQuantity().unmodifyFlat(id + "_0");
                industry.getSupply(commodityId).getQuantity().unmodifyFlat(id + "_1");
                industry.getSupply(commodityId).getQuantity().unmodifyFlat(id + "_2");
            }
        }

		if (Commodities.FOOD.equals(commodityId)) {
			market.addImmigrationModifier(this);
		}
	}

	public void unapply(String id) {
		super.unapply(id);
		market.removeImmigrationModifier(this);

		String commodityId = COMMODITY.get(condition.getId());
		if (commodityId == null) return;

        for (String industryId : INDUSTRY.keySet()) {
            if (!INDUSTRY.get(industryId).contains(commodityId)) continue;

            Industry industry = market.getIndustry(industryId);
            if (industry == null) continue;

            industry.getSupply(commodityId).getQuantity().unmodifyFlat(id + "_0");
            industry.getSupply(commodityId).getQuantity().unmodifyFlat(id + "_1");
            industry.getSupply(commodityId).getQuantity().unmodifyFlat(id + "_2");
        }
	}

//	@Override
//	public Map<String, String> getTokenReplacements() {
//		Map<String, String> map = super.getTokenReplacements();
//
//		String commodityId = COMMODITY.get(condition.getId());
//		if (commodityId == null) return map;
//
//		Integer mod = MODIFIER.get(condition.getId());
//		if (mod == null) return map;
//
//		CommoditySpecAPI spec = Global.getSettings().getCommoditySpec(commodityId);
//
//		String str = "" + mod;
//		if (mod > 0) str = "+" + mod;
//		if (mod == 0) {
//			map.put("$resourceModText", "No bonuses or penalties to " + spec.getName().toLowerCase() + " production.");
//		} else {
//			map.put("$resourceModText", "" + str + " to " + spec.getName().toLowerCase() + " production.");
//		}
//
//		//map.put("$resourceMod", Misc.ucFirst(spec.getName().toLowerCase()) )
//
//
//		return map;
//	}

	@Override
	public String[] getHighlights() {
		return super.getHighlights();

//		String commodityId = COMMODITY.get(condition.getId());
//		if (commodityId == null) return super.getHighlights();
//
//		Integer mod = MODIFIER.get(condition.getId());
//		if (mod == null) return super.getHighlights();
//
//		String str = "" + mod;
//		if (mod > 0) str = "+" + mod;
//
//		if (mod == 0) {
//			return super.getHighlights();
//		}
//
//		return new String[] {str};
	}

	protected void createTooltipAfterDescription(TooltipMakerAPI tooltip, boolean expanded) {
		super.createTooltipAfterDescription(tooltip, expanded);

		String commodityId = COMMODITY.get(condition.getId());
		if (commodityId != null) {

			Integer mod = MODIFIER.get(condition.getId());
			if (mod != null) {
				CommoditySpecAPI spec = Global.getSettings().getCommoditySpec(commodityId);

                String str = "" + mod;
                if (mod > 0) str = "+" + mod;
                String text = "";
                if (mod == 0) {
                    text = "No bonuses or penalties to " + spec.getName().toLowerCase() + " production";
                } else {
                    //text = "" + str + " to " + spec.getName().toLowerCase() + " production.";
                    text = "" + str + " " + spec.getName().toLowerCase() + " production";
                }
                float pad = 10f;
                tooltip.addPara(text, pad, Misc.getHighlightColor(), str);
			}
		}
	}


	public void modifyIncoming(MarketAPI market, PopulationComposition incoming) {
		float qty = 0f;
		switch (condition.getId()) {
            case Conditions.FARMLAND_POOR: qty = 5f;
                break;
            case Conditions.FARMLAND_ADEQUATE: qty = 10f;
                break;
            case Conditions.FARMLAND_RICH: qty = 20f;
                break;
            case Conditions.FARMLAND_BOUNTIFUL: qty = 30f;
                break;
            case Conditions.WATER_SURFACE: qty = 10f;
                break;
        }

		if (qty > 0) {
			incoming.add(Factions.LUDDIC_CHURCH, qty);
		}
	}
}




