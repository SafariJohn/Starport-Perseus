package campaign.econ.industries;

import campaign.SPP_ImmigrationScript.PopLimitModifier;
import static campaign.econ.industries.SPP_Shipyard.BASE_QUALITY_BONUS;
import campaign.fleets.SPP_SystemWarFleetRouteManager;
import campaign.fleets.SPP_WarFleetRouteSource;
import campaign.ids.SPP_Conditions;
import campaign.ids.SPP_FleetTypes;
import campaign.ids.SPP_Industries;
import campaign.ids.SPP_MemKeys;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.FactionDoctrineAPI;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.*;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.MutableCharacterStatsAPI;
import com.fs.starfarer.api.impl.campaign.econ.CommRelayCondition;
import com.fs.starfarer.api.impl.campaign.econ.impl.MilitaryBase;
import com.fs.starfarer.api.impl.campaign.econ.impl.MilitaryBase.PatrolFleetData;
import static com.fs.starfarer.api.impl.campaign.econ.impl.MilitaryBase.getPatrolCombatFP;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactory.PatrolType;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactoryV3;
import com.fs.starfarer.api.impl.campaign.fleets.FleetParamsV3;
import com.fs.starfarer.api.impl.campaign.fleets.PatrolAssignmentAIV4;
import com.fs.starfarer.api.impl.campaign.fleets.RouteManager;
import com.fs.starfarer.api.impl.campaign.fleets.RouteManager.OptionalFleetData;
import com.fs.starfarer.api.impl.campaign.fleets.RouteManager.RouteData;
import com.fs.starfarer.api.impl.campaign.ids.*;
import com.fs.starfarer.api.impl.campaign.population.PopulationComposition;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Pair;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import util.SPP_Misc;
import util.SPP_PortFunctions;
import org.json.JSONArray;
import org.json.JSONException;

/**
 * Author: SafariJohn
 */
public class SPP_Spaceport extends SPP_BaseIndustry implements MarketImmigrationModifier {
	public static float UPKEEP_MULT_PER_DEFICIT = 0.1f;
	public static final float ALPHA_CORE_ACCESSIBILITY = 0.2f;

    public static final int SPACEPORT_SIZE = 3;
    public static final int MEGAPORT_SIZE = 7;

    private static final int FREEPORT_SCALE = 3;
    private static final int FREEPORT_GROWTH = 5;

    private SPP_WarFleetRouteSource patrolSource;
    private SPP_WarFleetRouteSource indieMercSource;

    @Override
    public void init(String id, MarketAPI market) {
        super.init(id, market);

        initWarFleetSources();
    }

    @Override
	public void apply() {
		modifyStability(this, market, getModId(3));
		super.apply(true);
        market.setHasSpaceport(true);

		int size = market.getSize();
        int adjustedSize = SPP_PortFunctions.getPortCommoditySize(size);
        int population = SPP_PortFunctions.getPopulationSize(market);

		supply(Commodities.ORGANS, Math.min(population - 5, adjustedSize - 3), SPP_BaseIndustry.BASE_POPULATION_TEXT);

        int portDemand = adjustedSize;
//        if (size >= SPACEPORT_SIZE) extraSize++;
//        if (size >= MEGAPORT_SIZE) extraSize++;
//        if (size >= MEGAPORT_SIZE) portDemand += 2;

        demand(Commodities.FOOD, portDemand - 3);
		demand(Commodities.CREW, Math.max(1, portDemand));
		demand(Commodities.FUEL, Math.max(1, portDemand));
		demand(Commodities.SUPPLIES, Math.max(1, portDemand));
		demand(Commodities.SHIPS, portDemand);

        // Access Bonus
		float sizeBonus = getAccessibilityBonus(size);
		if (sizeBonus > 0) {
			market.getAccessibilityMod().modifyFlat(getModId(1), sizeBonus, "Port size");
		}

//        // Add faction-wide bonus, if exists. Set by Corporate HQ.
//        if (market.getFaction().getMemoryWithoutUpdate().contains(SPP_MemKeys.FACTION_ACCESS_BONUS)) {
//            float bonus = (float) market.getFaction().getMemoryWithoutUpdate().get(SPP_MemKeys.FACTION_ACCESS_BONUS);
//			market.getAccessibilityMod().modifyFlat(getModId(2), bonus, "Corporate HQ - faction-wide");
//        }

        // Trade fleets weight
//        MutableStat fleetWeight = (MutableStat) market.getMemoryWithoutUpdate()
//                    .get(SPP_MemKeys.TRADE_FLEET_WEIGHT);
//        if (fleetWeight == null) {
//            fleetWeight = new MutableStat(1);
//            market.getMemoryWithoutUpdate().set(SPP_MemKeys.TRADE_FLEET_WEIGHT, fleetWeight);
//        }
//
//        fleetWeight.setBaseValue(market.getSize());

		Pair<String, Integer> deficit = getMaxDeficit(Commodities.CREW, Commodities.FUEL, Commodities.SUPPLIES, Commodities.SHIPS);
		if (deficit.two > 0) {
			float loss = getUpkeepPenalty(deficit);
			getUpkeep().modifyMult("deficit", 1f + loss, getDeficitText(deficit.one));
		} else {
			getUpkeep().unmodifyMult("deficit");
		}

		float stability = market.getPrevStability();
		float stabilityQualityMod = FleetFactoryV3.getShipQualityModForStability(stability);
		float doctrineQualityMod = market.getFaction().getDoctrine().getShipQualityContribution();

		market.getStats().getDynamic().getMod(Stats.FLEET_QUALITY_MOD).modifyFlatAlways(getModId(0), stabilityQualityMod,
										      "Stability");

		market.getStats().getDynamic().getMod(Stats.FLEET_QUALITY_MOD).modifyFlatAlways(getModId(1), doctrineQualityMod,
											  Misc.ucFirst(market.getFaction().getEntityNamePrefix()) + " fleet doctrine");

        // Low stability inflicts a penalty to defense.
		float stabilityDefenseMult = Math.min(1f, 0.5f + stability / 10f);
		market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).modifyMultAlways(getModId(),
											  stabilityDefenseMult, "Stability");

		float baseDef = getBaseGroundDefenses(market.getSize());
		market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).modifyFlatAlways(getModId(),
											  baseDef, "Base value for a size " + market.getSize() + " port");

        // Benefit for station-block conditions, hackily hard-coded

		market.getStats().getDynamic().getMod(Stats.MAX_INDUSTRIES).modifyFlat(getModId(), getMaxIndustries(), null);

		FactionDoctrineAPI doctrine = market.getFaction().getDoctrine();
		float doctrineShipsMult = FleetFactoryV3.getDoctrineNumShipsMult(doctrine.getNumShips());
		float marketSizeShipsMult = FleetFactoryV3.getNumShipsMultForMarketSize(market.getSize());
		float deficitShipsMult = FleetFactoryV3.getShipDeficitFleetSizeMult(market);
		float stabilityShipsMult = FleetFactoryV3.getNumShipsMultForStability(stability);

		market.getStats().getDynamic().getMod(Stats.COMBAT_FLEET_SIZE_MULT).modifyFlatAlways(getModId(0), marketSizeShipsMult,
											  "Port size");

		market.getStats().getDynamic().getMod(Stats.COMBAT_FLEET_SIZE_MULT).modifyMultAlways(getModId(1), doctrineShipsMult,
											  Misc.ucFirst(market.getFaction().getEntityNamePrefix()) + " fleet doctrine");

		if (deficitShipsMult != 1f) {
			market.getStats().getDynamic().getMod(Stats.COMBAT_FLEET_SIZE_MULT).modifyMult(getModId(2), deficitShipsMult,
												  getDeficitText(Commodities.SHIPS));
		} else {
			market.getStats().getDynamic().getMod(Stats.COMBAT_FLEET_SIZE_MULT).modifyMultAlways(getModId(2), deficitShipsMult,
					  							  getDeficitText(Commodities.SHIPS).replaceAll("shortage", "demand met"));
		}

		market.getStats().getDynamic().getMod(Stats.COMBAT_FLEET_SIZE_MULT).modifyMultAlways(getModId(3), stabilityShipsMult,
												  "Stability");

		market.addTransientImmigrationModifier(this);


        // Pop limit modifiers
        Map<String, PopLimitModifier> mods = SPP_Misc.getPopulationLimitModifiers(market);

        int value = 0;
        if (market.getSize() >= SPACEPORT_SIZE) value++;
        if (market.getSize() >= MEGAPORT_SIZE) value++;

        int growth = value * PopLimitModifier.DEFAULT_GROWTH;

        PopLimitModifier mod = new PopLimitModifier(value, growth, getCurrentName());
        mods.put(SPP_Industries.SPACEPORT, mod);

        if (market.isFreePort()) {
            value = 1;
            mod = new PopLimitModifier(value, FREEPORT_SCALE, FREEPORT_GROWTH, "Free Port");
            mods.put(Conditions.FREE_PORT, mod);
        }

		MemoryAPI memory = market.getMemoryWithoutUpdate();
		Misc.setFlagWithReason(memory, MemFlags.MARKET_PATROL, getModId(), true, -1);

		market.getStats().getDynamic().getMod(Stats.PATROL_NUM_LIGHT_MOD).modifyFlat(getModId(), 3);
		market.getStats().getDynamic().getMod(Stats.PATROL_NUM_MEDIUM_MOD).modifyFlat(getModId(), 2);
		market.getStats().getDynamic().getMod(Stats.PATROL_NUM_HEAVY_MOD).modifyFlat(getModId(), 1);

        if (market.getPrimaryEntity() != null && market.getStarSystem() != null) {
            SPP_SystemWarFleetRouteManager manager = SPP_Misc.getWarFleetRouteManager(market.getStarSystem());
            manager.getWarPorts().put(market.getPrimaryEntity(), market.getSize());

            patrolSource.getFleetWeights().remove(SPP_FleetTypes.WAR_FLEET_PATROL);
            if (market.getSize() >= SPACEPORT_SIZE) patrolSource.getFleetWeights().put(SPP_FleetTypes.WAR_FLEET_PATROL, market.getSize() * 2f);

            indieMercSource.getFleetWeights().remove(SPP_FleetTypes.WAR_FLEET_MERC);
            indieMercSource.getFleetWeights().put(SPP_FleetTypes.WAR_FLEET_MERC, (12 - market.getStabilityValue()) / 3f);

            manager.getRouteSources().remove(patrolSource);
            manager.getRouteSources().add(patrolSource);

            manager.getRouteSources().remove(indieMercSource);
            if (!market.getFaction().isHostileTo(Factions.INDEPENDENT)) {
                manager.getRouteSources().add(indieMercSource);
            }
        }

		if (!isFunctional()) {
			supply.clear();
			unapply();
		}
	}

	protected float getUpkeepPenalty(Pair<String, Integer> deficit) {
		float loss = deficit.two * UPKEEP_MULT_PER_DEFICIT;
		if (loss < 0) loss = 0;
		return loss;
	}


	public static float getAccessibilityBonus(int marketSize) {
        if (marketSize > 10) {
            Global.getLogger(SPP_Spaceport.class).error("Market size is greater than 10!");
            marketSize = 10;
        }

        float bonus = 0f;
        switch (marketSize) {
            case 10: // 30%
            case 9: bonus += 0.05f; // 30%
            case 8: bonus += 0.05f; // 25%
            case 7: bonus += 0.05f; // 20%
            case 6: bonus += 0.05f; // 15%
            case 5: bonus += 0.1f; // 10%
            default: // 0%
        }

        if (marketSize >= SPACEPORT_SIZE) bonus += 0.5f; // +50%
        if (marketSize >= MEGAPORT_SIZE) bonus += 0.3f; // +30% more

        return bonus;
	}

	public static float getBaseGroundDefenses(int marketSize) {
		if (marketSize <= 1) return 50; // Need a platoon to disrupt
		if (marketSize == 2) return 150; // Company
		if (marketSize == 3) return 300;
		if (marketSize == 4) return 450;
		if (marketSize == 5) return 500;
		if (marketSize == 6) return 600;
		if (marketSize == 7) return 750; // Battalion
		if (marketSize == 8) return 800;
		if (marketSize == 9) return 900;
		if (marketSize == 10) return 1000; // Brigade/Regiment with all upgrades

		return marketSize * 100;
	}

	@Override
	public void unapply() {
		super.unapply();

        market.setHasSpaceport(false);

		market.getStability().unmodify(getModId(0));
		market.getStability().unmodify(getModId(1));
		market.getStability().unmodify(getModId(2));

		market.getAccessibilityMod().unmodifyFlat(getModId(0));
		market.getAccessibilityMod().unmodifyFlat(getModId(1));
		market.getAccessibilityMod().unmodifyFlat(getModId(2));

		market.getStats().getDynamic().getMod(Stats.FLEET_QUALITY_MOD).unmodifyFlat(getModId(0));
		market.getStats().getDynamic().getMod(Stats.FLEET_QUALITY_MOD).unmodifyFlat(getModId(1));

		Misc.setFlagWithReason(market.getMemoryWithoutUpdate(), MemFlags.MARKET_PATROL, getModId(), false, -1);

		market.getStats().getDynamic().getMod(Stats.PATROL_NUM_LIGHT_MOD).unmodifyFlat(getModId());
		market.getStats().getDynamic().getMod(Stats.PATROL_NUM_MEDIUM_MOD).unmodifyFlat(getModId());
		market.getStats().getDynamic().getMod(Stats.PATROL_NUM_HEAVY_MOD).unmodifyFlat(getModId());

		market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodifyFlat(getModId());

		market.getStats().getDynamic().getMod(Stats.MAX_INDUSTRIES).unmodifyFlat(getModId());

		market.getStats().getDynamic().getMod(Stats.COMBAT_FLEET_SIZE_MULT).unmodifyFlat(getModId(0));
		market.getStats().getDynamic().getMod(Stats.COMBAT_FLEET_SIZE_MULT).unmodifyMult(getModId(1));
		market.getStats().getDynamic().getMod(Stats.COMBAT_FLEET_SIZE_MULT).unmodifyMult(getModId(2));
		market.getStats().getDynamic().getMod(Stats.COMBAT_FLEET_SIZE_MULT).unmodifyMult(getModId(3));

		unmodifyStability(market, getModId(3));

		market.removeTransientImmigrationModifier(this);

//        cutterManager = null;

        // Remove pop limit modifiers
        Map<String, PopLimitModifier> mods = SPP_Misc.getPopulationLimitModifiers(market);
        mods.remove(SPP_Industries.SPACEPORT);
        mods.remove(Conditions.FREE_PORT);

		MemoryAPI memory = market.getMemoryWithoutUpdate();
		Misc.setFlagWithReason(memory, MemFlags.MARKET_PATROL, getModId(), false, -1);

        if (market.getPrimaryEntity() != null && market.getStarSystem() != null) {
            SPP_SystemWarFleetRouteManager manager = SPP_Misc.getWarFleetRouteManager(market.getStarSystem());
            manager.getWarPorts().remove(market.getPrimaryEntity());
            manager.getRouteSources().remove(patrolSource);
            manager.getRouteSources().remove(indieMercSource);
        }
	}

    @Override
	protected boolean hasPostDemandSection(boolean hasDemand, Industry.IndustryTooltipMode mode) {
		return true;
	}

	@Override
	public String getCurrentImage() {
		float size = market.getSize();

        if (market.hasCondition(SPP_Conditions.ORBITAL_STATION)) {
            if (size < SPACEPORT_SIZE) {
                // Makeshift Station
                return Global.getSettings().getSpriteName("industry", "SPP_makeshiftStation");
            }
            if (size >= MEGAPORT_SIZE) {
                // Megastation
                return Global.getSettings().getSpriteName("industry", "SPP_megastation");
            }
            // Space Station
            return Global.getSettings().getSpriteName("industry", "SPP_station");
        } else {
            if (size < SPACEPORT_SIZE) {
                // Makeshift Port
                return Global.getSettings().getSpriteName("industry", "techmining");
            }
            if (size >= MEGAPORT_SIZE) {
                // Megaport
                return Global.getSettings().getSpriteName("industry", "SPP_megaport");
            }

            // Spaceport
            return super.getCurrentImage();
        }
	}

    @Override
    public String getCurrentName() {
		float size = market.getSize();

        if (market.hasCondition(SPP_Conditions.ORBITAL_STATION)) {
            if (size < SPACEPORT_SIZE) {
                // Makeshift Station
                return "Makeshift Station";
            }
            if (size >= MEGAPORT_SIZE) {
                // Megastation
                return "Megastation";
            }

            // Orbital Station
            return "Orbital Station";
        } else {
            if (size < SPACEPORT_SIZE) {
                // Makeshift Port
                return "Makeshift Port";
            }
            if (size >= MEGAPORT_SIZE) {
                // Megaport
                return "Megaport";
            }

            // Spaceport
            return super.getCurrentName();
        }
    }


	public static float getIncomeStabilityMult(float stability) {
		if (stability <= 5) {
			return Math.max(0, stability / 5f);
		}
		return 1f + (stability - 5f) * .1f;
	}

	public static float getUpkeepHazardMult(float hazard) {
		//float hazardMult = 1f + hazard;
		float hazardMult = hazard;
		float min = Global.getSettings().getFloat("minUpkeepMult");
		if (hazardMult < min) hazardMult = min;
		return hazardMult;
	}


	public static int getMismanagementPenalty() {
		int outposts = 0;
		for (MarketAPI curr : Global.getSector().getEconomy().getMarketsCopy()) {
			if (!curr.isPlayerOwned()) continue;

			if (curr.getAdmin().isPlayer()) {
				outposts++;
			}
		}

		MutableCharacterStatsAPI stats = Global.getSector().getCharacterData().getPerson().getStats();

		int maxOutposts = stats.getOutpostNumber().getModifiedInt();

		int overOutposts = outposts - maxOutposts;

		//if (overOutposts < 0) overOutposts = 0;

		int penaltyOrBonus = (int) (overOutposts * Misc.getOutpostPenalty());

		return penaltyOrBonus;
	}

	public static void modifyStability(Industry industry, MarketAPI market, String modId) {
		market.getIncomeMult().modifyMultAlways(modId, getIncomeStabilityMult(market.getPrevStability()), "Stability");
		market.getUpkeepMult().modifyMultAlways(modId, getUpkeepHazardMult(market.getHazardValue()), "Hazard rating");

		float inFactionSupply = 0f;
		float totalDemand = 0f;
		for (CommodityOnMarketAPI com : market.getCommoditiesCopy()) {
			if (com.isNonEcon()) continue;

			int d = com.getMaxDemand();
			if (d <= 0) continue;

			totalDemand += d;
			CommodityMarketDataAPI cmd = com.getCommodityMarketData();
			int inFaction = Math.max(com.getMaxSupply(),
							   Math.min(cmd.getMaxShipping(market, true), cmd.getMaxExport(market.getFactionId())));
			if (inFaction > d) inFaction = d;
			if (inFaction < d) inFaction = Math.max(com.getMaxSupply(), 0);

			//CommoditySourceType source = cmd.getMarketShareData(market).getSource();;
			//if (source != CommoditySourceType.GLOBAL) {
			//	inFactionSupply += Math.min(d - inFaction, com.getAvailable());
			//}
			inFactionSupply += Math.max(0, Math.min(inFaction, com.getAvailable()));
		}

		if (totalDemand > 0) {
			float max = Global.getSettings().getFloat("upkeepReductionFromInFactionImports");
			float f = inFactionSupply / totalDemand;
			if (f < 0) f = 0;
			if (f > 1) f = 1;
			if (f > 0) {
				float mult = Math.round(100f - (f * max * 100f)) / 100f;
				String desc = "Demand supplied in-faction (" + (int)Math.round(f * 100f) + "%)";
				if (f == 1f) desc = "All demand supplied in-faction";
				market.getUpkeepMult().modifyMultAlways(modId + "ifi", mult, desc);
			} else {
				market.getUpkeepMult().modifyMultAlways(modId + "ifi", 1f, "All demand supplied out-of-faction; no upkeep reduction");
			}
		}


		if (market.isPlayerOwned() && market.getAdmin().isPlayer()) {
			int penalty = getMismanagementPenalty();
			if (penalty > 0) {
				market.getStability().modifyFlat("_" + modId + "_mm", -penalty, "Mismanagement penalty");
			} else if (penalty < 0) {
				market.getStability().modifyFlat("_" + modId + "_mm", -penalty, "Management bonus");
			} else {
				market.getStability().unmodifyFlat("_" + modId + "_mm");
			}
		} else {
			market.getStability().unmodifyFlat(modId + "_mm");
		}

		market.getStability().modifyFlat("_" + modId + "_ms", Global.getSettings().getFloat("stabilityBaseValue"), "Base value");

		if (!market.hasCondition(Conditions.COMM_RELAY)) {
			market.getStability().modifyFlat(CommRelayCondition.COMM_RELAY_MOD_ID, CommRelayCondition.NO_RELAY_PENALTY, "No active comm relay in-system");
		}
	}


	public static void unmodifyStability(MarketAPI market, String modId) {
		market.getIncomeMult().unmodifyMult(modId);
		market.getUpkeepMult().unmodifyMult(modId);
		market.getUpkeepMult().unmodifyMult(modId + "ifi");

		market.getStability().unmodifyFlat(modId);

//		for (int i = 0; i < 30; i++) {
//			market.getStability().unmodify(modId + i);
//		}
		market.getStability().unmodifyFlat("_" + modId + "_mm");
		market.getStability().unmodifyFlat("_" + modId + "_ms");

		if (!market.hasCondition(Conditions.COMM_RELAY)) {
			market.getStability().unmodifyFlat(CommRelayCondition.COMM_RELAY_MOD_ID);
		}

	}



	@Override
	public boolean showShutDown() {
		return false;
	}

	@Override
	public String getCanNotShutDownReason() {
		//return "Use \"Abandon Colony\" instead.";
		return null;
	}

	@Override
	public boolean canShutDown() {
		return false;
	}

	@Override
	protected String getDescriptionOverride() {
		float size = market.getSize();

        if (market.hasCondition(SPP_Conditions.ORBITAL_STATION)) {
            if (size < SPACEPORT_SIZE) {
                // Makeshift Station
                return "A makeshift station, serving as a meeting place and base of operations. Vulnerable to conventional ship weapons.";
            }
            if (size >= MEGAPORT_SIZE) {
                // Megastation
                return "An enormous space station which can host sprawling shipyards, habitats, factories, "
                            + "and large stockpiles of weapons and supplies. These platforms allow humanity "
                            + "to project military and industrial power throughout known space.";
            }

            // Space Station
            return "A large station with facilities for loading and unloading cargo and performing starship repairs.";
        } else {
            if (size < SPACEPORT_SIZE) {
                // Makeshift Port
                return "Temporary facilities for loading and unloading cargo and performing starship repairs.";
            }
            if (size >= MEGAPORT_SIZE) {
                // Megaport
                return "A vast spaceport where the stars can touch the dirt. Regimented lander gantries "
                            + "and armoured fuel tanks are laced together by access-tunnels and "
                            + "short-haul cargo trams feeding a sprawl of warehouse districts and logistics terminals.";
            }

            // Spaceport
            return super.getDescriptionOverride();
        } // End else
	}

	public String getBuildOrUpgradeProgressText() {
//		float f = buildProgress / spec.getBuildTime();
//		return "" + (int) Math.round(f * 100f) + "%";
		if (isUpgrading()) {
			return "total development: " + Misc.getRoundedValue(SPP_Misc.getPortSizeProgress(market) * 100f) + "%";
		}

		return super.getBuildOrUpgradeProgressText();
	}

	@Override
	public float getBuildOrUpgradeProgress() {
		if (!super.isBuilding() && market.getSize() < 10) {
			return SPP_Misc.getPortSizeProgress(market);
		}
		return super.getBuildOrUpgradeProgress();
	}

	@Override
	public boolean isBuilding() {
		if (!super.isBuilding() && market.getSize() < 10 && getBuildOrUpgradeProgress() > 0) return true;

		return super.isBuilding();
	}

	@Override
	public boolean isUpgrading() {
		if (!super.isBuilding() && market.getSize() < 10) return true;

		return super.isUpgrading();
	}



	public void modifyIncoming(MarketAPI market, PopulationComposition incoming) {
		float patherLevel = 0;
		for (Industry curr : market.getIndustries()) {
			patherLevel += getAICoreImpact(curr.getAICoreId());
		}

		String adminCoreId = market.getAdmin().getAICoreId();
		if (adminCoreId != null) {
			patherLevel += 10f * getAICoreImpact(adminCoreId);
		}

		List<String> targeted = new ArrayList<String>();
		targeted.add(Industries.TECHMINING);
		targeted.add(Industries.HEAVYINDUSTRY);
		targeted.add(Industries.FUELPROD);
		targeted.add(Industries.STARFORTRESS);

		for (String curr : targeted) {
			if (market.hasIndustry(curr)) {
				patherLevel += 10f;
			}
		}

		if (patherLevel > 0) {
			incoming.add(Factions.LUDDIC_PATH, patherLevel * 0.2f);
		}
	}


	@Override
	protected void applyAlphaCoreModifiers() {
		market.getAccessibilityMod().modifyFlat(getModId(2), ALPHA_CORE_ACCESSIBILITY, "Alpha core (" + getNameForModifier() + ")");
	}

	@Override
	protected void applyNoAICoreModifiers() {
		market.getAccessibilityMod().unmodifyFlat(getModId(2));
	}

    @Override
	protected void addAlphaCoreDescription(TooltipMakerAPI tooltip, AICoreDescriptionMode mode) {
		float opad = 10f;
		Color highlight = Misc.getHighlightColor();

		String pre = "Alpha-level AI core currently assigned. ";
		if (mode == AICoreDescriptionMode.MANAGE_CORE_DIALOG_LIST || mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
			pre = "Alpha-level AI core. ";
		}
		float a = ALPHA_CORE_ACCESSIBILITY;
		String aStr = "" + (int)Math.round(a * 100f) + "%";

		if (mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
			CommoditySpecAPI coreSpec = Global.getSettings().getCommoditySpec(aiCoreId);
			TooltipMakerAPI text = tooltip.beginImageWithText(coreSpec.getIconName(), 48);
			text.addPara(pre + "Reduces upkeep cost by %s. Reduces demand by %s unit. " +
                    "Increases supply by %s unit." + "Increases accessibility by %s.", 0f, highlight,
					"" + (int)((1f - UPKEEP_MULT) * 100f) + "%", "" + DEMAND_REDUCTION, "" + SUPPLY_BONUS,
					aStr);
			tooltip.addImageWithText(opad);
			return;
		}

		tooltip.addPara(pre + "Reduces upkeep cost by %s. Reduces demand by %s unit. " +
                "Increases supply by %s unit." + "Increases accessibility by %s.", opad, highlight,
				"" + (int)((1f - UPKEEP_MULT) * 100f) + "%", "" + DEMAND_REDUCTION, "" + SUPPLY_BONUS,
				aStr);

	}

	private float getAICoreImpact(String coreId) {
		if (Commodities.ALPHA_CORE.equals(coreId)) return 10f;
		if (Commodities.BETA_CORE.equals(coreId)) return 4f;
		if (Commodities.GAMMA_CORE.equals(coreId)) return 1f;
		return 0f;
	}

	public boolean canBeDisrupted() {
		return false;
	}

	public int getMaxIndustries() {
		return getMaxIndustries(market.getSize());
	}

	public static int [] MAX_IND = null;
	public static int getMaxIndustries(int size) {
		if (MAX_IND == null) {
			try {
				MAX_IND = new int [10];
				JSONArray a = Global.getSettings().getJSONArray("SPP_maxIndustries");
				for (int i = 0; i < MAX_IND.length; i++) {
					MAX_IND[i] = a.getInt(i);
				}
			} catch (JSONException e) {
				throw new RuntimeException(e);
			}
		}
		size--;
		if (size < 0) size = 0;
		if (size > 9) size = 9;
		return MAX_IND[size];
//		if (size <= 3) return 1;
//		if (size <= 5) return 2;
//		if (size <= 7) return 3;
//		return 4;
	}

    private void initWarFleetSources() {
        patrolSource = new SPP_WarFleetRouteSource() {
            public FactionAPI getFaction() { return market.getFaction(); }

            public RouteData createRoute(StarSystemAPI system, String fleetType) {
                int light = getCount(PatrolType.FAST) + 1;
                int medium = getCount(PatrolType.COMBAT) + 1;
                int heavy = getCount(PatrolType.HEAVY) + 1;

                int lightWeight = getPatrolTypeWeight(PatrolType.FAST);
                int mediumWeight = getPatrolTypeWeight(PatrolType.COMBAT);
                int heavyWeight = getPatrolTypeWeight(PatrolType.HEAVY);

                WeightedRandomPicker<PatrolType> picker = new WeightedRandomPicker<PatrolType>();
                picker.add(PatrolType.HEAVY, heavyWeight / heavy);
                picker.add(PatrolType.COMBAT, mediumWeight / medium);
                picker.add(PatrolType.FAST, lightWeight / light);

                if (picker.isEmpty()) return null;

                PatrolType type = picker.pick();
                PatrolFleetData custom = new PatrolFleetData(type);

                OptionalFleetData extra = new OptionalFleetData(market);
                extra.fleetType = type.getFleetType();

                SPP_SystemWarFleetRouteManager manager = SPP_Misc.getWarFleetRouteManager(system);

                RouteData route = RouteManager.getInstance().addRoute(manager.getRouteSourceId(), market, Misc.genRandomSeed(), extra, manager, custom);
                extra.strength = (float) getPatrolCombatFP(type, route.getRandom());
                extra.strength = Misc.getAdjustedStrength(extra.strength, market);


                float patrolDays = 35f + (float) Math.random() * 10f;
                route.addSegment(new RouteManager.RouteSegment(patrolDays, market.getPrimaryEntity()));

                return route;
            }

            public CampaignFleetAPI spawnFleet(RouteData route) {
                PatrolFleetData custom = (PatrolFleetData) route.getCustom();
                PatrolType type = custom.type;

                Random random = route.getRandom();
                if (random == null) random = new Random();


                float combat = getPatrolCombatFP(type, random);
                float tanker = 0f;
                float freighter = 0f;
                String fleetType = type.getFleetType();
                switch (type) {
                case FAST:
                    break;
                case COMBAT:
                    tanker = Math.round((float) random.nextFloat() * 5f);
                    break;
                case HEAVY:
                    tanker = Math.round((float) random.nextFloat() * 10f);
                    freighter = Math.round((float) random.nextFloat() * 10f);
                    break;
                }

                FleetParamsV3 params = new FleetParamsV3(
                        market,
                        null,
                        market.getFactionId(),
                        route.getQualityOverride(),
                        fleetType,
                        combat, // combatPts
                        freighter, // freighterPts
                        tanker, // tankerPts
                        0f, // transportPts
                        0f, // linerPts
                        0f, // utilityPts
                        0f // qualityMod
                        );
                params.timestamp = route.getTimestamp();
                params.random = random;
                CampaignFleetAPI fleet = FleetFactoryV3.createFleet(params);

                if (fleet == null || fleet.isEmpty()) return null;

                if (!fleet.getFaction().getCustomBoolean(Factions.CUSTOM_PATROLS_HAVE_NO_PATROL_MEMORY_KEY)) {
                    fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_PATROL_FLEET, true);
                    if (type == PatrolType.FAST || type == PatrolType.COMBAT) {
                        fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_CUSTOMS_INSPECTOR, true);
                    }
                } else if (fleet.getFaction().getCustomBoolean(Factions.CUSTOM_PIRATE_BEHAVIOR)) {
                    fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_PIRATE, true);

                    // hidden pather and pirate bases
                    // make them raid so there's some consequence to just having a colony in a system with one of those
                    if (market != null && market.isHidden()) {
                        fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_RAIDER, true);
                    }
                }

                String postId = Ranks.POST_PATROL_COMMANDER;
                String rankId = Ranks.SPACE_COMMANDER;
                switch (type) {
                case FAST:
                    rankId = Ranks.SPACE_LIEUTENANT;
                    break;
                case COMBAT:
                    rankId = Ranks.SPACE_COMMANDER;
                    break;
                case HEAVY:
                    rankId = Ranks.SPACE_CAPTAIN;
                    break;
                }

                fleet.getCommander().setPostId(postId);
                fleet.getCommander().setRankId(rankId);

                market.getContainingLocation().addEntity(fleet);
                fleet.setFacing((float) Math.random() * 360f);
                // this will get overridden by the patrol assignment AI, depending on route-time elapsed etc
                fleet.setLocation(market.getPrimaryEntity().getLocation().x, market.getPrimaryEntity().getLocation().y);

                fleet.addScript(new PatrolAssignmentAIV4(fleet, route));

                //market.getContainingLocation().addEntity(fleet);
                //fleet.setLocation(market.getPrimaryEntity().getLocation().x, market.getPrimaryEntity().getLocation().y);

                if (custom.spawnFP <= 0) {
                    custom.spawnFP = fleet.getFleetPoints();
                }

                return fleet;
            }

            public boolean shouldCancelRouteAfterDelayCheck(RouteData route) { return false; }
            public void reportAboutToBeDespawnedByRouteManager(RouteData route) {}
        };

        indieMercSource = new SPP_WarFleetRouteSource() {
            public FactionAPI getFaction() { return Global.getSector().getFaction(Factions.INDEPENDENT); }

            public RouteData createRoute(StarSystemAPI system, String fleetType) {
                return SPP_MercenaryBase.createMercRoute(system, getFaction(), fleetType, market);
            }

            public CampaignFleetAPI spawnFleet(RouteData route) {
                return SPP_MercenaryBase.createMercFleet(route, getFaction());
            }

            public boolean shouldCancelRouteAfterDelayCheck(RouteData route) { return false; }
            public void reportAboutToBeDespawnedByRouteManager(RouteData route) {}
        };
    }

    private int getCount(PatrolType ... types) {
        int count = 0;
        for (RouteData data : RouteManager.getInstance().getRoutesForSource(SPP_Misc.getWarFleetRouteManager(market.getStarSystem()).getRouteSourceId())) {
            if (data.getCustom() instanceof MilitaryBase.PatrolFleetData) {
                MilitaryBase.PatrolFleetData custom = (MilitaryBase.PatrolFleetData) data.getCustom();
                for (PatrolType type : types) {
                    if (type == custom.type) {
                        count++;
                        break;
                    }
                }
            }
        }
        return count;
    }

	private int getPatrolTypeWeight(PatrolType type) {
		if (type == PatrolType.FAST) {
			return (int) market.getStats().getDynamic().getMod(Stats.PATROL_NUM_LIGHT_MOD).computeEffective(1);
		}
		if (type == PatrolType.COMBAT) {
			return (int) market.getStats().getDynamic().getMod(Stats.PATROL_NUM_MEDIUM_MOD).computeEffective(1);
		}
		if (type == PatrolType.HEAVY) {
			return (int) market.getStats().getDynamic().getMod(Stats.PATROL_NUM_HEAVY_MOD).computeEffective(1);
		}
		return 0;
	}
}







