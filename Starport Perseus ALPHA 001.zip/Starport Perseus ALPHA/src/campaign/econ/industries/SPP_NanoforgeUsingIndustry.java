/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package campaign.econ.industries;

import com.fs.starfarer.api.campaign.SpecialItemData;

/**
 *
 * @author SafariJohn
 */
interface SPP_NanoforgeUsingIndustry {

    public SpecialItemData getNanoforge();

    public void setNanoforge(SpecialItemData data);

    public String getCurrentName();

}
