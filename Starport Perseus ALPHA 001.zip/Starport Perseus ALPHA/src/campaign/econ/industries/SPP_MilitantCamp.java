package campaign.econ.industries;

import campaign.econ.SPP_ResourceDepositsCondition;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketImmigrationModifier;
import com.fs.starfarer.api.combat.MutableStat;
import static com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry.DEMAND_REDUCTION;
import static com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry.UPKEEP_MULT;
import static com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry.getDeficitText;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.impl.campaign.population.PopulationComposition;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;

/**
 * Author: SafariJohn
 */
public class SPP_MilitantCamp extends SPP_BaseIndustry implements MarketImmigrationModifier {
    public static final float BASE_PATHER_INTEREST_REDUCTION = -4; // Reduces Pather interest
	public static final float DEFENSE_BONUS = 500f;
    public static final String DEFENSE_DESC = "Luddic Path fanatics";
    public static final int AI_STABILITY_PENALTY = -1;

    private float patherInterest = BASE_PATHER_INTEREST_REDUCTION;

    @Override
    public void apply() {
        int flatSize = SPP_ResourceDepositsCondition.RESOURCE_STRUCTURE_BASE_SIZE;

        modifyStabilityWithBaseMod();

		applyIncomeAndUpkeep(flatSize);
//        demand(Commodities.CREW, flatSize);
        demand(Commodities.SUPPLIES, flatSize);
//        demand(Commodities.FUEL, flatSize);
//        demand(Commodities.SHIPS, flatSize);
        demand(Commodities.HAND_WEAPONS, flatSize);

        // Ground defenses
        // Penalty from low supplies
		float mult = getDeficitMult(Commodities.SUPPLIES, Commodities.HAND_WEAPONS);
		String extra = "";
		if (mult != 1) {
			String com = getMaxDeficit(Commodities.SUPPLIES, Commodities.HAND_WEAPONS).one;
			extra = " (" + getDeficitText(com).toLowerCase() + ")";
		}
        float defense = DEFENSE_BONUS * mult;

        if (market.getFaction().isHostileTo(Factions.LUDDIC_PATH)) {
            market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodifyFlat(getModId());
        } else {
            market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD)
                        .modifyFlat(getModId(), defense, DEFENSE_DESC + extra);
        }

		if (!isFunctional()) {
			unapply();
		}
    }

    @Override
    protected int getBaseStabilityMod() {
        if (market.getAdmin().isAICore()) return AI_STABILITY_PENALTY;

        for (Industry ind : market.getIndustries()) {
            if (ind.getAICoreId() != null) return AI_STABILITY_PENALTY;
        }

        return 0;
    }

    @Override
    public void unapply() {
        super.unapply();

        unmodifyStabilityWithBaseMod();

		market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodifyFlat(getModId());

    }

	@Override
	public boolean isAvailableToBuild() {
		return Global.getSector().getPlayerFaction().knowsIndustry(getId());
	}

	public boolean showWhenUnavailable() {
		return Global.getSector().getPlayerFaction().knowsIndustry(getId());
	}

    @Override
    protected void applyAlphaCoreModifiers() {
        patherInterest = BASE_PATHER_INTEREST_REDUCTION * 3;
    }

	@Override
	protected void applyNoAICoreModifiers() {
        patherInterest = BASE_PATHER_INTEREST_REDUCTION;
	}

    @Override
    protected void addAlphaCoreDescription(TooltipMakerAPI tooltip, AICoreDescriptionMode mode) {
		float opad = 10f;
		Color highlight = Misc.getHighlightColor();

		String pre = "Alpha-level AI core currently assigned. ";
		if (mode == AICoreDescriptionMode.MANAGE_CORE_DIALOG_LIST || mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
			pre = "Alpha-level AI core. ";
		}
		if (mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
			CommoditySpecAPI coreSpec = Global.getSettings().getCommoditySpec(aiCoreId);
			TooltipMakerAPI text = tooltip.beginImageWithText(coreSpec.getIconName(), 48);
			text.addPara(pre + "Reduces upkeep cost by %s. Reduces demand by %s unit. " +
					"Reduces Luddic Path interest.", 0f, highlight,
					"" + (int)((1f - UPKEEP_MULT) * 100f) + "%", "" + DEMAND_REDUCTION);
			tooltip.addImageWithText(opad);
			return;
		}

		tooltip.addPara(pre + "Reduces upkeep cost by %s. Reduces demand by %s unit. " +
				"Reduces Luddic Path interest.", opad, highlight,
				"" + (int)((1f - UPKEEP_MULT) * 100f) + "%", "" + DEMAND_REDUCTION);
    }

    @Override
	protected boolean hasPostDemandSection(boolean hasDemand, IndustryTooltipMode mode) {
		return mode != IndustryTooltipMode.NORMAL || isFunctional();
	}

	@Override
	protected void addPostDemandSection(TooltipMakerAPI tooltip, boolean hasDemand, IndustryTooltipMode mode) {
		if (mode != IndustryTooltipMode.NORMAL || isFunctional()) {
//			addStabilityPostDemandSection(tooltip, hasDemand, mode);

            if (!market.getFaction().isHostileTo(Factions.LUDDIC_PATH)) {
                float bonus = DEFENSE_BONUS;
                addGroundDefensesImpactSection(tooltip, bonus, Commodities.SUPPLIES);
            }

			int mod = getBaseStabilityMod();
            if (mod < 0) {
                String totalStr = mod + "";
                Color h = Misc.getNegativeHighlightColor();
                float opad = 10f;
                tooltip.addPara("AI cores stability penalty: %s", opad, h, totalStr);
            }
		}
	}
    @Override
    protected void addGroundDefensesImpactSection(TooltipMakerAPI tooltip, float bonus, String... commodities) {
        if (bonus > 0 && bonus < 10) {
            super.addGroundDefensesImpactSection(tooltip, bonus, commodities);
            return;
        }

		Color h = Misc.getHighlightColor();
		float opad = 10f;

		MutableStat fake = new MutableStat(0);

		fake.modifyFlat("1", bonus, getNameForModifier());

		if (commodities != null) {
			float mult = getDeficitMult(commodities);
			//mult = 0.89f;
			if (mult != 1) {
				String com = getMaxDeficit(commodities).one;
				fake.modifyFlat("2", -(1f - mult) * bonus, getDeficitText(com));
			}
		}

		float total = Misc.getRoundedValueFloat(fake.getModifiedValue());
		String totalStr = "+" + (int) total;
		if (total < 1f) {
            totalStr = "" + (int) total;
			h = Misc.getNegativeHighlightColor();
		}
		float pad = 3f;
		tooltip.addPara("Ground defense strength: %s (" + DEFENSE_DESC + ")", opad, h, totalStr);
    }

    @Override
    public void modifyIncoming(MarketAPI market, PopulationComposition incoming) {
		incoming.add(Factions.LUDDIC_CHURCH, 5f);
		incoming.add(Factions.LUDDIC_PATH, 5f);
    }

    @Override
    public float getPatherInterest() {
        return super.getPatherInterest() + patherInterest;
    }

}
