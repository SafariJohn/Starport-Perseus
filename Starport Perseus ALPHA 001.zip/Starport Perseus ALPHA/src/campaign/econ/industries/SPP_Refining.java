package campaign.econ.industries;

import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.util.Pair;
import util.SPP_PortFunctions;


public class SPP_Refining extends SPP_BaseIndustry {

	public void apply() {
		super.apply(true);

		int size = market.getSize();
        int adjustedSize = SPP_PortFunctions.getPortCommoditySize(size);


		demand(Commodities.HEAVY_MACHINERY, adjustedSize - 2); // have to keep it low since it can be circular
		demand(Commodities.ORE, adjustedSize + 2);
		demand(Commodities.RARE_ORE, adjustedSize);

		supply(Commodities.METALS, adjustedSize);
		supply(Commodities.RARE_METALS, adjustedSize - 2);

		Pair<String, Integer> deficit = getMaxDeficit(Commodities.HEAVY_MACHINERY, Commodities.ORE);
		applyDeficitToProduction(1, deficit, Commodities.METALS);

		deficit = getMaxDeficit(Commodities.HEAVY_MACHINERY, Commodities.RARE_ORE);
		applyDeficitToProduction(1, deficit, Commodities.RARE_METALS);

		if (!isFunctional()) {
			supply.clear();
		}
	}


	@Override
	public void unapply() {
		super.unapply();
	}


	public float getPatherInterest() {
		return 2f + super.getPatherInterest();
	}

}
