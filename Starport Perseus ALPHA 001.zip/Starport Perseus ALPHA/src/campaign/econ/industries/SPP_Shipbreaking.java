package campaign.econ.industries;

import campaign.ids.SPP_Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.util.Pair;
import util.SPP_PortFunctions;

/**
 * Author: SafariJohn
 */
public class SPP_Shipbreaking extends SPP_BaseIndustry {

	public void apply() {
		super.apply(true);

		int size = SPP_PortFunctions.getPortCommoditySize(market.getSize());

		demand(Commodities.HEAVY_MACHINERY, size - 2);
		demand(Commodities.SHIPS, size);

		supply(Commodities.SUPPLIES, size);
		supply(Commodities.METALS, size);
		supply(Commodities.RARE_METALS, size - 2);

		Pair<String, Integer> deficit = getMaxDeficit(Commodities.HEAVY_MACHINERY, Commodities.SHIPS);
		applyDeficitToProduction(1, deficit,
                    Commodities.SUPPLIES,
                    Commodities.METALS,
                    Commodities.RARE_METALS);

		if (!isFunctional()) {
			supply.clear();
		}
	}

    @Override
    public boolean isAvailableToBuild() {
        return market.hasCondition(SPP_Conditions.BONEYARD)
                    || market.hasCondition(SPP_Conditions.GRAVEYARD);
    }

    @Override
    public boolean showWhenUnavailable() {
        return false;
    }

	public float getPatherInterest() {
		return 1f + super.getPatherInterest();
	}

}
