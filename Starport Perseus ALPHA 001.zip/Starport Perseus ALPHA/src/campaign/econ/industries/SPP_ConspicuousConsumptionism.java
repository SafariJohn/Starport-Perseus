package campaign.econ.industries;

import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.util.Pair;
import util.SPP_PortFunctions;

/**
 * Author: SafariJohn
 */
public class SPP_ConspicuousConsumptionism extends SPP_BaseIndustry {
    public static final int MAX_STABILITY_BONUS = 2;
    public static final int MAX_STABILITY_PENALTY = 3;

    @Override
    public void apply() {
        int population = SPP_PortFunctions.getPopulationSize(market);
        population = Math.max(1, population);

        demand(Commodities.DRUGS, population);
        demand(Commodities.LUXURY_GOODS, population);

        // Apply deficit as stability penalty
        modifyStabilityWithBaseMod();

		if (!isFunctional()) {
			supply.clear();
			unapply();
		}
    }

    @Override
    public void unapply() {
        super.unapply();

        unmodifyStabilityWithBaseMod();
    }

    @Override
    protected void modifyStabilityWithBaseMod() {
		int stabilityMod = getBaseStabilityMod();
		stabilityMod -= getStabilityPenalty();

        String extra = "";
		if (stabilityMod < 0) {
			String com = getMaxDeficit(Commodities.LUXURY_GOODS, Commodities.DRUGS).one;
			extra = " (" + getDeficitText(com).toLowerCase() + ")";
		}

        market.getStability().modifyFlat(getModId(), stabilityMod, getNameForModifier() + extra);
    }

    @Override
    protected int getBaseStabilityMod() {
        return MAX_STABILITY_BONUS;
    }

    @Override
    protected int getStabilityPenalty() {
        Pair<String, Integer> deficit = getMaxDeficit(Commodities.LUXURY_GOODS, Commodities.DRUGS);
//        if (deficit.two > 0) return MAX_STABILITY_PENALTY;
//        else return 0;

        int penalty = Math.min(MAX_STABILITY_PENALTY, Math.max(0, deficit.two));

        int population = SPP_PortFunctions.getPopulationSize(market);
        population = Math.max(1, population);

        if (penalty > population) return MAX_STABILITY_PENALTY;

        return penalty;
    }

    @Override
    public boolean isAvailableToBuild() {
        return true;
    }

    @Override
    public boolean showWhenUnavailable() {
        return false;
    }

    @Override
    public float getBuildCost() {
        if (currTooltipMode == IndustryTooltipMode.ADD_INDUSTRY
                    || currTooltipMode == null) return super.getBuildCost();

        return super.getBuildCost() * 2;
    }

}
