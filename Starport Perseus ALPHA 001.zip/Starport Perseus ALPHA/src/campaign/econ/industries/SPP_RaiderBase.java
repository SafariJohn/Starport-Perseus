package campaign.econ.industries;

import campaign.econ.SPP_ResourceDepositsCondition;
import campaign.fleets.SPP_SystemWarFleetRouteManager;
import campaign.fleets.SPP_SystemWarFleetRouteManager.WarFleetData;
import campaign.fleets.SPP_WarFleetRouteSource;
import campaign.ids.SPP_FleetTypes;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.impl.items.BlueprintProviderItem;
import com.fs.starfarer.api.campaign.impl.items.ModSpecItemPlugin;
import com.fs.starfarer.api.impl.campaign.econ.impl.MilitaryBase.PatrolFleetData;
import static com.fs.starfarer.api.impl.campaign.econ.impl.MilitaryBase.getPatrolCombatFP;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactory.PatrolType;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactoryV3;
import com.fs.starfarer.api.impl.campaign.fleets.FleetParamsV3;
import com.fs.starfarer.api.impl.campaign.fleets.PatrolAssignmentAIV4;
import com.fs.starfarer.api.impl.campaign.fleets.RouteManager;
import com.fs.starfarer.api.impl.campaign.fleets.RouteManager.RouteData;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.impl.campaign.ids.Ranks;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.impl.campaign.procgen.SalvageEntityGenDataSpec;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.SalvageEntity;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Pair;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import util.SPP_Misc;

/**
 * Author: SafariJohn
 */
public class SPP_RaiderBase extends SPP_BaseIndustry {
	public static final int BASE_STABILITY_BONUS = 1;
    public static final int MAX_STABILITY_PENALTY = 2;
	public static final float DEFENSE_BONUS = 500f;

    private SPP_WarFleetRouteSource source;

    @Override
    public void init(String id, MarketAPI market) {
        super.init(id, market);

        initWarFleetSource();
    }


    @Override
    public void apply() {
        int flatSize = 5;

		applyIncomeAndUpkeep(1f);

        // Deficit penalty to stability
        demand(Commodities.LUXURY_GOODS, flatSize - 2);
        demand(Commodities.DRUGS, flatSize - 2);

        modifyStabilityWithBaseMod();

        demand(Commodities.MARINES, flatSize);

//        demand(Commodities.CREW, flatSize);
//        demand(Commodities.SUPPLIES, flatSize);
//        demand(Commodities.FUEL, flatSize);
        demand(Commodities.SHIPS, flatSize);

        // Ground defenses
        // Penalty from low supplies
		float mult = getDeficitMult(Commodities.SUPPLIES);
		String extra = "";
		if (mult != 1) {
			String com = getMaxDeficit(Commodities.SUPPLIES).one;
			extra = " (" + getDeficitText(com).toLowerCase() + ")";
		}
		float bonus = DEFENSE_BONUS;
		market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD)
						.modifyFlat(getModId(), bonus * mult, getNameForModifier() + extra);

        // Apply deficit to raider spawn weight
        Pair<String, Integer> deficit = getMaxDeficit(Commodities.CREW, Commodities.SHIPS, Commodities.SUPPLIES, Commodities.FUEL);
        float weight = SPP_SystemWarFleetRouteManager.STANDARD_WEIGHT;
        if (deficit.two > 0) weight = Math.max(1, weight - deficit.two);

        source.getFleetWeights().put(SPP_FleetTypes.WAR_FLEET_RAIDER, weight);

        // Raider fleet source
        if (market.getPrimaryEntity() != null && market.getStarSystem() != null) {
            SPP_SystemWarFleetRouteManager manager = SPP_Misc.getWarFleetRouteManager(market.getStarSystem());
            manager.getRouteSources().remove(source);
            manager.getRouteSources().add(source);
        }

        if (weight - deficit.two > 0) source.getBonusFleets().put(SPP_FleetTypes.WAR_FLEET_RAIDER, 1);
        else source.getBonusFleets().remove(SPP_FleetTypes.WAR_FLEET_RAIDER);

		if (!isFunctional()) {
			supply.clear();
			unapply();
		}
    }

    @Override
    public void unapply() {
        super.unapply();

        unmodifyStabilityWithBaseMod();

		market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodifyFlat(getModId());

        if (market.getPrimaryEntity() != null && market.getStarSystem() != null) {
            SPP_SystemWarFleetRouteManager manager = SPP_Misc.getWarFleetRouteManager(market.getStarSystem());
            manager.getRouteSources().remove(source);
        }
    }

    @Override
    protected void modifyStabilityWithBaseMod() {
		int stabilityMod = getBaseStabilityMod();
		int stabilityPenalty = getStabilityPenalty();

		stabilityMod -= stabilityPenalty;

        String extra = "";
        if (stabilityMod < 0) {
			String com = getMaxDeficit(Commodities.LUXURY_GOODS, Commodities.DRUGS).one;
			extra = " (" + getDeficitText(com).toLowerCase() + ")";
        }

		stabilityMod -= stabilityPenalty;
        market.getStability().modifyFlat(getModId(), stabilityMod, getNameForModifier() + extra);
    }

    @Override
    protected int getBaseStabilityMod() {
		Pair<String, Integer> deficit = getMaxDeficit(Commodities.SUPPLIES);
        return Math.max(0, BASE_STABILITY_BONUS - deficit.two);
    }

    @Override
    protected int getStabilityPenalty() {
        Pair<String, Integer> deficit = getMaxDeficit(Commodities.LUXURY_GOODS, Commodities.DRUGS);
        return Math.min(MAX_STABILITY_PENALTY, Math.max(0, deficit.two));
    }

	public CargoAPI generateCargoForGatheringPoint(Random random) {
		if (!isFunctional()) return null;

		float base = 0.5f;

		List<SalvageEntityGenDataSpec.DropData> dropRandom = new ArrayList<SalvageEntityGenDataSpec.DropData>();
		List<SalvageEntityGenDataSpec.DropData> dropValue = new ArrayList<SalvageEntityGenDataSpec.DropData>();

		SalvageEntityGenDataSpec.DropData d = new SalvageEntityGenDataSpec.DropData();
//		d.chances = 1;
//		d.group = "blueprints_low";
//		d.valueMult = 0.1f;
//		//d.addCustom("item_:{tags:[single_bp], p:{tags:[rare_bp]}}", 1f);
//		dropRandom.add(d);

//		d = new SalvageEntityGenDataSpec.DropData();
//		d.chances = 1;
//		d.group = "rare_tech_low";
//		d.valueMult = 0.1f;
//		dropRandom.add(d);

		d = new SalvageEntityGenDataSpec.DropData();
		d.chances = 1;
		d.group = "any_hullmod_low";
		dropRandom.add(d);

		d = new SalvageEntityGenDataSpec.DropData();
		d.chances = 5;
		d.group = "weapons2";
		dropRandom.add(d);

		d = new SalvageEntityGenDataSpec.DropData();
		//d.chances = 100;
		d.group = "basic";
		d.value = 10000;
		dropValue.add(d);

		CargoAPI result = SalvageEntity.generateSalvage(random, 1f, 1f, base, 1f, dropValue, dropRandom);

		FactionAPI pf = Global.getSector().getPlayerFaction();
		OUTER: for (CargoStackAPI stack : result.getStacksCopy()) {
			if (stack.getPlugin() instanceof BlueprintProviderItem) {
				BlueprintProviderItem bp = (BlueprintProviderItem) stack.getPlugin();
				List<String> list = bp.getProvidedShips();
				if (list != null) {
					for (String id : list) {
						if (!pf.knowsShip(id)) continue OUTER;
					}
				}

				list = bp.getProvidedWeapons();
				if (list != null) {
					for (String id : list) {
						if (!pf.knowsWeapon(id)) continue OUTER;
					}
				}

				list = bp.getProvidedFighters();
				if (list != null) {
					for (String id : list) {
						if (!pf.knowsFighter(id)) continue OUTER;
					}
				}

				list = bp.getProvidedIndustries();
				if (list != null) {
					for (String id : list) {
						if (!pf.knowsIndustry(id)) continue OUTER;
					}
				}
				result.removeStack(stack);
			} else if (stack.getPlugin() instanceof ModSpecItemPlugin) {
				ModSpecItemPlugin mod = (ModSpecItemPlugin) stack.getPlugin();
				if (!pf.knowsHullMod(mod.getModId())) continue OUTER;
				result.removeStack(stack);
			}
		}

		return result;
	}

    private void initWarFleetSource() {
        source = new SPP_WarFleetRouteSource() {
            public FactionAPI getFaction() {
                return market.getFaction();
            }

            public RouteData createRoute(StarSystemAPI system, String fleetType) {
                return createRaiderRoute(system, fleetType, market);
            }

            public CampaignFleetAPI spawnFleet(RouteData route) {
                return createRaiderFleet(route, getFaction());
            }

            public boolean shouldCancelRouteAfterDelayCheck(RouteData route) {
                return false;
            }

            public void reportAboutToBeDespawnedByRouteManager(RouteData route) {

            }
        };
    }

    public static RouteData createRaiderRoute(StarSystemAPI system, String fleetType, MarketAPI from) {
        int light = getRaiderCount(from, PatrolType.FAST) + 1;
        int medium = getRaiderCount(from, PatrolType.COMBAT) + 1;
        int heavy = getRaiderCount(from, PatrolType.HEAVY) + 1;

        int lightWeight = getPatrolTypeWeight(PatrolType.FAST, from);
        int mediumWeight = getPatrolTypeWeight(PatrolType.COMBAT, from);
        int heavyWeight = getPatrolTypeWeight(PatrolType.HEAVY, from);

        WeightedRandomPicker<PatrolType> picker = new WeightedRandomPicker<PatrolType>();
        picker.add(PatrolType.HEAVY, heavyWeight / heavy);
        picker.add(PatrolType.COMBAT, mediumWeight / medium);
        picker.add(PatrolType.FAST, lightWeight / light);

        if (picker.isEmpty()) return null;

        PatrolType type = picker.pick();
        WarFleetData custom = new WarFleetData(type, SPP_FleetTypes.WAR_FLEET_RAIDER);

        RouteManager.OptionalFleetData extra = new RouteManager.OptionalFleetData(from);
        extra.fleetType = type.getFleetType();

        SPP_SystemWarFleetRouteManager manager = SPP_Misc.getWarFleetRouteManager(system);

        RouteData route = RouteManager.getInstance().addRoute(manager.getRouteSourceId(), from, Misc.genRandomSeed(), extra, manager, custom);
        extra.strength = (float) getPatrolCombatFP(type, route.getRandom());
        extra.strength = Misc.getAdjustedStrength(extra.strength, from);


        float patrolDays = 35f + (float) Math.random() * 10f;
        route.addSegment(new RouteManager.RouteSegment(patrolDays, from.getPrimaryEntity()));

        return route;
    }

    public static CampaignFleetAPI createRaiderFleet(RouteData route, FactionAPI faction) {
        Random random = route.getRandom();
        if (random == null) random = new Random();

        PatrolFleetData custom = (PatrolFleetData) route.getCustom();
        PatrolType type = custom.type;

        float combat = getPatrolCombatFP(type, random);
        float tanker = Math.round((float) random.nextFloat() * 5f);
        float freighter = 0f;
        String fleetType = SPP_FleetTypes.RAIDER_SMALL;
        switch (type) {
        case FAST:
            break;
        case COMBAT:
            tanker = Math.round((float) random.nextFloat() * 5f);
            fleetType = SPP_FleetTypes.RAIDER_MEDIUM;
            break;
        case HEAVY:
            tanker = Math.round((float) random.nextFloat() * 10f);
            freighter = Math.round((float) random.nextFloat() * 10f);
            fleetType = SPP_FleetTypes.RAIDER_LARGE;
            break;
        }

        MarketAPI from = route.getMarket();

        FleetParamsV3 params = new FleetParamsV3(
                from,
                null,
                faction.getId(),
                route.getQualityOverride(),
                fleetType,
                combat, // combatPts
                freighter, // freighterPts
                tanker, // tankerPts
                0f, // transportPts
                0f, // linerPts
                0f, // utilityPts
                0f // qualityMod
        );

        params.timestamp = route.getTimestamp();
        params.random = random;
        CampaignFleetAPI fleet = FleetFactoryV3.createFleet(params);

        if (fleet == null || fleet.isEmpty()) return null;

        if (fleet.getFaction().getCustomBoolean(Factions.CUSTOM_PIRATE_BEHAVIOR)) {
            fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_PIRATE, true);
        }

        fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_WAR_FLEET, true);
        fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_RAIDER, true);

        String postId = Ranks.POST_PATROL_COMMANDER;
        String rankId = Ranks.SPACE_COMMANDER;
        switch (type) {
        case FAST:
            rankId = Ranks.SPACE_LIEUTENANT;
            break;
        case COMBAT:
            rankId = Ranks.SPACE_COMMANDER;
            break;
        case HEAVY:
            rankId = Ranks.SPACE_CAPTAIN;
            break;
        }

        fleet.getCommander().setPostId(postId);
        fleet.getCommander().setRankId(rankId);

//		fleet.addEventListener(this);

        from.getContainingLocation().addEntity(fleet);
        fleet.setFacing((float) Math.random() * 360f);
        // this will get overridden by the patrol assignment AI, depending on route-time elapsed etc
        fleet.setLocation(from.getPrimaryEntity().getLocation().x, from.getPrimaryEntity().getLocation().y);

        fleet.addScript(new PatrolAssignmentAIV4(fleet, route));

        //market.getContainingLocation().addEntity(fleet);
        //fleet.setLocation(market.getPrimaryEntity().getLocation().x, market.getPrimaryEntity().getLocation().y);

//                if (custom.spawnFP <= 0) {
//                    custom.spawnFP = fleet.getFleetPoints();
//                }

        return fleet;

    }

    public static int getRaiderCount(MarketAPI market, PatrolType ... types) {
        int count = 0;

        if (market.getPrimaryEntity() == null || market.getStarSystem() == null) return count;

        String managerId = SPP_Misc.getWarFleetRouteManager(market.getStarSystem()).getRouteSourceId();
        for (RouteData data : RouteManager.getInstance().getRoutesForSource(managerId)) {
            if (data.getCustom() instanceof WarFleetData) {
                WarFleetData custom = (WarFleetData) data.getCustom();
                for (PatrolType type : types) {
                    if (type == custom.type && custom.warFleetType.equals(SPP_FleetTypes.WAR_FLEET_RAIDER)) {
                        count++;
                        break;
                    }
                }
            }
        }
        return count;
    }

	public static int getPatrolTypeWeight(PatrolType type, MarketAPI market) {
		if (type == PatrolType.FAST) {
			return (int) market.getStats().getDynamic().getMod(Stats.PATROL_NUM_LIGHT_MOD).computeEffective(1);
		}
		if (type == PatrolType.COMBAT) {
			return (int) market.getStats().getDynamic().getMod(Stats.PATROL_NUM_MEDIUM_MOD).computeEffective(1);
		}
		if (type == PatrolType.HEAVY) {
			return (int) market.getStats().getDynamic().getMod(Stats.PATROL_NUM_HEAVY_MOD).computeEffective(1);
		}
		return 0;
	}
}
