package campaign.econ.industries;

/**
 * Author: SafariJohn
 */
public class SPP_Dummy extends SPP_BaseIndustry {

    @Override
    public void apply() {}

	@Override
	public boolean isAvailableToBuild() {
        return false;
	}

    @Override
    public boolean showWhenUnavailable() {
        return false;
    }



}
