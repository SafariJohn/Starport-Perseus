package campaign.econ.industries.factionBuildings;

import campaign.econ.industries.SPP_MercenaryBase;

/**
 * Author: SafariJohn
 */
public class SPP_AuxiliariesDepot extends SPP_MercenaryBase {

    @Override
    public boolean isAvailableToBuild() {
        return false;
    }

    @Override
    public boolean showWhenUnavailable() {
        return false;
    }
}
