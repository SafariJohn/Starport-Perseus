package campaign.econ.industries.factionBuildings;

import campaign.econ.industries.SPP_MilitaryBase;
import com.fs.starfarer.api.impl.campaign.ids.Factions;


public class SPP_Academy extends SPP_MilitaryBase {

	@Override
	public boolean isFunctional() {
		return super.isFunctional() && market.getFactionId().equals(Factions.PERSEAN);
	}

	@Override
	public boolean isAvailableToBuild() {
		return false;
	}

	public boolean showWhenUnavailable() {
		return false;
	}
}
