package campaign.econ.industries.factionBuildings;

import campaign.ids.SPP_Factions;
import campaign.ids.SPP_MemKeys;
import campaign.ids.SPP_Ranks;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.characters.FullName.Gender;
import com.fs.starfarer.api.characters.ImportantPeopleAPI;
import com.fs.starfarer.api.impl.campaign.ids.Ranks;

/**
 * Author: SafariJohn
 */
public class SPP_KantaDepot extends SPP_BaseFactionBuilding {

    @Override
    protected void createRepresentative() {
        // All matriarchs for Kanta's brood
        ImportantPeopleAPI ip = Global.getSector().getImportantPeople();
        representative = getFaction().createRandomPerson(Gender.FEMALE);
        representative.setRankId(SPP_Ranks.FACTION_REP);
        representative.setPostId(Ranks.POST_OUTPOST_COMMANDER);

        market.getCommDirectory().addPerson(representative);
        market.addPerson(representative);
        market.getMemoryWithoutUpdate().set(SPP_MemKeys.FACTION_REP + "_" + getFaction().getId(), representative);
        ip.addPerson(representative);
    }


    @Override
    protected FactionAPI getFaction() {
//        return Global.getSector().getFaction(Factions.PERSEAN);
        return Global.getSector().getFaction(SPP_Factions.DYNASTY);
    }

}
