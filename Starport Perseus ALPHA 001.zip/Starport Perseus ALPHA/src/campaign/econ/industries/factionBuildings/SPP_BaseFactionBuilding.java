package campaign.econ.industries.factionBuildings;

import campaign.econ.industries.SPP_BaseIndustry;
import campaign.ids.SPP_MemKeys;
import campaign.ids.SPP_Ranks;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.characters.ImportantPeopleAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.CustomRepImpact;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.RepActionEnvelope;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Ranks;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.util.IntervalUtil;

/**
 * Author: SafariJohn
 */
public abstract class SPP_BaseFactionBuilding extends SPP_BaseIndustry {

    public static final float DEFENSE_BONUS = 250f;
    public static final float REP_PER_MONTH = 1f;

    protected PersonAPI representative;

    IntervalUtil interval = new IntervalUtil(25, 35);

    @Override
    public void apply() {
        int size = 2;

		demand(Commodities.SUPPLIES, size);
		demand(Commodities.MARINES, size);
		demand(Commodities.HAND_WEAPONS, size - 1);

		float mult = getDeficitMult(Commodities.SUPPLIES, Commodities.MARINES, Commodities.HAND_WEAPONS);
		String extra = "";
		if (mult != 1) {
			String com = getMaxDeficit(Commodities.SUPPLIES, Commodities.MARINES, Commodities.HAND_WEAPONS).one;
			extra = " (" + getDeficitText(com).toLowerCase() + ")";
		}
		market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD)
                    .modifyFlat(getModId(), DEFENSE_BONUS * mult, getNameForModifier() + extra);

        if (representative == null && isFunctional() && currTooltipMode != IndustryTooltipMode.ADD_INDUSTRY) {
            createRepresentative();
            addRepresentative();
        }
    }

    @Override
    public void unapply() {
        super.unapply();

        market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodifyFlat(getModId());
    }

    protected void createRepresentative() {
        representative = getFaction().createRandomPerson();
        representative.setRankId(SPP_Ranks.FACTION_REP);
        representative.setPostId(Ranks.POST_OUTPOST_COMMANDER);
    }

    protected void addRepresentative() {
        if (representative == null) return;

        if (market.getPeopleCopy().contains(representative)) return;

        market.addPerson(representative);
        market.getCommDirectory().addPerson(representative);
        market.getMemoryWithoutUpdate().set(SPP_MemKeys.FACTION_REP + "_" + getFaction().getId(), representative);

        ImportantPeopleAPI ip = Global.getSector().getImportantPeople();
        ip.addPerson(representative);
    }

    protected void removeRepresentative() {
        if (representative == null) return;

        market.removePerson(representative);
        market.getCommDirectory().removePerson(representative);
        market.getMemoryWithoutUpdate().unset(SPP_MemKeys.FACTION_REP + "_" + getFaction().getId());

		ImportantPeopleAPI ip = Global.getSector().getImportantPeople();
        ip.removePerson(representative);
    }

    @Override
    public void advance(float amount) {
        super.advance(amount);

        float days = Global.getSector().getClock().convertToDays(amount);

        interval.advance(days);

        // Every 30 seconds
        if (!interval.intervalElapsed()) return;

        if (isFunctional() && market.isPlayerOwned()) {
            CustomRepImpact impact = new CoreReputationPlugin.CustomRepImpact();
            impact.limit = RepLevel.FRIENDLY;
            impact.delta = REP_PER_MONTH / 100;
            RepActionEnvelope envelope = new RepActionEnvelope(CoreReputationPlugin.RepActions.CUSTOM, impact, null, null, false, true, "Change caused by " + getCurrentName() + " at " + market.getName());
            Global.getSector().adjustPlayerReputation(envelope, getFaction().getId());
        }
    }

    @Override
    public void notifyBeingRemoved(MarketAPI.MarketInteractionMode mode, boolean forUpgrade) {
        super.notifyBeingRemoved(mode, forUpgrade);

        removeRepresentative();
        // And delete them.
        representative = null;
    }

    protected abstract FactionAPI getFaction();

}
