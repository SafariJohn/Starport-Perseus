package campaign.econ.industries.factionBuildings;

import campaign.econ.industries.SPP_MilitaryBase;
import com.fs.starfarer.api.impl.campaign.ids.Factions;


public class SPP_StrategicModeler extends SPP_MilitaryBase {

	@Override
	public boolean isFunctional() {
		return super.isFunctional() && market.getFactionId().equals(Factions.TRITACHYON);
	}

	@Override
	public boolean isAvailableToBuild() {
		return false;
	}

	public boolean showWhenUnavailable() {
		return false;
	}
}
