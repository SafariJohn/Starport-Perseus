package campaign.econ.industries.factionBuildings;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;

/**
 * Author: SafariJohn
 */
public class SPP_Embassy extends SPP_BaseFactionBuilding {

    @Override
    public void apply() {
        super.apply();
    }


    @Override
    protected FactionAPI getFaction() {
        return Global.getSector().getFaction(Factions.PERSEAN);
    }
}
