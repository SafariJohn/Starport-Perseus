package campaign.econ.industries.factionBuildings;

import campaign.ids.SPP_Industries;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;

/**
 * Author: SafariJohn
 */
public class SPP_Monastery extends SPP_BaseFactionBuilding {

    @Override
    public void apply() {
        super.apply();
    }

    @Override
    protected FactionAPI getFaction() {
        if (getId().equals(SPP_Industries.MONASTERY)) {
            return Global.getSector().getFaction(Factions.LUDDIC_CHURCH);
        } else {
            return Global.getSector().getFaction(Factions.LUDDIC_PATH);
        }
    }

    @Override
    protected void createRepresentative() {
        super.createRepresentative();

        // Add Path representative
    }

    @Override
    public void notifyBeingRemoved(MarketAPI.MarketInteractionMode mode, boolean forUpgrade) {
        super.notifyBeingRemoved(mode, forUpgrade);

        // Remove Path representative
    }

}
