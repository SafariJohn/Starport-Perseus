package campaign.econ.industries.factionBuildings;

import campaign.econ.industries.SPP_MilitaryBase;
import campaign.econ.industries.SPP_RaiderBase;
import campaign.fleets.SPP_SystemWarFleetRouteManager;
import campaign.fleets.SPP_WarFleetRouteSource;
import campaign.ids.SPP_FleetTypes;
import java.util.Random;

import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactory.PatrolType;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactoryV3;
import com.fs.starfarer.api.impl.campaign.fleets.FleetParamsV3;
import com.fs.starfarer.api.impl.campaign.fleets.PatrolAssignmentAIV4;
import com.fs.starfarer.api.impl.campaign.fleets.RouteManager.RouteData;
import com.fs.starfarer.api.impl.campaign.ids.*;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import util.SPP_Misc;


public class SPP_LionsGuardHQ extends SPP_MilitaryBase {

	@Override
	public boolean isFunctional() {
		return super.isFunctional() && market.getFactionId().equals(Factions.DIKTAT);
    }

	@Override
	public boolean isAvailableToBuild() {
		return false;
	}

	public boolean showWhenUnavailable() {
		return false;
	}

    //<editor-fold defaultstate="collapsed" desc="Fleet Stuff">

    protected void initWarFleetSources() {
        localSource = new SPP_WarFleetRouteSource() {
            public FactionAPI getFaction() { return market.getFaction(); }

            public RouteData createRoute(StarSystemAPI system, String fleetType) {
                if (fleetType.equals(SPP_FleetTypes.WAR_FLEET_RAIDER)) {
                    return SPP_RaiderBase.createRaiderRoute(system, fleetType, market);
                }

                return SPP_MilitaryBase.createMilitaryRoute(system, fleetType, market);
            }

            public CampaignFleetAPI spawnFleet(RouteData route) {
                SPP_SystemWarFleetRouteManager.WarFleetData custom = (SPP_SystemWarFleetRouteManager.WarFleetData) route.getCustom();
                if (custom.warFleetType.equals(SPP_FleetTypes.WAR_FLEET_RAIDER)) {
                    return SPP_RaiderBase.createRaiderFleet(route, getFaction());
                }

                return createLionsGuardFleet(route);
            }

            public boolean shouldCancelRouteAfterDelayCheck(RouteData route) { return false; }
            public void reportAboutToBeDespawnedByRouteManager(RouteData route) {}
        };

        localSource.getFleetWeights().put(SPP_FleetTypes.WAR_FLEET_MILITARY, SPP_SystemWarFleetRouteManager.STANDARD_WEIGHT);
//        localSource.getFleetWeights().put(SPP_FleetTypes.WAR_FLEET_RAIDER, SPP_SystemWarFleetRouteManager.STANDARD_WEIGHT);
        localSource.getBonusFleets().put(SPP_FleetTypes.WAR_FLEET_MILITARY, 1);
//        localSource.getBonusFleets().put(SPP_FleetTypes.WAR_FLEET_RAIDER, 1);


        factionSource = new SPP_WarFleetRouteSource() {
            public FactionAPI getFaction() { return market.getFaction(); }

            public RouteData createRoute(StarSystemAPI system, String fleetType) {
                WeightedRandomPicker mPicker = new WeightedRandomPicker();
                for (MarketAPI iMarket : SPP_Misc.getMarketsInLocation(system, getFaction().getId())) {
                    mPicker.add(iMarket, iMarket.getSize());
                }

                MarketAPI from = (MarketAPI) mPicker.pick();

                if (from == null) return null;

                if (fleetType.equals(SPP_FleetTypes.WAR_FLEET_RAIDER)) {
                    return SPP_RaiderBase.createRaiderRoute(system, fleetType, from);
                }

                return SPP_MilitaryBase.createMilitaryRoute(system, fleetType, from);
            }

            public CampaignFleetAPI spawnFleet(RouteData route) {
                SPP_SystemWarFleetRouteManager.WarFleetData custom = (SPP_SystemWarFleetRouteManager.WarFleetData) route.getCustom();
                if (custom.warFleetType.equals(SPP_FleetTypes.WAR_FLEET_RAIDER)) {
                    return SPP_RaiderBase.createRaiderFleet(route, getFaction());
                }

                return createLionsGuardFleet(route);
            }

            public boolean shouldCancelRouteAfterDelayCheck(RouteData route) { return false; }
            public void reportAboutToBeDespawnedByRouteManager(RouteData route) {}
        };

        factionSource.getBonusFleets().put(SPP_FleetTypes.WAR_FLEET_MILITARY, 1);
//        factionSource.getBonusFleets().put(SPP_FleetTypes.WAR_FLEET_RAIDER, 1);
    }

    public static CampaignFleetAPI createLionsGuardFleet(RouteData route) {
        Random random = route.getRandom();
        if (random == null) random = new Random();

        MarketAPI from = route.getMarket();

        SPP_SystemWarFleetRouteManager.WarFleetData custom = (SPP_SystemWarFleetRouteManager.WarFleetData) route.getCustom();
        PatrolType type = custom.type;

        float combat = getPatrolCombatFP(type, random);
        float tanker = 0f;
        float freighter = 0f;
        String fleetType = SPP_FleetTypes.MILITARY_SMALL;
        switch (type) {
            case FAST:
                break;
            case COMBAT:
                fleetType = SPP_FleetTypes.MILITARY_MEDIUM;
                tanker = Math.round((float) random.nextFloat() * 5f);
                break;
            case HEAVY:
                fleetType = SPP_FleetTypes.MILITARY_LARGE;
                tanker = Math.round((float) random.nextFloat() * 10f);
                freighter = Math.round((float) random.nextFloat() * 10f);
                break;
        }

        FleetParamsV3 params = new FleetParamsV3(
                    from,
                    null,
                    Factions.LIONS_GUARD,
                    route.getQualityOverride(),
                    fleetType,
                    combat, // combatPts
                    freighter, // freighterPts
                    tanker, // tankerPts
                    0f, // transportPts
                    0f, // linerPts
                    0f, // utilityPts
                    0f // qualityMod
        );
        params.timestamp = route.getTimestamp();
        params.random = random;
        CampaignFleetAPI fleet = FleetFactoryV3.createFleet(params);

        if (fleet == null || fleet.isEmpty()) return null;

		fleet.setFaction(from.getFactionId(), true);
		fleet.setNoFactionInName(true);

        fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_WAR_FLEET, true);

        String postId = Ranks.POST_PATROL_COMMANDER;
        String rankId = Ranks.SPACE_COMMANDER;
        switch (type) {
            case FAST:
                rankId = Ranks.SPACE_LIEUTENANT;
                break;
            case COMBAT:
                rankId = Ranks.SPACE_COMMANDER;
                break;
            case HEAVY:
                rankId = Ranks.SPACE_CAPTAIN;
                break;
        }

        fleet.getCommander().setPostId(postId);
        fleet.getCommander().setRankId(rankId);

        from.getContainingLocation().addEntity(fleet);
        fleet.setFacing((float) Math.random() * 360f);
        // this will get overridden by the patrol assignment AI, depending on route-time elapsed etc
        fleet.setLocation(from.getPrimaryEntity().getLocation().x, from.getPrimaryEntity().getLocation().y);

        fleet.addScript(new PatrolAssignmentAIV4(fleet, route));

        //market.getContainingLocation().addEntity(fleet);
        //fleet.setLocation(market.getPrimaryEntity().getLocation().x, market.getPrimaryEntity().getLocation().y);

        if (custom.spawnFP <= 0) {
            custom.spawnFP = fleet.getFleetPoints();
        }

        return fleet;
    }
    //</editor-fold>
}
