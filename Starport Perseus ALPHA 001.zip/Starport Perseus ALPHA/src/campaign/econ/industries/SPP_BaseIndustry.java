package campaign.econ.industries;

import campaign.ids.SPP_Industries;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.comm.CommMessageAPI;
import com.fs.starfarer.api.campaign.econ.CommodityOnMarketAPI;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MutableCommodityQuantity;
import com.fs.starfarer.api.combat.MutableStat;
import com.fs.starfarer.api.combat.MutableStat.StatMod;
import com.fs.starfarer.api.impl.campaign.DebugFlags;
import com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry;
import static com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry.getDeficitText;
import com.fs.starfarer.api.impl.campaign.econ.impl.ConstructionQueue;
import com.fs.starfarer.api.impl.campaign.ids.Industries;
import com.fs.starfarer.api.impl.campaign.ids.Strings;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.impl.campaign.intel.MessageIntel;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.IconRenderMode;
import com.fs.starfarer.api.ui.LabelAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI.StatModValueGetter;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import java.util.Iterator;

/**
 * Author: SafariJohn
 */
public abstract class SPP_BaseIndustry extends BaseIndustry {
	public static final String BASE_VALUE_TEXT = "Base value for port size";
	public static final String BASE_POPULATION_TEXT = "Base value for population";

    @Override
	protected void demand(String commodityId, int quantity) {
		demand(0, commodityId, quantity, BASE_VALUE_TEXT);
	}

    @Override
	protected void supply(String commodityId, int quantity) {
		supply(0, commodityId, quantity, BASE_VALUE_TEXT);
	}

    @Override
    public boolean isAvailableToBuild() {
		return market.hasIndustry(SPP_Industries.SPACEPORT) && !getId().equals(SPP_Industries.SPACEPORT);
    }

    @Override
	public void createTooltip(IndustryTooltipMode mode, TooltipMakerAPI tooltip, boolean expanded) {
		currTooltipMode = mode;

		float pad = 3f;
		float opad = 10f;

		FactionAPI faction = market.getFaction();
		Color color = faction.getBaseUIColor();
		Color dark = faction.getDarkUIColor();
		Color grid = faction.getGridUIColor();
		Color bright = faction.getBrightUIColor();

		Color gray = Misc.getGrayColor();
		Color highlight = Misc.getHighlightColor();
		Color bad = Misc.getNegativeHighlightColor();


		MarketAPI copy = market.clone();
		MarketAPI orig = market;

		//int numBeforeAdd = Misc.getNumIndustries(market);

		market = copy;
		boolean needToAddIndustry = !market.hasIndustry(getId());
		//addDialogMode = true;
		if (needToAddIndustry) market.getIndustries().add(this);

		if (mode != IndustryTooltipMode.NORMAL) {
			market.clearCommodities();
			for (CommodityOnMarketAPI curr : market.getAllCommodities()) {
				curr.getAvailableStat().setBaseValue(100);
			}
		}

//		if (addDialogMode) {
//			market.reapplyConditions();
//			apply();
//		}
		market.reapplyConditions();
		reapply();

		String type = "";
		if (isIndustry()) type = " - Industry";
		if (isStructure()) type = " - Structure";

		tooltip.addTitle(getCurrentName() + type, color);

		String desc = spec.getDesc();
		String override = getDescriptionOverride();
		if (override != null) {
			desc = override;
		}
		desc = Global.getSector().getRules().performTokenReplacement(null, desc, market.getPrimaryEntity(), null);

		tooltip.addPara(desc, opad);

//		Industry inProgress = Misc.getCurrentlyBeingConstructed(market);
//		if ((mode == IndustryTooltipMode.ADD_INDUSTRY && inProgress != null) ||
//				(mode == IndustryTooltipMode.UPGRADE && inProgress != null)) {
//			//tooltip.addPara("Another project (" + inProgress.getCurrentName() + ") in progress", bad, opad);
//			//tooltip.addPara("Already building: " + inProgress.getCurrentName() + "", bad, opad);
//			tooltip.addPara("Another construction in progress: " + inProgress.getCurrentName() + "", bad, opad);
//		}

		//tooltip.addPara("Type: %s", opad, gray, highlight, type);
		if (isIndustry() && (mode == IndustryTooltipMode.ADD_INDUSTRY ||
				mode == IndustryTooltipMode.UPGRADE ||
				mode == IndustryTooltipMode.DOWNGRADE)
				) {

			int num = Misc.getNumIndustries(market);
			int max = Misc.getMaxIndustries(market);


			// during the creation of the tooltip, the market has both the current industry
			// and the upgrade/downgrade. So if this upgrade/downgrade counts as an industry, it'd count double if
			// the current one is also an industry. Thus reduce num by 1 if that's the case.
			if (isIndustry()) {
				if (mode == IndustryTooltipMode.UPGRADE) {
					for (Industry curr : market.getIndustries()) {
						if (getSpec().getId().equals(curr.getSpec().getUpgrade())) {
							if (curr.isIndustry()) {
								num--;
							}
							break;
						}
					}
				} else if (mode == IndustryTooltipMode.DOWNGRADE) {
					for (Industry curr : market.getIndustries()) {
						if (getSpec().getId().equals(curr.getSpec().getDowngrade())) {
							if (curr.isIndustry()) {
								num--;
							}
							break;
						}
					}
				}
			}

			Color c = gray;
			c = Misc.getTextColor();
			Color h1 = highlight;
			Color h2 = highlight;
			if (num > max) {// || (num >= max && mode == IndustryTooltipMode.ADD_INDUSTRY)) {
				//c = bad;
				h1 = bad;
				num--;

				tooltip.addPara("Maximum number of industries reached", bad, opad);
			}
			//tooltip.addPara("Maximum of %s industries on a colony of this size. Currently: %s.",
//			LabelAPI label = tooltip.addPara("Maximum industries for a colony of this size: %s. Industries: %s. ",
//					opad, c, h1, "" + max, "" + num);
//			label.setHighlightColors(h2, h1);
		}



		addRightAfterDescriptionSection(tooltip, mode);

		if (isDisrupted()) {
			int left = (int) getDisruptedDays();
			if (left < 1) left = 1;
			String days = "days";
			if (left == 1) days = "day";

			tooltip.addPara("Operations disrupted! %s " + days + " until return to normal function.",
					opad, Misc.getNegativeHighlightColor(), highlight, "" + left);
		}

		if (DebugFlags.COLONY_DEBUG || market.isPlayerOwned()) {
			if (mode == IndustryTooltipMode.NORMAL) {
				if (getSpec().getUpgrade() != null && !isBuilding()) {
					tooltip.addPara("Click to manage or upgrade", Misc.getPositiveHighlightColor(), opad);
				} else {
					tooltip.addPara("Click to manage", Misc.getPositiveHighlightColor(), opad);
				}
				//tooltip.addPara("Click to manage", market.getFaction().getBrightUIColor(), opad);
			}
		}

		if (mode == IndustryTooltipMode.QUEUED) {
			tooltip.addPara("Click to remove or adjust position in queue", Misc.getPositiveHighlightColor(), opad);
			tooltip.addPara("Currently queued for construction. Does not have any impact on the port.", opad);

			int left = (int) (getSpec().getBuildTime());
			if (left < 1) left = 1;
			String days = "days";
			if (left == 1) days = "day";
			tooltip.addPara("Requires %s " + days + " to build.", opad, highlight, "" + left);

			//return;
		} else if (!isFunctional() && mode == IndustryTooltipMode.NORMAL) {
			tooltip.addPara("Currently under construction and not producing anything or providing other benefits.", opad);

			int left = (int) (buildTime - buildProgress);
			if (left < 1) left = 1;
			String days = "days";
			if (left == 1) days = "day";
			tooltip.addPara("Requires %s more " + days + " to finish building.", opad, highlight, "" + left);
		}


		if (!isAvailableToBuild() &&
				(mode == IndustryTooltipMode.ADD_INDUSTRY ||
						mode == IndustryTooltipMode.UPGRADE ||
						mode == IndustryTooltipMode.DOWNGRADE)) {
			String reason = getUnavailableReason();
			if (reason != null) {
				tooltip.addPara(reason, bad, opad);
			}
		}

		boolean category = getSpec().hasTag(Industries.TAG_PARENT);

		if (!category) {
			int credits = (int) Global.getSector().getPlayerFleet().getCargo().getCredits().get();
			String creditsStr = Misc.getDGSCredits(credits);
			if (mode == IndustryTooltipMode.UPGRADE || mode == IndustryTooltipMode.ADD_INDUSTRY) {
				int cost = (int) getBuildCost();
				String costStr = Misc.getDGSCredits(cost);

				int days = (int) getBuildTime();
				String daysStr = "days";
				if (days == 1) daysStr = "day";

				LabelAPI label = null;
				if (mode == IndustryTooltipMode.UPGRADE) {
					label = tooltip.addPara("%s and %s " + daysStr + " to upgrade. You have %s.", opad,
											highlight, costStr, "" + days, creditsStr);
				} else {
					label = tooltip.addPara("%s and %s " + daysStr + " to build. You have %s.", opad,
											highlight, costStr, "" + days, creditsStr);
				}
				label.setHighlight(costStr, "" + days, creditsStr);
				if (credits >= cost) {
					label.setHighlightColors(highlight, highlight, highlight);
				} else {
					label.setHighlightColors(bad, highlight, highlight);
				}
			} else if (mode == IndustryTooltipMode.DOWNGRADE) {
				float refundFraction = Global.getSettings().getFloat("industryRefundFraction");
				int cost = (int) (getBuildCost() * refundFraction);
				String refundStr = Misc.getDGSCredits(cost);

				tooltip.addPara("%s refunded for downgrade.", opad, highlight, refundStr);
			}


			addPostDescriptionSection(tooltip, mode);

			if (!getIncome().isUnmodified()) {
				int income = getIncome().getModifiedInt();
				tooltip.addPara("Monthly income: %s", opad, highlight, Misc.getDGSCredits(income));
				tooltip.addStatModGrid(250, 65, 10, pad, getIncome(), true, new TooltipMakerAPI.StatModValueGetter() {
					public String getPercentValue(MutableStat.StatMod mod) {return null;}
					public String getMultValue(MutableStat.StatMod mod) {return null;}
					public Color getModColor(MutableStat.StatMod mod) {return null;}
					public String getFlatValue(MutableStat.StatMod mod) {
						return Misc.getWithDGS(mod.value) + Strings.C;
					}
				});
			}

			if (!getUpkeep().isUnmodified()) {
				int upkeep = getUpkeep().getModifiedInt();
				tooltip.addPara("Monthly upkeep: %s", opad, highlight, Misc.getDGSCredits(upkeep));
				tooltip.addStatModGrid(250, 65, 10, pad, getUpkeep(), true, new TooltipMakerAPI.StatModValueGetter() {
					public String getPercentValue(MutableStat.StatMod mod) {return null;}
					public String getMultValue(MutableStat.StatMod mod) {return null;}
					public Color getModColor(MutableStat.StatMod mod) {return null;}
					public String getFlatValue(MutableStat.StatMod mod) {
						return Misc.getWithDGS(mod.value) + Strings.C;
					}
				});
			}

			addPostUpkeepSection(tooltip, mode);

			boolean hasSupply = false;
			for (MutableCommodityQuantity curr : supply.values()) {
				int qty = curr.getQuantity().getModifiedInt();
				if (qty <= 0) continue;
				hasSupply = true;
				break;
			}
			boolean hasDemand = false;
			for (MutableCommodityQuantity curr : demand.values()) {
				int qty = curr.getQuantity().getModifiedInt();
				if (qty <= 0) continue;
				hasDemand = true;
				break;
			}

			float maxIconsPerRow = 10f;
			if (hasSupply) {
				tooltip.addSectionHeading("Production", color, dark, Alignment.MID, opad);
				tooltip.beginIconGroup();
				tooltip.setIconSpacingMedium();
				float icons = 0;
				for (MutableCommodityQuantity curr : supply.values()) {
					int qty = curr.getQuantity().getModifiedInt();
					//if (qty <= 0) continue;

					int normal = qty;
					if (normal > 0) {
						tooltip.addIcons(market.getCommodityData(curr.getCommodityId()), normal, IconRenderMode.NORMAL);
					}

					int plus = 0;
					int minus = 0;
					for (MutableStat.StatMod mod : curr.getQuantity().getFlatMods().values()) {
						if (mod.value > 0) {
							plus += (int) mod.value;
						} else if (mod.desc != null && mod.desc.contains("shortage")) {
							minus += (int) Math.abs(mod.value);
						}
					}
					minus = Math.min(minus, plus);
					if (minus > 0 && mode == IndustryTooltipMode.NORMAL) {
						tooltip.addIcons(market.getCommodityData(curr.getCommodityId()), minus, IconRenderMode.DIM_RED);
					}
					icons += normal + Math.max(0, minus);
				}
				int rows = (int) Math.ceil(icons / maxIconsPerRow);
				rows = 3;
				tooltip.addIconGroup(32, rows, opad);


			}
//			else if (!isFunctional() && mode == IndustryTooltipMode.NORMAL) {
//				tooltip.addPara("Currently under construction and not producing anything or providing other benefits.", opad);
//			}

			addPostSupplySection(tooltip, hasSupply, mode);

			if (hasDemand || hasPostDemandSection(hasDemand, mode)) {
				tooltip.addSectionHeading("Demand & effects", color, dark, Alignment.MID, opad);
			}
			if (hasDemand) {
				tooltip.beginIconGroup();
				tooltip.setIconSpacingMedium();
				float icons = 0;
				for (MutableCommodityQuantity curr : demand.values()) {
					int qty = curr.getQuantity().getModifiedInt();
					if (qty <= 0) continue;

					CommodityOnMarketAPI com = orig.getCommodityData(curr.getCommodityId());
					int available = com.getAvailable();

					int normal = Math.min(available, qty);
					int red = Math.max(0, qty - available);

					if (mode != IndustryTooltipMode.NORMAL) {
						normal = qty;
						red = 0;
					}
					if (normal > 0) {
						tooltip.addIcons(com, normal, IconRenderMode.NORMAL);
					}
					if (red > 0) {
						tooltip.addIcons(com, red, IconRenderMode.DIM_RED);
					}
					icons += normal + Math.max(0, red);
				}
				int rows = (int) Math.ceil(icons / maxIconsPerRow);
				rows = 3;
				rows = 1;
				tooltip.addIconGroup(32, rows, opad);
			}

			addPostDemandSection(tooltip, hasDemand, mode);

			if (!needToAddIndustry) {
				//addAICoreSection(tooltip, AICoreDescriptionMode.TOOLTIP);
				addInstalledItemsSection(mode, tooltip, expanded);
			}

			tooltip.addPara("*Shown production and demand values are already adjusted based on current market size and local conditions.", gray, opad);
		}

		if (needToAddIndustry) {
			unapply();
			market.getIndustries().remove(this);
		}
		market = orig;
		if (!needToAddIndustry) {
			reapply();
		}
	}

    @Override
	protected void buildingFinished() {
		sendBuildOrUpgradeMessage();
		buildNextInQueue(market);
	}

	public static void buildNextInQueue(MarketAPI market) {
		ConstructionQueue.ConstructionQueueItem next = null;
		Iterator<ConstructionQueue.ConstructionQueueItem> iter = market.getConstructionQueue().getItems().iterator();
		while (iter.hasNext()) {
			next = iter.next();
			iter.remove();

			Industry ind = market.instantiateIndustry(next.id);

			int num = Misc.getNumIndustries(market);
			int max = Misc.getMaxIndustries(market);
			if (ind.isAvailableToBuild() && (num <= max || !ind.isIndustry())) { // <= because num includes what's queued
				break;
			} else {
				if (market.isPlayerOwned()) {
					MessageIntel intel = new MessageIntel(ind.getCurrentName() + " at " + market.getName(), Misc.getBasePlayerColor());
					intel.addLine(BaseIntelPlugin.BULLET + "Construction aborted");

					int refund = next.cost;
					Global.getSector().getPlayerFleet().getCargo().getCredits().add(refund);
					intel.addLine(BaseIntelPlugin.BULLET + "%s refunded",
							Misc.getTextColor(),
							new String [] {Misc.getDGSCredits(refund)}, Misc.getHighlightColor());
					intel.setIcon(Global.getSector().getPlayerFaction().getCrest());
					intel.setSound(BaseIntelPlugin.getSoundStandardUpdate());
					Global.getSector().getCampaignUI().addMessage(intel, CommMessageAPI.MessageClickAction.COLONY_INFO, market);
				}
				next = null;
			}
		}

		if (next != null) {
			market.addIndustry(next.id);
			Industry ind = market.getIndustry(next.id);
			ind.startBuilding();

            if (next.id.equals(SPP_Industries.LOCAL_ECONOMY)) return;

			if (market.isPlayerOwned()) {
				MessageIntel intel = new MessageIntel(ind.getCurrentName() + " at " + market.getName(), Misc.getBasePlayerColor());
				intel.addLine(BaseIntelPlugin.BULLET + "Construction started");
				intel.setIcon(Global.getSector().getPlayerFaction().getCrest());
				intel.setSound(BaseIntelPlugin.getSoundStandardUpdate());
				Global.getSector().getCampaignUI().addMessage(intel, CommMessageAPI.MessageClickAction.COLONY_INFO, market);
			}
		}
	}

    @Override
    protected void addGroundDefensesImpactSection(TooltipMakerAPI tooltip, float bonus, String... commodities) {
        if (bonus > 0 && bonus < 10) {
            super.addGroundDefensesImpactSection(tooltip, bonus, commodities);
            return;
        }

		Color h = Misc.getHighlightColor();
		float opad = 10f;

		MutableStat fake = new MutableStat(0);

		fake.modifyFlat("1", bonus, getNameForModifier());

		if (commodities != null) {
			float mult = getDeficitMult(commodities);
			//mult = 0.89f;
			if (mult != 1) {
				String com = getMaxDeficit(commodities).one;
				fake.modifyFlat("2", -(1f - mult) * bonus, getDeficitText(com));
			}
		}

		float total = Misc.getRoundedValueFloat(fake.getModifiedValue());
		String totalStr = "+" + (int) total;
		if (total < bonus) {
			h = Misc.getNegativeHighlightColor();
		}
		float pad = 3f;
		tooltip.addPara("Ground defense strength: %s", opad, h, totalStr);
		tooltip.addStatModGrid(400, 40, opad, pad, fake, new StatModValueGetter() {
			public String getPercentValue(MutableStat.StatMod mod) {
				return null;
			}
			public String getMultValue(StatMod mod) {
				return null;
			}
			public Color getModColor(StatMod mod) {
				if (mod.value < 0) return Misc.getNegativeHighlightColor();
				return null;
			}
			public String getFlatValue(StatMod mod) {
				String r = Misc.getRoundedValue(mod.value);
				if (mod.value >= 0) return "+" + r;
				return r;
			}
		});
    }

	protected void addStabilityPostDemandSection(TooltipMakerAPI tooltip, boolean hasDemand, IndustryTooltipMode mode) {
		Color h = Misc.getHighlightColor();
		float opad = 10f;

		MutableStat fake = new MutableStat(0);
		int stabilityMod = getBaseStabilityMod();
		int stabilityPenalty = getStabilityPenalty();

		if (stabilityPenalty > stabilityMod) {
			stabilityPenalty = stabilityMod;
		}

		String str = getDeficitText(getStabilityAffectingDeficit().one);
		fake.modifyFlat("1", stabilityMod, getNameForModifier());
		if (stabilityPenalty != 0) {
			fake.modifyFlat("2", -stabilityPenalty, str);
		}

		int total = stabilityMod - stabilityPenalty;
		String totalStr = "+" + total;
		if (total < 0) {
			totalStr = "" + total;
			h = Misc.getNegativeHighlightColor();
		}
		float pad = 3f;
		if (total >= 0) {
			tooltip.addPara("Stability bonus: %s", opad, h, totalStr);
		} else {
			tooltip.addPara("Stability penalty: %s", opad, h, totalStr);
		}
		tooltip.addStatModGrid(400, 40, opad, pad, fake, new StatModValueGetter() {
			public String getPercentValue(StatMod mod) {
				return null;
			}
			public String getMultValue(StatMod mod) {
				return null;
			}
			public Color getModColor(StatMod mod) {
				if (mod.value < 0) return Misc.getNegativeHighlightColor();
				return null;
			}
			public String getFlatValue(StatMod mod) {
				return null;
			}
		});
	}
}




