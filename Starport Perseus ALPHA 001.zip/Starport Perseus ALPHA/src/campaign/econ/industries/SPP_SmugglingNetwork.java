package campaign.econ.industries;

import campaign.econ.SPP_ResourceDepositsCondition;
import campaign.ids.SPP_MemKeys;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.combat.MutableStat;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Pair;
import java.awt.Color;
import util.SPP_PortFunctions;

/**
 * Author: SafariJohn
 */
public class SPP_SmugglingNetwork extends SPP_BaseIndustry {
	public static final float ACCESSIBILITY_BONUS = 0.1f;
	public static final float TRADE_WEIGHT_MULT = 2f;

	public static final float ALPHA_CORE_ACCESSIBILITY = 0.1f;
	public static final float ALPHA_CORE_TRADE_WEIGHT_MULT = 1.5f;

    @Override
    public void apply() {
        int scalingSize = SPP_PortFunctions.getPortCommoditySize(market.getSize());

        Pair<String, Integer> deficit;
        if (market.isIllegal(Commodities.LUXURY_GOODS)) {
            demand(Commodities.METALS, scalingSize);
            supply(Commodities.LUXURY_GOODS, scalingSize - 2);
            deficit = getMaxDeficit(Commodities.METALS);
            applyDeficitToProduction(1, deficit, Commodities.LUXURY_GOODS);
        }

        demand(Commodities.ORGANICS, scalingSize);
        supply(Commodities.DRUGS, scalingSize);

        deficit = getMaxDeficit(Commodities.ORGANICS);
		applyDeficitToProduction(1, deficit, Commodities.DRUGS);

//        demand(Commodities.SUPPLIES, scalingSize);
//        demand(Commodities.FUEL, scalingSize);
//        demand(Commodities.SHIPS, scalingSize);
        demand(Commodities.CREW, scalingSize);

        // Increases weight for smuggling fleets to spawn here
        // and allows them to be of the port's faction (indies are always allowed)
        MutableStat fleetWeight = (MutableStat) market.getMemoryWithoutUpdate()
                    .get(SPP_MemKeys.TRADE_FLEET_WEIGHT);
        if (fleetWeight == null) {
            fleetWeight = new MutableStat(1);
            market.getMemoryWithoutUpdate().set(SPP_MemKeys.TRADE_FLEET_WEIGHT, fleetWeight);
        }

        float penalty = 0;
		deficit = getMaxDeficit(Commodities.CREW, Commodities.FUEL, Commodities.SUPPLIES, Commodities.SHIPS);
		if (deficit.two > 0) {
            penalty += (float) deficit.two / 10f;
		}

        float weightMult = TRADE_WEIGHT_MULT - penalty;

        fleetWeight.modifyMult(getNameForModifier(), weightMult);
        market.getMemoryWithoutUpdate().set(SPP_MemKeys.SPAWN_SMUGGLER_FLEETS, true);

		float a = ACCESSIBILITY_BONUS;
		if (a > 0) {
			market.getAccessibilityMod().modifyFlat(getModId(0), a, getNameForModifier());
		}

		if (!isFunctional()) {
			supply.clear();
			unapply();
		}
	}

	@Override
	public void unapply() {
		super.unapply();

        MutableStat weight = (MutableStat) market.getMemoryWithoutUpdate()
                    .get(SPP_MemKeys.TRADE_FLEET_WEIGHT);
        weight.unmodifyMult(getNameForModifier());
        market.getMemoryWithoutUpdate().unset(SPP_MemKeys.SPAWN_SMUGGLER_FLEETS);

		market.getAccessibilityMod().unmodifyFlat(getModId(0));
	}

	protected boolean hasPostDemandSection(boolean hasDemand, IndustryTooltipMode mode) {
		return mode != IndustryTooltipMode.NORMAL || isFunctional();
	}

	@Override
	protected void addPostDemandSection(TooltipMakerAPI tooltip, boolean hasDemand, IndustryTooltipMode mode) {
		if (mode != IndustryTooltipMode.NORMAL || isFunctional()) {
			MutableStat fake = new MutableStat(0);

			String desc = getNameForModifier();
			float a = ACCESSIBILITY_BONUS;
			if (a > 0) {
				fake.modifyFlat(getModId(0), a, desc);
			}
			float total = a;
			String totalStr = "+" + (int)Math.round(total * 100f) + "%";
			Color h = Misc.getHighlightColor();
			if (total < 0) {
				h = Misc.getNegativeHighlightColor();
				totalStr = "" + (int)Math.round(total * 100f) + "%";
			}
			float opad = 10f;
			float pad = 3f;
			if (total >= 0) {
				tooltip.addPara("Accessibility bonus: %s", opad, h, totalStr);
			} else {
				tooltip.addPara("Accessibility penalty: %s", opad, h, totalStr);
			}

            tooltip.addPara(market.getFaction().getEntityNamePrefix() + " smugglers allowed and more trade fleets originate at this port.", opad);
		}
	}


	@Override
	protected void applyAlphaCoreModifiers() {
		market.getAccessibilityMod().modifyFlat(getModId(2), ALPHA_CORE_ACCESSIBILITY, "Alpha core (" + getNameForModifier() + ")");

        // Increase trade fleet chance
        MutableStat fleetWeight = (MutableStat) market.getMemoryWithoutUpdate()
                    .get(SPP_MemKeys.TRADE_FLEET_WEIGHT);
        if (fleetWeight == null) {
            fleetWeight = new MutableStat(1);
            market.getMemoryWithoutUpdate().set(SPP_MemKeys.TRADE_FLEET_WEIGHT, fleetWeight);
        }

        fleetWeight.modifyMult( "Alpha core (" + getNameForModifier() + ")", ALPHA_CORE_TRADE_WEIGHT_MULT);

	}

	@Override
	protected void applyNoAICoreModifiers() {
		market.getAccessibilityMod().unmodifyFlat(getModId(2));

        MutableStat fleetWeight = (MutableStat) market.getMemoryWithoutUpdate()
                    .get(SPP_MemKeys.TRADE_FLEET_WEIGHT);
        if (fleetWeight == null) {
            fleetWeight = new MutableStat(1);
            market.getMemoryWithoutUpdate().set(SPP_MemKeys.TRADE_FLEET_WEIGHT, fleetWeight);
        }

        fleetWeight.unmodifyMult( "Alpha core (" + getNameForModifier() + ")");
	}

    @Override
	protected void addAlphaCoreDescription(TooltipMakerAPI tooltip, AICoreDescriptionMode mode) {
		float opad = 10f;
		Color highlight = Misc.getHighlightColor();

		String pre = "Alpha-level AI core currently assigned. ";
		if (mode == AICoreDescriptionMode.MANAGE_CORE_DIALOG_LIST || mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
			pre = "Alpha-level AI core. ";
		}
		float a = ALPHA_CORE_ACCESSIBILITY;
		String aStr = "" + (int)Math.round(a * 100f) + "%";

		if (mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
			CommoditySpecAPI coreSpec = Global.getSettings().getCommoditySpec(aiCoreId);
			TooltipMakerAPI text = tooltip.beginImageWithText(coreSpec.getIconName(), 48);
			text.addPara(pre + "Reduces upkeep cost by %s. Reduces demand by %s unit. " +
                    "Increases accessibility by %s. More trade fleets originate here.", 0f, highlight,
					"" + (int)((1f - UPKEEP_MULT) * 100f) + "%", "" + DEMAND_REDUCTION,	aStr);
			tooltip.addImageWithText(opad);
			return;
		}

		tooltip.addPara(pre + "Reduces upkeep cost by %s. Reduces demand by %s unit. " +
                "Increases accessibility by %s. More trade fleets originate here.", opad, highlight,
				"" + (int)((1f - UPKEEP_MULT) * 100f) + "%", "" + DEMAND_REDUCTION, aStr);

	}

    @Override
    public float getPatherInterest() {
        return 2f + super.getPatherInterest();
    }
}
