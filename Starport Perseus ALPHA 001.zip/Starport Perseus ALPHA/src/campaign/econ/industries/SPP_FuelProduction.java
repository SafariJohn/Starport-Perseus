package campaign.econ.industries;

import campaign.ids.SPP_Conditions;
import campaign.ids.SPP_Industries;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.SpecialItemSpecAPI;
import com.fs.starfarer.api.campaign.econ.CommodityOnMarketAPI;
import com.fs.starfarer.api.campaign.econ.InstallableIndustryItemPlugin;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.econ.impl.SynchrotronInstallableItemPlugin;
import com.fs.starfarer.api.impl.campaign.econ.impl.SynchrotronInstallableItemPlugin.SynchrotronEffect;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Pair;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import util.SPP_PortFunctions;

/**
 * Author: SafariJohn
 */
public class SPP_FuelProduction extends SPP_BaseIndustry {
    private boolean isDomainTech() {
        return market.getFaction().knowsIndustry(SPP_Industries.DOMAIN_FUEL);
    }

	public void apply() {
		super.apply(true);

        int mSize = market.getSize();

        applyIncomeAndUpkeep(mSize);

		int size = SPP_PortFunctions.getPortCommoditySize(mSize);

        if (!isDomainTech()) {
            size--;
        }

        if (!market.hasCondition(SPP_Conditions.SYNCHROTRON)
                    && currTooltipMode == IndustryTooltipMode.NORMAL
                    && isDomainTech()) {
            market.addCondition(SPP_Conditions.SYNCHROTRON);
        }

		demand(Commodities.VOLATILES, size - 1);
		demand(Commodities.RARE_METALS, size - 1);

        supply(getModId(0), Commodities.FUEL, size - 2, BASE_VALUE_TEXT);

		applySynchrotronEffects();

		Pair<String, Integer> deficit = getMaxDeficit(
                    Commodities.VOLATILES,
                    Commodities.RARE_METALS);

		applyDeficitToProduction(1, deficit, Commodities.FUEL);

		if (!isFunctional()) {
			supply.clear();
            demand.clear();
		}
	}


	@Override
	public void unapply() {
		super.unapply();

		if (synchrotron != null) {
			SynchrotronEffect effect = SynchrotronInstallableItemPlugin
                        .SYNCHROTRON_EFFECTS.get(synchrotron.getId());
			if (effect != null) {
				effect.unapply(this);
			}
		}
	}

    @Override
    public void finishBuildingOrUpgrading() {
        super.finishBuildingOrUpgrading();

        if (isDomainTech()
                    && !market.hasCondition(SPP_Conditions.SYNCHROTRON)) {
            market.addCondition(SPP_Conditions.SYNCHROTRON);
        }
    }

    @Override
    public boolean isFunctional() {
        int fuel = SPP_PortFunctions.getPortCommoditySize(market.getSize());

        boolean domainTech = isDomainTech();
        if (domainTech) {
            fuel -= 2;
        } else {
            fuel -= 3;
        }

        if (synchrotron != null) {
            fuel += 3;
        } else if (!market.hasCondition(SPP_Conditions.SYNCHROTRON)
                    && !domainTech) {
            fuel = 0;
        }

        if (fuel <= 0) return false;

        return super.isFunctional();
    }

    @Override
    public String getCurrentName() {
        if (isDomainTech()) {
			return "Domain-tech Fuel Production";
		}
        return super.getCurrentName();
    }


	@Override
	public String getCurrentImage() {
        if (isDomainTech()) {
			return Global.getSettings().getSpriteName("industry", "advanced_fuel_prod");
		}
		return super.getCurrentImage();
	}

    @Override
    protected String getDescriptionOverride() {
        if (isDomainTech()) {
            if (market.getSize() >= SPP_Spaceport.MEGAPORT_SIZE) {
                return "A massive Domain-tech facility produces "
                            + "starship fuel, the life-blood of "
                            + "interstellar civilization.";
            }

            return "A Domain-tech facility produces starship "
                        + "fuel, the life-blood of "
                        + "interstellar civilization.";
        }
        return super.getDescriptionOverride();
    }

    @Override
    protected void addRightAfterDescriptionSection(TooltipMakerAPI tooltip, IndustryTooltipMode mode) {
        if (!market.hasCondition(SPP_Conditions.SYNCHROTRON)
                    && synchrotron == null && !isDomainTech()) {
			float opad = 10f;
            tooltip.addPara("Producing fuel requires a synchrotron "
                        + "or synchrotron core.",
                        Misc.getNegativeHighlightColor(), opad);
        }
    }

    @Override
    public boolean isAvailableToBuild() {
        if (!super.isAvailableToBuild()) return false;

        return id.equals(SPP_Industries.DOMAIN_FUEL) == isDomainTech();
    }

    @Override
    public boolean showWhenUnavailable() {
        if (!super.isAvailableToBuild()) return false;

        return id.equals(SPP_Industries.DOMAIN_FUEL) == isDomainTech();
    }




	protected void applySynchrotronEffects() {
		if (synchrotron != null) {
			SynchrotronInstallableItemPlugin.SynchrotronEffect effect = SynchrotronInstallableItemPlugin.SYNCHROTRON_EFFECTS.get(synchrotron.getId());
			if (effect != null) {
				effect.apply(this);
			}
		}
	}

	protected SpecialItemData synchrotron = null;
	public void setSynchrotron(SpecialItemData synchrotron) {
		if (synchrotron == null && this.synchrotron != null) {
			SynchrotronInstallableItemPlugin.SynchrotronEffect effect = SynchrotronInstallableItemPlugin.SYNCHROTRON_EFFECTS.get(this.synchrotron.getId());
			if (effect != null) {
				effect.unapply(this);
			}
		}
		this.synchrotron = synchrotron;
	}

	public SpecialItemData getSynchrotron() {
		return synchrotron;
	}

	public SpecialItemData getSpecialItem() {
		return synchrotron;
	}

	public void setSpecialItem(SpecialItemData special) {
		synchrotron = special;
	}

	@Override
	public boolean wantsToUseSpecialItem(SpecialItemData data) {
		return synchrotron == null &&
				data != null &&
				SynchrotronInstallableItemPlugin.SYNCHROTRON_EFFECTS.containsKey(data.getId());
	}

	@Override
	public void notifyBeingRemoved(MarketAPI.MarketInteractionMode mode, boolean forUpgrade) {
		super.notifyBeingRemoved(mode, forUpgrade);
		if (synchrotron != null && !forUpgrade) {
			CargoAPI cargo = getCargoForInteractionMode(mode);
			if (cargo != null) {
				cargo.addSpecial(synchrotron, 1);
			}
		}
	}

	@Override
	protected boolean addNonAICoreInstalledItems(IndustryTooltipMode mode, TooltipMakerAPI tooltip, boolean expanded) {
		if (synchrotron == null) return false;

		float opad = 10f;

		FactionAPI faction = market.getFaction();
		Color color = faction.getBaseUIColor();
		Color dark = faction.getDarkUIColor();


		SpecialItemSpecAPI spec = Global.getSettings().getSpecialItemSpec(synchrotron.getId());

		TooltipMakerAPI text = tooltip.beginImageWithText(spec.getIconName(), 48);
		SynchrotronInstallableItemPlugin.SynchrotronEffect effect = SynchrotronInstallableItemPlugin.SYNCHROTRON_EFFECTS.get(synchrotron.getId());
		effect.addItemDescription(text, synchrotron, InstallableIndustryItemPlugin.InstallableItemDescriptionMode.INDUSTRY_TOOLTIP);
		tooltip.addImageWithText(opad);

		return true;
	}

	public boolean isDemandLegal(CommodityOnMarketAPI com) {
		return true;
	}

	public boolean isSupplyLegal(CommodityOnMarketAPI com) {
		return true;
	}

	@Override
	public List<InstallableIndustryItemPlugin> getInstallableItems() {
		ArrayList<InstallableIndustryItemPlugin> list = new ArrayList<InstallableIndustryItemPlugin>();
		list.add(new SPP_SynchrotronInstallableItemPlugin(this));
		return list;
	}

	@Override
	public void initWithParams(List<String> params) {
		super.initWithParams(params);

		for (String str : params) {
			if (SynchrotronInstallableItemPlugin.SYNCHROTRON_EFFECTS.containsKey(str)) {
				setSynchrotron(new SpecialItemData(str, null));
				break;
			}
		}
	}

	@Override
	public List<SpecialItemData> getVisibleInstalledItems() {
		List<SpecialItemData> result = super.getVisibleInstalledItems();

		if (synchrotron != null) {
			result.add(synchrotron);
		}

		return result;
	}

	public float getPatherInterest() {
		float base = 2f;
		if (synchrotron != null) base += 4f;
		return base + super.getPatherInterest();
	}
}
