package campaign.econ.industries;

import com.fs.starfarer.api.campaign.econ.CommodityOnMarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.util.Pair;
import util.SPP_PortFunctions;

/**
 * Author: SafariJohn
 */
public class SPP_HeavyIndustry extends SPP_BaseIndustry {

	public void apply() {
		super.apply(true);

		int size = SPP_PortFunctions.getPortCommoditySize(market.getSize());

        applyIncomeAndUpkeep(size);

		demand(Commodities.METALS, size);
		demand(Commodities.RARE_METALS, size - 2);
		demand(Commodities.VOLATILES, size - 2);

		supply(Commodities.HEAVY_MACHINERY, size);
		supply(Commodities.HAND_WEAPONS, size);

		Pair<String, Integer> deficit = getMaxDeficit(Commodities.METALS, Commodities.RARE_METALS);
		int maxDeficit = size - 3; // to allow *some* production so economy doesn't get into an unrecoverable state
		if (deficit.two > maxDeficit) deficit.two = maxDeficit;

		applyDeficitToProduction(1, deficit, Commodities.HEAVY_MACHINERY);


        deficit = getMaxDeficit(Commodities.METALS, Commodities.RARE_METALS, Commodities.VOLATILES);
		applyDeficitToProduction(2, deficit, Commodities.HAND_WEAPONS);

		if (!isFunctional()) {
			supply.clear();
		}
	}

	public boolean isDemandLegal(CommodityOnMarketAPI com) {
		return true;
	}

	public boolean isSupplyLegal(CommodityOnMarketAPI com) {
		return true;
	}


	public float getPatherInterest() {
		return 2f + super.getPatherInterest();
	}

}
