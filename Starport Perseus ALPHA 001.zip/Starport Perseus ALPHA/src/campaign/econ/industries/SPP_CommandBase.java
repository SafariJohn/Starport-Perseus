package campaign.econ.industries;

import campaign.econ.SPP_ResourceDepositsCondition;
import static campaign.econ.industries.SPP_Shipyard.BASE_QUALITY_BONUS;
import campaign.ids.SPP_Industries;
import campaign.ids.SPP_MemKeys;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.econ.CommodityOnMarketAPI;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.combat.MutableStat;
import com.fs.starfarer.api.impl.campaign.ids.*;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Pair;
import java.awt.Color;
import util.SPP_Misc;
import util.SPP_PortFunctions;

/**
 * Author: SafariJohn
 */
public class SPP_CommandBase extends SPP_BaseIndustry {
	public static final float ACCESSIBILITY_BONUS = 0.1f;
    public static final int STABILITY_MOD = 2;
	public static final float TRADE_WEIGHT_MULT = 2f;

	public static final float ALPHA_CORE_ACCESSIBILITY = 0.1f;
	public static final float ALPHA_CORE_TRADE_WEIGHT_MULT = 1.5f;
	public static final float ALPHA_CORE_STRENGTH_BONUS = 0.25f;

	public static final float DEFENSE_BONUS = 1000f;

    private String uid;
    private String[] uids;

    @Override
    public void init(String id, MarketAPI market) {
        super.init(id, market);

        uid = id + market.getId() + SPP_Misc.genUID();
		uids = new String[10];
		for (int i = 0; i < uids.length; i++) {
			uids[i] = uid + "_" + i;
		}
    }

    @Override
    public boolean isAvailableToBuild() {
        for (MarketAPI m : Global.getSector().getEconomy().getMarketsCopy()) {
            if (m.getFaction() != market.getFaction()) continue;

            for (Industry mc : m.getIndustries()) {
                if (mc instanceof SPP_CommandBase) {
                    SPP_CommandBase ind = (SPP_CommandBase) mc;
                    // Have to avoid detecting the preview industry
                    // the user is looking at.
                    if (!uid.equals(ind.getUID())) return false;
                }
            }
        }

        return true;
    }

    @Override
    public boolean showWhenUnavailable() {
        return false;
    }

    @Override
    public String getUnavailableReason() {
        return "You can only have one High Command";
    }

    @Override
    public void apply() {
		super.apply(true);

		int size = 2 + SPP_ResourceDepositsCondition.RESOURCE_STRUCTURE_BASE_SIZE;
        int scalingSize = SPP_PortFunctions.getPortCommoditySize(market.getSize());
        int adjustedSize = Math.max(size, scalingSize);
        adjustedSize = size + (int) (scalingSize * 0.3f);

//        Ship quality bonus
        market.getStats().getDynamic().getMod(Stats.FLEET_QUALITY_MOD)
                    .modifyFlat(getModId(0), BASE_QUALITY_BONUS, getNameForModifier());

        // Patrol size weights
		market.getStats().getDynamic().getMod(Stats.PATROL_NUM_LIGHT_MOD).modifyFlat(getModId(), 3);
		market.getStats().getDynamic().getMod(Stats.PATROL_NUM_MEDIUM_MOD).modifyFlat(getModId(), 2);
		market.getStats().getDynamic().getMod(Stats.PATROL_NUM_HEAVY_MOD).modifyFlat(getModId(), 1);


		demand(Commodities.SUPPLIES, adjustedSize);
		demand(Commodities.FUEL, adjustedSize);
		demand(Commodities.SHIPS, adjustedSize);
		demand(Commodities.CREW, adjustedSize);

		modifyStabilityWithBaseMod();

		MemoryAPI memory = market.getMemoryWithoutUpdate();
		Misc.setFlagWithReason(memory, MemFlags.MARKET_PATROL, getModId(), true, -1);
        Misc.setFlagWithReason(memory, MemFlags.MARKET_MILITARY, getModId(), true, -1);

        market.getAccessibilityMod().modifyFlat(getModId(0), getAccessibilityBonus(), getNameForModifier());

        // Increase trade fleet chance
        MutableStat fleetWeight = (MutableStat) market.getMemoryWithoutUpdate()
                    .get(SPP_MemKeys.TRADE_FLEET_WEIGHT);
        if (fleetWeight == null) {
            fleetWeight = new MutableStat(1);
            market.getMemoryWithoutUpdate().set(SPP_MemKeys.TRADE_FLEET_WEIGHT, fleetWeight);
        }

        fleetWeight.modifyMult(getNameForModifier(), getTradeFleetMult());

		if (!isFunctional()) {
			supply.clear();
			unapply();
		}
    }

    protected String getUID() {
        return uid;
    }

    protected String getUID(int index) {
        return uids[index];
    }

    //<editor-fold defaultstate="collapsed" desc="Static Getters">
    protected float getAccessibilityBonus() {
        return ACCESSIBILITY_BONUS;
    }

    protected float getTradeFleetMult() {
        return TRADE_WEIGHT_MULT;
    }

    @Override
    protected int getBaseStabilityMod() {
        return STABILITY_MOD;
    }

    protected float getAlphaCoreAccessibilityBonus() {
        return ALPHA_CORE_ACCESSIBILITY;
    }

    protected float getAlphaCoreTradeFleetMult() {
        return ALPHA_CORE_TRADE_WEIGHT_MULT;
    }

    protected float getAlphaCoreFleetSizeBonus() {
        return ALPHA_CORE_STRENGTH_BONUS;
    }
    //</editor-fold>

	@Override
	protected Pair<String, Integer> getStabilityAffectingDeficit() {
		return getMaxDeficit(Commodities.SUPPLIES, Commodities.FUEL, Commodities.SHIPS, Commodities.CREW);
	}

	@Override
	public void unapply() {
		super.unapply();

        market.getStats().getDynamic().getMod(Stats.FLEET_QUALITY_MOD).unmodifyFlat(getModId(0));

        MutableStat weight = (MutableStat) market.getMemoryWithoutUpdate()
                    .get(SPP_MemKeys.TRADE_FLEET_WEIGHT);
        if (weight != null) weight.unmodifyMult(getNameForModifier());
//        market.getMemoryWithoutUpdate().set(SPP_MemKeys.SPAWN_TRADE_FLEETS, false);
//        market.getMemoryWithoutUpdate().set(SPP_MemKeys.SPAWN_SMUGGLER_FLEETS, false);

		unmodifyStabilityWithBaseMod();

		MemoryAPI memory = market.getMemoryWithoutUpdate();
		Misc.setFlagWithReason(memory, MemFlags.MARKET_PATROL, getModId(), false, -1);
		Misc.setFlagWithReason(memory, MemFlags.MARKET_MILITARY, getModId(), false, -1);

		market.getStats().getDynamic().getMod(Stats.PATROL_NUM_LIGHT_MOD).unmodifyFlat(getModId());
		market.getStats().getDynamic().getMod(Stats.PATROL_NUM_MEDIUM_MOD).unmodifyFlat(getModId());
		market.getStats().getDynamic().getMod(Stats.PATROL_NUM_HEAVY_MOD).unmodifyFlat(getModId());

		market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodifyFlat(getModId());

		market.getAccessibilityMod().unmodifyFlat(getModId(0));
	}

	public boolean isDemandLegal(CommodityOnMarketAPI com) {
		return true;
	}

	public boolean isSupplyLegal(CommodityOnMarketAPI com) {
		return true;
	}

	protected boolean hasPostDemandSection(boolean hasDemand, IndustryTooltipMode mode) {
		return mode != IndustryTooltipMode.NORMAL || isFunctional();
	}

	@Override
	protected void addPostDemandSection(TooltipMakerAPI tooltip, boolean hasDemand, IndustryTooltipMode mode) {
		if (mode != IndustryTooltipMode.NORMAL || isFunctional()) {
			addStabilityPostDemandSection(tooltip, hasDemand, mode);
		}
	}

    //<editor-fold defaultstate="collapsed" desc="AI Core Stuff">
    @Override
    protected void applyAlphaCoreModifiers() {
        market.getAccessibilityMod().modifyFlat(getModId(2),
                    getAlphaCoreAccessibilityBonus(),
                    "Alpha core (" + getNameForModifier() + ")");

        // Increase trade fleet chance
        MutableStat fleetWeight = (MutableStat) market.getMemoryWithoutUpdate()
                    .get(SPP_MemKeys.TRADE_FLEET_WEIGHT);
        if (fleetWeight == null) {
            fleetWeight = new MutableStat(1);
            market.getMemoryWithoutUpdate().set(SPP_MemKeys.TRADE_FLEET_WEIGHT, fleetWeight);
        }

        fleetWeight.modifyMult( "Alpha core (" + getNameForModifier() + ")", getAlphaCoreTradeFleetMult());

        market.getStats().getDynamic().getMod(Stats.COMBAT_FLEET_SIZE_MULT).modifyMult(
                    getModId(), 1f + getAlphaCoreFleetSizeBonus(),
                    "Alpha core (" + getNameForModifier() + ")");
    }

    @Override
    protected void applyNoAICoreModifiers() {
        market.getAccessibilityMod().unmodifyFlat(getModId(2));

        MutableStat fleetWeight = (MutableStat) market.getMemoryWithoutUpdate()
                    .get(SPP_MemKeys.TRADE_FLEET_WEIGHT);
        if (fleetWeight == null) {
            fleetWeight = new MutableStat(1);
            market.getMemoryWithoutUpdate().set(SPP_MemKeys.TRADE_FLEET_WEIGHT, fleetWeight);
        }

        fleetWeight.unmodifyMult( "Alpha core (" + getNameForModifier() + ")");

        market.getStats().getDynamic().getMod(Stats.COMBAT_FLEET_SIZE_MULT).unmodifyMult(getModId());
    }

    @Override
    protected void applyAlphaCoreSupplyAndDemandModifiers() {
        demandReduction.modifyFlat(getModId(0), DEMAND_REDUCTION, "Alpha core");
    }

    @Override
    protected void addAlphaCoreDescription(TooltipMakerAPI tooltip, AICoreDescriptionMode mode) {
        float opad = 10f;
        Color highlight = Misc.getHighlightColor();

        String pre = "Alpha-level AI core currently assigned. ";
        if (mode == AICoreDescriptionMode.MANAGE_CORE_DIALOG_LIST || mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            pre = "Alpha-level AI core. ";
        }
        float a = getAlphaCoreAccessibilityBonus();
        String aStr = "" + (int)Math.round(a * 100f) + "%";

        a = getAlphaCoreFleetSizeBonus();
        //String str = "" + (int)Math.round(a * 100f) + "%";
        String str = Strings.X + (1f + a);

        if (mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            CommoditySpecAPI coreSpec = Global.getSettings().getCommoditySpec(aiCoreId);
            TooltipMakerAPI text = tooltip.beginImageWithText(coreSpec.getIconName(), 48);
            text.addPara(pre + "Reduces upkeep cost by %s. Reduces demand by %s unit. " +
                        "Increases accessibility by %s. Increases fleet size by %s. More trade fleets originate here.", 0f, highlight,
                        "" + (int)((1f - UPKEEP_MULT) * 100f) + "%", "" + DEMAND_REDUCTION,	aStr, str);
            tooltip.addImageWithText(opad);
            return;
        }

        tooltip.addPara(pre + "Reduces upkeep cost by %s. Reduces demand by %s unit. " +
                    "Increases accessibility by %s. Increases fleet size by %s. More trade fleets originate here.", opad, highlight,
                    "" + (int)((1f - UPKEEP_MULT) * 100f) + "%", "" + DEMAND_REDUCTION, aStr, str);

    }
    //</editor-fold>

}
