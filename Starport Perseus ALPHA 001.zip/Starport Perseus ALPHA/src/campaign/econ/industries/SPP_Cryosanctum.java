package campaign.econ.industries;

import campaign.ids.SPP_Conditions;
import campaign.ids.SPP_Industries;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import static com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry.getDeficitText;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Pair;


public class SPP_Cryosanctum extends SPP_BaseIndustry {
	public static float DEFENSE_BONUS_CRYO = 1000f;

	public void apply() {
		super.apply(false);

		int size = 6;
//        int size = SPP_PortFunctions.getBuildingSize(market.getSize());

		applyIncomeAndUpkeep(size);

		demand(Commodities.SUPPLIES, size - 3);
		demand(Commodities.ORGANICS, size - 3);

		supply(Commodities.ORGANS, size);


		Pair<String, Integer> deficit = getMaxDeficit(Commodities.ORGANICS, Commodities.SUPPLIES);
		// that's right.
		if (deficit.two > 0) deficit.two = -1;

		applyDeficitToProduction(1, deficit, Commodities.ORGANS);


		float mult = getDeficitMult(Commodities.SUPPLIES);
		String extra = "";
		if (mult != 1) {
			String com = getMaxDeficit(Commodities.SUPPLIES).one;
			extra = " (" + getDeficitText(com).toLowerCase() + ")";
		}
		float bonus = DEFENSE_BONUS_CRYO;
		market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD)
						.modifyFlat(getModId(), bonus * mult, getNameForModifier() + extra);

		if (!isFunctional()) {
			supply.clear();
		}
	}


	@Override
	public void unapply() {
		super.unapply();

		market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodifyFlat(getModId());
	}

	@Override
	public boolean isAvailableToBuild() {
        boolean hasRevival = market.hasIndustry(SPP_Industries.CRYOREVIVAL);
        boolean hasVault = market.hasCondition(SPP_Conditions.CRYOVAULT);
        boolean sleeperUsable = false;

		StarSystemAPI system = market.getStarSystem();
		if (system != null) {
            for (SectorEntityToken entity : system.getEntitiesWithTag(Tags.CRYOSLEEPER)) {
                if (entity.getMemoryWithoutUpdate().contains("$usable")) {
                    sleeperUsable = true;
                    break;
                }
            }
        }

        return hasVault && (!hasRevival || (hasRevival && sleeperUsable));
	}

	@Override
	public boolean showWhenUnavailable() {
        boolean hasRevival = market.hasIndustry(SPP_Industries.CRYOREVIVAL);
        boolean hasVault = market.hasCondition(SPP_Conditions.CRYOVAULT);

        return hasVault && hasRevival;
	}

	@Override
	public String getUnavailableReason() {
		return "Requires usable cryovault";
	}

	protected boolean hasPostDemandSection(boolean hasDemand, IndustryTooltipMode mode) {
		//return mode == IndustryTooltipMode.NORMAL && isFunctional();
		return mode != IndustryTooltipMode.NORMAL || isFunctional();
	}

	@Override
	protected void addPostDemandSection(TooltipMakerAPI tooltip, boolean hasDemand, IndustryTooltipMode mode) {
		//if (mode == IndustryTooltipMode.NORMAL && isFunctional()) {
		if (mode != IndustryTooltipMode.NORMAL || isFunctional()) {
			float bonus = DEFENSE_BONUS_CRYO;
			addGroundDefensesImpactSection(tooltip, bonus, Commodities.SUPPLIES);
		}
	}

}
