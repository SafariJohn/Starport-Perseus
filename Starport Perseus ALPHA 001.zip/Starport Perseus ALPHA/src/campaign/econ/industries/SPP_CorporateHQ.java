package campaign.econ.industries;

import campaign.econ.SPP_ResourceDepositsCondition;
import static campaign.econ.industries.SPP_CommandBase.DEFENSE_BONUS;
import static campaign.econ.industries.SPP_MercenaryBase.createMercFleet;
import static campaign.econ.industries.SPP_MercenaryBase.createMercRoute;
import campaign.fleets.SPP_SystemWarFleetRouteManager;
import campaign.fleets.SPP_WarFleetRouteSource;
import campaign.ids.SPP_FleetTypes;
import campaign.ids.SPP_Industries;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import static com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry.getDeficitText;
import com.fs.starfarer.api.impl.campaign.fleets.RouteManager;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Pair;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import java.awt.Color;
import util.SPP_Misc;
import util.SPP_PortFunctions;

/**
 * Author: SafariJohn
 */
public class SPP_CorporateHQ extends SPP_CommandBase {
	public static final float HQ_ACCESSIBILITY_BONUS = 0.1f;
	public static final float HQ_TRADE_WEIGHT_MULT = 4f;

	public static final float HQ_ALPHA_CORE_ACCESSIBILITY = 0.1f;
	public static final float HQ_ALPHA_CORE_TRADE_WEIGHT_MULT = 2.25f;

    public static final float FACTION_ACCESSIBILITY_BONUS = 0f;

    private SPP_WarFleetRouteSource localSource;
    private SPP_WarFleetRouteSource indieMercSource;
    private SPP_WarFleetRouteSource factionSource;

    @Override
    public void init(String id, MarketAPI market) {
        super.init(id, market);

        initWarFleetSources();
    }

    @Override
    public void apply() {
        super.apply();

		int size = 2 + SPP_ResourceDepositsCondition.RESOURCE_STRUCTURE_BASE_SIZE;
        int scalingSize = SPP_PortFunctions.getPortCommoditySize(market.getSize());
        int adjustedSize = Math.max(size, scalingSize);
        adjustedSize = size + (int) (scalingSize * 0.3f);

        demand(Commodities.MARINES, adjustedSize);

        Pair<String, Integer> deficit;


        // Ground defenses
        // Penalty from low marines and/or heavy armaments
		float mult = getDeficitMult(Commodities.MARINES);
		String extra = "";
		if (mult != 1) {
			String com = getMaxDeficit(Commodities.MARINES).one;
			extra = " (" + getDeficitText(com).toLowerCase() + ")";
		}
		float bonus = DEFENSE_BONUS;
		market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD)
						.modifyFlat(getModId(), bonus * mult, getNameForModifier() + extra);


        // Apply deficit to local spawn weight
        deficit = getMaxDeficit(Commodities.CREW, Commodities.SHIPS,
                    Commodities.SUPPLIES, Commodities.FUEL);
        float warWeight = SPP_SystemWarFleetRouteManager.STANDARD_WEIGHT;
        if (deficit.two > 0) warWeight = Math.max(1, warWeight - deficit.two);

        localSource.getFleetWeights().put(SPP_FleetTypes.WAR_FLEET_MERC, warWeight);

        if (market.getPrimaryEntity() != null && market.getStarSystem() != null) {
            SPP_SystemWarFleetRouteManager manager = SPP_Misc.getWarFleetRouteManager(market.getStarSystem());
            manager.getRouteSources().remove(localSource);
            manager.getRouteSources().remove(indieMercSource);
            manager.getRouteSources().add(localSource);
            manager.getRouteSources().add(indieMercSource);
        }

        if (warWeight - deficit.two > 0) localSource.getBonusFleets().put(SPP_FleetTypes.WAR_FLEET_MERC, 1);
        else localSource.getBonusFleets().remove(SPP_FleetTypes.WAR_FLEET_MERC);

        // Faction-wide fleets increase with market size
        warWeight = market.getSize() / 3f;
        if (deficit.two > 0) warWeight = Math.max(1, warWeight - deficit.two);

        factionSource.getFleetWeights().put(SPP_FleetTypes.WAR_FLEET_MERC, warWeight);

        SPP_Misc.getFactionWarFleetSources(market.getFaction()).remove(factionSource);
        SPP_Misc.getFactionWarFleetSources(market.getFaction()).add(factionSource);

        if (warWeight - deficit.two > 0) {
            SPP_Misc.getFactionWarFleetBonusFleets(market.getFaction()).put(getUID(), SPP_FleetTypes.WAR_FLEET_MERC);
        } else {
            SPP_Misc.getFactionWarFleetBonusFleets(market.getFaction()).remove(getUID());
        }

		if (!isFunctional()) {
			supply.clear();
			unapply();
		}
    }

    @Override
    public void unapply() {
        super.unapply();

        if (market.getPrimaryEntity() != null && market.getStarSystem() != null) {
            SPP_SystemWarFleetRouteManager manager = SPP_Misc.getWarFleetRouteManager(market.getStarSystem());
            manager.getRouteSources().remove(localSource);
            manager.getRouteSources().remove(indieMercSource);
        }

        SPP_Misc.getFactionWarFleetSources(market.getFaction()).remove(factionSource);

        SPP_Misc.getFactionWarFleetBonusFleets(market.getFaction()).remove(getUID());
    }

	@Override
	protected void addPostDemandSection(TooltipMakerAPI tooltip, boolean hasDemand, IndustryTooltipMode mode) {
        super.addPostDemandSection(tooltip, hasDemand, mode);

        float bonus = DEFENSE_BONUS;
        addGroundDefensesImpactSection(tooltip, bonus, Commodities.MARINES);

		if (mode != IndustryTooltipMode.NORMAL || isFunctional()) {
			float opad = 10f;
            float a = getAccessibilityBonus();
            float total = a;
            String totalStr = "+" + (int)Math.round(total * 100f) + "%";
            Color h = Misc.getHighlightColor();
            tooltip.addPara("Accessibility bonus: %s", opad, h, totalStr);


            tooltip.addPara("More trade fleets originate at this port.", opad);
		}
	}

    @Override
    public boolean isAvailableToBuild() {
        if (!super.isAvailableToBuild()) return false;

        if (id.equals(SPP_Industries.CORPORATE_HQ_TEMP)) {
            return !market.hasIndustry(SPP_Industries.MERCENARY_BASE);
        }

        return true;
    }

    @Override
    public String getUnavailableReason() {
        if (!super.isAvailableToBuild()) return super.getUnavailableReason();

        if (market.hasIndustry(SPP_Industries.MERCENARY_BASE)) {
            return "Upgrade your Mercenary Base!";
        }

        return "Can not be built";
    }

    //<editor-fold defaultstate="collapsed" desc="Fleet Stuff">
    private void initWarFleetSources() {
        localSource = new SPP_WarFleetRouteSource() {
            public FactionAPI getFaction() { return market.getFaction(); }

            public RouteManager.RouteData createRoute(StarSystemAPI system, String fleetType) {
                return createMercRoute(system, getFaction(), fleetType, market);
            }

            public CampaignFleetAPI spawnFleet(RouteManager.RouteData route) {
                return createMercFleet(route, getFaction());
            }

            public boolean shouldCancelRouteAfterDelayCheck(RouteManager.RouteData route) { return false; }
            public void reportAboutToBeDespawnedByRouteManager(RouteManager.RouteData route) {}
        };


        //*************************************
        indieMercSource = new SPP_WarFleetRouteSource() {
            public FactionAPI getFaction() { return Global.getSector().getFaction(Factions.INDEPENDENT); }

            public RouteManager.RouteData createRoute(StarSystemAPI system, String fleetType) {
                return createMercRoute(system, getFaction(), fleetType, market);
            }

            public CampaignFleetAPI spawnFleet(RouteManager.RouteData route) {
                return createMercFleet(route, getFaction());
            }

            public boolean shouldCancelRouteAfterDelayCheck(RouteManager.RouteData route) { return false; }
            public void reportAboutToBeDespawnedByRouteManager(RouteManager.RouteData route) {}
        };

        indieMercSource.getFleetWeights().put(SPP_FleetTypes.WAR_FLEET_MERC, 1f);

        factionSource = new SPP_WarFleetRouteSource() {
            public FactionAPI getFaction() { return market.getFaction(); }

            public RouteManager.RouteData createRoute(StarSystemAPI system, String fleetType) {
                WeightedRandomPicker mPicker = new WeightedRandomPicker();
                for (MarketAPI iMarket : SPP_Misc.getMarketsInLocation(system, getFaction().getId())) {
                    mPicker.add(iMarket, iMarket.getSize());
                }

                MarketAPI from = (MarketAPI) mPicker.pick();

                if (from == null) return null;

                return SPP_MercenaryBase.createMercRoute(system, getFaction(), fleetType, from);
            }

            public CampaignFleetAPI spawnFleet(RouteManager.RouteData route) {
                return SPP_MercenaryBase.createMercFleet(route, getFaction());
            }

            public boolean shouldCancelRouteAfterDelayCheck(RouteManager.RouteData route) { return false; }
            public void reportAboutToBeDespawnedByRouteManager(RouteManager.RouteData route) {}
        };
    }
    //</editor-fold>

    @Override
    public float getPatherInterest() {
        return 6f + super.getPatherInterest();
    }

}
