package campaign.econ.industries.resourceBuildings;

import campaign.econ.SPP_ResourceDepositsCondition;
import campaign.econ.industries.SPP_BaseIndustry;
import campaign.econ.industries.SPP_Spaceport;
import campaign.ids.SPP_Industries;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.util.Pair;
import util.SPP_PortFunctions;

/**
 * Author: SafariJohn
 */
public class SPP_Hydroponics extends SPP_BaseIndustry {

    @Override
    public void apply() {
        super.apply(true);

        // Produces base 3 food if the planet has farmland
        int size = SPP_ResourceDepositsCondition.RESOURCE_STRUCTURE_BASE_SIZE;

        boolean farmland = SPP_PortFunctions.hasAquaculture(market) || SPP_PortFunctions.getFood(market) > -2;

        if (farmland) {
            int bonus = 0;
            String desc = market.getIndustry(SPP_Industries.SPACEPORT).getCurrentName();
            if (market.getSize() >= SPP_Spaceport.MEGAPORT_SIZE) {
                bonus = 2;
            } else if (market.getSize() >= SPP_Spaceport.SPACEPORT_SIZE) {
                bonus = 1;
            }

            if (SPP_PortFunctions.getFood(market) > -2) {
                supply(getModId(3), Commodities.FOOD, bonus, desc);
            }

            demand(Commodities.HEAVY_MACHINERY, size, "Base value");
            demand(3, Commodities.HEAVY_MACHINERY, bonus, desc);
        } else {
            // If no farmland, produces food = population - 2
            // Capped by port size and a minimum of 1 food
            // Because you should be able to grow food anywhere
            size = Math.max(1, SPP_PortFunctions.getPopulationSize(market) - 2);
            int portLimit = SPP_PortFunctions.getPopulationCommoditySize(market);
            int reduction = Math.min(portLimit - size, 0);

            supply(getModId(1), Commodities.FOOD, size, SPP_BaseIndustry.BASE_POPULATION_TEXT);
            supply(getModId(2), Commodities.FOOD, reduction, "Port size");

            demand(Commodities.HEAVY_MACHINERY, size, SPP_BaseIndustry.BASE_POPULATION_TEXT);
        }

        applyIncomeAndUpkeep(size);

        Pair<String, Integer> deficit = getMaxDeficit(Commodities.HEAVY_MACHINERY);
        applyDeficitToProduction(0, deficit, Commodities.FOOD);

        if (!isFunctional()) {
            supply.clear();
        }
    }

}
