package campaign.econ.industries.resourceBuildings;

import campaign.econ.SPP_ResourceDepositsCondition;
import campaign.econ.industries.SPP_BaseIndustry;
import campaign.econ.industries.SPP_Spaceport;
import campaign.ids.SPP_Conditions;
import campaign.ids.SPP_Industries;
import campaign.ids.SPP_MemKeys;
import campaign.ids.SPP_Tags;
import com.fs.starfarer.api.campaign.CustomCampaignEntityAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import static com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry.getDeficitText;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.population.PopulationComposition;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Pair;
import java.awt.Color;
import util.SPP_Misc;
import util.SPP_PortFunctions;

/**
 * Author: SafariJohn
 */
public class SPP_SiphonPlatform extends SPP_BaseIndustry {
    @Override
    public void apply() {
        super.apply(true);

        int size = SPP_ResourceDepositsCondition.RESOURCE_STRUCTURE_BASE_SIZE;

		applyIncomeAndUpkeep(size);


        int bonus = 0;
        String desc = market.getIndustry(SPP_Industries.SPACEPORT).getCurrentName();
        if (market.getSize() >= SPP_Spaceport.MEGAPORT_SIZE) {
            bonus = 2;
        } else if (market.getSize() >= SPP_Spaceport.SPACEPORT_SIZE) {
            bonus = 1;
        }

        if (SPP_PortFunctions.getVolatiles(market) > -2) {
            supply(getModId(3), Commodities.VOLATILES, bonus, desc);
        }


        demand(Commodities.HEAVY_MACHINERY, size, "Base value");
        demand(3, Commodities.HEAVY_MACHINERY, bonus, desc);
        demand(Commodities.DRUGS, size, "Base value");
        demand(3, Commodities.DRUGS, bonus, desc);

        Pair<String, Integer> deficit = getMaxDeficit(Commodities.HEAVY_MACHINERY);
        applyDeficitToProduction(0, deficit, Commodities.VOLATILES);

        if (!isFunctional()) {
            supply.clear();
        }
    }

    @Override
    public void advance(float amount) {
        super.advance(amount);

        PlanetAPI tapTarget = (PlanetAPI) market.getPrimaryEntity().getMemoryWithoutUpdate().get(SPP_Tags.MEMKEY_TAP_TARGET);

        if (tapTarget != null && !tapTarget.getMarket().hasCondition(SPP_Conditions.SIPHON_TAPPED)) {
            tapTarget.getMarket().addCondition(SPP_Conditions.SIPHON_TAPPED);
            market.getMemoryWithoutUpdate().set(SPP_Tags.MEMKEY_SIPHON_MOON, true);
        }

		if (stationEntity == null) {
			ensureStationEntityIsSetOrCreated();
		}
    }

    @Override
    public boolean isAvailableToBuild() {
        if (!super.isAvailableToBuild()) return false;
        if (getId().equals(SPP_Industries.MIMIR_SIPHON)) return false;

        boolean minVolatiles = SPP_PortFunctions.getVolatiles(market) >= 0;
        boolean moonSiphon = market.hasCondition(SPP_Conditions.MOON_SIPHON);
        if (!moonSiphon && !minVolatiles) return false;

        // Check for orbital block
        if (SPP_PortFunctions.hasOrbitalPortBlock(market)) return false;

        // If moon siphon is possible, check for orbital block on target
        if (moonSiphon) {
            PlanetAPI tapTarget = (PlanetAPI) market.getPlanetEntity().getMemoryWithoutUpdate().get(SPP_Tags.MEMKEY_TAP_TARGET);
            minVolatiles |= SPP_PortFunctions.getVolatiles(tapTarget.getMarket()) >= 0;

            if (SPP_PortFunctions.hasOrbitalPortBlock(tapTarget.getMarket())) return false;
        }

        return minVolatiles;
    }

	@Override
	public String getUnavailableReason() {
		if (!super.isAvailableToBuild()) return super.getUnavailableReason();

        boolean minVolatiles = SPP_PortFunctions.getVolatiles(market) >= 0;
        boolean moonSiphon = market.hasCondition(SPP_Conditions.MOON_SIPHON);
        if (moonSiphon) {
            PlanetAPI tapTarget = (PlanetAPI) market.getPlanetEntity().getMemoryWithoutUpdate().get(SPP_Tags.MEMKEY_TAP_TARGET);

            boolean tapBlocked = SPP_PortFunctions.hasOrbitalPortBlock(tapTarget.getMarket());
            if (!minVolatiles && tapBlocked) return tapTarget.getName() + " cannot be siphoned from currently";
        }

        if (!SPP_PortFunctions.hasOrbitalPortBlock(market, false)
                    && SPP_PortFunctions.hasOrbitalPortBlock(market)) {
            return "The orbit of " + market.getName() + " is currently blocked";
        }

        return "Insufficient volatiles to start Ouyang Process";
	}

    @Override
    public boolean showWhenUnavailable() {
        if (getId().equals(SPP_Industries.MIMIR_SIPHON)) return false;

        boolean moonSiphon = market.hasCondition(SPP_Conditions.MOON_SIPHON);
        if (!moonSiphon && SPP_PortFunctions.hasOrbitalPortBlock(market, false)) return false;

        return moonSiphon || SPP_PortFunctions.getVolatiles(market) > -2;
    }

	protected boolean hasPostDemandSection(boolean hasDemand, IndustryTooltipMode mode) {
		Pair<String, Integer> deficit = getMaxDeficit(Commodities.DRUGS);
		if (deficit.two <= 0) return false;
		//return mode == IndustryTooltipMode.NORMAL && isFunctional();
		return mode != IndustryTooltipMode.NORMAL || isFunctional();
	}

	@Override
	protected void addPostDemandSection(TooltipMakerAPI tooltip, boolean hasDemand, IndustryTooltipMode mode) {
		//if (mode == IndustryTooltipMode.NORMAL && isFunctional()) {
		if (mode != IndustryTooltipMode.NORMAL || isFunctional()) {
			Color h = Misc.getHighlightColor();
			float opad = 10f;
			float pad = 3f;

			Pair<String, Integer> deficit = getMaxDeficit(Commodities.DRUGS);
			if (deficit.two > 0) {
				tooltip.addPara(getDeficitText(Commodities.DRUGS) + ": %s units. Reduced port growth.", pad, h, "" + deficit.two);
			}
		}
	}

    @Override
    public void startBuilding() {
        super.startBuilding();

        PlanetAPI tapTarget = (PlanetAPI) market.getPrimaryEntity().getMemoryWithoutUpdate().get(SPP_Tags.MEMKEY_TAP_TARGET);

        if (tapTarget != null && !tapTarget.getMarket().hasCondition(SPP_Conditions.SIPHON_TAPPED)) {
            tapTarget.getMarket().addCondition(SPP_Conditions.SIPHON_TAPPED);
            market.getMemoryWithoutUpdate().set(SPP_Tags.MEMKEY_SIPHON_MOON, true);
        }
    }

	@Override
	protected void buildingFinished() {
		super.buildingFinished();

        // Add siphon condition and stuff here instead of apply
        PlanetAPI tapTarget = (PlanetAPI) market.getPrimaryEntity().getMemoryWithoutUpdate().get(SPP_Tags.MEMKEY_TAP_TARGET);

        if (isTapping()) {
//            tapTarget.getMarket().addCondition(SPP_Conditions.SIPHON_TAPPED);
//            market.getMemoryWithoutUpdate().set(SPP_Tags.MEMKEY_SIPHON_MOON, true);

            // Save native volatiles and migrate target's condition
            String condId = SPP_PortFunctions.getResourceCondId(
                        Commodities.VOLATILES,
                        SPP_PortFunctions.getVolatiles(market));
            market.getMemoryWithoutUpdate().set(SPP_MemKeys.SIPHON_SAVED_COND, condId);
            market.removeCondition(condId);

            condId = SPP_PortFunctions.getResourceCondId(
                        Commodities.VOLATILES,
                        SPP_PortFunctions.getVolatiles(tapTarget.getMarket()));
            String token = market.addCondition(condId);
            market.getSpecificCondition(token).setSurveyed(true);

            market.reapplyConditions();
        }


		if (stationEntity == null) {
			ensureStationEntityIsSetOrCreated();
		}
	}

	@Override
	protected void upgradeFinished(Industry previous) {
		super.upgradeFinished(previous);

		if (previous instanceof SPP_SiphonPlatform) {
			SPP_SiphonPlatform prev = (SPP_SiphonPlatform) previous;
			stationEntity = prev.stationEntity;
			usingExistingStation = prev.usingExistingStation;

			if (stationEntity == null) {
				ensureStationEntityIsSetOrCreated();
			}
		}
	}

	@Override
	public void notifyBeingRemoved(MarketAPI.MarketInteractionMode mode, boolean forUpgrade) {
		super.notifyBeingRemoved(mode, forUpgrade);

		if (!forUpgrade) {
			removeStationEntityIfNeeded();
		}

        PlanetAPI tapTarget = (PlanetAPI) market.getPrimaryEntity()
                    .getMemoryWithoutUpdate().get(SPP_Tags.MEMKEY_TAP_TARGET);

        if (isTapping()) {
            tapTarget.getMarket().removeCondition(SPP_Conditions.SIPHON_TAPPED);
            market.getMemoryWithoutUpdate().set(SPP_Tags.MEMKEY_SIPHON_MOON, false);

            // Remove target's condition and restore native volatiles
            String condId = SPP_PortFunctions.getResourceCondId(
                        Commodities.VOLATILES,
                        SPP_PortFunctions.getVolatiles(market));
//            market.getCondition(condId).getPlugin().unapply(condId);
            market.removeCondition(condId);

            condId = (String) market.getMemoryWithoutUpdate().get(SPP_MemKeys.SIPHON_SAVED_COND);
            if (!condId.isEmpty()) {
                String token = market.addCondition(condId);
                market.getSpecificCondition(token).setSurveyed(true);
            }

            market.reapplyConditions();
            market.reapplyIndustries();
        }
	}

	@Override
	public void notifyColonyRenamed() {
		super.notifyColonyRenamed();

		if (!usingExistingStation) {
			stationEntity.setName(market.getName() + " Siphon");
		}
	}

	protected boolean usingExistingStation = false;
	protected SectorEntityToken stationEntity = null;

	protected void ensureStationEntityIsSetOrCreated() {
		if (stationEntity == null) {
			for (SectorEntityToken entity : market.getConnectedEntities()) {
				if (entity.hasTag(Tags.STATION)) {
					stationEntity = entity;
					usingExistingStation = true;
					break;
				}
			}
		}

		if (stationEntity == null) {
			stationEntity = market.getContainingLocation().addCustomEntity(
					null, market.getName() + " Siphon", "station_side05", market.getFactionId());
//            stationEntity.setCustomDescriptionId(upgradeId);

            // Time to handle the orbit
			SectorEntityToken primary = market.getPrimaryEntity();
            PlanetAPI tapTarget = (PlanetAPI) market.getMemoryWithoutUpdate().get(SPP_Tags.MEMKEY_TAP_TARGET);

            if (isTapping()) {
                float orbitRadius = primary.getCircularOrbitRadius();
                orbitRadius -= primary.getRadius();
                orbitRadius -= 15;
                orbitRadius -= stationEntity.getRadius();
                stationEntity.setCircularOrbitWithSpin(tapTarget, primary.getCircularOrbitAngle(), orbitRadius, primary.getCircularOrbitPeriod(), 5f, 5f);
            } else {
                float orbitRadius = primary.getRadius() + 150f;
                stationEntity.setCircularOrbitPointingDown(primary, (float) Math.random() * 360f, orbitRadius, orbitRadius / 10f);
            }


			market.getConnectedEntities().add(stationEntity);
			stationEntity.setMarket(market);
		}
	}

	protected void removeStationEntityIfNeeded() {
		if (stationEntity != null) {
			stationEntity.getMemoryWithoutUpdate().unset(MemFlags.STATION_FLEET);
			stationEntity.getMemoryWithoutUpdate().unset(MemFlags.STATION_BASE_FLEET);

			if (stationEntity.getContainingLocation() != null && !usingExistingStation) {
				stationEntity.getContainingLocation().removeEntity(stationEntity);
				market.getConnectedEntities().remove(stationEntity);

				// commented out so that MarketCMD doesn't NPE if you destroy a market through bombardment of a station
				//stationEntity.setMarket(null);

			} else if (stationEntity.hasTag(Tags.USE_STATION_VISUAL)) {
				((CustomCampaignEntityAPI)stationEntity).setFleetForVisual(null);
				float origRadius = ((CustomCampaignEntityAPI)stationEntity).getCustomEntitySpec().getDefaultRadius();
				((CustomCampaignEntityAPI)stationEntity).setRadius(origRadius);
			}

			stationEntity = null;
		}
	}

	public void modifyIncoming(MarketAPI market, PopulationComposition incoming) {
		Pair<String, Integer> deficit = getMaxDeficit(Commodities.DRUGS);
		if (deficit.two > 0) {
			incoming.getWeight().modifyFlat(getModId(), -deficit.two, getCurrentName() + ": drug shortage");
		}
	}

	public float getPatherInterest() {
		return 1f + super.getPatherInterest();
	}

    private boolean isTapping() {
        PlanetAPI tapTarget = (PlanetAPI) market.getMemoryWithoutUpdate().get(SPP_Tags.MEMKEY_TAP_TARGET);

        return tapTarget != null && market.getMemoryWithoutUpdate().getBoolean(SPP_Tags.MEMKEY_SIPHON_MOON);
    }
}
