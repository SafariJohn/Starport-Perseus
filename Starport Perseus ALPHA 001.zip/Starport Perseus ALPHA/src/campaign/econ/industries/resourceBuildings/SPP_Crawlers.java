package campaign.econ.industries.resourceBuildings;

import campaign.econ.SPP_ResourceDepositsCondition;
import campaign.econ.industries.SPP_BaseIndustry;
import campaign.econ.industries.SPP_Spaceport;
import campaign.ids.SPP_Industries;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import static com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry.getDeficitText;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.population.PopulationComposition;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Pair;
import java.awt.Color;
import util.SPP_PortFunctions;

/**
 * Author: SafariJohn
 */
public class SPP_Crawlers extends SPP_BaseIndustry {

    @Override
    public void apply() {
        super.apply(true);

        int size = SPP_ResourceDepositsCondition.RESOURCE_STRUCTURE_BASE_SIZE;

		applyIncomeAndUpkeep(size);

        int bonus = 0;
        String desc = market.getIndustry(SPP_Industries.SPACEPORT).getCurrentName();
        if (market.getSize() >= SPP_Spaceport.MEGAPORT_SIZE) {
            bonus = 2;
        } else if (market.getSize() >= SPP_Spaceport.SPACEPORT_SIZE) {
            bonus = 1;
        }

        if (SPP_PortFunctions.getOre(market) > -2) {
            supply(getModId(3), Commodities.ORE, bonus, desc);
        }
        if (SPP_PortFunctions.getRareOre(market) > -2) {
            supply(getModId(3), Commodities.RARE_ORE, bonus, desc);
        }
        if (SPP_PortFunctions.getOrganics(market) > -2) {
            supply(getModId(3), Commodities.ORGANICS, bonus, desc);
        }

        demand(Commodities.HEAVY_MACHINERY, size, "Base value");
        demand(3, Commodities.HEAVY_MACHINERY, bonus, desc);
        demand(Commodities.DRUGS, size, "Base value");
        demand(3, Commodities.DRUGS, bonus, desc);

        Pair<String, Integer> deficit = getMaxDeficit(Commodities.HEAVY_MACHINERY);
        applyDeficitToProduction(0, deficit,
                    Commodities.ORE,
                    Commodities.RARE_ORE,
                    Commodities.ORGANICS);

        if (!isFunctional()) {
            supply.clear();
        }
    }

    @Override
    public boolean isAvailableToBuild() {
        if (!super.isAvailableToBuild()) return false;

        boolean ore = SPP_PortFunctions.getOre(market) > -2;
        boolean rare = SPP_PortFunctions.getRareOre(market) > -1;
        boolean organics = SPP_PortFunctions.getOrganics(market) > -2;

        return ore || rare || organics;
    }

	@Override
	public String getUnavailableReason() {
		if (!super.isAvailableToBuild()) return super.getUnavailableReason();

        if (SPP_PortFunctions.getRareOre(market) == -1) return "Requires economical resource deposits";

		return "Requires resource deposits";
	}

	protected boolean hasPostDemandSection(boolean hasDemand, IndustryTooltipMode mode) {
		Pair<String, Integer> deficit = getMaxDeficit(Commodities.DRUGS);
		if (deficit.two <= 0) return false;
		//return mode == IndustryTooltipMode.NORMAL && isFunctional();
		return mode != IndustryTooltipMode.NORMAL || isFunctional();
	}

	@Override
	protected void addPostDemandSection(TooltipMakerAPI tooltip, boolean hasDemand, IndustryTooltipMode mode) {
		//if (mode == IndustryTooltipMode.NORMAL && isFunctional()) {
		if (mode != IndustryTooltipMode.NORMAL || isFunctional()) {
			Color h = Misc.getHighlightColor();
			float opad = 10f;
			float pad = 3f;

			Pair<String, Integer> deficit = getMaxDeficit(Commodities.DRUGS);
			if (deficit.two > 0) {
				tooltip.addPara(getDeficitText(Commodities.DRUGS) + ": %s units. Reduced port growth.", pad, h, "" + deficit.two);
			}
		}
	}

	public void modifyIncoming(MarketAPI market, PopulationComposition incoming) {
		Pair<String, Integer> deficit = getMaxDeficit(Commodities.DRUGS);
		if (deficit.two > 0) {
			incoming.getWeight().modifyFlat(getModId(), -deficit.two, "Crawlers: drug shortage");
		}
	}

	public float getPatherInterest() {
		return 1f + super.getPatherInterest();
	}

}
