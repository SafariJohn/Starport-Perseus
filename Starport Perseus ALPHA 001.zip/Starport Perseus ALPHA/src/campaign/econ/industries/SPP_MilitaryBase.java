package campaign.econ.industries;

import campaign.econ.SPP_ResourceDepositsCondition;
import static campaign.econ.industries.SPP_CommandBase.TRADE_WEIGHT_MULT;
import static campaign.econ.industries.SPP_Shipyard.BASE_QUALITY_BONUS;
import campaign.fleets.SPP_SystemWarFleetRouteManager;
import campaign.fleets.SPP_SystemWarFleetRouteManager.WarFleetData;
import campaign.fleets.SPP_WarFleetRouteSource;
import campaign.ids.SPP_FleetTypes;
import campaign.ids.SPP_MemKeys;
import java.util.Random;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.combat.MutableStat;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactoryV3;
import com.fs.starfarer.api.impl.campaign.fleets.FleetParamsV3;
import com.fs.starfarer.api.impl.campaign.fleets.PatrolAssignmentAIV4;
import com.fs.starfarer.api.impl.campaign.fleets.RouteManager;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactory.PatrolType;
import com.fs.starfarer.api.impl.campaign.fleets.RouteManager.OptionalFleetData;
import com.fs.starfarer.api.impl.campaign.fleets.RouteManager.RouteData;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Industries;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.impl.campaign.ids.Ranks;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Pair;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import util.SPP_Misc;
import util.SPP_PortFunctions;



public class SPP_MilitaryBase extends SPP_CommandBase {
    protected SPP_WarFleetRouteSource localSource;
    protected SPP_WarFleetRouteSource factionSource;

    @Override
    public void init(String id, MarketAPI market) {
        super.init(id, market);

        initWarFleetSources();
    }

	public void apply() {
		super.apply();

        // Ship quality bonus
        market.getStats().getDynamic().getMod(Stats.FLEET_QUALITY_MOD)
                    .modifyFlat(getModId(0), BASE_QUALITY_BONUS * 1.5f, getNameForModifier());

		int size = 2 + SPP_ResourceDepositsCondition.RESOURCE_STRUCTURE_BASE_SIZE;
        int scalingSize = SPP_PortFunctions.getPortCommoditySize(market.getSize());
        int adjustedSize = Math.max(size, scalingSize);
        adjustedSize = size + (int) (scalingSize * 0.3f);

        demand(Commodities.HAND_WEAPONS, adjustedSize);
        supply(Commodities.MARINES, adjustedSize);

        // Ground defenses
        // Penalty from low marines and/or heavy armaments
		float mult = getDeficitMult(Commodities.HAND_WEAPONS);
		String extra = "";
		if (mult != 1) {
			String com = getMaxDeficit(Commodities.HAND_WEAPONS).one;
			extra = " (" + getDeficitText(com).toLowerCase() + ")";
		}
		float bonus = DEFENSE_BONUS;
		market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD)
						.modifyFlat(getModId(), bonus * mult, getNameForModifier() + extra);

		Pair<String, Integer> deficit;

		deficit = getMaxDeficit(Commodities.HAND_WEAPONS);
		applyDeficitToProduction(1, deficit, Commodities.MARINES);

        // Apply deficit to local spawn weight
        deficit = getMaxDeficit(Commodities.CREW, Commodities.SHIPS, Commodities.SUPPLIES);
        float warWeight = SPP_SystemWarFleetRouteManager.STANDARD_WEIGHT;
        if (deficit.two > 0) warWeight = Math.max(1, warWeight - deficit.two);

        localSource.getFleetWeights().put(SPP_FleetTypes.WAR_FLEET_MILITARY, warWeight);
//        localSource.getFleetWeights().put(SPP_FleetTypes.WAR_FLEET_RAIDER, warWeight);

        // Sources to spawn war fleets
        if (market.getPrimaryEntity() != null && market.getStarSystem() != null) {
            SPP_SystemWarFleetRouteManager manager = SPP_Misc.getWarFleetRouteManager(market.getStarSystem());
            manager.getRouteSources().remove(localSource);
            manager.getRouteSources().add(localSource);
        }

        if (warWeight - deficit.two > 0) {
            localSource.getBonusFleets().put(SPP_FleetTypes.WAR_FLEET_MILITARY, 1);
//            localSource.getBonusFleets().put(SPP_FleetTypes.WAR_FLEET_RAIDER, 1);
        } else {
            localSource.getBonusFleets().remove(SPP_FleetTypes.WAR_FLEET_MILITARY);
//            localSource.getBonusFleets().remove(SPP_FleetTypes.WAR_FLEET_RAIDER);
        }

        // Faction-wide fleets increase with market size
        warWeight = market.getSize() / 3f;
        deficit = getMaxDeficit(Commodities.CREW, Commodities.SHIPS, Commodities.SUPPLIES, Commodities.FUEL);
        if (deficit.two > 0) warWeight = Math.max(1, warWeight - deficit.two);

        factionSource.getFleetWeights().put(SPP_FleetTypes.WAR_FLEET_MILITARY, warWeight);
//        factionSource.getFleetWeights().put(SPP_FleetTypes.WAR_FLEET_RAIDER, warWeight);

        SPP_Misc.getFactionWarFleetSources(market.getFaction()).remove(factionSource);
        SPP_Misc.getFactionWarFleetSources(market.getFaction()).add(factionSource);

        if (warWeight - deficit.two > 0) {
            SPP_Misc.getFactionWarFleetBonusFleets(market.getFaction())
                        .put(getUID(0), SPP_FleetTypes.WAR_FLEET_MILITARY);
//            SPP_Misc.getFactionWarFleetBonusFleets(market.getFaction()).put(getUID(1), SPP_FleetTypes.WAR_FLEET_RAIDER);
        } else {
            SPP_Misc.getFactionWarFleetBonusFleets(market.getFaction()).remove(getUID(0));
//            SPP_Misc.getFactionWarFleetBonusFleets(market.getFaction()).remove(getUID(1));
        }

		if (!isFunctional()) {
			supply.clear();
			unapply();
		}

	}

    @Override
    protected float getAccessibilityBonus() {
        return 0;
    }

    @Override
    protected float getTradeFleetMult() {
        return 1f;
    }

    @Override
    protected float getAlphaCoreAccessibilityBonus() {
        return 0;
    }

    @Override
    protected float getAlphaCoreTradeFleetMult() {
        return 1f;
    }

	@Override
	public void unapply() {
		super.unapply();

        if (market.getPrimaryEntity() != null && market.getStarSystem() != null) {
            SPP_SystemWarFleetRouteManager manager = SPP_Misc.getWarFleetRouteManager(market.getStarSystem());
            manager.getRouteSources().remove(localSource);
        }

        SPP_Misc.getFactionWarFleetSources(market.getFaction()).remove(factionSource);

        SPP_Misc.getFactionWarFleetBonusFleets(market.getFaction()).remove(getUID(0));
//        SPP_Misc.getFactionWarFleetBonusFleets(market.getFaction()).remove(getUID(1));
	}

	@Override
	protected void addPostDemandSection(TooltipMakerAPI tooltip, boolean hasDemand, IndustryTooltipMode mode) {
        super.addPostDemandSection(tooltip, hasDemand, mode);

        float bonus = DEFENSE_BONUS;
        addGroundDefensesImpactSection(tooltip, bonus, Commodities.HAND_WEAPONS);
	}


	@Override
	public String getCurrentImage() {
        // If no planet, display patrolHQ
        // If no atmo, display orbital military
        // Else, display normal military

		boolean military = Industries.MILITARYBASE.equals(getId());
		if (military) {
			PlanetAPI planet = market.getPlanetEntity();
			if (planet == null || planet.isGasGiant() || planet.getMarket().hasCondition(Conditions.NO_ATMOSPHERE)) {
				return Global.getSettings().getSpriteName("industry", "military_base_orbital");
			}
		}
		return super.getCurrentImage();
	}

    //<editor-fold defaultstate="collapsed" desc="Fleet Stuff">
    public static int getPatrolCombatFP(PatrolType type, Random random) {
        float combat = 0;
        switch (type) {
            case FAST:
                combat = Math.round(3f + (float) random.nextFloat() * 2f) * 5f;
                break;
            case COMBAT:
                combat = Math.round(6f + (float) random.nextFloat() * 3f) * 5f;
                break;
            case HEAVY:
                combat = Math.round(10f + (float) random.nextFloat() * 5f) * 5f;
                break;
        }
        return (int) Math.round(combat);
    }

    protected void initWarFleetSources() {
        localSource = new SPP_WarFleetRouteSource() {
            public FactionAPI getFaction() { return market.getFaction(); }

            public RouteData createRoute(StarSystemAPI system, String fleetType) {
                if (fleetType.equals(SPP_FleetTypes.WAR_FLEET_RAIDER)) {
                    return SPP_RaiderBase.createRaiderRoute(system, fleetType, market);
                }

                return createMilitaryRoute(system, fleetType, market);
            }

            public CampaignFleetAPI spawnFleet(RouteData route) {
                WarFleetData custom = (WarFleetData) route.getCustom();
                if (custom.warFleetType.equals(SPP_FleetTypes.WAR_FLEET_RAIDER)) {
                    return SPP_RaiderBase.createRaiderFleet(route, getFaction());
                }

                return createMilitaryFleet(route);
            }

            public boolean shouldCancelRouteAfterDelayCheck(RouteData route) { return false; }
            public void reportAboutToBeDespawnedByRouteManager(RouteData route) {}
        };

        localSource.getFleetWeights().put(SPP_FleetTypes.WAR_FLEET_MILITARY, SPP_SystemWarFleetRouteManager.STANDARD_WEIGHT);
//        localSource.getFleetWeights().put(SPP_FleetTypes.WAR_FLEET_RAIDER, SPP_SystemWarFleetRouteManager.STANDARD_WEIGHT);
        localSource.getBonusFleets().put(SPP_FleetTypes.WAR_FLEET_MILITARY, 1);
//        localSource.getBonusFleets().put(SPP_FleetTypes.WAR_FLEET_RAIDER, 1);


        factionSource = new SPP_WarFleetRouteSource() {
            public FactionAPI getFaction() { return market.getFaction(); }

            public RouteData createRoute(StarSystemAPI system, String fleetType) {
                WeightedRandomPicker mPicker = new WeightedRandomPicker();
                for (MarketAPI iMarket : SPP_Misc.getMarketsInLocation(system, getFaction().getId())) {
                    mPicker.add(iMarket, iMarket.getSize());
                }

                MarketAPI from = (MarketAPI) mPicker.pick();

                if (from == null) return null;

                if (fleetType.equals(SPP_FleetTypes.WAR_FLEET_RAIDER)) {
                    return SPP_RaiderBase.createRaiderRoute(system, fleetType, from);
                }

                return createMilitaryRoute(system, fleetType, from);
            }

            public CampaignFleetAPI spawnFleet(RouteData route) {
                WarFleetData custom = (WarFleetData) route.getCustom();
                if (custom.warFleetType.equals(SPP_FleetTypes.WAR_FLEET_RAIDER)) {
                    return SPP_RaiderBase.createRaiderFleet(route, getFaction());
                }

                return createMilitaryFleet(route);
            }

            public boolean shouldCancelRouteAfterDelayCheck(RouteData route) { return false; }
            public void reportAboutToBeDespawnedByRouteManager(RouteData route) {}
        };

        factionSource.getBonusFleets().put(SPP_FleetTypes.WAR_FLEET_MILITARY, 1);
//        factionSource.getBonusFleets().put(SPP_FleetTypes.WAR_FLEET_RAIDER, 1);
    }

    public static RouteData createMilitaryRoute(StarSystemAPI system, String fleetType, MarketAPI from) {
        int light = getMilitaryCount(from, PatrolType.FAST) + 1;
        int medium = getMilitaryCount(from, PatrolType.COMBAT) + 1;
        int heavy = getMilitaryCount(from, PatrolType.HEAVY) + 1;

        int lightWeight = getPatrolTypeWeight(PatrolType.FAST, from);
        int mediumWeight = getPatrolTypeWeight(PatrolType.COMBAT, from);
        int heavyWeight = getPatrolTypeWeight(PatrolType.HEAVY, from);

        WeightedRandomPicker<PatrolType> picker = new WeightedRandomPicker<PatrolType>();
        picker.add(PatrolType.HEAVY, heavyWeight / heavy);
        picker.add(PatrolType.COMBAT, mediumWeight / medium);
        picker.add(PatrolType.FAST, lightWeight / light);

        if (picker.isEmpty()) return null;

        PatrolType type = picker.pick();
        WarFleetData custom = new WarFleetData(type, fleetType);

        OptionalFleetData extra = new OptionalFleetData(from);

        SPP_SystemWarFleetRouteManager manager = SPP_Misc.getWarFleetRouteManager(system);

        RouteData route = RouteManager.getInstance().addRoute(manager.getRouteSourceId(), from, Misc.genRandomSeed(), extra, manager, custom);
        extra.strength = (float) getPatrolCombatFP(type, route.getRandom());
        extra.strength = Misc.getAdjustedStrength(extra.strength, from);


        float patrolDays = 35f + (float) Math.random() * 10f;
        route.addSegment(new RouteManager.RouteSegment(patrolDays, from.getPrimaryEntity()));

        return route;
    }

    public static CampaignFleetAPI createMilitaryFleet(RouteData route) {
        Random random = route.getRandom();
        if (random == null) random = new Random();

        MarketAPI from = route.getMarket();

        WarFleetData custom = (WarFleetData) route.getCustom();
        PatrolType type = custom.type;

        float combat = getPatrolCombatFP(type, random);
        float tanker = 0f;
        float freighter = 0f;
        String fleetType = SPP_FleetTypes.MILITARY_SMALL;
        switch (type) {
            case FAST:
                break;
            case COMBAT:
                fleetType = SPP_FleetTypes.MILITARY_MEDIUM;
                tanker = Math.round((float) random.nextFloat() * 5f);
                break;
            case HEAVY:
                fleetType = SPP_FleetTypes.MILITARY_LARGE;
                tanker = Math.round((float) random.nextFloat() * 10f);
                freighter = Math.round((float) random.nextFloat() * 10f);
                break;
        }

        FleetParamsV3 params = new FleetParamsV3(
                    from,
                    null,
                    from.getFactionId(),
                    route.getQualityOverride(),
                    fleetType,
                    combat, // combatPts
                    freighter, // freighterPts
                    tanker, // tankerPts
                    0f, // transportPts
                    0f, // linerPts
                    0f, // utilityPts
                    0f // qualityMod
        );
        params.timestamp = route.getTimestamp();
        params.random = random;
        CampaignFleetAPI fleet = FleetFactoryV3.createFleet(params);

        if (fleet == null || fleet.isEmpty()) return null;

        fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_WAR_FLEET, true);

        if (fleet.getFaction().getCustomBoolean(Factions.CUSTOM_PIRATE_BEHAVIOR)) {
            fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_PIRATE, true);

            // hidden pather and pirate bases
            // make them raid so there's some consequence to just having a colony in a system with one of those
            if (from.isHidden()) {
                fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_RAIDER, true);
            }
        }

        String postId = Ranks.POST_PATROL_COMMANDER;
        String rankId = Ranks.SPACE_COMMANDER;
        switch (type) {
            case FAST:
                rankId = Ranks.SPACE_LIEUTENANT;
                break;
            case COMBAT:
                rankId = Ranks.SPACE_COMMANDER;
                break;
            case HEAVY:
                rankId = Ranks.SPACE_CAPTAIN;
                break;
        }

        fleet.getCommander().setPostId(postId);
        fleet.getCommander().setRankId(rankId);

        from.getContainingLocation().addEntity(fleet);
        fleet.setFacing((float) Math.random() * 360f);
        // this will get overridden by the patrol assignment AI, depending on route-time elapsed etc
        fleet.setLocation(from.getPrimaryEntity().getLocation().x, from.getPrimaryEntity().getLocation().y);

        fleet.addScript(new PatrolAssignmentAIV4(fleet, route));

        //market.getContainingLocation().addEntity(fleet);
        //fleet.setLocation(market.getPrimaryEntity().getLocation().x, market.getPrimaryEntity().getLocation().y);

        if (custom.spawnFP <= 0) {
            custom.spawnFP = fleet.getFleetPoints();
        }

        return fleet;
    }

    public static int getMilitaryCount(MarketAPI market, PatrolType ... types) {
        int count = 0;

        if (market.getPrimaryEntity() == null || market.getStarSystem() == null) return count;

        String managerId = SPP_Misc.getWarFleetRouteManager(market.getStarSystem()).getRouteSourceId();
        for (RouteData data : RouteManager.getInstance().getRoutesForSource(managerId)) {
            if (data.getCustom() instanceof WarFleetData) {
                WarFleetData custom = (WarFleetData) data.getCustom();
                for (PatrolType type : types) {
                    if (type == custom.type && custom.warFleetType.equals(SPP_FleetTypes.WAR_FLEET_MILITARY)) {
                        count++;
                        break;
                    }
                }
            }
        }
        return count;
    }

    public static int getPatrolTypeWeight(PatrolType type, MarketAPI market) {
        if (type == PatrolType.FAST) {
            return (int) market.getStats().getDynamic().getMod(Stats.PATROL_NUM_LIGHT_MOD).computeEffective(1);
        }
        if (type == PatrolType.COMBAT) {
            return (int) market.getStats().getDynamic().getMod(Stats.PATROL_NUM_MEDIUM_MOD).computeEffective(1);
        }
        if (type == PatrolType.HEAVY) {
            return (int) market.getStats().getDynamic().getMod(Stats.PATROL_NUM_HEAVY_MOD).computeEffective(1);
        }
        return 0;
    }
    //</editor-fold>

    @Override
    public float getPatherInterest() {
        return 4f + super.getPatherInterest();
    }
}




