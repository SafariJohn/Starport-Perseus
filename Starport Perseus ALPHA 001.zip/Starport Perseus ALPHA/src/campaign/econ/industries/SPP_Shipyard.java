package campaign.econ.industries;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.SpecialItemSpecAPI;
import com.fs.starfarer.api.campaign.econ.CommodityOnMarketAPI;
import com.fs.starfarer.api.campaign.econ.InstallableIndustryItemPlugin;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.econ.impl.NanoforgeInstallableItemPlugin;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Pair;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import util.SPP_PortFunctions;

/**
 * Author: SafariJohn
 */
public class SPP_Shipyard extends SPP_BaseIndustry
            implements SPP_NanoforgeUsingIndustry {

	public static float BASE_QUALITY_BONUS = 0.2f;

	public void apply() {
		super.apply(true);

		int size = SPP_PortFunctions.getPortCommoditySize(market.getSize());

		float qualityBonus = BASE_QUALITY_BONUS;

		demand(Commodities.METALS, size);
		demand(Commodities.RARE_METALS, size - 2);
		demand(Commodities.HEAVY_MACHINERY, size - 2);

//		supply(Commodities.SUPPLIES, size - 2);
		supply(Commodities.SHIPS, size - 2);

		Pair<String, Integer> deficit = getMaxDeficit(Commodities.METALS, Commodities.RARE_METALS, Commodities.HEAVY_MACHINERY);
		int maxDeficit = Math.max(0, size - 3); // to allow *some* production so economy doesn't get into an unrecoverable state
		if (deficit.two > maxDeficit) deficit.two = maxDeficit;

		applyDeficitToProduction(2, deficit, Commodities.SHIPS);

		applyNanoforgeEffects();

		if (qualityBonus > 0) {
			market.getStats().getDynamic().getMod(Stats.PRODUCTION_QUALITY_MOD).modifyFlat(getModId(1), qualityBonus, "Shipyard");
		}

		float stability = market.getPrevStability();
		if (stability < 5) {
			float stabilityMod = (stability - 5f) / 5f;
			stabilityMod *= 0.5f;
			//market.getStats().getDynamic().getMod(Stats.PRODUCTION_QUALITY_MOD).modifyFlat(getModId(0), stabilityMod, "Low stability at production source");
			market.getStats().getDynamic().getMod(Stats.PRODUCTION_QUALITY_MOD).modifyFlat(getModId(0), stabilityMod, getNameForModifier() + " - low stability");
		}

		if (!isFunctional()) {
			supply.clear();
            demand.clear();
			unapply();
		}
	}

    @Override
    public boolean isFunctional() {
        int size = SPP_PortFunctions.getPortCommoditySize(market.getSize());
        boolean pristine = false;
        boolean corrupted = false;

        if (nanoforge != null) {
            pristine = nanoforge.getId().equals(Items.PRISTINE_NANOFORGE);
            corrupted = nanoforge.getId().equals(Items.CORRUPTED_NANOFORGE);
        }

        if (size == 1 && !pristine) return false;
        if (size == 2 && !(pristine || corrupted)) return false;

        return super.isFunctional();
    }

	@Override
	public void unapply() {
		super.unapply();

		if (nanoforge != null) {
			NanoforgeInstallableItemPlugin.NanoforgeEffect effect = SPP_NanoforgeInstallableItemPlugin.NANOFORGE_EFFECTS.get(nanoforge.getId());
			if (effect != null) {
				effect.unapply(this);
			}
		}

		market.getStats().getDynamic().getMod(Stats.PRODUCTION_QUALITY_MOD).unmodifyFlat(getModId(0));
		market.getStats().getDynamic().getMod(Stats.PRODUCTION_QUALITY_MOD).unmodifyFlat(getModId(1));
	}

	protected void applyNanoforgeEffects() {
//		if (Global.getSector().getEconomy().isSimMode()) {
//			return;
//		}

		if (nanoforge != null) {
			NanoforgeInstallableItemPlugin.NanoforgeEffect effect = SPP_NanoforgeInstallableItemPlugin.NANOFORGE_EFFECTS.get(nanoforge.getId());
			if (effect != null) {
				effect.apply(this);
			}
		}
	}

	protected SpecialItemData nanoforge = null;
	public void setNanoforge(SpecialItemData nanoforge) {
		if (nanoforge == null && this.nanoforge != null) {
			NanoforgeInstallableItemPlugin.NanoforgeEffect effect = SPP_NanoforgeInstallableItemPlugin.NANOFORGE_EFFECTS.get(this.nanoforge.getId());
			if (effect != null) {
				effect.unapply(this);
			}
		}
		this.nanoforge = nanoforge;
	}

	public SpecialItemData getNanoforge() {
		return nanoforge;
	}

	public SpecialItemData getSpecialItem() {
		return nanoforge;
	}

	public void setSpecialItem(SpecialItemData special) {
		nanoforge = special;
	}

	@Override
	public boolean wantsToUseSpecialItem(SpecialItemData data) {
		if (nanoforge != null && Items.CORRUPTED_NANOFORGE.equals(nanoforge.getId()) &&
				data != null && Items.PRISTINE_NANOFORGE.equals(data.getId())) {
			return true;
		}

		return nanoforge == null &&
				data != null &&
				SPP_NanoforgeInstallableItemPlugin.NANOFORGE_EFFECTS.containsKey(data.getId());
	}

	@Override
	protected void addPostSupplySection(TooltipMakerAPI tooltip, boolean hasSupply, IndustryTooltipMode mode) {
		super.addPostSupplySection(tooltip, hasSupply, mode);
	}

	@Override
	public void notifyBeingRemoved(MarketAPI.MarketInteractionMode mode, boolean forUpgrade) {
		super.notifyBeingRemoved(mode, forUpgrade);
		if (nanoforge != null && !forUpgrade) {
			CargoAPI cargo = getCargoForInteractionMode(mode);
			if (cargo != null) {
				cargo.addSpecial(nanoforge, 1);
			}
		}
	}

	@Override
	protected boolean addNonAICoreInstalledItems(IndustryTooltipMode mode, TooltipMakerAPI tooltip, boolean expanded) {
		if (nanoforge == null) return false;

		float opad = 10f;

		FactionAPI faction = market.getFaction();
		Color color = faction.getBaseUIColor();
		Color dark = faction.getDarkUIColor();


		SpecialItemSpecAPI nanoforgeSpec = Global.getSettings().getSpecialItemSpec(nanoforge.getId());

		TooltipMakerAPI text = tooltip.beginImageWithText(nanoforgeSpec.getIconName(), 48);
		NanoforgeInstallableItemPlugin.NanoforgeEffect effect = SPP_NanoforgeInstallableItemPlugin.NANOFORGE_EFFECTS.get(nanoforge.getId());
		effect.addItemDescription(text, nanoforge, InstallableIndustryItemPlugin.InstallableItemDescriptionMode.INDUSTRY_TOOLTIP);
		tooltip.addImageWithText(opad);

		return true;
	}

	@Override
	protected void addPostDemandSection(TooltipMakerAPI tooltip, boolean hasDemand, IndustryTooltipMode mode) {
		//if (mode == IndustryTooltipMode.NORMAL && isFunctional()) {
		if (mode != IndustryTooltipMode.NORMAL || isFunctional()) {
            float total = BASE_QUALITY_BONUS;
            String totalStr = "+" + (int)Math.round(total * 100f) + "%";
            Color h = Misc.getHighlightColor();
            if (total < 0) {
                h = Misc.getNegativeHighlightColor();
                totalStr = "" + (int)Math.round(total * 100f) + "%";
            }
            float opad = 10f;
            if (total >= 0) {
                tooltip.addPara("Ship quality: %s", opad, h, totalStr);
                tooltip.addPara("*Quality bonus only applies for the largest ship producer in the faction.",
                        Misc.getGrayColor(), opad);
            }
		}
	}

	public boolean isDemandLegal(CommodityOnMarketAPI com) {
		return true;
	}

	public boolean isSupplyLegal(CommodityOnMarketAPI com) {
		return true;
	}

	@Override
	public List<InstallableIndustryItemPlugin> getInstallableItems() {
		ArrayList<InstallableIndustryItemPlugin> list = new ArrayList<InstallableIndustryItemPlugin>();
		list.add(new SPP_NanoforgeInstallableItemPlugin(this));
		return list;
	}

	@Override
	public void initWithParams(List<String> params) {
		super.initWithParams(params);

		for (String str : params) {
			if (SPP_NanoforgeInstallableItemPlugin.NANOFORGE_EFFECTS.containsKey(str)) {
				setNanoforge(new SpecialItemData(str, null));
				break;
			}
		}
	}

	@Override
	public List<SpecialItemData> getVisibleInstalledItems() {
		List<SpecialItemData> result = super.getVisibleInstalledItems();

		if (nanoforge != null) {
			result.add(nanoforge);
		}

		return result;
	}

	public float getPatherInterest() {
		float base = 2f;
		if (nanoforge != null) base += 4f;
		return base + super.getPatherInterest();
	}

}




