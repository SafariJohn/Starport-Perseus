package campaign.econ.industries;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.util.Pair;
import util.SPP_PortFunctions;

/**
 * Author: SafariJohn
 */
public class SPP_LightIndustry extends SPP_BaseIndustry {

	public void apply() {
		super.apply(true);

		int size = SPP_PortFunctions.getPortCommoditySize(market.getSize());

        applyIncomeAndUpkeep(size);

		demand(Commodities.ORGANICS, size);
		demand(Commodities.METALS, size);

		supply(Commodities.SUPPLIES, size);

		Pair<String, Integer> deficit = getMaxDeficit(Commodities.ORGANICS, Commodities.METALS);
		applyDeficitToProduction(1, deficit, Commodities.SUPPLIES);


		if (!isFunctional()) {
			supply.clear();
		}
	}

	@Override
	public String getCurrentImage() {
		float size = market.getSize();
		PlanetAPI planet = market.getPlanetEntity();
		if (planet == null || planet.isGasGiant()) {
			if (size < SPP_Spaceport.SPACEPORT_SIZE) {
				return Global.getSettings().getSpriteName("industry", "light_industry_orbital_low");
			}
			if (size >= SPP_Spaceport.MEGAPORT_SIZE) {
				return Global.getSettings().getSpriteName("industry", "light_industry_orbital_high");
			}
			return Global.getSettings().getSpriteName("industry", "light_industry_orbital");
		}
		else
		{
			if (size < SPP_Spaceport.SPACEPORT_SIZE) {
				return Global.getSettings().getSpriteName("industry", "light_industry_low");
			}
			if (size >= SPP_Spaceport.MEGAPORT_SIZE) {
				return Global.getSettings().getSpriteName("industry", "light_industry_high");
			}
		}

		return super.getCurrentImage();
	}


}
