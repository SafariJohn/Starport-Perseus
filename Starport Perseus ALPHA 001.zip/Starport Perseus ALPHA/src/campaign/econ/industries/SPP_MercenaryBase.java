package campaign.econ.industries;

import static campaign.fleets.SPP_MercFleetManager.ROUTE_PATROL;
import static campaign.fleets.SPP_MercFleetManager.ROUTE_PREPARE;
import static campaign.fleets.SPP_MercFleetManager.ROUTE_RETURN;
import static campaign.fleets.SPP_MercFleetManager.ROUTE_STAND_DOWN;
import static campaign.fleets.SPP_MercFleetManager.ROUTE_TRAVEL;
import campaign.fleets.SPP_SystemWarFleetRouteManager;
import campaign.fleets.SPP_SystemWarFleetRouteManager.WarFleetData;
import campaign.fleets.SPP_WarFleetRouteSource;
import campaign.ids.SPP_FleetTypes;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import static com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry.getDeficitText;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactory.MercType;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactory.PatrolType;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactoryV3;
import com.fs.starfarer.api.impl.campaign.fleets.FleetParamsV3;
import com.fs.starfarer.api.impl.campaign.fleets.MercAssignmentAIV2;
import com.fs.starfarer.api.impl.campaign.fleets.RouteManager;
import com.fs.starfarer.api.impl.campaign.fleets.RouteManager.OptionalFleetData;
import com.fs.starfarer.api.impl.campaign.fleets.RouteManager.RouteData;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.intel.SystemBountyManager;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Pair;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import java.util.Random;
import util.SPP_Misc;

/**
 * Author: SafariJohn
 */
public class SPP_MercenaryBase extends SPP_BaseIndustry {
	public static final int BASE_STABILITY_BONUS = 1;
	public static float DEFENSE_BONUS = 500f;

    private SPP_WarFleetRouteSource mercSource;
    private SPP_WarFleetRouteSource indieMercSource;

    @Override
    public void init(String id, MarketAPI market) {
        super.init(id, market);

        initWarFleetSources();
    }



    @Override
    public void apply() {
        int flatSize = 5;

		applyIncomeAndUpkeep(1f);

//        supply(Commodities.MARINES, flatSize);

        demand(Commodities.CREW, flatSize);
        demand(Commodities.SUPPLIES, flatSize);
        demand(Commodities.MARINES, flatSize);
        demand(Commodities.SHIPS, flatSize);

        modifyStabilityWithBaseMod();

        // Ground defenses
        // Penalty from low supplies
		float mult = getDeficitMult(Commodities.SUPPLIES);
		String extra = "";
		if (mult != 1) {
			String com = getMaxDeficit(Commodities.SUPPLIES).one;
			extra = " (" + getDeficitText(com).toLowerCase() + ")";
		}
		float bonus = DEFENSE_BONUS;
		market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD)
						.modifyFlat(getModId(), bonus * mult, getNameForModifier() + extra);

		MemoryAPI memory = market.getMemoryWithoutUpdate();
		Misc.setFlagWithReason(memory, MemFlags.MARKET_PATROL, getModId(), true, -1);

        // Apply deficit to mercenary spawn weight
        Pair<String, Integer> deficit = getMaxDeficit(Commodities.CREW,
                    Commodities.SHIPS, Commodities.SUPPLIES, Commodities.FUEL);
        float weight = SPP_SystemWarFleetRouteManager.STANDARD_WEIGHT;
        if (deficit.two > 0) weight = Math.max(1, weight - deficit.two);

        mercSource.getFleetWeights().put(SPP_FleetTypes.WAR_FLEET_MERC, weight);

        if (market.getPrimaryEntity() != null && market.getStarSystem() != null) {
            SPP_SystemWarFleetRouteManager manager = SPP_Misc.getWarFleetRouteManager(market.getStarSystem());
            manager.getRouteSources().remove(mercSource);
            manager.getRouteSources().remove(indieMercSource);
            manager.getRouteSources().add(mercSource);
            manager.getRouteSources().add(indieMercSource);
        }

        if (weight - deficit.two > 0) mercSource.getBonusFleets().put(SPP_FleetTypes.WAR_FLEET_MERC, 1);
        else mercSource.getBonusFleets().remove(SPP_FleetTypes.WAR_FLEET_MERC);

		if (!isFunctional()) {
			supply.clear();
			unapply();
		}
    }

    @Override
    public void unapply() {
        super.unapply();

        unmodifyStabilityWithBaseMod();

		market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodifyFlat(getModId());

		MemoryAPI memory = market.getMemoryWithoutUpdate();
		Misc.setFlagWithReason(memory, MemFlags.MARKET_PATROL, getModId(), false, -1);

        if (market.getPrimaryEntity() != null && market.getStarSystem() != null) {
            SPP_SystemWarFleetRouteManager manager = SPP_Misc.getWarFleetRouteManager(market.getStarSystem());
            manager.getRouteSources().remove(mercSource);
            manager.getRouteSources().remove(indieMercSource);
        }
    }

    @Override
    protected String getDescriptionOverride() {
        if (market.getFactionId().equals(Factions.HEGEMONY)) {
            return "A staging point for the Hegemony Auxiliaries. Many merchantmen and "
                        + "privately-owned warships are on the auxiliary list, to be "
                        + "pressed into service during emergencies.";
        }

        return null;
    }

    @Override
    public String getCurrentName() {
        if (market.getFactionId().equals(Factions.HEGEMONY)) {
            return "Auxiliaries Depot";
        }

        return super.getCurrentName();
    }

    @Override
    public String getCurrentImage() {
        if (market.getFactionId().equals(Factions.HEGEMONY)) {
            return Global.getSettings().getSpriteName("industry", "SPP_auxDepot");
        }

        return super.getCurrentImage();
    }

    @Override
    protected int getBaseStabilityMod() {
		Pair<String, Integer> deficit = getMaxDeficit(Commodities.SUPPLIES);
        return Math.max(0, BASE_STABILITY_BONUS - deficit.two);
    }

    private void initWarFleetSources() {
        mercSource = new SPP_WarFleetRouteSource() {
            public FactionAPI getFaction() { return market.getFaction(); }

            public RouteData createRoute(StarSystemAPI system, String fleetType) {
                return createMercRoute(system, getFaction(), fleetType, market);
            }

            public CampaignFleetAPI spawnFleet(RouteData route) {
                return createMercFleet(route, getFaction());
            }

            public boolean shouldCancelRouteAfterDelayCheck(RouteManager.RouteData route) { return false; }
            public void reportAboutToBeDespawnedByRouteManager(RouteManager.RouteData route) {}
        };

        //*************************************
        indieMercSource = new SPP_WarFleetRouteSource() {
            public FactionAPI getFaction() { return Global.getSector().getFaction(Factions.INDEPENDENT); }

            public RouteData createRoute(StarSystemAPI system, String fleetType) {
                return createMercRoute(system, getFaction(), fleetType, market);
            }

            public CampaignFleetAPI spawnFleet(RouteData route) {
                return createMercFleet(route, getFaction());
            }

            public boolean shouldCancelRouteAfterDelayCheck(RouteData route) { return false; }
            public void reportAboutToBeDespawnedByRouteManager(RouteData route) {}
        };

        indieMercSource.getFleetWeights().put(SPP_FleetTypes.WAR_FLEET_MERC, 1f);
    }

    public static RouteData createMercRoute(StarSystemAPI system, FactionAPI faction, String fleetType, MarketAPI from) {
        MarketAPI to = pickNearbyMarketToDefend(from, faction);
        if (to == null) return null;

        Long seed = new Random().nextLong();
        SPP_SystemWarFleetRouteManager manager = SPP_Misc.getWarFleetRouteManager(system);

        OptionalFleetData extra = new OptionalFleetData(from);

        WarFleetData custom = new WarFleetData(PatrolType.FAST, fleetType);

        RouteData route = RouteManager.getInstance().addRoute(manager.getRouteSourceId(), from, seed, extra, manager, custom);

        float orbitDays = 3f + (float) Math.random() * 3f;
        float deorbitDays = 3f + (float) Math.random() * 3f;
        float patrolDays = 35f + (float) Math.random() * 10f;

        SectorEntityToken target = to.getPrimaryEntity();
        if ((float) Math.random() > 0.25f && to.getStarSystem() != null) {
            if ((float) Math.random() > 0.25f) {
                target = to.getStarSystem().getCenter();
            } else {
                target = to.getStarSystem().getHyperspaceAnchor();
            }
        }

        if (from.getContainingLocation() == to.getContainingLocation() && !from.getContainingLocation().isHyperspace()) {
            route.addSegment(new RouteManager.RouteSegment(ROUTE_PREPARE, orbitDays, from.getPrimaryEntity()));
            route.addSegment(new RouteManager.RouteSegment(ROUTE_PATROL, patrolDays, target));
            route.addSegment(new RouteManager.RouteSegment(ROUTE_STAND_DOWN, deorbitDays, from.getPrimaryEntity()));
        } else {
            route.addSegment(new RouteManager.RouteSegment(ROUTE_PREPARE, orbitDays, from.getPrimaryEntity()));
            route.addSegment(new RouteManager.RouteSegment(ROUTE_TRAVEL, from.getPrimaryEntity(), to.getPrimaryEntity()));
            route.addSegment(new RouteManager.RouteSegment(ROUTE_PATROL, patrolDays, target));
            route.addSegment(new RouteManager.RouteSegment(ROUTE_RETURN, to.getPrimaryEntity(), from.getPrimaryEntity()));
            route.addSegment(new RouteManager.RouteSegment(ROUTE_STAND_DOWN, deorbitDays, from.getPrimaryEntity()));
        }

        return route;
    }

    public static CampaignFleetAPI createMercFleet(RouteData route, FactionAPI faction) {
        Random random = route.getRandom();

        WeightedRandomPicker<MercType> picker = new WeightedRandomPicker<MercType>(random);
        picker.add(MercType.SCOUT, 10f);
        picker.add(MercType.BOUNTY_HUNTER, 10f);
        picker.add(MercType.PRIVATEER, 10f);
        picker.add(MercType.PATROL, 10f);
        picker.add(MercType.ARMADA, 3f);
        MercType type = picker.pick();

        float combat = 0f;
        float tanker = 0f;
        float freighter = 0f;
        String fleetType = type.fleetType;
        PatrolType pt = PatrolType.FAST;
        switch (type) {
        case SCOUT:
            combat = Math.round(1f + random.nextFloat() * 2f);
            break;
        case PRIVATEER:
        case BOUNTY_HUNTER:
            combat = Math.round(3f + random.nextFloat() * 2f);
            break;
        case PATROL:
            pt = PatrolType.COMBAT;
            combat = Math.round(9f + random.nextFloat() * 3f);
            tanker = Math.round(random.nextFloat()) * 5f;
            break;
        case ARMADA:
            pt = PatrolType.HEAVY;
            combat = Math.round(10f + random.nextFloat() * 4f);
            tanker = Math.round(random.nextFloat()) * 10f;
            freighter = Math.round(random.nextFloat()) * 10f;
            break;
        }

        WarFleetData custom = (WarFleetData) route.getCustom();
        String ft = custom.warFleetType;
        custom = new WarFleetData(pt, ft);
        route.setCustom(custom);

        combat *= 5f;

        FleetParamsV3 params = new FleetParamsV3(
                route.getMarket(),
                null,
                faction.getId(),
                route.getQualityOverride(),
                fleetType,
                combat / 2, // combatPts
                freighter, // freighterPts
                tanker, // tankerPts
                0f, // transportPts
                0f, // linerPts
                0f, // utilityPts
                0f // qualityMod
                );
        params.timestamp = route.getTimestamp();
        params.random = random;
        CampaignFleetAPI fleet = FleetFactoryV3.createFleet(params);

        if (fleet == null || fleet.isEmpty()) return null;

        // Create random indie ships and merge
        params = new FleetParamsV3(
                route.getMarket(),
                null,
                Factions.INDEPENDENT,
                route.getQualityOverride(),
                fleetType,
                combat / 2, // combatPts
                0, // freighterPts
                0, // tankerPts
                0f, // transportPts
                0f, // linerPts
                0f, // utilityPts
                0f // qualityMod
                );
        params.timestamp = route.getTimestamp();
        params.random = random;
        CampaignFleetAPI tempFleet = FleetFactoryV3.createFleet(params);

        if (tempFleet != null && !tempFleet.isEmpty()) {
            for (FleetMemberAPI m : tempFleet.getFleetData().getMembersListCopy()) {
                fleet.getFleetData().addFleetMember(m);
            }
        }

        fleet.setNoFactionInName(true);

        route.getMarket().getContainingLocation().addEntity(fleet);
        fleet.setFacing((float) Math.random() * 360f);
        // this will get overridden by the patrol assignment AI, depending on route-time elapsed etc
        fleet.setLocation(route.getMarket().getPrimaryEntity().getLocation().x, route.getMarket().getPrimaryEntity().getLocation().y);

        MercAssignmentAIV2 ai = new MercAssignmentAIV2(fleet, route);
        fleet.addScript(ai);


        return fleet;
    }

	public static MarketAPI pickNearbyMarketToDefend(MarketAPI source, FactionAPI fleetFaction) {
		WeightedRandomPicker<MarketAPI> picker = new WeightedRandomPicker<MarketAPI>();

		for (MarketAPI iMarket : Global.getSector().getEconomy().getMarketsCopy()) {
            if (iMarket.getFaction().isHostileTo(fleetFaction)) continue;
			if (iMarket.getStarSystem() == null) continue;
			if (iMarket.isHidden()) continue;

			if (iMarket.getStarSystem() != null && iMarket.getStarSystem().hasTag(Tags.SYSTEM_CUT_OFF_FROM_HYPER)) {
				continue;
			}

            if (!fleetFaction.getId().equals(Factions.INDEPENDENT) && iMarket.getStarSystem() != source.getStarSystem()) {
                continue; // Faction mercs stay in-system
            }

			float dist = Misc.getDistance(iMarket.getLocationInHyperspace(), source.getLocationInHyperspace());
			if (dist < 1000) dist = 1000;
			float weight = 10000f / dist;

			if (SystemBountyManager.getInstance().isActive(iMarket)) {
				weight *= 5f;
			}

			picker.add(iMarket, weight);
		}
		MarketAPI rMarket = picker.pick();
//		if (market == null) return null;
//		return market.getStarSystem();
		return rMarket;
	}

    @Override
    public float getPatherInterest() {
        return 2f + super.getPatherInterest();
    }
}
