package campaign.econ.industries;

import campaign.SPP_ImmigrationScript.PopLimitModifier;
import campaign.econ.SPP_NativePopCondition;
import campaign.ids.SPP_Industries;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;
import com.fs.starfarer.api.campaign.econ.MarketImmigrationModifier;
import com.fs.starfarer.api.characters.MarketConditionSpecAPI;
import com.fs.starfarer.api.combat.MutableStat;
import static com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry.getDeficitText;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Industries;
import com.fs.starfarer.api.impl.campaign.population.PopulationComposition;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Pair;
import java.awt.Color;
import java.util.*;
import util.SPP_Misc;
import util.SPP_PortFunctions;


public class SPP_LocalEconomy extends SPP_BaseIndustry implements MarketImmigrationModifier {
    public enum Ind {
        FARMING,
        AQUACULTURE,
        MINING,
        DRILLING,
        SIPHONING,
        NONE
    }


	public void apply() {
		super.apply(true);

        if (isBuilding() && !isUpgrading()) finishBuildingOrUpgrading();

        int population = SPP_PortFunctions.getPopulationSize(market);

		demand(Commodities.ORGANS, population - 3, SPP_BaseIndustry.BASE_POPULATION_TEXT);

        boolean hasNatives = false;
        for (MarketConditionAPI cond : market.getConditions()) {
            if (cond.getPlugin() instanceof SPP_NativePopCondition) {
                hasNatives = true;
                break;
            }
        }

        if (!market.hasCondition(Conditions.HABITABLE) && !hasNatives) {
            demand(Commodities.FOOD, population + 1, SPP_BaseIndustry.BASE_POPULATION_TEXT);
        }

		demand(Commodities.DOMESTIC_GOODS, population - 1, SPP_BaseIndustry.BASE_POPULATION_TEXT);
		demand(Commodities.LUXURY_GOODS, population - 3, SPP_BaseIndustry.BASE_POPULATION_TEXT);

        demand(Commodities.DRUGS, population - 2, SPP_BaseIndustry.BASE_POPULATION_TEXT);


        int portLimit = SPP_PortFunctions.getPopulationCommoditySize(market);
        int reduction = Math.min(portLimit - (population - 1), 0);
//        int size = population;

        supply(getModId(1), Commodities.CREW, population - 1,
                    SPP_BaseIndustry.BASE_POPULATION_TEXT);
        supply(getModId(2), Commodities.CREW, reduction, "Port size");

        if (market.hasCondition(Conditions.WATER_SURFACE)) {
            demand(Commodities.HEAVY_MACHINERY, portLimit,
                        SPP_BaseIndustry.BASE_POPULATION_TEXT);
        } else if (getPrimaryIndusty() != Ind.NONE) {
            demand(Commodities.HEAVY_MACHINERY, portLimit - 3,
                        SPP_BaseIndustry.BASE_POPULATION_TEXT);
        }


		Pair<String, Integer> deficit = getMaxDeficit(Commodities.HEAVY_MACHINERY);
		applyDeficitToProduction(0, deficit,
						Commodities.ORE,
						Commodities.RARE_ORE,
						Commodities.ORGANICS,
						Commodities.VOLATILES,
                        Commodities.FOOD);


		deficit = getMaxDeficit(Commodities.DOMESTIC_GOODS);
		if (deficit.two <= 0 && population - 1 > 0) {
			market.getStability().modifyFlat(getModId(0), 1, "Domestic goods demand met");
		} else {
			market.getStability().unmodifyFlat(getModId(0));
		}

		deficit = getMaxDeficit(Commodities.LUXURY_GOODS);
		if (deficit.two <= 0 && population - 3 > 0) {
			market.getStability().modifyFlat(getModId(1), 1, "Luxury goods demand met");
		} else {
			market.getStability().unmodifyFlat(getModId(1));
		}

		deficit = getMaxDeficit(Commodities.FOOD);
//		if (!market.hasCondition(Conditions.HABITABLE)) {
//			deficit = getMaxDeficit(Commodities.FOOD, Commodities.ORGANICS);
//		}
		if (deficit.two > 0) {
			market.getStability().modifyFlat(getModId(2), -deficit.two, getDeficitText(deficit.one));
		} else {
			market.getStability().unmodifyFlat(getModId(2));
		}


        // Pop limit modifiers
        Map<String, PopLimitModifier> mods = SPP_Misc.getPopulationLimitModifiers(market);
        PopLimitModifier mod;

        String desc = "";
        if (market.hasIndustry(SPP_Industries.HYDROPONICS)) desc = "Farming";
        if (market.hasIndustry(SPP_Industries.CRAWLERS)) desc = "Mining";
        if (market.hasIndustry(SPP_Industries.SIPHON_PLATFORM)) desc = "Mining";
        switch (getPrimaryIndusty()) {
            case FARMING:
                desc = "Farming";
                break;
            case AQUACULTURE:
                desc = "Aquaculture";
                break;
            case MINING:
            case DRILLING:
            case SIPHONING:
                desc = "Mining";
                break;
        }

        if (!desc.isEmpty()) {
            mod = new PopLimitModifier(desc);
            mods.put(SPP_Industries.LOCAL_ECONOMY, mod);
        }

        if (hasSecondaryEconomy()) {
            mod = new PopLimitModifier("Industry");
            mods.put(SPP_Industries.LIGHT_INDUSTRY, mod);
        }

        if (!isFunctional()) {
            supply.clear();
        }
	}

    private boolean hasSecondaryEconomy() {
        for (Industry ind : market.getIndustries()) {
            if (ind.getSpec().hasTag(SPP_Industries.TAG_INDUSTRIAL_POP)) return true;
        }

        return false;

//        return market.hasIndustry(SPP_Industries.LIGHT_INDUSTRY)
//                    || market.hasIndustry(SPP_Industries.HEAVY_INDUSTRY)
//                    || market.hasIndustry(SPP_Industries.REFINING)
//                    || market.hasIndustry(SPP_Industries.SHIPYARD)
//                    || market.hasIndustry(SPP_Industries.BONEYARD)
//                    || market.hasIndustry(SPP_Industries.FUEL_PROD)
//                    || market.hasIndustry(SPP_Industries.TRADE_CENTER)
//                    || market.hasIndustry(SPP_Industries.SMUGGLING_NETWORK)
//                    || market.hasIndustry(SPP_Industries.TECH_MINING)
//                    || market.hasIndustry(SPP_Industries.SHIPBREAKERS)
//                    || market.hasIndustry(SPP_Industries.COLONY_PROGRAM)
//                    || market.hasIndustry(SPP_Industries.MILITARY_BASE)
//                    || market.hasIndustry(SPP_Industries.CORPORATE_HQ)
//                    || market.hasIndustry(SPP_Industries.RAIDER_FORTRESS);
    }


	@Override
	public void unapply() {
		super.unapply();

		market.getStability().unmodify(getModId(0));
		market.getStability().unmodify(getModId(1));
		market.getStability().unmodify(getModId(2));

        // Remove pop limit modifiers
        Map<String, PopLimitModifier> mods = SPP_Misc.getPopulationLimitModifiers(market);
        mods.remove(SPP_Industries.LOCAL_ECONOMY);
        mods.remove(SPP_Industries.LIGHT_INDUSTRY);
	}

    @Override
	protected boolean hasPostDemandSection(boolean hasDemand, IndustryTooltipMode mode) {
		Pair<String, Integer> deficit = getMaxDeficit(Commodities.DRUGS);
		if (deficit.two <= 0) return false;
		//return mode == IndustryTooltipMode.NORMAL && isFunctional();
		return mode != IndustryTooltipMode.NORMAL || isFunctional();
	}

	@Override
	protected void addPostDemandSection(TooltipMakerAPI tooltip, boolean hasDemand, IndustryTooltipMode mode) {
		//if (mode == IndustryTooltipMode.NORMAL && isFunctional()) {
		if (mode != IndustryTooltipMode.NORMAL || isFunctional()) {

			MutableStat stabilityMods = new MutableStat(0);

			float total = 0;
			for (MutableStat.StatMod mod : market.getStability().getFlatMods().values()) {
				if (mod.source.startsWith(getModId())) {
					stabilityMods.modifyFlat(mod.source, mod.value, mod.desc);
					total += mod.value;
				}
			}

			String totalStr = "+" + (int)Math.round(total);
			Color h = Misc.getHighlightColor();
			if (total < 0) {
				totalStr = "" + (int)Math.round(total);
				h = Misc.getNegativeHighlightColor();
			}
			float opad = 10f;
			float pad = 3f;

			if (total >= 0) {
				tooltip.addPara("Stability bonus: %s", opad, h, totalStr);
			} else {
				tooltip.addPara("Stability penalty: %s", opad, h, totalStr);
			}

			tooltip.addStatModGrid(400, 30, opad, pad, stabilityMods, new TooltipMakerAPI.StatModValueGetter() {
                @Override
				public String getPercentValue(MutableStat.StatMod mod) {
					return null;
				}
                @Override
				public String getMultValue(MutableStat.StatMod mod) {
					return null;
				}
                @Override
				public Color getModColor(MutableStat.StatMod mod) {
					if (mod.value < 0) return Misc.getNegativeHighlightColor();
					return null;
				}
                @Override
				public String getFlatValue(MutableStat.StatMod mod) {
					return null;
				}
			});

			Pair<String, Integer> deficit = getMaxDeficit(Commodities.DRUGS);
			if (deficit.two > 0) {
				tooltip.addPara(getDeficitText(Commodities.DRUGS) + ": %s units. Reduced port development.", pad, h, "" + deficit.two);
			}
		}
	}


	@Override
	public void modifyIncoming(MarketAPI market, PopulationComposition incoming) {
        if (supply.get(Commodities.FOOD).getQuantity().isPositive()) {
            incoming.add(Factions.LUDDIC_CHURCH, 10f);
        }


		Pair<String, Integer> deficit = getMaxDeficit(Commodities.DRUGS);
		if (deficit.two > 0) {
			incoming.getWeight().modifyFlat(getModId(), -deficit.two, "Mining: drug shortage");
		}


		float patherLevel = 0;
		for (Industry curr : market.getIndustries()) {
			patherLevel += getAICoreImpact(curr.getAICoreId());
		}

		String adminCoreId = market.getAdmin().getAICoreId();
		if (adminCoreId != null) {
			patherLevel += 10f * getAICoreImpact(adminCoreId);
		}

		List<String> targeted = new ArrayList<String>();
		targeted.add(Industries.TECHMINING);
		targeted.add(SPP_Industries.SHIPYARD);
		targeted.add(Industries.FUELPROD);
		targeted.add(Industries.STARFORTRESS);
		targeted.add(SPP_Industries.HEAVY_INDUSTRY);
		targeted.add(SPP_Industries.BONEYARD);

		for (String curr : targeted) {
			if (market.hasIndustry(curr)) {
				patherLevel += 10f;
			}
		}

		if (patherLevel > 0) {
			incoming.add(Factions.LUDDIC_PATH, patherLevel * 0.2f);
		}
	}

	private float getAICoreImpact(String coreId) {
		if (Commodities.ALPHA_CORE.equals(coreId)) return 10f;
		if (Commodities.BETA_CORE.equals(coreId)) return 4f;
		if (Commodities.GAMMA_CORE.equals(coreId)) return 1f;
		return 0f;
	}


	@Override
	public String getCurrentImage() {
        switch (getPrimaryIndusty()) {
            case FARMING:
                switch (SPP_PortFunctions.getFood(market)) {
                    case  2: return Global.getSettings().getSpriteName("industry", "farming_high");
                    case  1: return Global.getSettings().getSpriteName("industry", "farming");
                    case  0: return Global.getSettings().getSpriteName("industry", "farming_med");
                    case -1: return Global.getSettings().getSpriteName("industry", "farming_low");
                }
                break;
            case AQUACULTURE: return Global.getSettings().getSpriteName("industry", "aquaculture");
            case MINING:
                switch (Math.max(SPP_PortFunctions.getOre(market), SPP_PortFunctions.getRareOre(market))) {
                    case  3:
                    case  2:
                    case  1: return Global.getSettings().getSpriteName("industry", "mining");
                    case  0:
                    case -1: return Global.getSettings().getSpriteName("industry", "mining_low");
                }
                break;
            case DRILLING:
                switch (SPP_PortFunctions.getOrganics(market)) {
                    case  2:
                    case  1: return Global.getSettings().getSpriteName("industry", "mining");
                    case  0:
                    case -1: return Global.getSettings().getSpriteName("industry", "mining_low");
                }
                break;
            case SIPHONING:
                switch (SPP_PortFunctions.getVolatiles(market)) {
                    case  2:
                    case  1: return Global.getSettings().getSpriteName("industry", "mining");
                    case  0:
                    case -1: return Global.getSettings().getSpriteName("industry", "mining_low");
                }
                break;
            case NONE:
                int pop = SPP_PortFunctions.getPopulationSize(market);

                if (pop <= 4) {
                    return Global.getSettings().getSpriteName("industry", "pop_low");
                }
                if (pop >= 7) {
                    return Global.getSettings().getSpriteName("industry", "pop_high");
                }
        }

		return super.getCurrentImage(); // pop_mid
	}

    @Override
    public String getCurrentName() {
        String desc = "Population";

        Ind primary = getPrimaryIndusty();
        switch (primary) {
            case FARMING: return desc + " (Farming)";
            case AQUACULTURE: return desc + " (Aquaculture)";
            case MINING:
            case DRILLING:
            case SIPHONING: return desc + " (Mining)";
            case NONE:
        }

//        if (SPP_PortFunctions.getPopulationSize(market) == 0) return "Desolate";

        return desc;
    }

    @Override
    protected String getDescriptionOverride() {
        int pop = SPP_PortFunctions.getPopulationSize(market);
        Ind primary = getPrimaryIndusty();

        if (pop == 0 && primary == Ind.NONE) return super.getDescriptionOverride();

        // Primary industry descriptions
        String farming = "Agriculture is a trade and technology as old as civilization itself; "
                    + "for thousands of cycles Humanity has harnessed the power of natural, modified, "
                    + "and artificial biological machines for sustenance. So it has always been, "
                    + "so it shall be so long as humans are human.";
        String aquaculture = "Farming on a water world requires a significant initial investment "
                    + "in bioengineering suitable species, but once the process takes off, "
                    + "algae farms and fisheries can be operated by the population without requiring "
                    + "much in the way of specialized training or equipment.";
        String mining = "Metal and metalloid ores, organics, and volatile compounds all require heavy equipment, "
                    + "special infrastructure, and a skilled workforce to extract. "
                    + "The harsh work attracts a certain type, and an administration that's not willing "
                    + "to look the other way now and again may find itself running short of willing personnel.";

        // Our return string.
        String desc = "";

        // Place description of pop size first.
		String cid;
		if (pop >= 0) {
			cid = "population_" + pop;
            if (pop == 0) cid = "SPP_population_0";
			MarketConditionSpecAPI mcs = Global.getSettings().getMarketConditionSpec(cid);
			if (mcs != null) {
				desc += mcs.getDesc();
			}
		} else {
            desc += "There is no permanent population at $market.";
        }

        // Mention primary industry and add its description.
        switch (primary) {
            case FARMING:
//                desc += "The primary extraction industry is farming.";
                desc += "\n\n";
                desc += farming;
                break;
            case AQUACULTURE:
//                desc += "The primary extraction industry is aquaculture.";
                desc += "\n\n";
                desc += aquaculture;
                break;
            case MINING:
            case DRILLING:
            case SIPHONING:
//                desc += "The primary extraction industry is mining.";
                desc += "\n\n";
                desc += mining;
                break;
            case NONE:
//                if (pop > 0) {
////                    desc += "There is no primary industry.";
//                    // Service economy?
//                } else {
//                    desc = "$market is desolate beyond the boundaries of the port.";
//                }

//                if (pop <= 4) {
//                }
//                if (pop >= 7) {
//                }
        }

        // Finally, list any other primary industries.

        return desc;
    }

    public Ind getPrimaryIndusty() {
		List<Pair<Ind, Integer>> values = new ArrayList<>();

        int farming = SPP_PortFunctions.getFood(market);
        if (SPP_PortFunctions.hasAquaculture(market)) {
            return Ind.AQUACULTURE;
//            farming = getMaxAquaculture();
//            values.add(new Pair<>(Ind.AQUACULTURE, farming));
        } else {
            if (farming == 2) return Ind.FARMING;
            values.add(new Pair<>(Ind.FARMING, farming));
        }


        int mining = Math.max(SPP_PortFunctions.getOre(market), SPP_PortFunctions.getRareOre(market));
        if (mining >= 2) return Ind.MINING;
        values.add(new Pair<>(Ind.MINING, mining));


        int drilling = SPP_PortFunctions.getOrganics(market);
        if (drilling == 2) return Ind.DRILLING;
        values.add(new Pair<>(Ind.DRILLING, drilling));


        int siphoning = SPP_PortFunctions.getVolatiles(market);
        if (siphoning == 2 && isProducing(Ind.SIPHONING)) return Ind.SIPHONING;
        values.add(new Pair<>(Ind.SIPHONING, siphoning));


        Ind industry = Ind.NONE;
        int highest = -2;
        for (Pair p : values) {
            if (!isProducing((Ind) p.one)) continue;

            if ((int) p.two > highest) {
                industry = (Ind) p.one;
                highest = (int) p.two;
            }
        }

//        if (industry == Ind.FARMING && SPP_PortFunctions.hasAquaculture(market)) industry = Ind.AQUACULTURE;

        return industry;
    }

    private boolean isProducing(Ind industry) {
        int size = SPP_PortFunctions.getPopulationCommoditySize(market);

        switch (industry) {
            case FARMING: return size + SPP_PortFunctions.getFood(market) > 0;
            case AQUACULTURE: return true;
            case MINING:
                int ore = SPP_PortFunctions.getOre(market);
                int rare = SPP_PortFunctions.getRareOre(market) - 2;
                return size + Math.max(ore, rare) > 0;
            case DRILLING: return size + SPP_PortFunctions.getOrganics(market) > 0;
            case SIPHONING: return size - 2 + SPP_PortFunctions.getVolatiles(market) > 0;
            default: return false;
        }
    }

	public String getBuildOrUpgradeProgressText() {
//		float f = buildProgress / spec.getBuildTime();
//		return "" + (int) Math.round(f * 100f) + "%";
		if (isUpgrading()) {
			return "total growth: " + Misc.getRoundedValue(SPP_Misc.getPopulationSizeProgress(market) * 100f) + "%";
		}

		return super.getBuildOrUpgradeProgressText();
	}

	@Override
	public float getBuildOrUpgradeProgress() {
        if (market.getContainingLocation() == null) return 0;

        return SPP_Misc.getPopulationSizeProgress(market);
	}

	@Override
	public boolean isBuilding() {
		return SPP_Misc.getPopulationGrowth(market) > 0;
	}

	@Override
	public boolean isUpgrading() {
		return SPP_Misc.getPopulationGrowth(market) > 0;
	}

	@Override
	public boolean showShutDown() {
		return false;
	}

	@Override
	public String getCanNotShutDownReason() {
		//return "Use \"Abandon Colony\" instead.";
		return null;
	}

	@Override
	public boolean canShutDown() {
		return false;
	}

	@Override
	public float getPatherInterest() {
		return 1f + super.getPatherInterest();
	}

    @Override
    protected void sendBuildOrUpgradeMessage() {}
}
