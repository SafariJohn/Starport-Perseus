package campaign.econ.industries;

import campaign.econ.SPP_ResourceDepositsCondition;
import static campaign.econ.industries.SPP_CommandBase.TRADE_WEIGHT_MULT;
import static campaign.econ.industries.SPP_RaiderBase.BASE_STABILITY_BONUS;
import campaign.fleets.SPP_SystemWarFleetRouteManager;
import campaign.fleets.SPP_SystemWarFleetRouteManager.WarFleetData;
import campaign.fleets.SPP_WarFleetRouteSource;
import campaign.ids.SPP_FleetTypes;
import campaign.ids.SPP_Industries;
import campaign.ids.SPP_MemKeys;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.impl.items.BlueprintProviderItem;
import com.fs.starfarer.api.campaign.impl.items.ModSpecItemPlugin;
import com.fs.starfarer.api.combat.MutableStat;
import static com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry.getDeficitText;
import com.fs.starfarer.api.impl.campaign.fleets.RouteManager.RouteData;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.impl.campaign.procgen.SalvageEntityGenDataSpec;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.SalvageEntity;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Pair;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import util.SPP_Misc;
import util.SPP_PortFunctions;

/**
 * Author: SafariJohn
 */
public class SPP_RaiderFortress extends SPP_CommandBase {
    public static final int MAX_STABILITY_PENALTY = 2;

    private SPP_WarFleetRouteSource localSource;
    private SPP_WarFleetRouteSource indieMercSource;
    private SPP_WarFleetRouteSource factionSource;

    @Override
    public void init(String id, MarketAPI market) {
        super.init(id, market);

        initWarFleetSources();
    }

    @Override
    public void apply() {
        super.apply();

		int size = 2 + SPP_ResourceDepositsCondition.RESOURCE_STRUCTURE_BASE_SIZE;
        int scalingSize = SPP_PortFunctions.getPortCommoditySize(market.getSize());
        int adjustedSize = Math.max(size, scalingSize);
        adjustedSize = size + (int) (scalingSize * 0.3f);

        demand(Commodities.MARINES, adjustedSize);

        Pair<String, Integer> deficit;

        // Ground defenses
        // Penalty from low marines and/or heavy armaments
		float mult = getDeficitMult(Commodities.MARINES);
		String extra = "";
		if (mult != 1) {
			String com = getMaxDeficit(Commodities.MARINES).one;
			extra = " (" + getDeficitText(com).toLowerCase() + ")";
		}
		float bonus = DEFENSE_BONUS;
		market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD)
						.modifyFlat(getModId(), bonus * mult, getNameForModifier() + extra);

        // Deficit penalty to stability
        demand(Commodities.LUXURY_GOODS, adjustedSize - 2);
        demand(Commodities.DRUGS, adjustedSize - 2);

        // Apply deficit to local spawn weight
        deficit = getMaxDeficit(Commodities.CREW, Commodities.SHIPS,
                    Commodities.SUPPLIES, Commodities.FUEL);
        float warWeight = SPP_SystemWarFleetRouteManager.STANDARD_WEIGHT;
        if (deficit.two > 0) warWeight = Math.max(1, warWeight - deficit.two);

        localSource.getFleetWeights().put(SPP_FleetTypes.WAR_FLEET_MERC, warWeight);
        localSource.getFleetWeights().put(SPP_FleetTypes.WAR_FLEET_RAIDER, warWeight);

        // Sources to spawn war fleets
        if (market.getPrimaryEntity() != null && market.getStarSystem() != null) {
            SPP_SystemWarFleetRouteManager manager = SPP_Misc.getWarFleetRouteManager(market.getStarSystem());
            manager.getRouteSources().remove(localSource);
            manager.getRouteSources().add(localSource);
        }

        if (warWeight - deficit.two > 0) {
//            localSource.getBonusFleets().put(SPP_FleetTypes.WAR_FLEET_MERC, 1);
            localSource.getBonusFleets().put(SPP_FleetTypes.WAR_FLEET_RAIDER, 1);
        } else {
//            localSource.getBonusFleets().remove(SPP_FleetTypes.WAR_FLEET_MERC);
            localSource.getBonusFleets().remove(SPP_FleetTypes.WAR_FLEET_RAIDER);
        }

        // Faction-wide fleets increase with market size
        warWeight = market.getSize() / 3f;
        if (deficit.two > 0) warWeight = Math.max(1, warWeight - deficit.two);

//        factionSource.getFleetWeights().put(SPP_FleetTypes.WAR_FLEET_MERC, warWeight);
        factionSource.getFleetWeights().put(SPP_FleetTypes.WAR_FLEET_RAIDER, warWeight);

        SPP_Misc.getFactionWarFleetSources(market.getFaction()).remove(factionSource);
        SPP_Misc.getFactionWarFleetSources(market.getFaction()).add(factionSource);

        if (warWeight - deficit.two > 0) {
//            SPP_Misc.getFactionWarFleetBonusFleets(market.getFaction()).put(getUID(0), SPP_FleetTypes.WAR_FLEET_MERC);
            SPP_Misc.getFactionWarFleetBonusFleets(market.getFaction()).put(getUID(1), SPP_FleetTypes.WAR_FLEET_RAIDER);
        } else {
//            SPP_Misc.getFactionWarFleetBonusFleets(market.getFaction()).remove(getUID(0));
            SPP_Misc.getFactionWarFleetBonusFleets(market.getFaction()).remove(getUID(1));
        }

		if (!isFunctional()) {
			supply.clear();
			unapply();
		}

	}

    @Override
    protected void modifyStabilityWithBaseMod() {
		int stabilityMod = getBaseStabilityMod();
		int stabilityPenalty = getStabilityPenalty();

        String extra = "";
        if (stabilityMod < BASE_STABILITY_BONUS) {
			String com = getMaxDeficit(Commodities.SUPPLIES).one;
			extra = " (" + getDeficitText(com).toLowerCase() + ")";
        }

        market.getStability().modifyFlat(getModId(0), stabilityMod, getNameForModifier() + extra);

        if (stabilityPenalty > 0) {
			String com = getMaxDeficit(Commodities.LUXURY_GOODS, Commodities.DRUGS).one;
			extra = " (" + getDeficitText(com).toLowerCase() + ")";

            market.getStability().modifyFlat(getModId(1), stabilityPenalty, getNameForModifier() + extra);
		}
    }

    @Override
    protected int getStabilityPenalty() {
        Pair<String, Integer> deficit = getMaxDeficit(Commodities.LUXURY_GOODS, Commodities.DRUGS);
        return Math.min(MAX_STABILITY_PENALTY, deficit.two);
    }

    @Override
    protected void unmodifyStabilityWithBaseMod() {
		market.getStability().unmodifyFlat(getModId(0));
		market.getStability().unmodifyFlat(getModId(1));
    }

    @Override
    public void unapply() {
        super.unapply();

        market.getMemoryWithoutUpdate().set(SPP_MemKeys.SPAWN_SMUGGLER_FLEETS, false);

        if (market.getPrimaryEntity() != null && market.getStarSystem() != null) {
            SPP_SystemWarFleetRouteManager manager = SPP_Misc.getWarFleetRouteManager(market.getStarSystem());
            manager.getRouteSources().remove(localSource);
        }

        SPP_Misc.getFactionWarFleetSources(market.getFaction()).remove(factionSource);

        SPP_Misc.getFactionWarFleetBonusFleets(market.getFaction()).remove(getUID(0));
        SPP_Misc.getFactionWarFleetBonusFleets(market.getFaction()).remove(getUID(1));
    }

	@Override
	protected void addPostDemandSection(TooltipMakerAPI tooltip, boolean hasDemand, IndustryTooltipMode mode) {
        super.addPostDemandSection(tooltip, hasDemand, mode);

        float bonus = DEFENSE_BONUS;
        addGroundDefensesImpactSection(tooltip, bonus, Commodities.MARINES);

		if (mode != IndustryTooltipMode.NORMAL || isFunctional()) {
			float opad = 10f;
            float a = getAccessibilityBonus();
            float total = a;
            String totalStr = "+" + (int)Math.round(total * 100f) + "%";
            Color h = Misc.getHighlightColor();
            tooltip.addPara("Accessibility bonus: %s", opad, h, totalStr);


            tooltip.addPara("More trade fleets originate at this port.", opad);
		}
	}

	public CargoAPI generateCargoForGatheringPoint(Random random) {
		if (!isFunctional()) return null;

		float base = 0.5f;
        float bonus = 0.2f;

		List<SalvageEntityGenDataSpec.DropData> dropRandom = new ArrayList<SalvageEntityGenDataSpec.DropData>();
		List<SalvageEntityGenDataSpec.DropData> dropValue = new ArrayList<SalvageEntityGenDataSpec.DropData>();

		SalvageEntityGenDataSpec.DropData d = new SalvageEntityGenDataSpec.DropData();
//		d.chances = 1;
//		d.group = "blueprints_low";
//		d.valueMult = 0.1f;
//		//d.addCustom("item_:{tags:[single_bp], p:{tags:[rare_bp]}}", 1f);
//		dropRandom.add(d);
//
//		d = new SalvageEntityGenDataSpec.DropData();
//		d.chances = 1;
//		d.group = "rare_tech_low";
//		d.valueMult = 0.1f;
//		dropRandom.add(d);

		d = new SalvageEntityGenDataSpec.DropData();
		d.chances = 1;
		d.group = "any_hullmod_low";
		dropRandom.add(d);

		d = new SalvageEntityGenDataSpec.DropData();
		d.chances = 5;
		d.group = "weapons2";
		dropRandom.add(d);

		d = new SalvageEntityGenDataSpec.DropData();
		//d.chances = 100;
		d.group = "basic";
		d.value = 10000;
		dropValue.add(d);

		CargoAPI result = SalvageEntity.generateSalvage(random, 1f, 1f, base + bonus, 1f, dropValue, dropRandom);

		FactionAPI pf = Global.getSector().getPlayerFaction();
		OUTER: for (CargoStackAPI stack : result.getStacksCopy()) {
			if (stack.getPlugin() instanceof BlueprintProviderItem) {
				BlueprintProviderItem bp = (BlueprintProviderItem) stack.getPlugin();
				List<String> list = bp.getProvidedShips();
				if (list != null) {
					for (String id : list) {
						if (!pf.knowsShip(id)) continue OUTER;
					}
				}

				list = bp.getProvidedWeapons();
				if (list != null) {
					for (String id : list) {
						if (!pf.knowsWeapon(id)) continue OUTER;
					}
				}

				list = bp.getProvidedFighters();
				if (list != null) {
					for (String id : list) {
						if (!pf.knowsFighter(id)) continue OUTER;
					}
				}

				list = bp.getProvidedIndustries();
				if (list != null) {
					for (String id : list) {
						if (!pf.knowsIndustry(id)) continue OUTER;
					}
				}
				result.removeStack(stack);
			} else if (stack.getPlugin() instanceof ModSpecItemPlugin) {
				ModSpecItemPlugin mod = (ModSpecItemPlugin) stack.getPlugin();
				if (!pf.knowsHullMod(mod.getModId())) continue OUTER;
				result.removeStack(stack);
			}
		}

		return result;
	}

    @Override
    public boolean isAvailableToBuild() {
        if (!super.isAvailableToBuild()) return false;

        if (id.equals(SPP_Industries.RAIDER_FORTRESS_TEMP)) {
            return !market.hasIndustry(SPP_Industries.RAIDER_CAMP);
        }

        return true;
    }

    @Override
    public String getUnavailableReason() {
        if (!super.isAvailableToBuild()) return super.getUnavailableReason();

        if (market.hasIndustry(SPP_Industries.RAIDER_CAMP)) {
            return "Upgrade your Raider Camp!";
        }

        return "Can not be built";
    }

    //<editor-fold defaultstate="collapsed" desc="Fleet Stuff">
    private void initWarFleetSources() {
        localSource = new SPP_WarFleetRouteSource() {
            public FactionAPI getFaction() { return market.getFaction(); }

            public RouteData createRoute(StarSystemAPI system, String fleetType) {
                if (fleetType.equals(SPP_FleetTypes.WAR_FLEET_MERC)) {
                    return SPP_MercenaryBase.createMercRoute(system, getFaction(), fleetType, market);
                }

                return SPP_RaiderBase.createRaiderRoute(system, fleetType, market);
            }

            public CampaignFleetAPI spawnFleet(RouteData route) {
                WarFleetData custom = (WarFleetData) route.getCustom();
                if (custom.warFleetType.equals(SPP_FleetTypes.WAR_FLEET_MERC)) {
                    return SPP_MercenaryBase.createMercFleet(route, getFaction());
                }

                return SPP_RaiderBase.createRaiderFleet(route, getFaction());
            }

            public boolean shouldCancelRouteAfterDelayCheck(RouteData route) { return false; }
            public void reportAboutToBeDespawnedByRouteManager(RouteData route) {}
        };

        indieMercSource = new SPP_WarFleetRouteSource() {
            public FactionAPI getFaction() { return Global.getSector().getFaction(Factions.INDEPENDENT); }

            public RouteData createRoute(StarSystemAPI system, String fleetType) {
                return SPP_MercenaryBase.createMercRoute(system, getFaction(), fleetType, market);
            }

            public CampaignFleetAPI spawnFleet(RouteData route) {
                return SPP_MercenaryBase.createMercFleet(route, getFaction());
            }

            public boolean shouldCancelRouteAfterDelayCheck(RouteData route) { return false; }
            public void reportAboutToBeDespawnedByRouteManager(RouteData route) {}
        };

        indieMercSource.getFleetWeights().put(SPP_FleetTypes.WAR_FLEET_MERC, 1f);

        factionSource = new SPP_WarFleetRouteSource() {
            public FactionAPI getFaction() { return market.getFaction(); }

            public RouteData createRoute(StarSystemAPI system, String fleetType) {
                WeightedRandomPicker mPicker = new WeightedRandomPicker();
                for (MarketAPI iMarket : SPP_Misc.getMarketsInLocation(system, getFaction().getId())) {
                    mPicker.add(iMarket, iMarket.getSize());
                }

                MarketAPI from = (MarketAPI) mPicker.pick();

                if (from == null) return null;

                if (fleetType.equals(SPP_FleetTypes.WAR_FLEET_MERC)) {
                    return SPP_MercenaryBase.createMercRoute(system, getFaction(), fleetType, from);
                }

                return SPP_RaiderBase.createRaiderRoute(system, fleetType, from);
            }

            public CampaignFleetAPI spawnFleet(RouteData route) {
                WarFleetData custom = (WarFleetData) route.getCustom();
                if (custom.warFleetType.equals(SPP_FleetTypes.WAR_FLEET_MERC)) {
                    return SPP_MercenaryBase.createMercFleet(route, getFaction());
                }

                return SPP_RaiderBase.createRaiderFleet(route, getFaction());
            }

            public boolean shouldCancelRouteAfterDelayCheck(RouteData route) { return false; }
            public void reportAboutToBeDespawnedByRouteManager(RouteData route) {}
        };
    }
    //</editor-fold>

    @Override
    public float getPatherInterest() {
        return 4f + super.getPatherInterest();
    }
}
