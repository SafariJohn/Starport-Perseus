package campaign.econ.industries;

import campaign.ids.SPP_Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.util.Pair;
import util.SPP_PortFunctions;

/**
 * Author: SafariJohn
 */
public class SPP_Boneyard extends SPP_BaseIndustry {

    @Override
    public void apply() {
        int size = SPP_PortFunctions.getPortCommoditySize(market.getSize());

		supply(Commodities.SHIPS, size - 1);
		supply(Commodities.METALS, size);

		demand(Commodities.SUPPLIES, size);
		demand(Commodities.HEAVY_MACHINERY, size - 2);

		Pair<String, Integer> deficit = getMaxDeficit(Commodities.SUPPLIES, Commodities.HEAVY_MACHINERY);
		int maxDeficit = Math.max(0, size - 3); // to allow *some* production so economy doesn't get into an unrecoverable state
		if (deficit.two > maxDeficit) deficit.two = maxDeficit;

		applyDeficitToProduction(2, deficit,
					Commodities.METALS,
					Commodities.SHIPS);

		float stability = market.getPrevStability();
		if (stability < 5) {
			float stabilityMod = (stability - 5f) / 5f;
			stabilityMod *= 0.5f;
			//market.getStats().getDynamic().getMod(Stats.PRODUCTION_QUALITY_MOD).modifyFlat(getModId(0), stabilityMod, "Low stability at production source");
			market.getStats().getDynamic().getMod(Stats.PRODUCTION_QUALITY_MOD).modifyFlat(getModId(0), stabilityMod, getNameForModifier() + " - low stability");
		}

		if (!isFunctional()) {
			supply.clear();
            unapply();
		}
    }

    @Override
    public void unapply() {
        super.unapply();

		market.getStats().getDynamic().getMod(Stats.PRODUCTION_QUALITY_MOD).unmodifyFlat(getModId(0));
    }

    @Override
    public boolean isAvailableToBuild() {
        return market.hasCondition(SPP_Conditions.BONEYARD);
    }

    @Override
    public boolean showWhenUnavailable() {
        return false;
    }

	public float getPatherInterest() {
		return 2f + super.getPatherInterest();
	}

}
