package campaign.econ.industries;

import campaign.SPP_ImmigrationScript.PopLimitModifier;
import campaign.econ.SPP_ResourceDepositsCondition;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.util.Pair;
import util.SPP_Misc;
import util.SPP_PortFunctions;

/**
 * Author: SafariJohn
 */
public class SPP_ColonyProgram extends SPP_BaseIndustry {

    @Override
    public void apply() {
        int flatSize = SPP_ResourceDepositsCondition.RESOURCE_STRUCTURE_BASE_SIZE;
        int scalingSize = SPP_PortFunctions.getPortCommoditySize(market.getSize());

        demand(Commodities.FOOD, scalingSize);
        demand(Commodities.CREW, scalingSize);

        // Pop growth scaling
		Pair<String, Integer> deficit = getMaxDeficit(Commodities.FOOD, Commodities.CREW);

        // Flat domestic goods production
        demand(Commodities.ORGANICS, flatSize);
        supply(Commodities.DOMESTIC_GOODS, flatSize);

        deficit = getMaxDeficit(Commodities.ORGANICS);
		applyDeficitToProduction(1, deficit, Commodities.DOMESTIC_GOODS);

        // Increase pop limit by 1
        PopLimitModifier mod = new PopLimitModifier(1, getGrowthRate(market.getSize()), getCurrentName());
        SPP_Misc.getPopulationLimitModifiers(market).put(getModId(), mod);

		if (!isFunctional()) {
			supply.clear();
			unapply();
		}
    }

    @Override
    public void unapply() {
        super.unapply();

        SPP_Misc.getPopulationLimitModifiers(market).remove(getModId());
    }

    private int getGrowthRate(int portSize) {
        int result = 10;
        switch (portSize) {
            case 10: result += 3; // 25
            case 9: result += 2; // 22
            case 8: result += 2; // 20
            case 7: result += 2; // 18
            case 6: result += 2; // 16
            case 5: result++; // 14
            case 4: result++; // 13
            case 3: result++; // 12
            case 2: result++; // 11
            case 1: // 10
        }

        return result;
    }

}
