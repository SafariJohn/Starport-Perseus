package campaign.econ.industries;

import campaign.SPP_ImmigrationScript.PopLimitModifier;
import campaign.ids.SPP_Conditions;
import campaign.ids.SPP_Industries;
import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketImmigrationModifier;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.population.PopulationComposition;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Pair;
import java.util.Map;
import util.SPP_Misc;

public class SPP_Cryorevival extends SPP_BaseIndustry implements MarketImmigrationModifier {

    public static final int POP_LIMIT_MOD = 2;
    public static final int POP_LIMIT_SCALE = 6;
    public static final int POP_LIMIT_GROWTH = 20;

	public void apply() {
		super.apply(true);

		int size = market.getSize();

		demand(Commodities.HEAVY_MACHINERY, size);

        // Pop limit modifiers
        Map<String, PopLimitModifier> mods = SPP_Misc.getPopulationLimitModifiers(market);

        float growth = getImmigrationBonus();

        if (Commodities.ALPHA_CORE.equals(getAICoreId())) {
            growth += getImmigrationBonus() * ALPHA_CORE_BONUS;
        }

        PopLimitModifier mod = new PopLimitModifier(POP_LIMIT_MOD, POP_LIMIT_SCALE, Math.round(growth), getCurrentName());
        mods.put(SPP_Industries.CRYOREVIVAL, mod);
	}


	@Override
	public void unapply() {
		super.unapply();

        Map<String, PopLimitModifier> mods = SPP_Misc.getPopulationLimitModifiers(market);
        mods.remove(SPP_Industries.CRYOREVIVAL);
	}

	protected boolean hasPostDemandSection(boolean hasDemand, IndustryTooltipMode mode) {
		return mode != IndustryTooltipMode.NORMAL || isFunctional();
	}

	@Override
	protected void addPostDemandSection(TooltipMakerAPI tooltip, boolean hasDemand, IndustryTooltipMode mode) {
		if (mode != IndustryTooltipMode.NORMAL || isFunctional()) {
			Color h = Misc.getHighlightColor();
			float opad = 10f;

			float growth = getImmigrationBonus();
			growth += getImmigrationBonus() * ALPHA_CORE_BONUS;

			tooltip.addPara("Population growth: %s", opad, h, "+" + Math.round(growth));
		}
	}


	@Override
	public boolean isAvailableToBuild() {
        boolean hasSanctum = market.hasIndustry(SPP_Industries.CRYOSANCTUM);
        boolean hasVault = market.hasCondition(SPP_Conditions.CRYOVAULT);
        boolean sleeperUsable = false;

		StarSystemAPI system = market.getStarSystem();
		if (system != null) {
            for (SectorEntityToken entity : system.getEntitiesWithTag(Tags.CRYOSLEEPER)) {
                if (entity.getMemoryWithoutUpdate().contains("$usable")) {
                    sleeperUsable = true;
                    break;
                }
            }
        }

        return sleeperUsable || (hasVault && !hasSanctum);
	}

	@Override
	public boolean showWhenUnavailable() {
        boolean hasVault = market.hasCondition(SPP_Conditions.CRYOVAULT);
        boolean sleeperFound = false;

		StarSystemAPI system = market.getStarSystem();
		if (system != null) {
            for (SectorEntityToken entity : system.getEntitiesWithTag(Tags.CRYOSLEEPER)) {
                if (!entity.isDiscoverable()) {
                    sleeperFound = true;
                }
            }
        }

        return sleeperFound || hasVault;
	}


	@Override
	public String getUnavailableReason() {
        boolean hasSanctum = market.hasIndustry(SPP_Industries.CRYOSANCTUM);
        boolean sleeperFound = false;
        boolean sleeperUsable = false;

		StarSystemAPI system = market.getStarSystem();
		if (system != null) {
            for (SectorEntityToken entity : system.getEntitiesWithTag(Tags.CRYOSLEEPER)) {
                if (!entity.isDiscoverable()) {
                    sleeperFound = true;

                    if (entity.getMemoryWithoutUpdate().contains("$usable")) {
                        sleeperUsable = true;
                        break;
                    }
                }
            }
        }

        if (hasSanctum && sleeperFound && !sleeperUsable) {
            return "Requires usable cryosleeper or cryovault";
        } else if (sleeperFound && !sleeperUsable) {
            return "Requires usable cryosleeper";
        } else {
            return "Requires usable cryovault";
        }
	}

	public void modifyIncoming(MarketAPI market, PopulationComposition incoming) {
		if (isFunctional()) {
			incoming.add(Factions.SLEEPER, getImmigrationBonus() * 2f);
		}
	}

	protected float getImmigrationBonus() {
		Pair<String, Integer> deficit = getMaxDeficit(Commodities.HEAVY_MACHINERY);
		float demand = getDemand(Commodities.HEAVY_MACHINERY).getQuantity().getModifiedValue();
		float def = deficit.two;
		if (def > demand) def = demand;

		float mult = 1f;
		if (def > 0 && demand > 0) {
			mult = (demand - def) / demand;
		}

		return getMaxImmigrationBonus() * mult;
	}

	protected float getMaxImmigrationBonus() {
		return POP_LIMIT_GROWTH;
	}


	public static float ALPHA_CORE_BONUS = 1f;
	@Override
	protected void applyAlphaCoreModifiers() {
	}

	@Override
	protected void applyNoAICoreModifiers() {
	}

	@Override
	protected void applyAlphaCoreSupplyAndDemandModifiers() {
		demandReduction.modifyFlat(getModId(0), DEMAND_REDUCTION, "Alpha core");
	}

	protected void addAlphaCoreDescription(TooltipMakerAPI tooltip, AICoreDescriptionMode mode) {
		float opad = 10f;
		Color highlight = Misc.getHighlightColor();

		String pre = "Alpha-level AI core currently assigned. ";
		if (mode == AICoreDescriptionMode.MANAGE_CORE_DIALOG_LIST || mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
			pre = "Alpha-level AI core. ";
		}
		float a = getImmigrationBonus() * ALPHA_CORE_BONUS;
		String str = "+" + Math.round(a);

		if (mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
			CommoditySpecAPI coreSpec = Global.getSettings().getCommoditySpec(aiCoreId);
			TooltipMakerAPI text = tooltip.beginImageWithText(coreSpec.getIconName(), 48);
			text.addPara(pre + "Reduces upkeep cost by %s. Reduces demand by %s unit. " +
					"%s population growth.", 0f, highlight,
					"" + (int)((1f - UPKEEP_MULT) * 100f) + "%", "" + DEMAND_REDUCTION,
					str);
			tooltip.addImageWithText(opad);
			return;
		}

		tooltip.addPara(pre + "Reduces upkeep cost by %s. Reduces demand by %s unit. " +
				"%s population growth.", opad, highlight,
				"" + (int)((1f - UPKEEP_MULT) * 100f) + "%", "" + DEMAND_REDUCTION,
				str);

	}
}



