package campaign.econ;

import campaign.ids.SPP_Tags;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.impl.campaign.econ.BaseMarketConditionPlugin;
import java.util.Map;
import util.SPP_Misc;

/**
 * Author: SafariJohn
 */
public class SPP_PortInOrbit extends BaseMarketConditionPlugin {

    @Override
    public Map<String, String> getTokenReplacements() {
		Map<String, String> tokens = super.getTokenReplacements();
        SectorEntityToken station = SPP_Misc.getOther(market.getPrimaryEntity());

        if (station != null) {
            tokens.put("$station", station.getName());
        }

        return tokens;
    }

}
