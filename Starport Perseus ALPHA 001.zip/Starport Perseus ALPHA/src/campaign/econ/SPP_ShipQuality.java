package campaign.econ;

import campaign.econ.industries.SPP_CommandBase;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.econ.CommodityOnMarketAPI;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.econ.impl.ShipQuality;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import util.SPP_PortFunctions;

/**
 * Author: SafariJohn
 */
public class SPP_ShipQuality extends ShipQuality {

	public static SPP_ShipQuality getInstance() {
		Object test = Global.getSector().getMemoryWithoutUpdate().get(KEY);
		if (test == null) {
			test = new SPP_ShipQuality();
			Global.getSector().getMemoryWithoutUpdate().set(KEY, test);
		}
		return (SPP_ShipQuality) test;
	}

	public void economyUpdated() {
		// use highest in-faction export, tie-break with quality
		// need to consider different econ groups separately CommodityMarketDataAPI
		// even a ship production of 1 unit in-faction is enough
		// to get in-faction rather than imported hulls and quality

		data.clear();

		for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
//			if (market.getName().equals("Stral")) {
//				System.out.println("wefwef");
//			}

			QualityData d = getQualityData(market);

			CommodityOnMarketAPI com = market.getCommodityData(Commodities.SHIPS);
			int prod = Math.min(com.getAvailable(), com.getMaxSupply());
//			if (com.getCommodityMarketData() == null) {
//				System.out.println("wfwefew");
//			}
//			if (market.isPlayerOwned()) {
//				System.out.println("wefwefwe");
//			}
//			if (market.getName().contains("Kapteyn")) {
//				System.out.println("wefwefwe");
//			}
			int inFactionShipping = com.getCommodityMarketData().getMaxShipping(market, true);
			prod = Math.min(prod, inFactionShipping);
			prod = Math.max(com.getMaxSupply(), prod);

            if (prod <= 0 && SPP_PortFunctions.factionHasCommandBase(market.getFaction())) prod = 1;

			if (prod >= d.prod && prod > 0) {
				float q = market.getStats().getDynamic().getMod(Stats.PRODUCTION_QUALITY_MOD).computeEffective(0f);
				if (q >= d.qMod) {
					d.prod = prod;
					d.qMod = q;
					d.market = market;
					d.quality = market.getStats().getDynamic().getMod(Stats.PRODUCTION_QUALITY_MOD);
				}
			}
		}
	}

}















