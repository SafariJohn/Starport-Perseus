package campaign.econ;

/**
 * Author: SafariJohn
 */
public class SPP_Primitives extends SPP_NativePopCondition {
    @Override
    public boolean isAllowedForPopulationSize(int size) {
        return size > 3;
    }
}
