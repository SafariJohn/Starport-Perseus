package campaign.econ;

import campaign.SPP_ImmigrationScript.PopLimitModifier;
import campaign.ids.SPP_Conditions;
import campaign.ids.SPP_Industries;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;
import com.fs.starfarer.api.combat.MutableStat;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import java.util.*;
import util.SPP_Misc;
import util.SPP_PortFunctions;


public class SPP_Population extends SPP_BaseHazardCondition {
    public static final Map<String, Integer> PLANET_POP_MODIFIERS = new LinkedHashMap<>();
    static {
        // Category 5 Habitable = +3
        // None

        // Category 4 Habitable = +2
        PLANET_POP_MODIFIERS.put("terran", 2);

        // Category 3 Habitable = +1
        PLANET_POP_MODIFIERS.put("terran-eccentric", 1);
        PLANET_POP_MODIFIERS.put("jungle", 1);
        PLANET_POP_MODIFIERS.put("water", 1);
        PLANET_POP_MODIFIERS.put("arid", 1);
        PLANET_POP_MODIFIERS.put("tundra", 1);
    }

	public void apply(String id) {
        Map<String, PopLimitModifier> mods = SPP_Misc.getPopulationLimitModifiers(market);

        int value = getPlanetPopLimitModifier();
        int scale = 10;
        PopLimitModifier mod;
        if (market.getPlanetEntity() != null) {
            try {
                mod = new PopLimitModifier(value, value * 5, market.getPlanetEntity().getTypeNameWithWorld());
                mods.put(Tags.PLANET, mod);
            } catch (NullPointerException ex) {}
        }

        if (market.hasCondition(Conditions.HABITABLE)) {
            mod = new PopLimitModifier("Habitable");
            mods.put(Conditions.HABITABLE, mod);
        }

        if (market.hasCondition(Conditions.MILD_CLIMATE)) {
            mod = new PopLimitModifier("Mild climate");
            mods.put(Conditions.MILD_CLIMATE, mod);
        }

        if (market.hasCondition(SPP_Conditions.CLOSE_MOON)
                    && !SPP_PortFunctions.getOrbitalConditions(market).contains(condition.getId())) {
            mod = new PopLimitModifier("Lunar habitats");
            mods.put(SPP_Conditions.CLOSE_MOON, mod);
        }

        if (market.hasCondition(SPP_Conditions.HIVE_CITIES)) {
            mod = new PopLimitModifier("Hive cities");
            mods.put(SPP_Conditions.HIVE_CITIES, mod);
        }

        String desc = "Ruins";
        int growth = 5;
        switch (SPP_PortFunctions.getRuins(market)) {
            case 0:
                value = 0;
                break;
            case 1:
                value = 1;
                scale = 3;
                desc = "Scattered ruins";
                break;
            case 2:
                value = 1;
                scale = 5;
                desc = "Widespread ruins";
                break;
            case 3:
                value = 2;
                scale = 6;
                desc = "Extensive ruins";
                break;
            case 4:
                value = 3;
                scale = 7;
                growth = 10;
                desc = "Vast ruins";
                break;
        }

        mod = new PopLimitModifier(value, scale, growth, desc);
        if (value != 0) mods.put(Conditions.RUINS_VAST, mod);

        if (market.isPlanetConditionMarketOnly()) {
            value = 2;
            mod = new PopLimitModifier(value, "Megaport");
            mods.put(SPP_Industries.SPACEPORT + "_demo", mod);

            for (MarketConditionAPI mc : market.getConditions()) {
                if (mc.getPlugin() instanceof SPP_ResourceDepositsCondition) {
                    mod = new PopLimitModifier("Resource harvesting");
                    mods.put(SPP_Industries.LOCAL_ECONOMY + "_demo", mod);
                    break;
                }
            }

            mod = new PopLimitModifier("Industry");
            mods.put(SPP_Industries.LIGHT_INDUSTRY + "_demo", mod);
        }
	}

    private int getPlanetPopLimitModifier() {
        PlanetAPI planet = market.getPlanetEntity();
        if (planet == null) return 0;

        try {
            Integer modifier = PLANET_POP_MODIFIERS.get(planet.getTypeId());
            if (modifier == null) return 0;

            return modifier;
        } catch (NullPointerException ex) {
            return 0;
        }
    }

	public void unapply(String id) {
        Map<String, PopLimitModifier> mods = SPP_Misc.getPopulationLimitModifiers(market);
        mods.remove(Tags.PLANET);
        mods.remove(Conditions.HABITABLE);
        mods.remove(Conditions.MILD_CLIMATE);
        mods.remove(SPP_Conditions.CLOSE_MOON);
        mods.remove(Conditions.RUINS_VAST);

        mods.remove(SPP_Industries.SPACEPORT + "_demo");
        mods.remove(SPP_Industries.LOCAL_ECONOMY + "_demo");
        mods.remove(SPP_Industries.LIGHT_INDUSTRY + "_demo");

	}

    @Override
    protected void createTooltipAfterDescription(TooltipMakerAPI tooltip, boolean expanded) {
        apply("");
        Map<String, PopLimitModifier> mods = SPP_Misc.getPopulationLimitModifiers(market);

        float pad = 3f;
        float opad = 10f;

        if (mods.isEmpty()) {
            tooltip.addPara("Population limit: 0", opad, Misc.getHighlightColor(), "" + 0);
            return;
        }

        int pop = SPP_PortFunctions.getPopulationSize(market);
        MutableStat popLimit = new MutableStat(0);
        // Sort by scale, highest first. Then add mods
        List<PopLimitModifier> modList = new ArrayList<>();
        List<String> keyList = new ArrayList<>(mods.keySet());
        OUTER:
        for (String key : mods.keySet()) {
            PopLimitModifier mod = mods.get(key);

            // Add first mod
            if (modList.isEmpty()) {
                modList.add(mod);
                continue;
            }

            // Compare
            for (PopLimitModifier lMod : modList) {
                if (compareByScaleFirst(mod, lMod) >= 0) {
                    modList.add(modList.indexOf(lMod), mod);
                    continue OUTER;
                }
            }

            // If lowest, add to end
            modList.add(mod);
        }

        for (PopLimitModifier mod : modList) {
            String desc = mod.desc;
//            if (mod.scale < 10) desc += " - scale " + mod.scale;

            int modValue = mod.mod; // Reduce scaled mods if they go over their limit.
            if (popLimit.getModifiedInt() + mod.mod > mod.scale) modValue = mod.mod - ((popLimit.getModifiedInt() + mod.mod) - (mod.scale + 1));

            if (popLimit.getModifiedInt() <= mod.scale) popLimit.modifyFlat(keyList.get(modList.indexOf(mod)), modValue, desc);
        }

        // If actual population is higher than the limit, bridge the gap with this modifier.
        if (pop > popLimit.getModifiedInt()) popLimit.modifyFlat("spp_population", pop - popLimit.getModifiedInt(), "Established Population");

        tooltip.addPara("Population limit: " + popLimit.getModifiedInt(), opad, Misc.getHighlightColor(), "" + popLimit.getModifiedInt());

        tooltip.addStatModGrid(400, 30, opad, pad, popLimit, new TooltipMakerAPI.StatModValueGetter() {
            public String getPercentValue(MutableStat.StatMod mod) { return null; }
            public String getMultValue(MutableStat.StatMod mod) { return null; }
            public Color getModColor(MutableStat.StatMod mod) { return null; }
            public String getFlatValue(MutableStat.StatMod mod) { return null; }
        });
    }

    private int compareByScaleFirst(PopLimitModifier mod1, PopLimitModifier mod2) {
        // If scales are equal, compare by modifier
        if (mod1.scale == mod2.scale) {
            return mod1.mod - mod2.mod;
        }

        return mod1.scale - mod2.scale;
    }

}
