package campaign;

import campaign.ids.SPP_Conditions;
import campaign.ids.SPP_Tags;
import com.fs.starfarer.api.EveryFrameScript;
import java.util.ArrayList;
import java.util.List;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.comm.CommMessageAPI.MessageClickAction;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketImmigrationModifier;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.impl.campaign.intel.MessageIntel;
import com.fs.starfarer.api.impl.campaign.population.PopulationComposition;
import com.fs.starfarer.api.util.Misc;
import org.apache.log4j.Logger;
import util.SPP_Misc;
import util.SPP_PortFunctions;


/**
 * Controls population growth for ports.
 *
 * -Only ports tagged with {@link campaign.ids.SPP_Tags.MEMKEY_POP_GROWTH}
 * can grow. By default, only the player's ports are tagged.-
 */
public class SPP_ImmigrationScript implements EveryFrameScript {
    public static final String MEM_KEY = "$SPP_popImmigrationPlugin";
    public static final String POP_LIMIT_MODS = "$SPP_popLimitMods";

    public static class PopLimitModifier {
        public static final int DEFAULT_GROWTH = 5;

        /** How much to increase the limit by. */
        public final int mod;
        /** At what pop size this mod is ignored. */
        public final int scale;
        /** How much to increase growth by. */
        public final int growth;
        /** Displayed on Population condition tooltip */
        public final String desc;

        /**
         * @param desc Displayed on Population condition tooltip
         */
        public PopLimitModifier(String desc) {
            mod = 1;
            scale = 10;
            growth = DEFAULT_GROWTH;
            this.desc = desc;
        }

        /**
         * @param mod How much to increase the limit by.
         * @param desc Displayed on Population condition tooltip
         */
        public PopLimitModifier(int mod, String desc) {
            this.mod = mod;
            scale = 10;
            this.growth = DEFAULT_GROWTH;
            this.desc = desc;
        }

        /**
         * @param mod How much to increase the limit by.
         * @param growth How much to increase growth by.
         * @param desc Displayed on Population condition tooltip
         */
        public PopLimitModifier(int mod, int growth, String desc) {
            this.mod = mod;
            scale = 10;
            this.growth = growth;
            this.desc = desc;
        }
        /**
         * @param mod How much to increase the limit by.
         * @param scale At what pop size this mod is ignored.
         * @param growth How much to increase growth by.
         * @param desc Displayed on Population condition tooltip
         */
        public PopLimitModifier(int mod, int scale, int growth, String desc) {
            if (scale < 1) scale = 1;
            this.mod = mod;
            this.scale = scale;
            this.growth = growth;
            this.desc = desc;
        }

    }

	protected MarketAPI market;
    protected PopulationComposition pop;
    protected PopulationComposition inc;

	public static float IMMIGRATION_PER_HAZARD = Global.getSettings().getFloat("immigrationPerHazard");

	public SPP_ImmigrationScript(MarketAPI market) {
		this.market = market;
        pop = new PopulationComposition();
        inc = new PopulationComposition();
	}

    private float interval = 0;
    private int MAX_INTERVAL = 1;
	public void advance(float amount) {
        if (isDone()) return;
        // Only tagged ports can grow in population
        // Changing this to allowed
//        if (!market.getMemoryWithoutUpdate().getBoolean(SPP_Tags.MEMKEY_POP_GROWTH)) return;

        float days = Global.getSector().getClock().convertToDays(amount);
        interval += days;

//        Logger.getLogger(SPP_ImmigrationScript.class).info("SPP " + market.getName() + " interval: " + interval);

        if (interval < MAX_INTERVAL) {
            return;
        } else {
            interval -= MAX_INTERVAL;
        }


		inc = computeIncoming();

		float f = MAX_INTERVAL / 30f; // incoming is per month

//            pop = inc;
//            inc = computeIncoming();

        for (String id : inc.getComp().keySet()) {
            pop.add(id, inc.get(id) * f);
        }

        float min = getWeightForPopulationSize(SPP_PortFunctions.getPopulationSize(market));
        float max = getWeightForPopulationSize(1 + SPP_PortFunctions.getPopulationSize(market));
        //if (market.getSize() >= 10) max = min;

        float newIncWeight = inc.getWeightValue();
        int limit = SPP_Misc.getPopulationLimit(market);
        int currPop = SPP_PortFunctions.getPopulationSize(market);

        // Add limit's value to incoming
        newIncWeight += SPP_Misc.getPopulationGrowth(market);

        // Add port size to incoming
        newIncWeight += market.getSize();

        // Always at least some incoming
        if (newIncWeight < 1) newIncWeight = 1f;
        // Unless at or above max pop
        if (currPop >= limit) newIncWeight = -10f;

        float newWeight = pop.getWeightValue() + newIncWeight * f;
        if (newWeight < min || currPop >= limit) newWeight = min;
        if (newWeight > max) {
            increasePopulationSize();
            newWeight = max;
        }
        pop.setWeight(newWeight);
        pop.normalize();

        // up to 5% of the non-faction population gets converted to faction, per month, more or less
        float conversionFraction = 0.05f * market.getStabilityValue() / 10f;
        conversionFraction *= f;
        if (conversionFraction > 0) {
            pop.add(market.getFactionId(), (pop.getWeightValue() - pop.get(market.getFactionId())) * conversionFraction);
        }


        // add some poor/pirate population at stability below 5
        float pirateFraction = 0.01f * Math.max(0, (5f - market.getStabilityValue()) / 5f);
        pirateFraction *= f;
        if (pirateFraction > 0) {
            pop.add(Factions.PIRATES, pop.getWeightValue() * pirateFraction);
            pop.add(Factions.POOR, pop.getWeightValue() * pirateFraction);
        }


        for (String fid : new ArrayList<String>(pop.getComp().keySet())) {
            if (Global.getSector().getFaction(fid) == null) {
                pop.getComp().remove(fid);
            }
        }

        pop.normalize();

//		market.getPopulation().setWeight(getWeightForMarketSize(market.getSize()));
//		market.getPopulation().normalize();
	}

    public PopulationComposition getPop() {
        return pop;
    }

    public PopulationComposition getInc() {
        return inc;
    }

    public void setMarket(MarketAPI market) {
        this.market = market;
    }

	public void increasePopulationSize() {
//		if (SPP_PortFunctions.getPopulationSize(market) >= 10 || !market.isPlayerOwned()) {
		if (SPP_PortFunctions.getPopulationSize(market) >= 10) {
			pop.setWeight(getWeightForPopulationSizeStatic(SPP_PortFunctions.getPopulationSize(market)));
			pop.normalize();
			return;
		}

		increasePopulationSize(market);

		if (market.isPlayerOwned() || Global.getSettings().isDevMode()) {
			MessageIntel intel = new MessageIntel("Population Growth - " + market.getName(), Misc.getBasePlayerColor());
			intel.addLine(BaseIntelPlugin.BULLET + "Population increased to %s",
					Misc.getTextColor(),
					new String[] {"" + SPP_PortFunctions.getPopulationSize(market)},
					Misc.getHighlightColor());
            if (Global.getSettings().isDevMode()) intel.addLine("--DEBUG--");
			intel.setIcon(Global.getSector().getPlayerFaction().getCrest());
			intel.setSound(BaseIntelPlugin.getSoundMajorPosting());
            intel.setImportant(true);
			Global.getSector().getCampaignUI().addMessage(intel, MessageClickAction.COLONY_INFO, market);
		}
	}

	public static void increasePopulationSize(MarketAPI market) {
        int population = SPP_PortFunctions.getPopulationSize(market);
		if (population >= 10) return;


        PlanetAPI planet = null;
        PlanetAPI moon = null;
        // Get planet and moon
        if (market.hasCondition(SPP_Conditions.CLOSE_MOON)) {
            moon = SPP_Misc.getMoon(market.getPrimaryEntity());
        } else if (market.hasCondition(SPP_Conditions.LUNAR_ORBIT)
                        || market.hasCondition(SPP_Conditions.TIGHT_ORBIT)) {
            planet = SPP_Misc.getParent(market.getPrimaryEntity());
        } else if (market.hasCondition(SPP_Conditions.ORBITAL_STATION)) {
            planet = SPP_Misc.getParent(market.getPrimaryEntity());
        }

        String condId = SPP_PortFunctions.getPopulationConditionId(population);

        market.removeCondition(condId);
        if (planet != null && planet.getMarket() != market) planet.getMarket().removeCondition(condId);
        if (moon != null && moon.getMarket() != market) moon.getMarket().removeCondition(condId);

        String token;
        String pToken;
        String mToken;
        condId = SPP_PortFunctions.getPopulationConditionId(population + 1);

		token = market.addCondition(condId);
		market.getSpecificCondition(token).setSurveyed(true);

        if (planet != null && planet.getMarket() != market) {
            pToken = planet.getMarket().addCondition(condId);
            planet.getMarket().getSpecificCondition(pToken).setSurveyed(true);
        }

        if (moon != null && moon.getMarket() != market) {
            mToken = moon.getMarket().addCondition(condId);
            moon.getMarket().getSpecificCondition(mToken).setSurveyed(true);
        }

		market.reapplyConditions();
		market.reapplyIndustries();
	}

	public static void reducePopulationSize(MarketAPI market, PopulationComposition pop) {
        int population = SPP_PortFunctions.getPopulationSize(market);
		if (population <= 0) return;


        PlanetAPI planet = null;
        PlanetAPI moon = null;
        // Get planet and moon
        if (market.hasCondition(SPP_Conditions.CLOSE_MOON)) {
            moon = SPP_Misc.getMoon(market.getPrimaryEntity());
        } else if (market.hasCondition(SPP_Conditions.LUNAR_ORBIT)
                        || market.hasCondition(SPP_Conditions.TIGHT_ORBIT)) {
            planet = SPP_Misc.getParent(market.getPrimaryEntity());
        } else if (market.hasCondition(SPP_Conditions.ORBITAL_STATION)) {
            planet = SPP_Misc.getParent(market.getPrimaryEntity());
        }

        String condId = SPP_PortFunctions.getPopulationConditionId(population);

        boolean orbital = false;
        boolean pOrbital = false;
        boolean mOrbital = false;

        market.removeCondition(condId);
        orbital = SPP_PortFunctions.getOrbitalConditions(market).remove(condId);

        if (planet != null && planet.getMarket() != market) {
            planet.getMarket().removeCondition(condId);
            pOrbital = SPP_PortFunctions.getOrbitalConditions(planet).remove(condId);
        }
        if (moon != null && moon.getMarket() != market) {
            moon.getMarket().removeCondition(condId);
            mOrbital = SPP_PortFunctions.getOrbitalConditions(moon).remove(condId);
        }

        String token = "";
        String pToken = "";
        String mToken = "";
        condId = SPP_PortFunctions.getPopulationConditionId(population - 1);

		token = market.addCondition(condId);
        if (orbital) SPP_PortFunctions.getOrbitalConditions(market).add(condId);

        if (planet != null && planet.getMarket() != market) {
            pToken = planet.getMarket().addCondition(condId);
            if (pOrbital) SPP_PortFunctions.getOrbitalConditions(planet).add(condId);
        }
        if (moon != null && moon.getMarket() != market) {
            mToken = moon.getMarket().addCondition(condId);
            if (mOrbital) SPP_PortFunctions.getOrbitalConditions(moon).add(condId);
        }

        boolean surveyed = market.getSurveyLevel() == MarketAPI.SurveyLevel.FULL;

		market.getSpecificCondition(token).setSurveyed(surveyed);
        if (planet != null && planet.getMarket() != market) planet.getMarket().getSpecificCondition(pToken).setSurveyed(surveyed);
        if (moon != null && moon.getMarket() != market) moon.getMarket().getSpecificCondition(mToken).setSurveyed(surveyed);

        if (pop != null) {
            pop.setWeight(getWeightForPopulationSizeStatic(SPP_PortFunctions.getPopulationSize(market)));
            pop.normalize();
        }

		market.reapplyConditions();
		market.reapplyIndustries();
	}


	public static final float ZERO_STABILITY_PENALTY = -5;
	public static final float MAX_DIST_PENALTY = -5;

	public PopulationComposition computeIncoming() {
		PopulationComposition newInc = new PopulationComposition();

		float stability = market.getStabilityValue();

		if (stability > 0) {
			inc.getWeight().modifyFlat("inc_st", stability, "Stability");
		} else {
			inc.getWeight().modifyFlat("inc_st", ZERO_STABILITY_PENALTY, "Stability");
		}
//		if (stability < 10) {
//			newInc.getWeight().modifyFlat("inc_st", stability - 10, "Instability");
//		}

//		int numInd = Misc.getNumIndustries(market);
//		if (numInd <= 0) {
//			float weight = getWeightForMarketSize(market.getSize());
//			float penalty = -Math.round(weight * 0.01f);
//			inc.getWeight().modifyFlat("inc_noInd", penalty, "No industries");
//		}


		//inc.getWeight().modifyFlat("inc_size", -market.getSize(), "Colony size");

		float a = Math.round(market.getAccessibilityMod().computeEffective(0f) * 100f) / 100f;
		int accessibilityMod = (int) (a / Misc.PER_UNIT_SHIPPING);
		newInc.getWeight().modifyFlat("inc_access", accessibilityMod, "Accessibility");


//		float hazMod = Math.round((market.getHazardValue() - 1f) / IMMIGRATION_PER_HAZARD);
//		if (hazMod != 0) {
//			newInc.getWeight().modifyFlat("inc_hazard", -hazMod, "Hazard rating");
//		}

//		float dMult = getDistFromCoreMult(market);
//		float dPenalty = Math.round(dMult * MAX_DIST_PENALTY);
//		if (dPenalty > 0) {
//			inc.getWeight().modifyFlat("inc_dist", -dPenalty, "Distance from core worlds");
//		}

		MarketAPI biggestInSystem = null;
		List<MarketAPI> inReach = Global.getSector().getEconomy().getMarketsWithSameGroup(market);
		//Global.getSettings().profilerEnd();
		for (MarketAPI curr : inReach) {
			if (curr == market) continue;

			if (curr.getFaction().isHostileTo(market.getFaction())) continue;

			if (Misc.getDistanceLY(curr.getLocationInHyperspace(), market.getLocationInHyperspace()) <= 0) {
				if (biggestInSystem == null || SPP_PortFunctions.getPopulationSize(curr) > SPP_PortFunctions.getPopulationSize(biggestInSystem)) {
					biggestInSystem = curr;
				}
			}
		}

		if (biggestInSystem != null) {
			float sDiff = SPP_PortFunctions.getPopulationSize(biggestInSystem) - SPP_PortFunctions.getPopulationSize(market);
			sDiff *= 2;
			if (sDiff > 0) {
				newInc.getWeight().modifyFlat("inc_insys", sDiff, "Larger non-hostile market in same system");
			} else if (sDiff < 0) {
				//inc.getWeight().modifyFlat("inc_insys", sDiff, "Smaller non-hostile market in same system");
			}
		}

		// so that the "baseline" incoming composition is based on the number of industries
		// thus each industry can use a per-industry modifier without having outsize influence
		// for example Farming can bring in X more Luddic Church immigration, and the impact
		// this has will be diminished if there are more industries beyond Farming
		float numIndustries = market.getIndustries().size();
		newInc.add(Factions.PIRATES, 1f * numIndustries);
		newInc.add(Factions.POOR, 1f * numIndustries);

		String bulkFaction = Factions.INDEPENDENT;
		if (market.getFaction().isHostileTo(bulkFaction)) {
			bulkFaction = market.getFactionId();
		}
		newInc.add(bulkFaction, 10f * numIndustries);


		for (MarketImmigrationModifier mod : market.getAllImmigrationModifiers()) {
			mod.modifyIncoming(market, newInc);
		}

		for (String fid : new ArrayList<String>(newInc.getComp().keySet())) {
			if (Global.getSector().getFaction(fid) == null) {
				newInc.getComp().remove(fid);
			}
		}

		newInc.normalizeToPositive();

		return newInc;
	}

	public float getPopulationPointsForFraction(float fraction) {
		float min = getWeightForPopulationSize(SPP_PortFunctions.getPopulationSize(market));
		float max = getWeightForPopulationSize(1 + SPP_PortFunctions.getPopulationSize(market));

		return (max - min) * fraction;
	}

	public float getFractionForPopulationPoints(float points) {
		float min = getWeightForPopulationSize(SPP_PortFunctions.getPopulationSize(market));
		float max = getWeightForPopulationSize(1 + SPP_PortFunctions.getPopulationSize(market));

		return points / (max - min);
	}


	public static float getWeightForPopulationSizeStatic(float size) {
		return (float) (200f * Math.pow(2, size - 3));
//		return (float) (200f * Math.pow(2, size));
	}
	public float getWeightForPopulationSize(float size) {
		return getWeightForPopulationSizeStatic(size);
//		if (size <= 1) return 100;
//		if (size == 2) return 200;
//		if (size == 3) return 400;
//		if (size == 4) return 800;
//		if (size == 5) return 1600;
//		if (size == 6) return 3200;
//		if (size == 7) return 6400;
//		if (size == 8) return 12800;
//		if (size == 9) return 25600;
//		if (size == 10) return 51200;
//		if (size == 11) return 102400;
//		return 100000;
	}

    private boolean done = false;
    @Override
    public boolean isDone() {
        return done || market == null || market.isPlanetConditionMarketOnly();
    }

    public void setDone(boolean isDone) {
        done = isDone;
    }

    @Override
    public boolean runWhilePaused() {
        return false;
    }
}






