package hullmods;

import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.HullMods;
import com.fs.starfarer.api.impl.campaign.ids.Stats;

public class SPP_GroundSupport extends SPP_BaseLogisticsHullMod {

	public static final float GROUND_BONUS = 100;
	public static final float GROUND_BONUS_CRUISER = 200;
	public static final float GROUND_BONUS_CAPITAL = 500;

	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		stats.getDynamic().getMod(Stats.FLEET_GROUND_SUPPORT).modifyFlat(id, getGroundBonus(hullSize));
	}

    private float getGroundBonus(HullSize hullSize) {
        switch (hullSize) {
            case CAPITAL_SHIP: return GROUND_BONUS_CAPITAL;
            case CRUISER: return GROUND_BONUS_CRUISER;
            case DESTROYER: return GROUND_BONUS;
        }

        return GROUND_BONUS;
    }

	public String getDescriptionParam(int index, HullSize hullSize) {
		if (index == 0) return "" + (int) getGroundBonus(hullSize);
		return null;
	}
	@Override
	public boolean isApplicableToShip(ShipAPI ship) {
        boolean bigEnough = ship.getHullSize() == HullSize.CRUISER || ship.getHullSize() == HullSize.CAPITAL_SHIP;
        boolean militarized = (ship.getVariant().hasHullMod(HullMods.CIVGRADE) && ship.getVariant().hasHullMod(HullMods.MILITARIZED_SUBSYSTEMS))
                    || !ship.getVariant().hasHullMod(HullMods.CIVGRADE);

		return bigEnough && militarized;
	}

	@Override
	public String getUnapplicableReason(ShipAPI ship) {
        boolean bigEnough = ship.getHullSize() == HullSize.CRUISER || ship.getHullSize() == HullSize.CAPITAL_SHIP;
        boolean militarized = (ship.getVariant().hasHullMod(HullMods.CIVGRADE) && ship.getVariant().hasHullMod(HullMods.MILITARIZED_SUBSYSTEMS))
                    || !ship.getVariant().hasHullMod(HullMods.CIVGRADE);

        if (!bigEnough) return "Can only be installed on cruisers and capital ships";
        if (!militarized) return "Can not be installed on a civilian-grade hull";

		return super.getUnapplicableReason(ship);
	}
}




